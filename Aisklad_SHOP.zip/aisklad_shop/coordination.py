"""Cross-process purchase serialization. Never a lifetime lock for an account."""
from pathlib import Path
import os
import threading
import time

_guards={}
_guards_lock=threading.Lock()


class PurchaseBusy(TimeoutError):pass


class PurchaseLock:
    def __init__(self,path,timeout=90):
        self.path=Path(path).resolve();self.timeout=timeout;self.file=None
        with _guards_lock:self.guard=_guards.setdefault(str(self.path),threading.RLock())

    def __enter__(self):
        if not self.guard.acquire(timeout=self.timeout):raise PurchaseBusy('Обработка другого заказа; повторим позже.')
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            self.file=self.path.open('a+b')
            if self.file.seek(0,2)==0:self.file.write(b'0');self.file.flush()
            self.file.seek(0);deadline=time.monotonic()+self.timeout
            while True:
                try:
                    if os.name=='nt':
                        import msvcrt
                        msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
                    else:
                        import fcntl
                        fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    return self
                except OSError:
                    if time.monotonic()>=deadline:raise PurchaseBusy('Обработка другого заказа; повторим позже.')
                    time.sleep(.05)
        except BaseException:
            if self.file is not None:self.file.close();self.file=None
            self.guard.release()
            raise

    def __exit__(self,*args):
        try:
            if self.file is not None:
                self.file.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(self.file.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(self.file,fcntl.LOCK_UN)
                self.file.close();self.file=None
        finally:self.guard.release()
