"""Автономные тесты: все сетевые соединения запрещены на время проверки."""
from pathlib import Path
import io
import json
import logging
import os
import sys
import unittest
from unittest.mock import patch


def main():
    root = Path(__file__).resolve().parent
    os.chdir(root)
    logging.disable(logging.CRITICAL)
    transcript = io.StringIO()
    # Сохраняем сам класс socket: PySocks наследуется от него при импорте.
    with patch("socket.socket.connect", side_effect=AssertionError("Тестам запрещена сеть")), \
         patch("socket.socket.connect_ex", side_effect=AssertionError("Тестам запрещена сеть")), \
         patch("socket.create_connection", side_effect=AssertionError("Тестам запрещена сеть")), \
         patch("socket.getaddrinfo", side_effect=AssertionError("Тестам запрещена сеть")):
        suite = unittest.TestSuite()
        suite.addTests(unittest.TestLoader().discover(str(root / "tests")))
        suite.addTests(unittest.TestLoader().discover(str(root / "shop_tests")))
        result = unittest.TextTestRunner(stream=transcript, verbosity=2).run(suite)
    report = {
        "version": "0.14.0-aisklad-shop",
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "network_blocked": True,
        "real_purchases": 0,
        "success": result.wasSuccessful() and not result.skipped,
    }
    (root / "TEST_REPORT.txt").write_text(transcript.getvalue(), encoding="utf-8")
    (root / "TEST_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Tests: {report['tests_run']}; failures: {report['failures']}; errors: {report['errors']}; skipped: {report['skipped']}")
    print("Network blocked. No real purchases.")
    print("PASS" if report["success"] else "FAIL — see TEST_REPORT.txt")
    return 0 if report["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
