# noplug — persistent action journal and hourly owner reports; no purchases.
import time
from collections import Counter
from datetime import datetime,timezone,timedelta
from html import escape
import steamru_stars_notifications as notifications


def prepare(bot):
    with bot.STORE.conn() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
            offer TEXT NOT NULL, message TEXT NOT NULL, created_at REAL NOT NULL)''')


def record(bot,c,kind,message,offer='',notify_now=True):
    if bot.STORE is None:return
    try:
        return _record(bot,c,kind,message,offer,notify_now)
    except Exception as exc:
        logger=getattr(bot,'LOG',None)
        if logger:logger.warning('Журнал действий недоступен: %s',type(exc).__name__)


def _record(bot,c,kind,message,offer='',notify_now=True):
    prepare(bot)
    now=time.time()
    with bot.STORE.conn() as db:
        cursor=db.execute('INSERT INTO activity_log(kind,offer,message,created_at) VALUES(?,?,?,?)',
                          (kind,str(offer),str(message),now))
        event_id=cursor.lastrowid
    if notify_now and bot.CFG.get('activity_report',{}).get('enabled') and bot.CFG['activity_report'].get('immediate',False):
        notifications.notify(bot,c,'🛠 '+str(message),dedup_key='activity:'+str(event_id)+':'+str(now))
    return event_id


def chunks(lines,limit=3100):
    text=''
    for line in lines:
        line=str(line)
        # The Telegram sender escapes HTML; split by escaped length, not bytes.
        if len(escape(line))>limit:
            parts=[];piece=''
            for ch in line:
                if len(escape(piece+ch))>limit:parts.append(piece);piece=''
                piece+=ch
            if piece:parts.append(piece)
        else:parts=[line]
        for part in parts:
            if text and len(escape(text+'\n'+part))>limit:
                yield text;text=''
            text+=('\n' if text else '')+part
    if text:yield text


def hourly(bot,c,now=None,force=False):
    if bot.STORE is None or not bot.CFG.get('activity_report',{}).get('enabled'):return
    now=time.time() if now is None else now
    interval=bot.CFG['activity_report'].get('interval_seconds',3600)
    if not force and now-float(bot.STORE.get_meta('activity_report_at','0'))<interval:return
    prepare(bot);cursor=int(bot.STORE.get_meta('activity_report_cursor','0'))
    with bot.STORE.conn() as db:
        rows=db.execute('SELECT * FROM activity_log WHERE id>? ORDER BY id LIMIT 1000',(cursor,)).fetchall()
    stamp=datetime.fromtimestamp(now,timezone(timedelta(hours=3))).strftime('%d.%m · %H:%M МСК')
    lines=['📊 ОТЧЁТ ЗА ЧАС · '+stamp,'━━━━━━━━━━━━━━',
           'Режим: '+('⏸ пауза' if bot.paused() else '▶️ обработка заказов включена'),
           'Последний проверенный баланс STEAM.RU: $'+bot.STORE.get_meta('last_checked_balance','ещё не получен'),
           'Управляемых лотов: '+str(len(bot.CFG.get('managed_lots',{})))]
    counts={}
    for row in rows:counts[row['kind']]=counts.get(row['kind'],0)+1
    labels={'price':'💰 Изменения цены','rotation':'🔄 Смена игр','catalog':'🆕 Новые лоты',
            'availability':'📦 Наличие и доступность','balance':'💵 Изменения баланса','control':'🕹 Твои команды',
            'delivery':'✅ Выдача','appearance':'🎨 Оформление'}
    for kind,count in sorted(counts.items()):lines.append(labels.get(kind,kind)+': '+str(count))
    if rows:
        repeats=Counter((r['kind'],r['offer'],r['message']) for r in rows)
        latest={}
        for row in rows:latest[(row['kind'],row['offer'],row['message'])]=row
        unique=sorted(latest.values(),key=lambda row:row['id'])
        lines+=['','📝 Действия за период:']
        for row in unique[-40:]:
            at=datetime.fromtimestamp(row['created_at'],timezone(timedelta(hours=3))).strftime('%H:%M')
            count=repeats[(row['kind'],row['offer'],row['message'])]
            lines.append(at+' · '+row['message']+(f' · повторов: {count}' if count>1 else ''))
        if len(unique)>40:lines.append(f'Ещё {len(unique)-40} действий сохранены в журнале.')
    else:lines+=['','Изменений цен, наличия и ротации за период не было.']
    for key,label in [('catalog_error','⚠️ Каталог'),('rotation_summary','🔄 Ротация')]:
        value=bot.STORE.get_meta(key,'')
        if value:lines.append(label+': '+value)
    lines+=['','🛍 /sr_products · 📊 /sr_report · ⏸ /sr_pause']
    for i,part in enumerate(chunks(lines)):
        notifications.notify(bot,c,part,dedup_key='hour:'+str(now)+':'+str(i))
    bot.STORE.set_meta('activity_report_cursor',str(rows[-1]['id'] if rows else cursor))
    bot.STORE.set_meta('activity_report_at',str(now))


def register(bot,c,own):
    def report(message):
        if not own(message) or bot.STORE is None:return
        hourly(bot,c,force=True)
        c.telegram.bot.reply_to(message,'📊 Отчёт поставлен в очередь уведомлений и придёт в течение 10 секунд.')
    c.telegram.msg_handler(report,commands=['sr_report'])
    c.add_telegram_commands(bot.UUID,[('sr_report','Подробный отчёт о действиях бота',True)])
