# noplug — owner-only persistent product controls; no supplier purchases.
import hashlib,threading,time
from html import escape
from datetime import datetime,timezone,timedelta
from steamru_stars_engine import D,currency_code,strict_count
import steamru_stars_catalog as catalog
import steamru_stars_activity as activity

TASK_LOCK=threading.Lock()
PENDING_PRICE={}
PENDING_TEXT={}
HELP=('🛍 /sr_products — товары и кнопки\n'
 '/sr_product ID — карточка товара\n/sr_price ID ЦЕНА ЧАСЫ — ручная цена (по умолчанию 5 ч.)\n'
 '/sr_auto ID — вернуть автоцену\n/sr_off ID — снять с продажи\n/sr_on ID — разрешить продажу\n'
 '/sr_text ID ОПИСАНИЕ — заменить русский текст\n/sr_text_auto ID — вернуть описание бота\n'
 '/sr_pin ID — закрепить игру\n/sr_unpin ID — вернуть в ротацию\n'
 '/sr_rotation on|off — ротация игр\n/sr_sync — обновить каталог и цены\n'
 '/sr_limits USD_НА_ЗАКАЗ USD_В_СУТКИ — бюджеты\n'
 'Цены в рублях за единицу лота; для Steam RUB это цена за 1 ₽. Уже оплаченные заказы сохраняются.')

def policy(bot,offer):
    offer=str(offer);value=bot.CFG.get('lot_controls',{}).get(offer,{})
    if value and value.get('rule_name')!=bot.CFG['managed_lots'].get(offer):return {}
    return value

def disabled(bot,offer):return bool(policy(bot,offer).get('owner_disabled'))

def manual_price(bot,offer):
    value=policy(bot,offer).get('manual_price')
    if value and time.time()<float(value['expires_at']):return D(value['value'])
    return None

def apply_text(bot,offer,fields):
    value=policy(bot,offer)
    if value.get('description_ru'):fields.description_ru=value['description_ru']
    return fields

def expire(bot):
    with bot.PROCESS_LOCK:
        changed=False
        for value in bot.CFG.get('lot_controls',{}).values():
            manual=value.get('manual_price')
            if manual and time.time()>=float(manual['expires_at']):
                value.pop('manual_price');changed=True
        if changed:
            bot.persist_settings();bot.STORE.set_meta('last_reprice','0');bot.STORE.set_meta('next_availability_check','0')

def resolve(bot,offer):
    offer=str(strict_count(offer));name=bot.CFG['managed_lots'].get(offer)
    if not name:raise ValueError('Такого управляемого товара нет')
    return offer,name,bot.CFG['lot_rules'][name]

def save_policy(bot,offer,name,value):
    value['rule_name']=name;bot.CFG.setdefault('lot_controls',{})[offer]=value
    bot.persist_settings();bot.STORE.set_meta('next_availability_check','0');bot.MAINTENANCE_WAKE.set()

def check_fields(bot,fields,offer,rule):
    if int(fields.lot_id)!=int(offer) or fields.subcategory.id!=rule['subcategory_id'] or currency_code(fields.currency)!='RUB' or fields.auto_delivery:
        raise ValueError('Изменились категория, валюта или способ выдачи')
    if any(not catalog.field_matches(bot.editor_field_value(fields,k),k,rule) for k in rule['match_fields']):raise ValueError('Изменилась привязка товара')

def prepare_prices(bot,c,token):
    if not bot.CFG['auto_pricing']['enabled']:return
    for offer,name in list(bot.CFG['managed_lots'].items()):
        rule=bot.CFG['lot_rules'][name]
        if rule.get('kind','stars')=='stars' or not rule.get('sell_enabled',True) or disabled(bot,offer):continue
        if int(offer) in bot.rotation.busy_offers(bot):continue
        unit=rule.get('last_price_usd')
        if not unit:continue
        manual=manual_price(bot,offer)
        price=manual if manual is not None else bot.price_band(rule,unit)[1]
        bot.write_seller_price(c,offer,rule,price,token)

def change(bot,c,action,offer,args=(),expected_name=None):
    with bot.PROCESS_LOCK,bot.LOT_WRITE_LOCK:
        offer,name,rule=resolve(bot,offer)
        if expected_name is not None and name!=expected_name:raise ValueError('Товар в этом месте изменился. Открой новую карточку.')
        if int(offer) in bot.rotation.busy_offers(bot):raise ValueError('Лот сейчас заменяется; дождись окончания ротации')
        value=dict(policy(bot,offer));fields=c.account.get_lot_fields(int(offer),node_id=rule['subcategory_id'])
        check_fields(bot,fields,offer,rule)
        if action=='price':
            price=D(str(args[0]).replace(',','.'));hours=D(args[1] if len(args)>1 else '5')
            if not 0<price<=1000000 or price!=price.quantize(D('.01')) or not D('.05')<=hours<=720:
                raise ValueError('Цена: положительное число с копейками; срок: 0.05–720 часов')
            value['manual_price']={'value':str(price),'expires_at':time.time()+float(hours*3600)}
            save_policy(bot,offer,name,value);fields.price=float(price)
            until=datetime.fromtimestamp(value['manual_price']['expires_at'],timezone(timedelta(hours=3))).strftime('%d.%m %H:%M МСК')
            result=f'💰 Ручная цена {price} ₽ до {until}. Автоцена дождётся окончания срока.'
        elif action=='auto':
            value.pop('manual_price',None);save_policy(bot,offer,name,value)
            if rule.get('last_price_usd'):fields.price=float(bot.price_band(rule,rule['last_price_usd'])[1])
            bot.STORE.set_meta('last_reprice','0');result='🤖 Автоцена возвращена.'
        elif action=='off':
            value['owner_disabled']=True;save_policy(bot,offer,name,value);fields.active=False;result='⏸ Товар снят с продажи. Оплаченные заказы сохраняются.'
        elif action=='on':
            value['owner_disabled']=False;save_policy(bot,offer,name,value)
            # Activation is performed by the normal stock, balance and budget checks.
            result='▶️ Продажа разрешена. Бот включит лот после проверки наличия и баланса'+(' и /sr_resume.' if bot.paused() else '.')
        elif action in ('pin','unpin'):
            value['pinned']=action=='pin';save_policy(bot,offer,name,value)
            return '📌 Игра закреплена.' if action=='pin' else '🔄 Игра возвращена в ротацию.'
        elif action=='text':
            description=' '.join(args).strip()
            if not 1<=len(description)<=4000:raise ValueError('Описание должно содержать 1–4000 символов')
            value['description_ru']=description;save_policy(bot,offer,name,value);fields.description_ru=description
            result='📝 Русское описание сохранено. Регион и товар в настройках сохраняются.'
        elif action=='text_auto':
            value.pop('description_ru',None);save_policy(bot,offer,name,value);catalog.update_copy(fields,rule)
            result='📝 Описание бота возвращено.'
        else:raise ValueError('Неизвестное действие')
        if bot.paused():fields.active=False
        c.account.save_lot(fields.renew_fields())
        checked=c.account.get_lot_fields(int(offer),node_id=rule['subcategory_id']);check_fields(bot,checked,offer,rule)
        if action in ('price','auto') and D(checked.price)!=D(fields.price):raise ValueError('Цена не сохранилась')
        if action=='off' and checked.active:raise ValueError('Лот не выключился')
        if action in ('text','text_auto') and checked.description_ru!=fields.description_ru:raise ValueError('Описание не сохранилось')
        rule['last_seller_price']=str(D(checked.price));bot.persist_settings()
        activity.record(bot,c,'control',catalog.display_title(rule)+' · '+result,offer)
        return result

def register(bot,c,own):
    tg=c.telegram;telegram=tg.bot
    def reply(m,text,**kwargs):telegram.reply_to(m,text,**kwargs)
    def job(m,call,notice=True):
        if not TASK_LOCK.acquire(blocking=False):reply(m,'Изменение уже выполняется. Дождись результата.');return
        try:
            if notice:reply(m,'Выполняю изменение; FunPay может потребоваться немного времени.')
        except Exception:TASK_LOCK.release();raise
        def execute():
            try:
                result=call()
                if result is not None:reply(m,escape(result))
            except ValueError as exc:reply(m,escape(str(exc)[:220]))
            except Exception as exc:reply(m,'Изменение не подтверждено: '+type(exc).__name__+'. Проверь /sr_product ID; не отправляй секреты.')
            finally:TASK_LOCK.release()
        try:threading.Thread(target=execute,daemon=True,name='STEAMRUProductControl').start()
        except Exception:TASK_LOCK.release();raise
    def markup(rows):
        from telebot.types import InlineKeyboardMarkup,InlineKeyboardButton
        keyboard=InlineKeyboardMarkup()
        for row in rows:keyboard.row(*(InlineKeyboardButton(label,callback_data=data) for label,data in row))
        return keyboard
    def products(m,page=0):
        items=list(bot.CFG['managed_lots'].items());page=max(0,min(page,(len(items)-1)//8));rows=[];texts=[]
        for offer,name in items[page*8:(page+1)*8]:
            rule=bot.CFG['lot_rules'][name];label=catalog.display_title(rule)
            flag='⏸' if disabled(bot,offer) else '💰' if manual_price(bot,offer) is not None else '🤖'
            texts.append(f'{flag} {offer}: {escape(label)}');rows.append([(label[:42],'srp:card:'+offer)])
        navigation=[]
        if page:navigation.append(('←','srp:page:'+str(page-1)))
        if (page+1)*8<len(items):navigation.append(('→','srp:page:'+str(page+1)))
        if navigation:rows.append(navigation)
        reply(m,'🛍 Товары ('+str(page+1)+')\n'+'\n'.join(texts)+'\n\nНажми на товар для управления.',reply_markup=markup(rows))
    def card(m,offer):
        def read():
            oid,name,rule=resolve(bot,offer);fields=c.account.get_lot_fields(int(oid),node_id=rule['subcategory_id']);check_fields(bot,fields,oid,rule)
            label=catalog.display_title(rule)
            price=manual_price(bot,oid);value=policy(bot,oid)
            text=f"{label}\nЛот: {oid}\nЦена: {fields.price} ₽\nНа FunPay: {'включён' if fields.active else 'выключен'}\nУправление: {'ручная цена' if price is not None else 'автоцена'}\nРотация: {'закреплён' if value.get('pinned') else 'обычная'}\nЦена поставщика: ${rule.get('last_price_usd','?')}"
            if not rule.get('sell_enabled',True):text+='\nОжидает проверки доступности каталога.'
            if rule.get('last_price_usd') and D(rule['last_price_usd'])*rule['stars_per_unit']>D(bot.CFG['max_single_order_usd']):text+='\nЦена поставщика превышает лимит одного заказа.'
            tag=hashlib.sha256(name.encode()).hexdigest()[:6]
            def button(label,action):return label,'srp:'+action+':'+oid+':'+tag
            rows=[[button('💰 Цена','price'),button('🤖 Автоцена','auto')],
                  [button('▶️ Включить','on'),button('⏸ Выключить','off')],
                  [button('📝 Описание','text'),button('🤖 Текст бота','text_auto')]]
            if rule.get('kind')=='game_key':rows.append([button('📌 Закрепить','pin'),button('🔄 Ротация','unpin')])
            rows.append([('🛍 Все товары','srp:page:0')])
            reply(m,escape(text),reply_markup=markup(rows))
            return None
        job(m,read,notice=False)
    def command(m):
        if not own(m) or bot.STORE is None:return
        PENDING_PRICE.pop(m.from_user.id,None)
        PENDING_TEXT.pop(m.from_user.id,None)
        parts=(m.text or '').split();name=parts[0].split('@')[0][4:]
        if name=='help':reply(m,HELP);return
        if name=='products':
            try:products(m,int(parts[1])-1 if len(parts)>1 else 0)
            except (ValueError,IndexError):reply(m,'Формат: /sr_products 1')
            return
        if name=='sync':
            bot.STORE.set_meta('next_catalog_sync','0');bot.STORE.set_meta('last_reprice','0');bot.STORE.set_meta('next_availability_check','0');bot.MAINTENANCE_WAKE.set()
            reply(m,'🔄 Обновление каталога и цен запрошено. Ручные цены сохранятся.');return
        if name=='rotation':
            if len(parts)!=2 or parts[1] not in ('on','off'):reply(m,'Формат: /sr_rotation on или /sr_rotation off');return
            def rotate():
                with bot.PROCESS_LOCK:
                    if parts[1]=='off' and bot.rotation.busy_offers(bot):raise ValueError('Дождись текущей замены')
                    bot.CFG['rotation']['enabled']=parts[1]=='on';bot.persist_settings()
                return 'Ротация '+('включена.' if parts[1]=='on' else 'выключена.')
            job(m,rotate);return
        if name=='limits':
            if len(parts)!=3:reply(m,'Формат: /sr_limits USD_НА_ЗАКАЗ USD_В_СУТКИ');return
            def limits():
                single,daily=map(D,parts[1:])
                if not 0<single<=daily<=10000:raise ValueError('Неверный бюджет')
                with bot.PROCESS_LOCK:
                    bot.CFG.update(max_single_order_usd=str(single),max_daily_usd=str(daily));bot.persist_settings()
                    bot.STORE.set_meta('next_availability_check','0')
                return f'Лимиты: ${single} на заказ, ${daily} в сутки. Кошелёк автоматически не пополняется.'
            job(m,limits);return
        if len(parts)<2:reply(m,HELP);return
        if name=='product':card(m,parts[1]);return
        if name not in ('price','auto','on','off','text','text_auto','pin','unpin'):return
        if name=='price' and len(parts) not in (3,4):reply(m,'Формат: /sr_price ID ЦЕНА ЧАСЫ');return
        try:_,expected,_=resolve(bot,parts[1])
        except ValueError as exc:reply(m,escape(str(exc)));return
        args=[m.text.split(maxsplit=2)[2]] if name=='text' and len(parts)>2 else parts[2:]
        job(m,lambda:change(bot,c,name,parts[1],args,expected_name=expected))
    names=['help','products','product','price','auto','on','off','text','text_auto','pin','unpin','rotation','sync','limits']
    tg.msg_handler(command,commands=['sr_'+x for x in names])
    c.add_telegram_commands(bot.UUID,[("sr_products","Товары: полный контроль",True),("sr_help","Товары: команды управления",True)])
    if hasattr(tg,'cbq_handler'):
        def callback(q):
            import os
            if not q.message or str(q.from_user.id)!=os.getenv('STEAMRU_OWNER_TG_ID') or str(q.from_user.id) not in {str(x) for x in tg.authorized_users} or q.message.chat.type!='private':return
            telegram.answer_callback_query(q.id)
            pieces=q.data.split(':');_,action,value=pieces[:3];m=q.message
            if action=='page':products(m,int(value))
            elif action=='card':card(m,value)
            else:
                _,expected,_=resolve(bot,value)
                if len(pieces)!=4 or pieces[3]!=hashlib.sha256(expected.encode()).hexdigest()[:6]:
                    reply(m,'Товар в этом месте изменился. Открой новую карточку через /sr_products.');return
                if action=='price':
                    PENDING_TEXT.pop(q.from_user.id,None);PENDING_PRICE[q.from_user.id]=(value,expected)
                    reply(m,'Отправь цену в рублях и срок в часах, например: 120 5. Для отмены: /sr_products.')
                elif action=='text':
                    PENDING_PRICE.pop(q.from_user.id,None);PENDING_TEXT[q.from_user.id]=(value,expected)
                    reply(m,'Отправь новое описание одним сообщением. Для отмены: /sr_products.')
                else:job(m,lambda:change(bot,c,action,value,expected_name=expected))
        tg.cbq_handler(callback,func=lambda q:bool(q.data and q.data.startswith('srp:')))
        def price_reply(m):
            text_offer=PENDING_TEXT.pop(m.from_user.id,None)
            if text_offer is not None:
                offer,expected=text_offer;job(m,lambda:change(bot,c,'text',offer,[m.text or ''],expected_name=expected));return
            item=PENDING_PRICE.pop(m.from_user.id,None)
            if item is not None:
                offer,expected=item
                values=(m.text or '').split()
                if len(values) not in (1,2):reply(m,'Нужны цена и срок, например: 120 5. Нажми «Цена» ещё раз.');return
                job(m,lambda:change(bot,c,'price',offer,values,expected_name=expected))
        tg.msg_handler(price_reply,func=lambda m:own(m) and (m.from_user.id in PENDING_PRICE or m.from_user.id in PENDING_TEXT) and not (m.text or '').startswith('/'),content_types=['text'])
