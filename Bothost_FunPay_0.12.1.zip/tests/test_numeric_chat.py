"""Regression for real Cardinal numeric Message IDs vs order node_name."""
from types import SimpleNamespace as N
import unittest
import test_safety_integration as fixtures


class NumericChatRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.interfaces = fixtures.source_interfaces()

    setUp = fixtures.SafetyIntegrationTests.setUp
    tearDown = fixtures.SafetyIntegrationTests.tearDown
    capture = fixtures.SafetyIntegrationTests.capture
    def numeric_message(self, text='@recipient123 #ABCD1234', author=12, interlocutor=12):
        message = self.interfaces.Message(999, text, 294271654, 'buyer', interlocutor,
                                         'buyer', author, '', determine_msg_type=False)
        message.type = self.interfaces.MessageTypes.NON_SYSTEM
        return self.interfaces.NewMessageEvent('offline', message)

    def test_numeric_message_resolves_trusted_private_chat_and_delivers_once(self):
        import steamru_stars as bot
        self.capture()
        self.c.runner = N(users_ids={294271654: 12})
        event = self.numeric_message()
        bot.on_new_message(self.c, event)
        bot.on_new_message(self.c, event)
        self.assertEqual(self.store.get('ABCD1234')['status'], 'ready')
        bot.process_ready(self.c); bot.process_ready(self.c)
        self.assertEqual(len(self.api.created), 1)

    def test_username_alone_accepted_only_for_single_waiting_order(self):
        import steamru_stars as bot
        self.capture()
        self.c.runner = N(users_ids={294271654: 12})
        bot.on_new_message(self.c, self.numeric_message('@recipient123'))
        self.assertEqual(self.store.get('ABCD1234')['status'], 'ready')

    def test_ambiguous_username_alone_does_not_choose_order(self):
        import steamru_stars as bot
        self.capture()
        self.store.insert_order('OTHER123', 12, 'users-7-12', 'buyer', 'STEAMRU TG STARS 50', 50, 1, '90', captured_mode='live')
        self.c.runner = N(users_ids={294271654: 12})
        bot.on_new_message(self.c, self.numeric_message('@recipient123'))
        self.assertEqual(self.store.get('ABCD1234')['status'], 'awaiting_username')
        self.assertEqual(self.store.get('OTHER123')['status'], 'awaiting_username')

    def test_wrong_numeric_chat_cannot_assign_recipient(self):
        import steamru_stars as bot
        self.capture()
        self.c.runner = N(users_ids={294271654: 13})
        self.c.account.get_chat = lambda *a, **k: N(id=294271654, interlocutor_id=13)
        bot.on_new_message(self.c, self.numeric_message())
        self.assertEqual(self.store.get('ABCD1234')['status'], 'awaiting_username')

    def test_unknown_numeric_chat_verified_against_server(self):
        import steamru_stars as bot
        self.capture()
        self.c.account.get_chat = lambda *a, **k: N(id=294271654, interlocutor_id=12)
        bot.on_new_message(self.c, self.numeric_message())
        self.assertEqual(self.store.get('ABCD1234')['status'], 'ready')

    def test_refunded_numeric_order_is_not_reactivated(self):
        import steamru_stars as bot
        self.capture()
        self.store.set('ABCD1234', status='cancelled', funpay_status='REFUNDED')
        self.c.runner = N(users_ids={294271654: 12})
        bot.on_new_message(self.c, self.numeric_message())
        bot.process_ready(self.c)
        self.assertEqual(self.store.get('ABCD1234')['status'], 'cancelled')
        self.assertEqual(self.api.created, [])

    def test_paid_price_is_honored_after_supplier_price_increase(self):
        import steamru_stars as bot
        self.capture()
        self.c.runner = N(users_ids={294271654: 12})
        bot.CFG['honor_paid_price'] = True
        bot.CFG['min_margin_pct'] = '40'
        bot.on_new_message(self.c, self.numeric_message())
        bot.process_ready(self.c)
        self.assertEqual(len(self.api.created), 1)
        self.assertEqual(self.store.get('ABCD1234')['status'], 'completed')

    def test_honoring_paid_order_does_not_allow_underpriced_new_offers(self):
        import steamru_stars as bot
        bot.CFG['honor_paid_price'] = True
        bot.CFG['min_margin_pct'] = '40'
        with self.assertRaises(ValueError):
            bot.verify_price(self.c, {'stars': 50}, '0.0152', '75')
