"""Transparent catalogue curation and spelling-tolerant retrieval, not analytics.

Every item returned by this module already exists in the reseller catalogue.
Priority is an editable editorial list; it does not claim measured sales demand.
"""
from __future__ import annotations
import re
import unicodedata
from difflib import SequenceMatcher
from functools import lru_cache


BRANDS = (
    ("steam", ("steam", "стим", "стиме", "стима", "стимчик", "стимм", "stim", "steem", "stiam", "steamwallet")),
    ("telegram-stars", ("telegram stars", "tg stars", "stars", "старс", "старзы", "звезды", "звезд", "звёздочки", "звездочки", "телеграм звезды")),
    ("telegram-premium", ("telegram premium", "tg premium", "premium", "премиум", "премиум телеграм", "тг премиум", "телеграм премиум", "телега премиум")),
    ("telegram", ("telegram", "телеграм", "телеграмм", "телега", "телегу", "тг", "tg", "tlg")),
    ("roblox", ("roblox", "robux", "роблокс", "роблоксе", "робуксы", "робукс", "робуксов", "робакс", "rblx", "roboks", "роблоукс")),
    ("pubg", ("pubg", "pubg mobile", "пабг", "пубг", "пабджи", "пубджи", "battlegrounds", "юси", "uc")),
    ("mobile-legends", ("mobile legends", "mobile legends bang bang", "мобайл легенд", "мобайл легендс", "мобайл легендс банг банг", "mlbb", "млбб")),
    ("fortnite", ("fortnite", "фортнайт", "фортнаит", "v bucks", "vbucks", "вбаксы", "в баксы", "вбаксов")),
    ("minecraft", ("minecraft", "майнкрафт", "майн", "майнкрафта", "minecoins", "майнкоины")),
    ("genshin", ("genshin", "genshin impact", "геншин", "геншина", "геншин импакт", "генезис", "кристаллы сотворения")),
    ("honkai-star-rail", ("honkai star rail", "star rail", "hsr", "хср", "хонкай стар рейл", "стар рейл")),
    ("valorant", ("valorant", "валорант", "валоранта", "vp", "valorant points")),
    ("league-of-legends", ("league of legends", "лига легенд", "лол", "riot points", "wild rift")),
    ("playstation", ("playstation", "psn", "плейстейшн", "псн", "ps plus", "psplus", "пс плюс")),
    ("xbox", ("xbox", "иксбокс", "game pass", "gamepass", "гейм пасс", "геймпасс")),
    ("nintendo", ("nintendo", "нинтендо", "eshop", "e shop", "switch online")),
    ("blizzard", ("blizzard", "близзард", "близард", "battle net", "battlenet", "батлнет", "баттл нет", "diablo", "диабло")),
    ("discord", ("discord", "дискорд", "nitro", "нитро")),
    ("spotify", ("spotify", "спотифай", "споти", "спотифая")),
    ("netflix", ("netflix", "нетфликс", "нетфликса")),
    ("brawl-stars", ("brawl stars", "бравл старс", "бравл", "бравлстарс")),
    ("clash", ("clash royale", "clash of clans", "клеш рояль", "клэш рояль", "клэш оф кленс")),
    ("free-fire", ("free fire", "фри фаер", "фри фаир", "фрифаер")),
    ("afk-journey", ("afk journey", "afkjourney", "афк джорни", "афк жорни")),
    ("zenless", ("zenless", "zenless zone zero", "zzz", "ззз", "зенлесс")),
    ("wuthering-waves", ("wuthering waves", "wuwa", "вува", "вувы")),
    ("tiktok", ("tiktok", "тик ток", "тикток", "тиктока")),
    ("apple", ("apple", "itunes", "app store", "эппл", "айтюнс")),
    ("google-play", ("google play", "гугл плей", "gplay", "плей маркет")),
)

# Editorial familiarity, not a bestseller chart. Unknown games remain accessible.
GAME_CURATION = (
    ("elden ring", "элден ринг"), ("cyberpunk 2077", "киберпанк"),
    ("baldur s gate 3", "baldurs gate 3", "балдурс гейт"),
    ("hogwarts legacy", "хогвартс"), ("red dead redemption", "rdr2", "ред дед"),
    ("grand theft auto", "gta", "гта"), ("the witcher", "witcher", "ведьмак"),
    ("helldivers", "хеллдайверс"), ("forza horizon", "форза"),
    ("horizon forbidden west", "horizon zero dawn"), ("god of war", "год оф вар"),
    ("resident evil", "резидент ивл"), ("stardew valley", "старью валли"),
    ("terraria", "террария"), ("hades", "аид"), ("hollow knight", "холлоу найт"),
    ("no man s sky", "no mans sky"), ("rust", "раст"), ("v rising", "в райзинг"),
    ("civilization", "цивилизация"), ("age of empires",), ("doom", "дум"),
)

_LOOKALIKES = str.maketrans({"ё": "е", "’": "'", "`": "'"})
_STOP = set("а и или но в во на по для у от до за из об о с со к ко как где что мне мой моя хочу хотел хочется надо нужен нужна нужно купить покупка покупать пожалуйста плиз покажи показать подбери предложи есть ли можно хочу бы вы ваш ваши the a an i me my would like want need buy buying please show find get in on for of to and some any an can you could это мне еще давай купить заказать оформить хочу пополнить пополнение пополнять баланс посоветуй игру игры товар товары пакет пакеты вариант варианты руб рубль рублей рубля тенге kzt rub usd цена стоимость подскажи ищу разыскиваю вижу узнать насчет через сейчас сегодня да здравствуйте привет добрый день вечер утро нужна ищем буду накинуть закинуть положить сделать send looking recommend topup top up wallet recharge purchase how much give есть какой какая какие этой этого такой такая хочу взять найти нужно покажите хотелось стоимость пополнения пополнение пополнить подарить gift key keys game games code коды код ключ ключи подарок подарком steamgift".split())


def normalize(text):
    return _normalized(str(text or ""))


@lru_cache(maxsize=32768)
def _normalized(text):
    text = unicodedata.normalize("NFKC", str(text or "")).casefold().translate(_LOOKALIKES)
    mixed = str.maketrans({"а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "у": "y", "к": "k", "т": "t", "в": "b", "м": "m"})
    text = re.sub(r"[a-zа-я]+", lambda m: m[0].translate(mixed) if re.search("[a-z]", m[0]) and re.search("[а-я]", m[0]) else m[0], text)
    text = text.replace("₽", " rub ").replace("₸", " kzt ").replace("$", " usd ")
    text = re.sub(r"(?<=\d)(?=[a-zа-я])|(?<=[a-zа-я])(?=\d)", " ", text)
    text = re.sub(r"[\W_]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def _contains(text, alias):
    alias = normalize(alias)
    return bool(alias and (" " + alias + " ") in (" " + text + " "))


_ALIASES = tuple((brand, tuple(dict.fromkeys(normalize(a) for a in aliases + (brand,)))) for brand, aliases in BRANDS)
_BRAND_IDS = {brand for brand, _ in BRANDS}


def brand_of(text, fuzzy=False):
    return _brand_of(normalize(text), bool(fuzzy))


@lru_cache(maxsize=16384)
def _brand_of(text, fuzzy=False):
    found = []
    for index, (brand, aliases) in enumerate(_ALIASES):
        for alias in aliases:
            if _contains(text, alias):
                found.append((len(normalize(alias).replace(" ", "")), -index, brand))
    if found:
        # Premium/stars explicit words outrank a generic Telegram token.
        direct = {v[2] for v in found}
        for specialized in ("telegram-premium", "telegram-stars"):
            if specialized in direct:
                return specialized
        return max(found)[2]
    if fuzzy:
        tokens = [t for t in text.split() if len(t) >= 4 and t not in _STOP and not t.isdigit()]
        best = (0, None)
        for brand, aliases in _ALIASES:
            for alias in aliases:
                if " " in alias or len(alias) < 4:
                    continue
                for token in tokens:
                    similarity = SequenceMatcher(None, token, alias).ratio()
                    if similarity >= .80 and abs(len(token) - len(alias)) <= 2 and similarity > best[0]:
                        best = similarity, brand
        return best[1]
    return None


def item_brand(item):
    slug = str(item.get("service") or item.get("brand") or "")
    if not slug and item.get("kind") in ("brand", "service"):
        slug = str(item.get("id") or "").partition(":")[2]
    if slug in _BRAND_IDS:
        return slug
    if slug:
        matched = brand_of(slug)
        if matched:
            return matched
    fields = " ".join(str(item.get(k) or "") for k in ("title", "service", "brand"))
    return brand_of(fields)


def qualified_title(service_name, raw_name, service_slug=""):
    """Never display a denomination without its real game/service identity."""
    raw, service = str(raw_name or "").strip(), str(service_name or service_slug or "").strip()
    if not raw:
        return service or "Товар"
    raw_normal, service_normal = normalize(raw), normalize(service)
    raw_brand, service_brand = brand_of(raw), brand_of(service + " " + service_slug)
    if service_normal and service_normal in raw_normal:
        return raw
    if raw_brand and service_brand == raw_brand:
        return raw
    return service + " · " + raw if service else raw


def buyer_visible(item):
    if item.get("hidden_from_shop") is True:
        return False
    if item.get("service") == "steam" and item.get("supplier_product_id") is not None:
        return str(item["supplier_product_id"]) in ("1", "9")
    return True


def apply_buyer_policy(item):
    result = dict(item)
    if result.get('kind') in ('topup','code') and result.get('service'):
        service_name=result.get('service_name') or str(result['service']).replace('-',' ').title()
        result['title']=qualified_title(service_name,result.get('title'),result['service'])
    if result.get("service") == "steam" and result.get("supplier_product_id") is not None:
        supplier_id = str(result["supplier_product_id"])
        if supplier_id in ("1", "9"):
            result["unit_currency"] = "RUB" if supplier_id == "1" else "KZT"
            result["min_quantity"] = max(100, int(result.get("min_quantity", result.get("min_count", 1))))
            result["min_count"] = result["min_quantity"]
            result["max_count"] = int(result.get("max_quantity", result.get("max_count", 1)))
            result["max_quantity"] = result["max_count"]
            result["quantity_label"] = "Сумма зачисления в " + result["unit_currency"]
            if result["max_quantity"] < result["min_quantity"]:
                result["available"] = False
            result["hidden_from_shop"] = False
        else:
            result["hidden_from_shop"] = True
    return result


def query_terms(query):
    return [t for t in normalize(query).split() if t not in _STOP and not t.isdigit() and len(t) >= 2]


def relevance(item, query):
    text = normalize(" ".join(str(item.get(k) or "") for k in ("title", "service", "brand", "content_kind", "region")))
    q = normalize(query)
    terms = query_terms(q)
    brand = brand_of(q, fuzzy=True)
    score = 0.0
    if q and q == normalize(item.get("title")):
        score += 100
    if q and q in text:
        score += 45
    numbers = set(re.findall(r"\b\d+\b", q))
    score += 10 * len(numbers.intersection(re.findall(r"\b\d+\b", text)))
    if brand:
        actual = item_brand(item)
        if actual == brand or (brand == "telegram" and actual in ("telegram", "telegram-stars", "telegram-premium")):
            score += 35
        elif brand.startswith("telegram-") and actual == "telegram":
            score += 5
    tokens = text.split()
    for term in terms:
        if term in tokens:
            score += 12
        elif any(term in t or (len(term) >= 4 and len(t) >= 4 and SequenceMatcher(None, term, t).ratio() >= .78) for t in tokens):
            score += 6
    # Game aliases allow Cyrillic queries to resolve actual English game names.
    for aliases in GAME_CURATION:
        if any(_contains(q, a) for a in aliases) and any(_contains(text, a) for a in aliases):
            score += 35
    return score


def editorial_priority(item):
    kind = item.get("kind")
    if kind in ("key", "key_group", "gift", "gift_group"):
        name = normalize(item.get("title"))
        for index, aliases in enumerate(GAME_CURATION):
            if any(_contains(name, a) for a in aliases):
                return 50 + index
        return 150
    brand = item_brand(item)
    for index, (known, _) in enumerate(BRANDS):
        if brand == known:
            return index
    if item.get("id") == "keys":
        return 12.5
    if item.get("id") == "gifts":
        return 13.5
    return 200


def ranked(items, query=None):
    visible = [apply_buyer_policy(i) for i in items if buyer_visible(i)]
    candidates = [(item, relevance(item, query) if query else 0) for item in visible]
    def sort_key(entry):
        item, score = entry
        availability = 0 if item.get("available", True) or item.get("has_variants") else 1
        kind_weight = 0 if item.get("kind") in ("brand", "service", "topup", "code") else 1
        currency_weight = {"RUB": 0, "KZT": 1}.get(item.get("unit_currency"), 0)
        return (-score, editorial_priority(item), availability, kind_weight, currency_weight,
                normalize(item.get("title")), str(item.get("id")))
    if query:
        candidates = [entry for entry in candidates if entry[1] >= 6]
    return [entry[0] for entry in sorted(candidates, key=sort_key)]


def varied_featured(items):
    """First screen shows distinct real services, followed by all remaining SKUs."""
    ordered = ranked(items)
    featured, remaining, seen = [], [], set()
    for item in ordered:
        if item.get("service") == "steam":
            family = ("steam", str(item.get("supplier_product_id")))
        elif item.get("kind") in ("key", "key_group", "gift", "gift_group"):
            family = ("game", item.get("app_id"))
        else:
            family = ("service", item.get("service") or item_brand(item) or item.get("id"))
        if family in seen:
            remaining.append(item)
        else:
            seen.add(family)
            featured.append(item)
    return featured + remaining
