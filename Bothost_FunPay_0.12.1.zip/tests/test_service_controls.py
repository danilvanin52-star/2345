"""Service delivery, durable owner overrides, and Telegram authorization offline."""
from copy import deepcopy
import json,tempfile,time
from pathlib import Path
from types import SimpleNamespace as N
import unittest
from unittest.mock import Mock,patch
import steamru_stars as bot
import steamru_stars_services as services
import steamru_stars_controls as controls
import steamru_stars_catalog as catalog
from steamru_stars_engine import SteamClient,D,UnknownOutcome,Store
from test_cardinal_compatibility import source_interfaces,definitions,SOURCE
import test_catalog_pricing as earlier

def service(slug):return deepcopy(next(r for _,r in services.shortlist() if r['service']==slug))
def product(rule):return {'product_id':rule['product_id'],'name':rule['product_name'],
    'price_usd':rule['last_price_usd'],'min_count':1,'max_count':1,'fields':deepcopy(rule['recipient_fields'])}

class ServiceOrders(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.types=source_interfaces()
    setUp=earlier.NewProductsTests.setUp
    tearDown=earlier.NewProductsTests.tearDown
    create=earlier.NewProductsTests.create
    capture=earlier.NewProductsTests.capture

    def setup_service(self,slug):
        rule=service(slug);bot.CFG['allowed_subcategory_ids']=[rule['subcategory_id']]
        self.api.request=Mock(return_value={'products':[product(rule)]})
        self.api.create_service=Mock(side_effect=self.create)
        return rule
    def recipient(self,text,author=12):
        message=N(text=text,author_id=author,chat_id='users-7-12',type=N(name='NON_SYSTEM'),by_bot=False)
        bot.on_new_message(self.c,N(message=message))

    def test_pubg_numeric_id_creates_exact_service_once(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule)
        self.recipient('123456789');self.recipient('123456789 #ABCD1234')
        bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'completed')
        self.assertEqual(self.api.created,[('funpay-ABCD1234','pubg-mobile',11,{'id_igroka':'123456789'},'123456789')])
        self.api.check_username.assert_not_called() if isinstance(self.api.check_username,Mock) else None

    def test_ml_player_and_server_are_kept_separate(self):
        rule=self.setup_service('mobile-legends-global');self.capture(rule)
        self.recipient('123456789 1234 #ABCD1234');bot.process_ready(self.c)
        self.assertEqual(self.api.created[0][3],{'player_id':'123456789','server_id':'1234'})
        self.assertEqual(self.api.created[0][4],'123456789')

    def test_missing_ml_server_does_not_buy_or_mark_ready(self):
        rule=self.setup_service('mobile-legends-global');self.capture(rule)
        self.recipient('123456789');bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'awaiting_username');self.assertEqual(self.api.created,[])

    def test_other_buyer_cannot_assign_id(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule)
        self.recipient('123456789 #ABCD1234',author=99)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'awaiting_username')

    def test_multiple_waiting_orders_require_number(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule)
        bot.STORE.insert_order('OTHER123',12,'users-7-12','buyer','rule:product',1,1,'10',captured_mode='live',kind='service_topup')
        self.recipient('123456789');self.assertEqual(bot.STORE.get('ABCD1234')['status'],'awaiting_username')

    def test_refunded_paid_order_never_buys_service(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule);self.recipient('123456789')
        self.c.account.order.status=self.types.OrderStatuses.REFUNDED
        bot.process_ready(self.c);self.assertEqual(self.api.created,[])

    def test_card_is_automatically_ready_and_delivers_voucher_once(self):
        rule=self.setup_service('roblox-ru');self.api.status='delivered';self.capture(rule)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'ready')
        bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(self.api.created,[('funpay-ABCD1234','roblox-ru',20351,None,None)])
        self.assertEqual(sum('AAAAA-BBBBB-CCCCC' in text for _,text in self.c.messages),1)
        self.assertIn('roblox.com/redeem',self.c.messages[-1][1])

    def test_card_completed_without_delivered_code_needs_review(self):
        rule=self.setup_service('roblox-ru');self.capture(rule);bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'needs_review')
        bot.process_ready(self.c);self.assertEqual(len(self.api.created),1)

    def test_changed_supplier_field_schema_prevents_post(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule);self.recipient('123456789')
        changed=product(rule);changed['fields'].append({'key':'password','type':'text'})
        self.api.request.return_value={'products':[changed]};bot.process_ready(self.c)
        self.assertEqual(self.api.created,[])

    def test_lost_service_post_never_retries(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule);self.recipient('123456789')
        self.api.create_service.side_effect=UnknownOutcome('Fictitious lost response')
        bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'uncertain')
        self.api.create_service.assert_called_once()

    def test_two_packs_in_one_order_are_not_accepted(self):
        rule=self.setup_service('pubg-mobile');self.capture(rule,count=2)
        self.assertIsNone(bot.STORE.get('ABCD1234'))

class ServicePayloads(unittest.TestCase):
    def test_default_client_blocks_service_purchase(self):
        client=SteamClient('FICTITIOUS','FICTITIOUS',session=Mock())
        with self.assertRaises(PermissionError):client.create_service('funpay-ABC123','pubg-mobile',11,{'id_igroka':'123456789'},'123456789')
        client.session.request.assert_not_called()
    def test_topup_and_voucher_payloads_follow_official_schema(self):
        client=SteamClient('FICTITIOUS','FICTITIOUS');client.request=Mock(return_value={'uuid':'FICTITIOUS'})
        client.create_service('funpay-ABC123','pubg-mobile',11,{'id_igroka':'123456789'},'123456789')
        self.assertEqual(client.request.call_args.kwargs['payload'],{'external_order_id':'funpay-ABC123','service':'pubg-mobile','product_id':11,'product_count':1,'fields':{'id_igroka':'123456789'},'account':'123456789'})
        client.create_service('funpay-CODE123','roblox-ru',20351)
        self.assertNotIn('account',client.request.call_args.kwargs['payload']);self.assertNotIn('fields',client.request.call_args.kwargs['payload'])
    def test_catalog_is_selected_get_only_and_type_verified(self):
        rule=service('pubg-mobile');name=next(n for n,r in services.shortlist() if r['product_id']==11)
        api=Mock();api.request.side_effect=[{'services':[{'id':'pubg-mobile','type':'topup'}]},{'products':[product(rule)]}]
        result=services.catalogue(api,[name]);self.assertEqual(len(result),1)
        self.assertTrue(result[0][1]['sell_enabled']);self.assertTrue(all(c.args[0]=='GET' for c in api.request.call_args_list))
    def test_region_nominal_and_supplier_type_cannot_be_guessed(self):
        rule=service('pubg-mobile');name=next(n for n,r in services.shortlist() if r['product_id']==11)
        api=Mock();api.request.return_value={'services':[{'id':'pubg-mobile','type':'code'}]}
        self.assertEqual(services.catalogue(api,[name]),[]);self.assertEqual(api.request.call_count,1)
    def test_shortlist_has_unique_funpay_contracts(self):
        identities=[(r['subcategory_id'],tuple(sorted(r['match_fields'].items()))) for _,r in services.shortlist()]
        self.assertEqual(len(identities),len(set(identities)))
    def test_copy_does_not_promise_steam_activation_for_other_codes(self):
        copy=catalog.buyer_copy(service('roblox-ru'))
        self.assertIn('Россия',copy['ru']);self.assertIn('roblox.com/redeem',copy['ru']);self.assertNotIn('Steam',copy['ru'])
    def test_ml_copy_requests_both_ids_and_no_password(self):
        copy=catalog.buyer_copy(service('mobile-legends-global'))
        self.assertIn('ID игрока и ID сервера',copy['ru']);self.assertIn('Пароль и коды',copy['ru'])
    def test_apple_card_has_required_summary_in_both_languages(self):
        rule=service('apple-id-tr');fields=catalog.apply_rule({},rule,'100')
        self.assertIn('50 TRY',fields['fields[summary][ru]']);self.assertIn('Turkey',fields['fields[summary][en]'])
        self.assertNotIn('Турция',fields['fields[summary][en]'])

class OwnerControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.types=source_interfaces();definitions(SOURCE/'FunPayAPI/types.py',['LotFields'],cls.types.__dict__)
    def setUp(self):
        earlier.MaintenanceTests.setUp(self)
        self.rule={'subcategory_id':2418,'stars_per_unit':50,'last_price_usd':'.0152',
            'match_fields':{'quantity':'50 звёзд','quantity2':'','method':'По username'}}
        bot.CFG['lot_rules']={'stars':self.rule};bot.CFG['managed_lots']={'1':'stars'}
        self.offer=self.types.LotFields(1,{'price':'72','fields[quantity]':'50 звёзд','fields[quantity2]':'','fields[method]':'По username','active':'on'},subcategory=N(id=2418),currency=self.types.Currency.RUB)
        self.c.account.get_lot_fields=lambda *a,**kw:deepcopy(self.offer)
        self.c.account.save_lot=self.save
    tearDown=earlier.MaintenanceTests.tearDown
    def save(self,fields):self.offer=deepcopy(fields)
    def test_manual_price_below_margin_is_saved_and_durable(self):
        controls.change(bot,self.c,'price','1',['1','5'])
        self.assertEqual(D(self.offer.price),D('1'));self.assertEqual(controls.manual_price(bot,1),D('1'))
        saved=json.loads(bot.CFG_PATH.read_text(encoding='utf-8'));self.assertEqual(saved['lot_controls']['1']['manual_price']['value'],'1')
    def test_expired_price_releases_override_and_requests_repricing(self):
        controls.change(bot,self.c,'price',1,['1','.05'])
        expiry=bot.CFG['lot_controls']['1']['manual_price']['expires_at']
        with patch.object(controls.time,'time',return_value=expiry+1):controls.expire(bot)
        self.assertIsNone(controls.manual_price(bot,1));self.assertEqual(bot.STORE.get_meta('last_reprice'),'0')
    def test_hourly_auto_price_does_not_overwrite_manual_price(self):
        controls.change(bot,self.c,'price',1,['1','5'])
        self.c.account.get_subcategory_public_lots.return_value=[];self.api.product.return_value={'price_usd':'.0152'}
        bot.auto_reprice(self.c)
        self.assertEqual(D(self.offer.price),D('1'))
    def test_paused_global_state_is_preserved_when_owner_changes_price(self):
        bot.STORE.set_meta('paused','yes');controls.change(bot,self.c,'price',1,['71','5'])
        self.assertFalse(self.offer.active);self.assertTrue(bot.paused())
    def test_disabled_lot_stays_disabled_during_availability_check(self):
        controls.change(bot,self.c,'off',1);bot.maintain_availability(self.c)
        self.assertFalse(self.offer.active);self.assertTrue(controls.disabled(bot,1))
    def test_price_control_does_not_retarget_a_rotated_slot(self):
        controls.change(bot,self.c,'price',1,['71','5']);bot.CFG['managed_lots']['1']='OTHER'
        self.assertIsNone(controls.manual_price(bot,1))
    def test_queued_action_cannot_affect_a_different_game(self):
        with self.assertRaises(ValueError):controls.change(bot,self.c,'price',1,['1','5'],expected_name='OLD_GAME')
        self.assertEqual(self.offer.price,72)
    def test_auto_restores_normal_price(self):
        controls.change(bot,self.c,'price',1,['1','5']);controls.change(bot,self.c,'auto',1)
        self.assertIsNone(controls.manual_price(bot,1));self.assertGreater(self.offer.price,1)
    def test_description_survives_automatic_copy(self):
        controls.change(bot,self.c,'text',1,['⭐ Мой текст']);catalog.update_copy(self.offer,self.rule)
        controls.apply_text(bot,1,self.offer);self.assertEqual(self.offer.description_ru,'⭐ Мой текст')
    def test_unknown_lot_and_invalid_price_do_not_write(self):
        for offer,args in [(999,['10']), (1,['0']), (1,['NaN']), (1,['10.001']), (1,['10','0'])]:
            with self.subTest(offer=offer,args=args),self.assertRaises(ValueError):controls.change(bot,self.c,'price',offer,args)
        self.assertEqual(self.offer.price,72)
    def test_recipient_cas_refuses_cancelled_order(self):
        bot.STORE.insert_order('CAS123',12,'users-7-12','buyer','rule:TEST',1,1,'10',kind='service_topup')
        bot.STORE.set('CAS123',status='cancelled')
        self.assertFalse(bot.STORE.set_service_recipient('CAS123',12,'users-7-12',{'id_igroka':'123456789'}))

    def handlers(self):
        handlers={};callbacks=[];telegram=N(reply_to=Mock(),answer_callback_query=Mock())
        def register(handler,**kwargs):
            for command in kwargs.get('commands',[]):handlers[command]=handler
        self.c.telegram=N(bot=telegram,authorized_users={'123':{}},msg_handler=register,
            cbq_handler=lambda handler,**kw:callbacks.append(handler))
        self.c.add_telegram_commands=Mock()
        controls.register(bot,self.c,lambda m:m.from_user.id==123 and m.chat.type=='private')
        return handlers,callbacks,telegram
    def test_unauthorized_or_group_price_command_is_ignored(self):
        handlers,_,telegram=self.handlers()
        for uid,kind in [(99,'private'),(123,'group')]:
            handlers['sr_price'](N(text='/sr_price 1 1 5',from_user=N(id=uid),chat=N(type=kind)))
        telegram.reply_to.assert_not_called();self.assertEqual(self.offer.price,72)
    def test_callback_also_checks_owner_authorization(self):
        _,callbacks,telegram=self.handlers()
        with patch.dict('os.environ',{'STEAMRU_OWNER_TG_ID':'123'}):
            callbacks[0](N(id='fake',data='srp:off:1',from_user=N(id=99),message=N(chat=N(type='private'))))
        telegram.answer_callback_query.assert_not_called();self.assertTrue(self.offer.active)
