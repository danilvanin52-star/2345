"""Authenticated outbound bridge to the independently deployed Aisklad website.

The website checks its payment provider. The bot accepts only a signed, immutable
invoice-bound event; redirects and buyer claims never authorize purchases.
No supplier request is made by this module. Disabled mode still reconciles old
invoices, while refusing new checkouts. HTTP transport is injectable for tests.
"""
from __future__ import annotations
import hashlib
import hmac
import ipaddress
import json
import re
import threading
import time
import uuid
from dataclasses import fields as dataclass_fields
from decimal import Decimal, InvalidOperation
from urllib.parse import quote, urlencode, urlsplit, parse_qs
from .payments import PaymentUnavailable, VerifiedPaymentEvent, validate_event
from .store import dumps


class WebPaymentError(RuntimeError):
    """Fixed public descriptions only; never include HTTP bodies or private URLs."""


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON field")
        result[key] = value
    return result


def _amount(value):
    if isinstance(value, float) or isinstance(value, bool):
        raise ValueError("Payment amounts must be decimal strings")
    number = Decimal(str(value))
    if not number.is_finite() or number <= 0 or number != number.quantize(Decimal(".01")):
        raise ValueError("Invalid payment amount")
    result = format(number, ".2f")
    if not re.fullmatch(r"[0-9]{1,12}\.[0-9]{2}", result):
        raise ValueError("Invalid payment amount")
    return result


def _origin(url):
    parsed = urlsplit(str(url))
    host = parsed.hostname or ""
    if parsed.scheme != "https" or not host or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError("Only a public HTTPS website is accepted")
    if host.lower() == "localhost" or host.lower().endswith((".localhost", ".local", ".internal")):
        raise ValueError("Private website origins are not accepted")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ValueError("Private website origins are not accepted")
    return "https://" + host.lower()


class WebEventVerifier:
    def __init__(self, secret):
        self.secret = secret.encode("utf-8")

    def verify(self, raw_body, headers):
        if not isinstance(raw_body, bytes) or len(raw_body) > 1024 * 1024:
            raise ValueError("Invalid event body")
        signature = headers.get("X-Shop-Event-Signature", "")
        expected = hmac.new(self.secret, b"event\n" + raw_body, hashlib.sha256).hexdigest()
        if not isinstance(signature, str) or not re.fullmatch(r"[a-fA-F0-9]{64}", signature) or not hmac.compare_digest(expected, signature.lower()):
            raise ValueError("Invalid event authentication")
        payload = json.loads(raw_body.decode("utf-8"), object_pairs_hook=_object)
        allowed = {field.name for field in dataclass_fields(VerifiedPaymentEvent)}
        if not isinstance(payload, dict) or set(payload) != allowed:
            raise ValueError("Unexpected payment event fields")
        for key in allowed - {"user_id", "test"}:
            if not isinstance(payload[key], str) or not 1 <= len(payload[key]) <= 200:
                raise ValueError("Invalid payment event field")
        if type(payload["user_id"]) is not int or payload["user_id"] <= 0 or type(payload["test"]) is not bool:
            raise ValueError("Invalid payment recipient or mode")
        if payload["provider"] != "aisklad_web" or payload["currency"] != "RUB" or payload["amount"] != _amount(payload["amount"]):
            raise ValueError("Unexpected payment provider or amount")
        if payload["invoice_id"] != "shop:" + payload["order_id"]:
            raise ValueError("Unexpected invoice identity")
        return validate_event(VerifiedPaymentEvent(**payload))


class WebPayments:
    provider = "aisklad_web"
    currency = "RUB"
    external_payment = True
    reason = "Внешняя оплата на сайте Aisklad. Вход в аккаунт сайта для счёта не нужен."

    def __init__(self, base_url, secret, mode="test", session=None, clock=time.time, nonce_factory=None, timeout=15):
        parsed = urlsplit(str(base_url))
        self.base_url = _origin(base_url)
        if parsed.path not in ("", "/") or parsed.query or parsed.fragment:
            raise ValueError("Bridge base URL must contain only the website origin")
        if not isinstance(secret, str) or len(secret) < 32 or "\n" in secret:
            raise ValueError("Use a separate bridge secret of at least 32 characters")
        if mode not in ("disabled", "test", "live"):
            raise ValueError("Payment mode must be disabled, test or live")
        if session is None:
            import requests
            session = requests.Session()
        self.session, self.secret, self.mode = session, secret.encode("utf-8"), mode
        self.enabled = mode in ("test", "live")
        self.clock, self.nonce_factory = clock, nonce_factory or (lambda: uuid.uuid4().hex)
        self.timeout = min(30, max(1, float(timeout)))
        self.verifier = WebEventVerifier(secret)
        self._sync_lock = threading.Lock()

    def _request(self, method, path, payload=None):
        if not path.startswith("/api/shop/bridge/") or "#" in path or ".." in path or "\\" in path:
            raise WebPaymentError("Некорректный путь платёжного моста.")
        raw = dumps(payload).encode("utf-8") if payload is not None else b""
        if len(raw) > 1024 * 1024:
            raise WebPaymentError("Слишком большой запрос платёжного моста.")
        stamp, nonce = str(int(self.clock())), str(self.nonce_factory())
        material = "\n".join((stamp, nonce, method, path, hashlib.sha256(raw).hexdigest())).encode("utf-8")
        headers = {"X-Shop-Timestamp": stamp, "X-Shop-Nonce": nonce,
                   "X-Shop-Signature": hmac.new(self.secret, material, hashlib.sha256).hexdigest(),
                   "Accept": "application/json"}
        if payload is not None:
            headers["Content-Type"] = "application/json"
        response = None
        try:
            response = self.session.request(method, self.base_url + path, data=raw or None, headers=headers,
                                            timeout=self.timeout, allow_redirects=False, stream=True)
            if not 200 <= response.status_code < 300:
                raise WebPaymentError("Сайт не подтвердил запрос платёжного моста.")
            chunks, total = [], 0
            iterator = response.iter_content(chunk_size=65536) if hasattr(response, "iter_content") else [response.content]
            for chunk in iterator:
                if not chunk:
                    continue
                total += len(chunk)
                if total > 1024 * 1024:
                    raise WebPaymentError("Слишком большой ответ платёжного моста.")
                chunks.append(chunk)
            document = json.loads(b"".join(chunks).decode("utf-8"), object_pairs_hook=_object)
            if not isinstance(document, dict):
                raise ValueError("Expected JSON object")
            return document
        except WebPaymentError:
            raise
        except Exception:
            raise WebPaymentError("Не удалось подтвердить ответ сайта. Состояние сохранено для повторной сверки.") from None
        finally:
            if response is not None and hasattr(response, "close"):
                response.close()

    def _registered(self, request, result, expected_mode):
        if result.get("invoice_id") != "shop:" + request["order_id"] or result.get("mode") != expected_mode:
            raise WebPaymentError("Сайт вернул другой счёт или режим оплаты.")
        try:
            payment_url = result["payment_url"]
            parsed = urlsplit(payment_url)
            query, fragment = parse_qs(parsed.query), parse_qs(parsed.fragment)
            valid = (self.validate_checkout_url(payment_url) and
                     query.get("order_id") == [request["order_id"]] and len(fragment.get("token", [])) == 1 and
                     16 <= len(fragment["token"][0]) <= 1024)
            expiry = result["expires_at"]
            valid = valid and type(expiry) in (int, float) and float(expiry) == float(request["expires_at"])
            if not valid:
                raise ValueError("Untrusted checkout link")
        except (KeyError, ValueError, TypeError):
            raise WebPaymentError("Сайт не подтвердил безопасную ссылку на этот счёт.") from None
        return {"invoice_id": result["invoice_id"], "payment_url": payment_url, "expires_at": expiry,
                "mode": expected_mode, "external_payment": True}

    def validate_checkout_url(self, url):
        try:
            parsed = urlsplit(url)
            query, fragment = parse_qs(parsed.query), parse_qs(parsed.fragment)
            return bool(_origin(url) == self.base_url and parsed.path == "/shop/checkout" and
                        set(query) == {"order_id"} and len(query["order_id"]) == 1 and
                        re.fullmatch(r"[A-Za-z0-9_-]{1,100}", query["order_id"][0]) and
                        set(fragment) == {"token"} and len(fragment["token"]) == 1 and 16 <= len(fragment["token"][0]) <= 1024)
        except (TypeError, ValueError, KeyError):
            return False

    def create_invoice(self, order_id, amount, currency, user_id, items, created_at, expires_at):
        if not self.enabled:
            raise PaymentUnavailable("Новые внешние счета отключены.")
        request = self._invoice_request(order_id, amount, currency, user_id, items, created_at, expires_at)
        return self._registered(request, self._request("POST", "/api/shop/bridge/invoices", request), self.mode)

    def _invoice_request(self, order_id, amount, currency, user_id, items, created_at, expires_at):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", str(order_id)) or type(user_id) is not int or user_id <= 0 or currency != "RUB":
            raise ValueError("Invalid invoice identity")
        if type(created_at) not in (int, float) or type(expires_at) not in (int, float) or not 0 < expires_at - created_at <= 86400:
            raise ValueError("Invalid invoice lifetime")
        amount = _amount(amount)
        if not isinstance(items, list) or not 1 <= len(items) <= 20:
            raise ValueError("Invalid invoice items")
        if sum((Decimal(_amount(item["total_rub"])) for item in items), Decimal(0)) != Decimal(amount):
            raise ValueError("Invoice lines do not match the total")
        return {"order_id": str(order_id), "amount": amount, "currency": currency, "user_id": user_id,
                "items": items, "created_at": created_at, "expires_at": expires_at}

    def recover_invoice(self, request, expected_mode):
        """Same immutable registration, never a fresh invoice/id after a timeout."""
        request = self._invoice_request(**request)
        if expected_mode not in ("test", "live"):
            raise WebPaymentError("Неизвестен исходный режим счёта.")
        return self._registered(request, self._request("POST", "/api/shop/bridge/invoices", request), expected_mode)

    def poll_events(self, limit=50):
        result = self._request("GET", "/api/shop/bridge/payments?" + urlencode({"limit": min(50, max(1, int(limit)))}))
        if not isinstance(result.get("events"), list) or len(result["events"]) > 50:
            raise WebPaymentError("Некорректная очередь платёжных событий.")
        return result["events"]

    def ack_event(self, event_id):
        if not isinstance(event_id, str) or not 1 <= len(event_id) <= 200:
            raise ValueError("Invalid event identity")
        result = self._request("POST", "/api/shop/bridge/payments/" + quote(event_id, safe="") + "/ack", {})
        if result.get("ok") is not True:
            raise WebPaymentError("Сайт не подтвердил приём события.")

    def _delivery(self, order, revision):
        return {"order_id": order["id"], "status": order["status"], "revision": int(revision),
                "items": [{"id": line["id"], "title": line["title"], "quantity": line["quantity"],
                           "fields": line.get("fields", {}), "status": line["status"],
                           "delivery": list(line.get("delivery", [])) if line["status"] == "completed" else [],
                           "activation": list(line.get("activation", []))} for line in order["items"]]}

    def _publish_payload(self, payload):
        result = self._request("POST", "/api/shop/bridge/delivery", payload)
        if result.get("ok") is not True or result.get("revision") != payload["revision"]:
            raise WebPaymentError("Сайт не подтвердил состояние выдачи.")
        return result

    def publish_order(self, order, revision):
        return self._publish_payload(self._delivery(order, revision))

    def synchronize(self, service):
        """At-least-once inbox + durable monotonic delivery outbox. No purchases."""
        if not self._sync_lock.acquire(blocking=False):
            return {"state": "busy", "accepted": 0, "published": 0}
        accepted, published, failed = 0, 0, 0
        try:
            registration = service.retry_pending_invoices(limit=20)
            failed += registration.get("failed", 0)
            for envelope in self.poll_events():
                try:
                    raw = envelope["raw"].encode("utf-8")
                    headers = {"X-Shop-Event-Signature": envelope["signature"]}
                    verified = self.verifier.verify(raw, headers)
                    # envelope.payload is display-only; only signed raw is trusted.
                    service.handle_payment(raw, headers)
                    self.ack_event(verified.event_id)  # strictly after SQLite commit
                    service.store.set_setting("bridge:last_ack", {"event_id": verified.event_id, "at": self.clock()})
                    accepted += 1
                except Exception:
                    failed += 1  # No ack: authenticated retry/recovery remains possible.
            with service.store.connection() as db:
                rows = db.execute("SELECT id,status FROM orders WHERE json_valid(value) AND json_extract(value,'$.payment_provider')=? AND json_extract(value,'$.payment_mode')='live' AND status NOT IN ('invoice_creating','invoice_review','awaiting_payment') ORDER BY created_at", (self.provider,)).fetchall()
            for row in rows:
                key = "bridge:delivery:" + row["id"]
                state = service.store.get_setting(key, {"revision": 0})
                if row["status"] in ("completed", "test_paid") and state.get("published_status") == row["status"] and not state.get("pending"):
                    continue  # Do not reopen every delivered historical line on every poll.
                order = service.store.order_data(row["id"])
                if order.get("payment_provider") != self.provider or order.get("payment_mode") != "live" or order["status"] in ("invoice_creating", "invoice_review", "awaiting_payment", "test_paid"):
                    continue
                pending = state.get("pending")
                if not pending:
                    content = self._delivery(order, 0)
                    digest = hashlib.sha256(dumps(content).encode()).hexdigest()
                    if state.get("published_hash") == digest:
                        continue
                    pending = self._delivery(order, int(state.get("revision", 0)) + 1)
                    state.update(revision=pending["revision"], pending=pending, pending_hash=digest)
                    service.store.set_setting(key, state)  # durable before HTTP
                try:
                    self._publish_payload(pending)
                    state.update(published_hash=state.pop("pending_hash"), published_at=self.clock(), published_status=pending["status"])
                    state.pop("pending", None)
                    service.store.set_setting(key, state)
                    published += 1
                except Exception:
                    failed += 1
            service.store.set_setting("bridge:last_sync", {"at": self.clock(), "accepted": accepted, "published": published, "failed": failed})
            return {"state": "ok" if not failed else "retry", "accepted": accepted, "published": published, "failed": failed}
        finally:
            self._sync_lock.release()
