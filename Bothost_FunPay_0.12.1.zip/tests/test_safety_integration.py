"""Offline safety integration using actual Cardinal Order/event definitions."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_cardinal_compatibility import ROOT, actual_delivery_test_event, full_order, shortcut, source_interfaces
import steamru_stars as bot
from steamru_stars_engine import Store, SteamClient


class Account:
    id = 7

    def __init__(self, order):
        self.order = order
        self.reads = []
        self.lot_saves = []

    def get_order(self, oid):
        self.reads.append(oid)
        return self.order

    def get_lot_fields(self, lot_id):
        return N(active=True, renew_fields=lambda: {"active": ""})

    def save_lot(self, fields):
        self.lot_saves.append(fields)


class Cardinal:
    def __init__(self, order):
        self.account = Account(order)
        self.plugins = {bot.UUID: N(enabled=True)}
        self.telegram = None
        self.messages = []

    def send_message(self, chat_id, text, buyer_name, watermark=False):
        self.messages.append((chat_id, text))
        return [N()]


class API:
    def __init__(self):
        self.created = []
        self.before_post = None
        self.status = "completed"
        self.charged = "0.7600"

    def product(self, service, pid, count):
        return {"product_id": 55, "price_usd": "0.0152", "fields": []}

    def check_username(self, username):
        return True

    def balance(self):
        if self.before_post:
            self.before_post()
        return Decimal("100")

    def create(self, *args):
        self.created.append(args)
        return {"uuid": "cf6a7f78-b460-4cb3-92ce-38bccd3c1ea6", "product_id": 55, "status": "created"}

    def get_order(self, uuid):
        return {"uuid": uuid, "status": self.status, "amount_charged_usd": self.charged}


class SafetyIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.interfaces = source_interfaces()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / "orders.sqlite3")
        self.store.set_meta("paused", "no")
        self.c = Cardinal(full_order(self.interfaces))
        self.api = API()
        self.previous_store, self.previous_cfg = bot.STORE, bot.CFG
        bot.STORE = self.store
        bot.CFG = {**bot.DEFAULT, "mode": "live", "allowed_subcategory_ids": [999],
                   "rub_per_usd": "88.45", "other_cost_per_order_rub": "0.25",
                   "rub_per_usd_updated_at": datetime.now(timezone.utc).isoformat(),
                   "auto_disable_lots_on_pause": True, "lot_ids_to_disable": [123]}
        self.client_patch = patch.object(bot, "client", return_value=self.api)
        self.live_patch = patch.object(bot, "live_allowed", return_value=True)
        self.network_patch = patch("socket.socket", side_effect=AssertionError("Offline suite forbids network"))
        self.client_patch.start()
        self.live_patch.start()
        self.network_patch.start()

    def tearDown(self):
        self.network_patch.stop()
        self.live_patch.stop()
        self.client_patch.stop()
        bot.STORE, bot.CFG = self.previous_store, self.previous_cfg
        self.temp.cleanup()

    def capture(self, initial=False, oid="ABCD1234"):
        order = shortcut(self.interfaces, oid=oid)
        event_type = self.interfaces.InitialOrderEvent if initial else self.interfaces.NewOrderEvent
        handler = bot.on_initial_order if initial else bot.on_new_order
        handler(self.c, event_type("offline", order))
        return self.store.get(oid)

    def seed(self, oid="ABCD1234", stars=50, amount=1):
        self.store.insert_order(oid, 12, "users-7-12", "buyer", "STEAMRU TG STARS 50", stars, amount, "90")
        return self.store.get(oid)

    def ready(self):
        self.assertIsNotNone(self.capture())
        self.assertTrue(self.store.set_username("ABCD1234", 12, "users-7-12", "recipient123"))

    def test_default_config_is_paused_safe_range_without_capture(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["mode"], "dry_run")
        self.assertIs(cfg["capture_paid_orders_in_dry_run"], False)
        self.assertEqual(cfg["product_id"], 55)
        self.assertEqual(set(cfg["lots"].values()), {50, 100, 150})
        self.assertLessEqual(cfg["max_total_stars"], 150)
        self.assertEqual(cfg["allowed_subcategory_ids"], [])
        self.assertIs(bot.DEFAULT["capture_initial_paid_orders"], False)

    def test_dryrun_default_ignores_real_order_before_read_or_message(self):
        bot.CFG["mode"] = "dry_run"
        bot.CFG["capture_paid_orders_in_dry_run"] = False
        self.assertIsNone(self.capture())
        bot.process_ready(self.c)
        self.assertEqual(self.c.account.reads, [])
        self.assertEqual(self.c.messages, [])
        self.assertEqual(self.api.created, [])

    def test_explicit_dryrun_capture_reads_full_order_but_never_purchases(self):
        bot.CFG["mode"] = "dry_run"
        bot.CFG["capture_paid_orders_in_dry_run"] = True
        row = self.capture()
        self.assertIsNotNone(row)
        self.assertEqual(self.c.account.reads, ["ABCD1234"])
        self.assertTrue(self.store.set_username("ABCD1234", 12, "users-7-12", "recipient123"))
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])

    def test_initial_and_new_events_capture_one_fresh_order(self):
        bot.CFG["capture_initial_paid_orders"] = True
        self.assertIsNotNone(self.capture(initial=True))
        self.capture()
        self.assertEqual(len(self.store.rows()), 1)
        self.assertEqual(len(self.c.messages), 1)
        self.assertEqual(self.store.get("ABCD1234")["description"], "STEAMRU TG STARS 50")

    def test_default_initial_event_excludes_history_without_read_or_message(self):
        self.assertIs(bot.CFG["capture_initial_paid_orders"], False)
        self.assertIsNone(self.capture(initial=True))
        self.assertEqual(self.c.account.reads, [])
        self.assertEqual(self.c.messages, [])
        self.assertEqual(self.api.created, [])

    def test_paid_shortcut_cannot_override_fresh_refunded_order(self):
        self.c.account.order.status = self.interfaces.OrderStatuses.REFUNDED
        self.assertIsNone(self.capture())
        self.assertEqual(self.c.messages, [])
        self.assertEqual(self.api.created, [])

    def test_fresh_order_seller_category_and_exact_title_are_required(self):
        invalid = (
            full_order(self.interfaces, seller_id=8),
            full_order(self.interfaces, subcategory_id=998),
            full_order(self.interfaces, title="Prefix STEAMRU TG STARS 50"),
            full_order(self.interfaces, title="STEAMRU TG STARS 50 extra"),
        )
        for full in invalid:
            with self.subTest(seller=full.seller_id, category=full.subcategory.id, title=full.short_description):
                self.c.account.order = full
                self.assertIsNone(self.capture())
        self.assertEqual(self.c.messages, [])
        self.assertEqual(self.api.created, [])

    def test_common_lot_none_amount_is_one_pack(self):
        self.c.account.order.amount = None
        row = self.capture()
        self.assertIsNotNone(row)
        self.assertEqual(row["amount"], 1)
        self.assertEqual(row["stars"], 50)
        self.assertEqual(bot.preflight(self.c, row), Decimal("90"))

    def test_fractional_or_out_of_range_pack_is_never_captured(self):
        for amount in (1.5, "1.5", True, 0, -1, 4):
            with self.subTest(amount=amount):
                self.c.account.order.amount = amount
                self.assertIsNone(self.capture())
        self.assertEqual(self.api.created, [])

    def test_full_real_order_preflight_uses_sum_not_shortcut_price(self):
        row = self.seed()
        self.assertEqual(bot.preflight(self.c, row), Decimal("90"))
        self.c.account.order.sum = Decimal("101.25")
        self.assertEqual(bot.preflight(self.c, row), Decimal("101.25"))

    def test_preflight_detects_order_identity_changes(self):
        row = self.seed()
        for field, bad in (("seller_id", 8), ("buyer_id", 13), ("chat_id", "other-chat"),
                           ("amount", 2), ("currency", self.interfaces.Currency.USD)):
            with self.subTest(field=field):
                old = getattr(self.c.account.order, field)
                setattr(self.c.account.order, field, bad)
                try:
                    with self.assertRaises(ValueError):
                        bot.preflight(self.c, row)
                finally:
                    setattr(self.c.account.order, field, old)
        self.c.account.order.fields["summary"].value = {"ru": "STEAMRU TG STARS 100"}
        with self.assertRaises(ValueError):
            bot.preflight(self.c, row)

    def test_real_adtest_id_is_never_captured(self):
        event = actual_delivery_test_event(self.interfaces)
        bot.on_new_order(self.c, event)
        self.assertIsNone(self.store.get("ADTEST"))
        self.assertEqual(self.c.account.reads, [])
        self.assertEqual(self.c.messages, [])
        self.assertEqual(self.api.created, [])

    def test_preflight_rejects_seeded_adtest_row_in_live_mode(self):
        row = self.seed("ADTEST")
        self.c.account.order = full_order(self.interfaces, oid="ADTEST")
        with self.assertRaises(ValueError):
            bot.preflight(self.c, row)
        self.store.set_username("ADTEST", 12, "users-7-12", "recipient123")
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])

    def test_pause_during_supplier_preflight_blocks_final_post(self):
        self.ready()
        self.api.before_post = lambda: self.store.set_meta("paused", "yes")
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])
        self.assertNotEqual(self.store.get("ABCD1234")["status"], "submitting")

    def test_disable_plugin_during_preflight_blocks_final_post(self):
        self.ready()
        self.api.before_post = lambda: setattr(self.c.plugins[bot.UUID], "enabled", False)
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])

    def test_dryrun_switch_during_preflight_blocks_final_post(self):
        self.ready()
        self.api.before_post = lambda: bot.CFG.update(mode="dry_run")
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])

    def test_cancel_during_preflight_blocks_final_post(self):
        self.ready()
        self.api.before_post = lambda: self.store.set("ABCD1234", status="cancelled")
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])

    def test_actual_buyer_message_with_string_chat_id_enters_ready_once(self):
        self.capture()
        message = self.interfaces.Message(
            1, "@recipient123 #ABCD1234", "users-7-12", "buyer", 7,
            "buyer", 12, "", determine_msg_type=False)
        message.type = self.interfaces.MessageTypes.NON_SYSTEM
        event = self.interfaces.NewMessageEvent("offline", message)
        bot.on_new_message(self.c, event)
        bot.on_new_message(self.c, event)
        self.assertEqual(self.store.get("ABCD1234")["status"], "ready")
        bot.process_ready(self.c)
        bot.process_ready(self.c)
        self.assertEqual(len(self.api.created), 1)
        self.assertEqual(self.store.get("ABCD1234")["status"], "completed")

    def test_actual_closed_event_during_preparing_blocks_purchase(self):
        self.ready()
        def close():
            self.c.account.order.status = self.interfaces.OrderStatuses.CLOSED
            event = self.interfaces.OrderStatusChangedEvent("offline", shortcut(
                self.interfaces, status=self.interfaces.OrderStatuses.CLOSED))
            bot.on_order_status_change(self.c, event)
        self.api.before_post = close
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])

    def test_explicit_dryrun_quote_simulates_without_api_and_cannot_turn_live(self):
        bot.CFG.update(mode="dry_run", capture_paid_orders_in_dry_run=True, dry_run_price_usd="0.0152")
        self.ready()
        with patch.object(bot, "client", side_effect=AssertionError("A simulation cannot contact supplier")):
            bot.simulate_ready(self.c)
        row = self.store.get("ABCD1234")
        self.assertEqual(row["status"], "simulated")
        self.assertIsNone(row["supplier_uuid"])
        self.assertIsNone(row["quoted_usd"])
        self.assertEqual(self.store.today_spend(), Decimal(0))
        bot.CFG["mode"] = "live"
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])
        self.assertEqual(self.store.get("ABCD1234")["status"], "simulated")

    def test_dryrun_ready_origin_persists_and_cannot_buy_after_live_switch(self):
        bot.CFG.update(mode="dry_run", capture_paid_orders_in_dry_run=True, dry_run_price_usd=None)
        self.ready()
        self.assertEqual(self.store.get("ABCD1234")["captured_mode"], "dry_run")
        bot.simulate_ready(self.c)
        self.assertEqual(self.store.get("ABCD1234")["status"], "ready")
        # Reopen the database to prove the restriction survives a process restart.
        bot.STORE = self.store = Store(Path(self.temp.name) / "orders.sqlite3")
        self.store.set_meta("paused", "no")
        bot.CFG["mode"] = "live"
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])
        self.assertEqual(self.store.get("ABCD1234")["captured_mode"], "dry_run")
        self.assertIsNone(self.store.get("ABCD1234")["supplier_uuid"])

    def test_dryrun_awaiting_origin_cannot_buy_after_reply_in_live_mode(self):
        bot.CFG.update(mode="dry_run", capture_paid_orders_in_dry_run=True, dry_run_price_usd=None)
        self.assertIsNotNone(self.capture())
        self.assertEqual(self.store.get("ABCD1234")["status"], "awaiting_username")
        bot.CFG["mode"] = "live"
        message = self.interfaces.Message(
            1, "@recipient123 #ABCD1234", "users-7-12", "buyer", 7,
            "buyer", 12, "", determine_msg_type=False)
        message.type = self.interfaces.MessageTypes.NON_SYSTEM
        bot.on_new_message(self.c, self.interfaces.NewMessageEvent("offline", message))
        bot.process_ready(self.c)
        self.assertEqual(self.api.created, [])
        self.assertEqual(self.store.get("ABCD1234")["captured_mode"], "dry_run")
        self.assertIsNone(self.store.get("ABCD1234")["supplier_uuid"])

    def test_fresh_live_origin_remains_eligible_for_one_purchase(self):
        self.ready()
        self.assertEqual(self.store.get("ABCD1234")["captured_mode"], "live")
        bot.process_ready(self.c)
        bot.process_ready(self.c)
        self.assertEqual(len(self.api.created), 1)
        self.assertEqual(self.store.get("ABCD1234")["status"], "completed")

    def test_refund_racing_stale_preparing_snapshot_blocks_order_before_post(self):
        self.ready()
        original_get = self.store.get
        raced = False
        def stale_snapshot(oid):
            nonlocal raced
            row = original_get(oid)
            if not raced and row and row["status"] == "preparing":
                raced = True
                self.assertTrue(self.store.reserve_submission(oid, "0.7600", "20", "30"))
            return row
        def refund():
            event = self.interfaces.OrderStatusChangedEvent("offline", shortcut(
                self.interfaces, status=self.interfaces.OrderStatuses.REFUNDED))
            with patch.object(self.store, "get", side_effect=stale_snapshot):
                bot.on_order_status_change(self.c, event)
        self.api.before_post = refund
        bot.process_ready(self.c)
        row = original_get("ABCD1234")
        self.assertTrue(raced)
        self.assertFalse(bot.paused())
        self.assertNotEqual(row["status"], "cancelled")
        self.assertEqual(Decimal(row["quoted_usd"]), Decimal("0.7600"))
        self.assertEqual(self.api.created, [])

    def test_refund_error_review_closed_require_review_until_exact_refunded(self):
        self.api.status = "processing"
        self.ready()
        bot.process_ready(self.c)
        self.assertEqual(len(self.api.created), 1)
        for status in ("refund", "error", "review", "closed", "delivered", "unknown"):
            with self.subTest(status=status):
                self.api.status = status
                bot.process_pending(self.c, self.store.get("ABCD1234"), api=self.api)
                self.assertEqual(self.store.get("ABCD1234")["status"], "needs_review")
                self.assertFalse(bot.paused())
        self.api.status = "refunded"
        bot.process_pending(self.c, self.store.get("ABCD1234"), api=self.api)
        self.assertEqual(self.store.get("ABCD1234")["status"], "refunded")
        self.assertEqual(len(self.api.created), 1)

    def test_late_actual_charge_updates_profit_cost_budget_once_without_global_pause(self):
        self.api.status = "processing"
        self.ready()
        bot.process_ready(self.c)
        original = self.store.get("ABCD1234")
        self.assertEqual(Decimal(original["quoted_usd"]), Decimal("0.7600"))
        self.assertEqual(self.store.today_spend(), Decimal("0.7600"))
        self.api.charged = "0.90"
        bot.process_pending(self.c, self.store.get("ABCD1234"), api=self.api)
        updated = self.store.get("ABCD1234")
        delta = (Decimal("0.90") - Decimal("0.7600")) * Decimal("88.45")
        self.assertEqual(Decimal(updated["cost_rub"]), Decimal(original["cost_rub"]) + delta)
        self.assertEqual(Decimal(updated["profit_rub"]), Decimal(original["profit_rub"]) - delta)
        self.assertEqual(self.store.today_spend(), Decimal("0.90"))
        self.assertFalse(bot.paused())
        bot.process_pending(self.c, updated, api=self.api)
        repeated = self.store.get("ABCD1234")
        self.assertEqual(repeated["cost_rub"], updated["cost_rub"])
        self.assertEqual(repeated["profit_rub"], updated["profit_rub"])
        self.assertEqual(self.store.today_spend(), Decimal("0.90"))
        self.assertEqual(len(self.api.created), 1)

    def test_invalid_username_racing_cancel_cannot_restore_awaiting_username(self):
        self.ready()
        prior_messages = len(self.c.messages)
        def invalid_username(username):
            self.store.set("ABCD1234", status="cancelled")
            return False
        self.api.check_username = invalid_username
        bot.process_ready(self.c)
        self.assertEqual(self.store.get("ABCD1234")["status"], "cancelled")
        self.assertEqual(len(self.c.messages), prior_messages)
        self.assertEqual(self.api.created, [])


class WorkerLifecycleTests(unittest.TestCase):
    def test_worker_starts_once_and_pre_stop_pauses(self):
        with tempfile.TemporaryDirectory() as temp:
            store = Store(Path(temp) / "state.sqlite3")
            store.set_meta("paused", "no")
            old_store = bot.STORE
            old_worker = getattr(bot, "WORKER", None)
            old_notice_worker = bot.NOTICE_WORKER
            bot.STORE = store
            bot.WORKER = None
            bot.NOTICE_WORKER = None
            bot.STOP.clear()
            fake_thread = N(start=lambda: None, is_alive=lambda: True, join=lambda timeout=None: None)
            try:
                with patch.object(bot.threading, "Thread", return_value=fake_thread) as factory:
                    bot.on_post_start(N())
                    bot.on_post_start(N())
                    self.assertEqual(factory.call_count, 2)
                    self.assertEqual({call.kwargs['name'] for call in factory.call_args_list},
                                     {'STEAMRUStarsWorker','STEAMRUNotifications'})
                    bot.on_pre_stop(N())
                self.assertTrue(bot.STOP.is_set())
                self.assertEqual(store.get_meta("paused"), "yes")
            finally:
                bot.STORE = old_store
                bot.WORKER = old_worker
                bot.NOTICE_WORKER = old_notice_worker
                bot.STOP.clear()


class ClientSafetyIntegrationTests(unittest.TestCase):
    def test_default_client_blocks_create_and_direct_mutating_request_before_transport(self):
        transport = N(request=lambda *args, **kwargs: self.fail("A mutation reached transport"))
        client = SteamClient("offline-key", "offline-secret", session=transport)
        with self.assertRaises(PermissionError):
            client.create("funpay-ABCD1234", "telegram-stars", 55, 50, "recipient123")
        for method in ("POST", "PUT", "PATCH", "DELETE"):
            with self.subTest(method=method), self.assertRaises(PermissionError):
                client.request(method, "/orders", payload={})


if __name__ == "__main__":
    unittest.main()
