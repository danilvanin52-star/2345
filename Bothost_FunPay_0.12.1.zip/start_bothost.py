"""Bothost bootstrap: private persistent state in /app/data, code from Git.

No interactive prompts; no supplier purchase before normal LIVE checks and
the owner's /sr_resume. Staging files are imported exactly once.
"""
import base64
import binascii
import configparser
from contextlib import closing
import importlib.util
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import sqlite3
import sys
import tempfile
import time

from steamru_instance import InstanceLock, AlreadyRunning

SOURCE=Path(__file__).resolve().parent
INPUT_FILES=('steamru_stars_config.json','steamru_stars.sqlite3','tg_authorized_users.json')
STATE_PATHS=('storage/plugins/steamru_stars_config.json','storage/plugins/steamru_stars.sqlite3',
             'storage/cache/tg_authorized_users.json')
CODE_DIRS=('FunPayAPI','Utils','locales','tg_bot','plugins')
CODE_FILES=('main.py','cardinal.py','handlers.py','announcements.py','first_setup.py',
            'steamru_instance.py','start_steamru_live.py','hosting_main_template.json')
REQUIRED_ENV=('BOT_TOKEN','FUNPAY_GOLDEN_KEY','STEAMRU_API_KEY','STEAMRU_API_SECRET',
              'STEAMRU_PARTNER_EMAIL','STEAMRU_PARTNER_PASSWORD','STEAMRU_OWNER_TG_ID')


class HostingSetupError(RuntimeError):
    """Only locally written safe descriptions may be shown to the operator."""


class UploadPending(ValueError):
    """A fixed, non-private explanation of an unreadable staging file."""


def uploaded_bytes(path,kind):
    """Accept native files or one Base64 upload wrapper; never change staging."""
    raw=path.read_bytes()
    candidates=[(raw,False)]
    try:
        candidates.append((base64.b64decode(b''.join(raw.split()),validate=True),True))
    except (ValueError,binascii.Error):
        pass
    for payload,encoded in candidates:
        if kind=='sqlite':
            if payload.startswith(b'SQLite format 3\x00'):
                return payload,encoded
        else:
            try:
                document=json.loads(payload.decode('utf-8-sig'))
            except (UnicodeDecodeError,json.JSONDecodeError):
                continue
            if isinstance(document,dict):
                return document,encoded
    expected='база SQLite' if kind=='sqlite' else 'объект JSON'
    raise UploadPending(path.name+': файл пока не читается; ожидается '+expected+
                        ' или его Base64-копия. Проверь завершение загрузки и сам файл.')


def validate_environment(env):
    missing=[name for name in REQUIRED_ENV if not env.get(name)]
    if missing:raise HostingSetupError('В настройках Bothost заполни: '+', '.join(missing))
    if not env['STEAMRU_OWNER_TG_ID'].isdigit():raise HostingSetupError('STEAMRU_OWNER_TG_ID должен быть числом.')
    if not re.fullmatch(r'[A-Za-z0-9]{32}',env['FUNPAY_GOLDEN_KEY']):
        raise HostingSetupError('Проверь FUNPAY_GOLDEN_KEY: ожидается 32 символа.')
    if '\n' in env['BOT_TOKEN'] or ':' not in env['BOT_TOKEN']:
        raise HostingSetupError('Проверь поле Bot Token.')


def private_write(path, text):
    path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_name(path.name+'.hosting-tmp')
    pending.write_text(text,encoding='utf-8')
    pending.chmod(0o600)
    pending.replace(path)


def validate_owner(authorized,owner):
    if not isinstance(authorized,dict) or owner not in authorized:
        raise HostingSetupError('Telegram ID владельца не совпадает с перенесённой авторизацией.')


def import_state(data,runtime,owner,report=None):
    marker=runtime/'.bothost-imported.json'
    if marker.exists():
        if not all((runtime/name).is_file() for name in STATE_PATHS):
            raise HostingSetupError('Часть сохранённых данных пропала. Восстанови папку data из резервной копии.')
        validate_owner(json.loads((runtime/STATE_PATHS[2]).read_text(encoding='utf-8')),owner)
        return True
    if (runtime/STATE_PATHS[1]).exists():
        raise HostingSetupError('Сохранённая база уже есть, но отметка переноса пропала. Автоматическая замена старым снимком запрещена; восстанови отметку или резервную копию.')
    missing=[name for name in INPUT_FILES if not (data/name).is_file()]
    if missing:
        if report:report('Не найдены файлы переноса в /app/data: '+', '.join(missing))
        return False
    # Validate complete uploaded files before touching the working state.
    try:
        config,config_encoded=uploaded_bytes(data/INPUT_FILES[0],'json')
        authorized,owner_encoded=uploaded_bytes(data/INPUT_FILES[2],'json')
        database,database_encoded=uploaded_bytes(data/INPUT_FILES[1],'sqlite')
        if not isinstance(config,dict) or not config.get('managed_lots'):
            raise HostingSetupError('Загружен пример настроек. Нужны личные настройки из пакета переноса.')
        validate_owner(authorized,owner)
        # Validate an immutable private snapshot, including binary uploads. The
        # user's original three files remain available for recovery/re-upload.
        with tempfile.TemporaryDirectory(prefix='.bothost-import-',dir=data) as folder:
            scratch=Path(folder);scratch.chmod(0o700)
            snapshot=scratch/'state.sqlite3';snapshot.write_bytes(database);snapshot.chmod(0o600)
            with closing(sqlite3.connect('file:'+snapshot.resolve().as_posix()+'?mode=ro',uri=True)) as source:
                try:
                    if source.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                        raise HostingSetupError('Перенесённая база повреждена.')
                    source.execute('SELECT id,status,external_id FROM orders LIMIT 1').fetchall()
                    source.execute('SELECT key,value FROM settings LIMIT 1').fetchall()
                except sqlite3.DatabaseError:
                    raise UploadPending(INPUT_FILES[1]+': база пока не читается или загружена не полностью. '
                                        'Проверь завершение загрузки и исходный файл.') from None
                for name in STATE_PATHS:(runtime/name).parent.mkdir(parents=True,exist_ok=True)
                private_write(runtime/STATE_PATHS[0],json.dumps(config,ensure_ascii=False,indent=2)+'\n')
                private_write(runtime/STATE_PATHS[2],json.dumps(authorized)+'\n')
                target=runtime/STATE_PATHS[1];pending=target.with_name(target.name+'.hosting-tmp')
                with closing(sqlite3.connect(pending)) as destination:
                    source.backup(destination)
            pending.chmod(0o600);pending.replace(target)
            private_write(marker,json.dumps({'schema':1,'imported_at':time.time()})+'\n')
    except UploadPending as exc:
        if report:report(str(exc))
        return False
    encoded=[name for name,wrapped in zip(INPUT_FILES,(config_encoded,database_encoded,owner_encoded)) if wrapped]
    if encoded and report:
        report('Распознан формат загрузки Base64: '+', '.join(encoded)+'. Данные проверены; исходные файлы сохранены.')
    return True


def prepare_code(source,runtime):
    for name in CODE_DIRS:
        shutil.copytree(source/name,runtime/name,dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.before-*'))
    for name in CODE_FILES:shutil.copy2(source/name,runtime/name)
    for name in ('configs','logs','storage/cache','storage/plugins','storage/products'):
        (runtime/name).mkdir(parents=True,exist_ok=True)


def configure_cardinal(source,runtime,env):
    file=runtime/'configs/_main.cfg'
    config=configparser.ConfigParser(delimiters=(':',),interpolation=None)
    config.optionxform=str
    config.read_dict(json.loads((source/'hosting_main_template.json').read_text(encoding='utf-8')))
    if file.exists():config.read(file,encoding='utf-8')
    config['FunPay']['golden_key']=env['FUNPAY_GOLDEN_KEY']
    config['FunPay']['autoRestore']='0';config['FunPay']['autoDelivery']='0'
    config['Telegram']['enabled']='1';config['Telegram']['token']=env['BOT_TOKEN']
    config['Telegram']['blockLogin']='1'
    # Existing owner access comes from the transferred authorization cache.
    # Disable password login; keep an unguessable hash for Cardinal validation.
    if not file.exists():
        import bcrypt
        config['Telegram']['secretKeyHash']=bcrypt.hashpw(secrets.token_bytes(32),bcrypt.gensalt()).decode()
    import io
    output=io.StringIO();config.write(output)
    private_write(file,output.getvalue())


def run_live(runtime):
    sys.path[:0]=[str(runtime),str(runtime/'plugins')]
    spec=importlib.util.spec_from_file_location('bothost_live_entry',runtime/'start_steamru_live.py')
    entry=importlib.util.module_from_spec(spec);spec.loader.exec_module(entry)
    os.environ['FPC_IS_RUNNIG_AS_SERVICE']='0'
    try:
        return entry.run_live()
    finally:
        for name in entry.VARIABLES:os.environ.pop(name,None)
        if entry.pricing.TOPUP_CLIENT is not None:
            entry.pricing.TOPUP_CLIENT.close();entry.pricing.TOPUP_CLIENT=None


def run_host(source=SOURCE,data=None,check_only=False,wait=True,env=None):
    env=os.environ if env is None else env
    validate_environment(env)
    data=Path(data or env.get('FPC_DATA_DIR','/app/data')).resolve()
    data.mkdir(parents=True,exist_ok=True)
    runtime=data/'cardinal';runtime.mkdir(exist_ok=True)
    with InstanceLock(runtime):
        waiting=False
        last_upload_message=None
        def report_upload(message):
            nonlocal last_upload_message
            if message!=last_upload_message:
                print(message,flush=True)
                last_upload_message=message
        while not import_state(data,runtime,env['STEAMRU_OWNER_TG_ID'],report=report_upload):
            if check_only or not wait:
                raise HostingSetupError('Загрузи в /app/data три файла переноса: '+', '.join(INPUT_FILES))
            if not waiting:
                print('Ожидаю перенос. Загрузи в /app/data три файла: '+', '.join(INPUT_FILES),flush=True)
                waiting=True
            time.sleep(10)
        prepare_code(source,runtime)
        configure_cardinal(source,runtime,env)
        if check_only:
            print('Файлы и настройки готовы. Подключений к аккаунтам и покупок не было.')
            return 0
        print('Данные перенесены. Запускаю проверки STEAM.RU; после запуска отправь /sr_resume.',flush=True)
        return run_live(runtime)


def main():
    try:return run_host(check_only='--check' in sys.argv)
    except (HostingSetupError,AlreadyRunning) as exc:
        print(str(exc),flush=True);return 2
    except KeyboardInterrupt:return 0
    except Exception as exc:
        print('Ошибка подготовки хостинга: '+type(exc).__name__+'. Проверь три файла переноса и права папки data.',flush=True)
        return 1


if __name__=='__main__':
    def stop(signum,frame):raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,stop)
    sys.exit(main())
