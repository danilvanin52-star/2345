"""Production-incident regressions with fake HTTP only: no purchases/payments."""
import json
import socket
import ssl
import unittest
from requests.exceptions import ConnectionError, SSLError, Timeout
from aisklad_shop.service import ShopError
from aisklad_shop.web_payments import WebPaymentError, WebPayments
from shop_tests import test_web_payments as web_fixtures
Response, SECRET, BASE = web_fixtures.Response, web_fixtures.SECRET, web_fixtures.BASE


class Recovery0141Tests(unittest.TestCase):
    setUp = web_fixtures.WebPaymentsTests.setUp
    checkout = web_fixtures.WebPaymentsTests.checkout
    event = web_fixtures.WebPaymentsTests.event
    authorize = web_fixtures.WebPaymentsTests.authorize
    count = web_fixtures.WebPaymentsTests.count

    def fail_checkout(self, response):
        self.bridge.response_override = response
        with self.assertRaises(ShopError) as caught:
            self.checkout()
        return caught.exception

    def test_safe_http_codes_and_static_actions_never_capture_body_or_headers(self):
        marker = "PRIVATE-PASSWORD-cookie-api_key-capability-https://hidden/"
        for status, remote, expected in ((403, "shop_bridge_signature_invalid", "BRIDGE_AUTH_ERROR"),
                                         (403, "shop_bridge_time_skew", "BRIDGE_CLOCK_SKEW"),
                                         (404, "shop_route_not_found", "BRIDGE_ROUTE_NOT_FOUND"),
                                         (503, "shop_database_missing", "BRIDGE_REMOTE_DATABASE"),
                                         (503, "shop_payments_disabled", "BRIDGE_REMOTE_DISABLED")):
            response = Response({"error": {"code": remote, "message": marker}, "token": marker}, status)
            response.headers = {"X-Private": marker}
            self.bridge.response_override = response
            with self.assertRaises(WebPaymentError) as caught:
                self.payments.poll_events()
            diagnostic = caught.exception.diagnostic()
            self.assertEqual(expected, diagnostic["code"])
            self.assertEqual(status, diagnostic["http_status"])
            self.assertTrue(diagnostic["action"])
            self.assertNotIn(marker, str(caught.exception) + json.dumps(diagnostic))

    def test_http_html_403_route_404_429_retry_after_5xx(self):
        for status, body, code in ((403, b"<html>private challenge</html>", "BRIDGE_HTTP_FORBIDDEN"),
                                  (404, b"<html>not found</html>", "BRIDGE_ROUTE_NOT_FOUND"),
                                  (429, b"private", "BRIDGE_RATE_LIMIT"),
                                  (502, b"private", "BRIDGE_REMOTE_ERROR")):
            response = Response(body, status); response.headers = {"Retry-After": "120"}
            self.bridge.response_override = response
            with self.assertRaises(WebPaymentError) as caught: self.payments.poll_events()
            self.assertEqual(code, caught.exception.code)
            self.assertEqual(120, caught.exception.retry_after)
            self.assertNotIn("private", str(caught.exception))

    def test_tls_timeout_dns_and_connection_failures_are_distinct_without_exception_text(self):
        original = self.bridge.request
        marker = "https://private.example/#token=VERY-PRIVATE"
        nested = ConnectionError(marker); nested.__cause__ = socket.gaierror(-2, marker)
        for failure, code in ((SSLError(marker), "BRIDGE_TLS_ERROR"), (ssl.SSLEOFError(marker), "BRIDGE_TLS_ERROR"),
                              (Timeout(marker), "BRIDGE_TIMEOUT"), (nested, "BRIDGE_DNS_ERROR"),
                              (ConnectionError(marker), "BRIDGE_CONNECTION_ERROR")):
            def fail(*args, **kwargs): raise failure
            self.bridge.request = fail
            with self.assertRaises(WebPaymentError) as caught: self.payments.poll_events()
            self.assertEqual(code, caught.exception.code)
            self.assertIsNone(caught.exception.status)
            self.assertNotIn(marker, str(caught.exception) + json.dumps(caught.exception.diagnostic()))
        self.bridge.request = original

    def test_preserved_order_error_exposes_id_and_recovery_sends_owned_notification_once(self):
        error = self.fail_checkout(Response({"error": {"code": "shop_bridge_signature_invalid"}}, 403))
        identity = error.order_id
        self.assertEqual("BRIDGE_AUTH_ERROR", error.diagnostic["code"])
        order = self.service.order(100, identity)
        self.assertEqual("invoice_review", order["status"])
        self.assertEqual("configuration_required", order["invoice_recovery_state"])
        self.assertGreater(order["invoice_retry_in_seconds"], 0)
        self.assertEqual(0, self.count("payment_authorizations"))
        self.now += 16
        self.bridge.response_override = None
        before = len(self.bridge.requests)
        retried = self.service.retry_invoice(100, identity)
        self.assertEqual(identity, retried["id"])
        self.assertEqual(before, len(self.bridge.requests))  # button does no HTTP
        self.assertEqual(self.now, self.store.get_setting("bridge:retry_requested_at"))
        self.payments.synchronize(self.service)
        self.payments.synchronize(self.service)
        order = self.service.order(100, identity)
        self.assertEqual("awaiting_payment", order["status"])
        self.assertEqual("registered", order["invoice_recovery_state"])
        self.assertTrue(order["payment_url"])
        events = [e for e in self.service.pending_notifications() if e["user_id"] == 100 and e["payload"].get("order_id") == identity]
        self.assertEqual(1, len(events))
        self.assertNotIn("token", json.dumps(events))
        self.assertNotIn("payment_url", json.dumps(events))
        self.assertEqual(0, self.count("payment_authorizations"))

    def test_retry_owner_check_and_button_throttle(self):
        error = self.fail_checkout(Response({}, 503)); identity = error.order_id
        with self.assertRaises(ShopError): self.service.retry_invoice(101, identity)
        self.assertFalse(self.service.order(100, identity)["invoice_retry_allowed"])
        self.now += 16
        first = self.service.retry_invoice(100, identity)
        stamp = self.store.get_setting("bridge:retry_requested_at")
        self.now += 1
        second = self.service.retry_invoice(100, identity)
        self.assertEqual(stamp, self.store.get_setting("bridge:retry_requested_at"))
        self.assertEqual(first["id"], second["id"])
        self.assertFalse(second["invoice_retry_allowed"])

    def test_expired_unregistered_invoice_stops_automatic_creation_but_retains_history(self):
        self.fail_checkout(Response({}, 503)); order = self.service.orders(100)["items"][0]
        request = order["invoice_request"]
        self.now += 901
        self.bridge.response_override = Response({"error": {"code": "shop_invoice_expired"}}, 410)
        self.service.retry_pending_invoices()
        count = len(self.bridge.requests)
        self.now += 500
        self.service.retry_pending_invoices(); self.service.retry_pending_invoices()
        self.assertEqual(count, len(self.bridge.requests))
        restored = self.service.order(100, order["id"])
        self.assertEqual("expired", restored["invoice_recovery_state"])
        self.assertEqual(request, restored["invoice_request"])
        self.assertEqual("shop:" + order["id"], restored["invoice_id"])
        self.assertEqual(0, self.count("payment_authorizations"))
        self.assertEqual([], self.supplier.posts)

    def test_expired_existing_invoice_can_recover_and_accept_late_original_test_proof(self):
        self.bridge.drop_register_once = True
        with self.assertRaises(ShopError): self.checkout()
        order = self.service.orders(100)["items"][0]
        self.now += 901
        self.service.retry_pending_invoices()
        self.assertEqual("awaiting_payment", self.service.order(100, order["id"])["status"])
        self.authorize(self.event(order))
        self.assertEqual("test_paid", self.service.order(100, order["id"])["status"])
        self.assertEqual(0, self.count("payment_authorizations"))

    def test_explicit_checkout_after_switch_to_live_never_reuses_or_converts_test_invoice(self):
        test = self.checkout()
        self.payments.mode = self.bridge.mode = "live"
        live = self.service.checkout(100)
        self.assertNotEqual(test["id"], live["id"])
        self.assertEqual("test", self.service.order(100, test["id"])["payment_mode"])
        self.assertEqual("live", live["payment_mode"])
        self.authorize(self.event(test))
        self.assertEqual("test_paid", self.service.order(100, test["id"])["status"])
        self.assertEqual(0, self.count("payment_authorizations"))

    def test_diagnostics_owner_notifications_deduplicated_and_no_network_for_local_status(self):
        for _ in range(2):
            self.service.record_payment_diagnostic(WebPaymentError(code="BRIDGE_TLS_ERROR"), next_retry=self.now + 15)
        private = self.service.payment_diagnostics()
        self.assertEqual("BRIDGE_TLS_ERROR", private["payment_health"]["code"])
        self.assertEqual(self.now + 15, private["payment_health"]["next_retry"])
        alerts = [e for e in self.service.pending_notifications() if e["kind"] == "owner:payment"]
        self.assertEqual(1, len(alerts))
        self.service.record_payment_diagnostic()
        self.assertEqual("BRIDGE_OK", self.service.status()["payment_health"]["code"])
        self.assertEqual([], self.bridge.requests)

    def test_200_mode_and_origin_mismatches_are_actionable_not_tls(self):
        request = {"order_id": "A-example", "expires_at": self.now + 900}
        good = {"invoice_id": "shop:A-example", "mode": "test", "expires_at": request["expires_at"], "payment_url": BASE + "/shop/checkout?order_id=A-example#token=" + "x" * 64}
        with self.assertRaises(WebPaymentError) as mode: self.payments._registered(request, {**good, "mode": "live"}, "test")
        self.assertEqual("BRIDGE_MODE_MISMATCH", mode.exception.code)
        with self.assertRaises(WebPaymentError) as origin: self.payments._registered(request, {**good, "payment_url": good["payment_url"].replace("shop.example.test", "other.example.test")}, "test")
        self.assertEqual("BRIDGE_ORIGIN_MISMATCH", origin.exception.code)

    def test_auth_health_returns_only_safe_bounded_schema(self):
        self.bridge.response_override = Response({"ok": True, "version": "0.14.1", "unix_time": self.now, "expected_mode": "live",
            "public_origin": "https://private.example/#token=PRIVATE", "password": "PRIVATE", "configured": {"bridge_secret": True, "database_binding": True, "public_url": True},
            "database": {"ready": True}, "providers": {"robokassa": {"test_ready": True, "live_ready": False}}, "issues": ["shop_payments_disabled", "PRIVATE"], "payments_ready": False})
        result = self.payments.health_check()
        self.assertNotIn("PRIVATE", json.dumps(result))
        self.assertEqual(["shop_payments_disabled"], result["issues"])
        self.assertEqual("live", result["expected_mode"])

    def test_runtime_generic_retry_keeps_specific_http_diagnostic(self):
        self.service.record_payment_diagnostic(WebPaymentError(code="BRIDGE_ROUTE_NOT_FOUND", status=404))
        self.service.record_payment_diagnostic(RuntimeError("Payment synchronization incomplete"), next_retry=self.now + 300)
        self.assertEqual("BRIDGE_ROUTE_NOT_FOUND", self.service.status()["payment_health"]["code"])
        self.assertEqual(404, self.service.status()["payment_health"]["http_status"])
        self.assertEqual(self.now + 300, self.service.status()["payment_health"]["next_retry"])

    def test_supplier_failure_is_cached_safely_for_local_diagnostics(self):
        from plugins.steamru_stars_engine import ApiFailure
        def fail(): raise ApiFailure("api.error", "PRIVATE-SUPPLIER-RESPONSE", 403)
        self.supplier.services = fail
        with self.assertRaises(ShopError): self.service.sync_catalog()
        result = self.service.payment_diagnostics()
        self.assertEqual(403, result["supplier_health"]["http_status"])
        self.assertNotIn("PRIVATE-SUPPLIER-RESPONSE", json.dumps(result))


if __name__ == "__main__": unittest.main()
