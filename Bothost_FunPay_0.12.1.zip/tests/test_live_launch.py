"""LIVE launch and offer lifecycle, using fictitious accounts only."""
from copy import deepcopy
from datetime import datetime, timezone, timedelta
import importlib.util
import io
import json
import os
import sys
from pathlib import Path
import tempfile
from types import SimpleNamespace as N
import unittest
from unittest.mock import patch, Mock

from test_cardinal_compatibility import source_interfaces, full_order, shortcut, definitions, SOURCE
from test_safety_integration import Cardinal, API
import steamru_stars as bot
from steamru_stars_engine import Store, effective_exchange_rate, D
from steamru_instance import InstanceLock

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('live_entry_test', ROOT / 'start_steamru_live.py')
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


def rules():
    return {f'stars{n}': {'subcategory_id': 2418, 'stars_per_unit': n,
                         'match_fields': {'quantity': f'{n} звёзд', 'quantity2': '', 'method': 'По username'}}
            for n in (50, 100, 150)}


def config():
    return {**bot.DEFAULT, 'mode': 'live', 'allowed_subcategory_ids': [2418],
            'lot_rules': rules(), 'lots': {}, 'managed_lots': {'101': 'stars50', '102': 'stars100', '103': 'stars150'},
            'lot_ids_to_disable': [101, 102, 103], 'activate_lots_on_resume': True,
            'auto_disable_lots_on_pause': True, 'min_margin_pct': '4', 'wallet_paid_rub': '521.01',
            'wallet_credited_usd': '5.96', 'rub_per_usd': str(effective_exchange_rate('521.01', '5.96')),
            'rub_per_usd_updated_at': datetime.now(timezone.utc).isoformat(), 'funding_rate_policy': 'deposit_cost'}


class OfferLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.types = source_interfaces()
        definitions(SOURCE / 'FunPayAPI/types.py', ['LotFields'], cls.types.__dict__)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old = bot.CFG, bot.STORE, bot.WORKER, bot.C, bot.CFG_PATH
        bot.CFG_PATH = Path(self.temp.name) / 'cfg.json'
        bot.CFG = config()
        bot.STORE = Store(Path(self.temp.name) / 'state.sqlite3')
        bot.WORKER = N(is_alive=lambda: True)
        bot.C = None
        bot.STOP.clear()
        self.c = Cardinal(full_order(self.types, title='', subcategory_id=2418))
        self.c.autorestore_enabled = False
        self.c.autodelivery_enabled = False
        self.c.runner = N(saved_orders={}, make_order_requests=True, make_msg_requests=True)
        self.offers = {}
        self.saves = []
        self.fail_offer = None
        for offer, n, price in ((101, 50, '72'), (102, 100, '145'), (103, 150, '220')):
            self.offers[offer] = self.types.LotFields(offer,
                {'price': price, 'fields[quantity]': f'{n} звёзд', 'fields[quantity2]': '',
                 'fields[method]': 'По username', 'active': ''},
                subcategory=self.c.account.order.subcategory, currency=self.types.Currency.RUB)
        self.c.account.get_lot_fields = lambda offer, **kwargs: deepcopy(self.offers[offer])
        self.c.account.save_lot = self.save
        self.api = API()
        self.api.balance = lambda: D('5.96')
        self.client = patch.object(bot, 'client', return_value=self.api)
        self.client_mock = self.client.start()
        self.env = patch.dict(os.environ, {'STEAMRU_API_KEY': 'FAKEKEY', 'STEAMRU_API_SECRET': 'FAKESECRET',
                                          'STEAMRU_OWNER_TG_ID': '123',
                                          'STEAMRU_LIVE_CONFIRM': 'I_ACCEPT_REAL_PURCHASES'}, clear=True)
        self.env.start()

    def tearDown(self):
        self.env.stop(); self.client.stop()
        bot.CFG, bot.STORE, bot.WORKER, bot.C, bot.CFG_PATH = self.old
        bot.STOP.clear()
        self.temp.cleanup()

    def save(self, fields):
        if fields.active and fields.lot_id == self.fail_offer:
            raise RuntimeError('Fictitious activation failure')
        self.saves.append((fields.lot_id, fields.active))
        self.offers[fields.lot_id] = deepcopy(fields)

    def assert_closed(self):
        self.assertTrue(bot.paused())
        self.assertFalse(any(lot.active for lot in self.offers.values()))
        self.assertEqual(self.api.created, [])

    def test_resume_reads_catalog_and_opens_all_three_without_supplier_post(self):
        self.assertEqual(bot.resume_live(self.c), 3)
        self.assertFalse(bot.paused())
        self.assertTrue(all(lot.active for lot in self.offers.values()))
        self.assertEqual(self.api.created, [])
        self.client_mock.assert_called_with()  # readonly default

    def test_insufficient_margin_rolls_back_and_never_buys(self):
        self.offers[101].price = 68
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()

    def test_insufficient_balance_refuses_opening(self):
        self.api.balance = lambda: D('2')
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()

    def test_changed_package_fields_refuse_opening(self):
        self.offers[102].fields['fields[quantity]'] = '500 звёзд'
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()

    def test_currency_mismatch_refuses_opening(self):
        self.offers[103].currency = self.types.Currency.USD
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()

    def test_partial_activation_failure_closes_already_opened_lot(self):
        self.fail_offer = 102
        with self.assertRaises(RuntimeError):
            bot.resume_live(self.c)
        self.assertIn((101, True), self.saves)
        self.assertIn((101, False), self.saves)
        self.assert_closed()

    def test_pause_during_readiness_check_cancels_activation(self):
        def interrupt():
            bot.STORE.set_meta('resume_token', '')
            bot.STORE.set_meta('paused', 'yes')
            return D('5.96')
        self.api.balance = interrupt
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()
        self.assertFalse(any(active for offer, active in self.saves))

    def test_missing_worker_refuses_opening(self):
        bot.WORKER = None
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()

    def test_initial_order_history_must_load_before_offers_open(self):
        self.c.runner.saved_orders = None
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()
        self.client_mock.assert_not_called()

    def test_balance_increase_requires_rechecking_funding_cost(self):
        bot.STORE.set_meta('last_checked_balance', '5.20')
        with self.assertRaises(ValueError):
            bot.resume_live(self.c)
        self.assert_closed()

    def test_deposit_cost_does_not_expire_after_midnight(self):
        bot.CFG['rub_per_usd_updated_at'] = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
        self.assertTrue(bot.live_allowed())
        self.assertEqual(bot.resume_live(self.c), 3)

    def test_dated_rate_retains_original_expiration_guard(self):
        bot.CFG['funding_rate_policy'] = 'dated'
        bot.CFG['rub_per_usd_updated_at'] = (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
        self.assertFalse(bot.live_allowed())

    def test_future_or_mismatched_deposit_cost_is_rejected(self):
        bot.CFG['rub_per_usd_updated_at'] = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        self.assertFalse(bot.live_allowed())
        bot.CFG['rub_per_usd_updated_at'] = datetime.now(timezone.utc).isoformat()
        bot.CFG['rub_per_usd'] = '1'
        self.assertFalse(bot.live_allowed())

    def test_single_periodic_health_failure_keeps_global_sales_running(self):
        bot.resume_live(self.c)
        self.api.balance = lambda: D('0')
        bot.STORE.set_meta('last_health_check', '0')
        with patch.object(bot.STOP, 'wait', side_effect=[False, True]):
            bot.worker(self.c)
        self.assertFalse(bot.paused())
        self.assertTrue(all(lot.active for lot in self.offers.values()))

    def test_owner_pause_command_closes_lots(self):
        bot.resume_live(self.c)
        handlers = {}
        fake_bot = N(reply_to=lambda *args: None)
        self.c.telegram = N(bot=fake_bot, authorized_users={'123': {}},
            msg_handler=lambda handler, commands: handlers.update({commands[0]: handler}))
        self.c.add_telegram_commands = lambda *args: None
        bot.on_pre_init(self.c)
        handlers['sr_pause'](N(from_user=N(id=123), chat=N(type='private')))
        self.assert_closed()

    def telegram_handlers(self):
        handlers={};replies=Mock()
        self.c.telegram=N(bot=N(reply_to=replies),authorized_users={'123':{}},
            msg_handler=lambda handler,commands:handlers.update({commands[0]:handler}))
        self.c.add_telegram_commands=lambda *args:None
        bot.on_pre_init(self.c)
        return handlers,replies,N(from_user=N(id=123),chat=N(type='private'),text='/sr_resume')

    def test_duplicate_resume_starts_only_one_job_and_status_remains_available(self):
        handlers,replies,message=self.telegram_handlers()
        with patch.object(bot.threading,'Thread') as thread:
            handlers['sr_resume'](message)
            handlers['sr_resume'](message)
            handlers['sr_status'](message)
            self.assertEqual(thread.call_count,1)
            self.assertTrue(bot.RESUME_TASK_LOCK.locked())
            thread.call_args.kwargs['target']()
        self.assertFalse(bot.RESUME_TASK_LOCK.locked())
        self.assertFalse(bot.paused());self.assertEqual(self.api.created,[])
        self.assertTrue(any('Запуск уже идёт' in c.args[1] for c in replies.call_args_list))

    def test_pause_before_background_job_cannot_be_overridden_by_resume(self):
        handlers,replies,message=self.telegram_handlers()
        with patch.object(bot.threading,'Thread') as thread:
            handlers['sr_resume'](message)
            handlers['sr_pause'](message)
            thread.call_args.kwargs['target']()
        self.assertFalse(bot.RESUME_TASK_LOCK.locked());self.assert_closed()
        self.assertFalse(any(active for _,active in self.saves))

    def test_catalog_import_failure_does_not_cancel_resume_or_pause_sales(self):
        bot.CFG['catalog_sync']={**bot.DEFAULT['catalog_sync'],'enabled':True}
        bot.STORE.set_meta('resume_token','IN_PROGRESS')
        with patch.object(bot,'sync_catalog',side_effect=ValueError('No new form')), \
             patch.object(bot,'critical') as critical, \
             patch.object(bot.STOP,'wait',side_effect=[False,True]):
            bot.maintenance_worker(self.c)
        critical.assert_not_called()
        self.assertEqual(bot.STORE.get_meta('resume_token'),'IN_PROGRESS')
        self.assertTrue(float(bot.STORE.get_meta('next_catalog_sync'))>bot.time.time()+1700)

    def test_repeated_paid_events_for_each_pack_produce_one_fictitious_purchase(self):
        bot.resume_live(self.c)
        for count, price in ((50, '72'), (100, '145'), (150, '220')):
            oid = f'LIVE{count}'
            order = full_order(self.types, oid=oid, title='', subcategory_id=2418, amount=None)
            order.sum = D(price)
            order.fields = {key: self.types.LotField(key, value)
                            for key, value in rules()[f'stars{count}']['match_fields'].items()}
            self.c.account.order = order
            preview = shortcut(self.types, oid=oid, description='Stars')
            preview.subcategory.id = 2418
            event = self.types.NewOrderEvent('offline', preview)
            bot.on_new_order(self.c, event); bot.on_new_order(self.c, event)
            self.assertTrue(bot.STORE.set_username(oid, 12, 'users-7-12', 'recipient123'))
            self.api.charged = str(D('0.0152') * count)
            bot.process_ready(self.c); bot.process_ready(self.c)
            self.assertEqual(bot.STORE.get(oid)['status'], 'completed')
        self.assertEqual(len(self.api.created), 3)
        self.assertEqual([call[3] for call in self.api.created], [50, 100, 150])

    def test_invalid_new_paid_order_fields_hold_only_this_order(self):
        bot.resume_live(self.c)
        order = self.c.account.order
        order.fields = {'quantity': self.types.LotField('quantity', '500 звёзд')}
        preview = shortcut(self.types, description='Stars')
        preview.subcategory.id = 2418
        bot.on_new_order(self.c, self.types.NewOrderEvent('offline', preview))
        self.assertFalse(bot.paused())
        self.assertIsNone(bot.STORE.get(order.id))
        self.assertTrue(any(lot.active for lot in self.offers.values()))


class LiveEntryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for folder in ('configs', 'storage/plugins', 'storage/cache'):
            (self.root / folder).mkdir(parents=True)
        self.cfg_path = self.root / 'storage/plugins/steamru_stars_config.json'
        self.cfg_path.write_text(json.dumps(config()))
        (self.root / 'configs/_main.cfg').write_text('[FunPay]\nautoRestore: 0\nautoDelivery: 0\n')
        (self.root / 'storage/cache/tg_authorized_users.json').write_text('{"123": {}}')
        self.old_cwd = Path.cwd()
        self.root_patch = patch.object(entry, 'ROOT', self.root)
        self.root_patch.start()
        self.env_patch = patch.dict(os.environ, {}, clear=True)
        self.env_patch.start()

    def tearDown(self):
        os.chdir(self.old_cwd)
        self.root_patch.stop(); self.env_patch.stop()
        self.temp.cleanup()

    def test_dry_run_config_refuses_live_before_secrets_or_network(self):
        self.cfg_path.write_text(json.dumps({**config(), 'mode': 'dry_run'}))
        with patch.object(entry.getpass, 'getpass') as secrets, patch.object(entry, 'SteamClient') as api, patch('sys.stdout', new=io.StringIO()):
            self.assertEqual(entry.main(), 2)
        secrets.assert_not_called(); api.assert_not_called()

    def test_partner_failure_records_precise_stage_without_any_secrets(self):
        cfg=config();cfg['auto_pricing']={**bot.DEFAULT['auto_pricing'],'enabled':True,'watch_topup_rate':True}
        self.cfg_path.write_text(json.dumps(cfg))
        partner=N(trace=[{'method':'POST','path':'/login','status':302}],
                  refresh=Mock(side_effect=entry.pricing.PartnerFailure('login_denied',302)),close=Mock())
        with patch.object(entry.getpass,'getpass',side_effect=['TEST_KEY','TEST_SECRET','PRIVATE_EMAIL','PRIVATE_PASSWORD']), \
             patch.object(entry,'SteamClient') as api,patch.object(entry.pricing,'PartnerTopupClient',return_value=partner), \
             patch.object(entry.runpy,'run_path') as run,patch('sys.stdout',new=io.StringIO()) as output:
            api.return_value.account.return_value={'balance':'5.96'}
            api.return_value.product.return_value={'price_usd':'0.0152'}
            self.assertEqual(entry.main(),1);run.assert_not_called()
            self.assertIn('HTTP 302',output.getvalue())
        diagnostic=json.loads((self.root/'storage/plugins/steamru_startup_diagnostic.json').read_text())
        self.assertEqual(diagnostic['stage'],'partner_login_and_rate')
        self.assertEqual(diagnostic['partner_error_code'],'login_denied')
        for secret in ('TEST_KEY','TEST_SECRET','PRIVATE_EMAIL','PRIVATE_PASSWORD'):
            self.assertNotIn(secret,output.getvalue())
            for path in self.root.rglob('*'):
                if path.is_file():self.assertNotIn(secret.encode(),path.read_bytes())
        partner.close.assert_called_once()

    def test_autorestore_refuses_start_before_secrets(self):
        (self.root / 'configs/_main.cfg').write_text('[FunPay]\nautoRestore: 1\nautoDelivery: 0\n')
        with patch.object(entry.getpass, 'getpass') as secrets, patch('sys.stdout', new=io.StringIO()):
            self.assertEqual(entry.main(), 2)
        secrets.assert_not_called()

    def test_live_start_passes_confirmation_only_to_process_and_does_not_purchase(self):
        def app(*args, **kwargs):
            self.assertEqual(os.environ['STEAMRU_LIVE_CONFIRM'], 'I_ACCEPT_REAL_PURCHASES')
            self.assertEqual(os.environ['STEAMRU_API_KEY'], 'TEST_KEY')
        with patch.object(entry.getpass, 'getpass', side_effect=['TEST_KEY', 'TEST_SECRET']), \
             patch.object(entry, 'SteamClient') as api, \
             patch.object(entry.runpy, 'run_path', side_effect=app) as run, \
             patch('sys.stdout', new=io.StringIO()) as output:
            api.return_value.account.return_value = {'balance': '5.96'}
            api.return_value.product.return_value = {'price_usd': '0.0152'}
            self.assertEqual(entry.main(), 0)
            run.assert_called_once()
            api.assert_called_once_with('TEST_KEY', 'TEST_SECRET')
            api.return_value.create.assert_not_called()
            self.assertNotIn('TEST_KEY', output.getvalue())
            self.assertNotIn('TEST_SECRET', output.getvalue())
        for path in self.root.rglob('*'):
            if path.is_file():
                self.assertNotIn(b'TEST_SECRET', path.read_bytes())
                self.assertNotIn(b'TEST_KEY', path.read_bytes())
        self.assertFalse(any(name in os.environ for name in entry.VARIABLES))

    def test_insufficient_balance_does_not_start_cardinal(self):
        with patch.object(entry.getpass, 'getpass', side_effect=['TEST_KEY', 'TEST_SECRET']), \
             patch.object(entry, 'SteamClient') as api, patch.object(entry.runpy, 'run_path') as run, \
             patch('sys.stdout', new=io.StringIO()):
            api.return_value.account.return_value = {'balance': '1'}
            api.return_value.product.return_value = {'price_usd': '0.0152'}
            self.assertEqual(entry.main(), 1)
            run.assert_not_called()

    def test_shared_lock_blocks_second_instance_and_releases_after_exit(self):
        with InstanceLock(self.root):
            with patch.object(entry.getpass, 'getpass') as secrets, patch('sys.stdout', new=io.StringIO()):
                self.assertEqual(entry.main(), 2)
            secrets.assert_not_called()
        with InstanceLock(self.root):
            pass

    def test_cardinal_exit_stops_loaded_plugin_and_cleans_process_keys(self):
        loaded = N(C=N(), on_pre_stop=lambda c: cleanup.append(c))
        cleanup = []
        with patch.dict(sys.modules, {'plugins.steamru_stars': loaded}), \
             patch.object(entry.getpass, 'getpass', side_effect=['TEST_KEY', 'TEST_SECRET']), \
             patch.object(entry, 'SteamClient') as api, \
             patch.object(entry.runpy, 'run_path', side_effect=SystemExit(0)), \
             patch('sys.stdout', new=io.StringIO()):
            api.return_value.account.return_value = {'balance': '5.96'}
            api.return_value.product.return_value = {'price_usd': '0.0152'}
            with self.assertRaises(SystemExit):
                entry.main()
        self.assertEqual(cleanup, [loaded.C])
        self.assertFalse(any(name in os.environ for name in entry.VARIABLES))


if __name__ == '__main__':
    unittest.main()
