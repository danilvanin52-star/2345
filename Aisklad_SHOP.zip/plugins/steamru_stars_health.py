# noplug — consecutive failure policy; individual unsafe orders remain blocked.
import json
import threading
import time

LOCK = threading.RLock()
PREFIX = 'failure_streak:'


def label(scope):
    if scope.startswith('supplier:'):
        return 'проверка заказа #' + scope.split(':',1)[1]
    return {'processing':'обработка','purchase':'закупка','capture':'чтение оплат',
            'maintenance':'каталог и цены','offer_health':'проверка лотов',
            'live_access':'доступ и курс','worker':'обработка заказов'}.get(scope,scope)


def safe_notice(bot, c, message, **kwargs):
    try:
        return bot.notifications.notify(bot, c, message, **kwargs)
    except Exception as exc:
        bot.LOG.warning('Уведомление сохранено не было: %s', type(exc).__name__)


def success(bot, scope):
    if bot.STORE is None:
        return
    key = PREFIX + scope
    with LOCK:
        previous = json.loads(bot.STORE.get_meta(key, '{}'))
        if previous.get('count'):
            bot.STORE.set_meta(key, json.dumps({'count': 0, 'generation': previous.get('generation', 0) + 1}))


def reset_all(bot):
    with bot.STORE.conn() as db:
        scopes = [row['key'][len(PREFIX):] for row in db.execute(
            'SELECT key FROM settings WHERE key LIKE ?', (PREFIX + '%',))]
    for scope in scopes:
        success(bot, scope)
        try:
            # An explicit successful /sr_resume resolves shop-wide stop alarms.
            # Individual uncertain purchases/help incidents remain untouched.
            bot.notifications.resolve(bot, 'SYSTEM_' + scope.replace(':', '_'))
        except Exception as exc:
            bot.LOG.warning('Не удалось закрыть системное уведомление: %s',type(exc).__name__)


def failure(bot, c, message, scope='processing', urgent=False, incident=None):
    """Only a seventh consecutive failure pauses the whole shop.

    A successful operation resets its own stream, not unrelated failures.
    Database transitions precede optional notifications. Never retries a POST.
    """
    limit = int(bot.CFG.get('consecutive_error_limit', 7))
    key = PREFIX + scope
    now = time.time()
    with LOCK:
        state = json.loads(bot.STORE.get_meta(key, '{}'))
        count = min(limit, int(state.get('count', 0)) + 1)
        stop_now = count >= limit and not state.get('tripped', False)
        generation = state.get('generation', 0)
        state.update(count=count, tripped=bool(stop_now or state.get('tripped')),
                     generation=generation, last_at=now, message=str(message))
        warn_now = count == 1 or stop_now or (state['tripped'] and now - float(state.get('last_warning_at', 0)) >= 900)
        if warn_now:
            state['last_warning_at'] = now
        # Persist the decision before attempting to queue any Telegram message.
        with bot.STORE.lock, bot.STORE.conn() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)', (key, json.dumps(state)))
            if stop_now and bot.CFG.get('pause_on_critical_error', True):
                db.executemany('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',
                               [('paused', 'yes'), ('resume_token', '')])
            db.execute('COMMIT')
    log = bot.LOG.warning if warn_now else bot.LOG.debug
    log('Сбой %s: %s/%s — %s', scope, count, limit, message)
    if stop_now and bot.CFG.get('pause_on_critical_error', True):
        try:
            if bot.CFG.get('auto_disable_lots_on_pause'):
                bot.disable_managed_lots(c)
        except Exception as exc:
            bot.LOG.warning('Не все лоты удалось выключить: %s', type(exc).__name__)
        safe_notice(bot, c, f'⛔ Продажи остановлены: {limit} ошибок подряд ({label(scope)}).\n{message}',
                    urgent=True, incident='SYSTEM_' + scope.replace(':', '_'),
                    dedup_key=f'failure-stop:{scope}:{generation}')
    elif count == 1 or urgent:
        safe_notice(bot, c, f'⚠️ {message}\nПорог общей автоматической паузы: {limit} ошибок подряд.',
                    urgent=urgent, incident=incident,
                    dedup_key=f'failure:{scope}:{generation}:{incident or "first"}')
    return count


def order_issue(bot, c, oid, message):
    """Unsupported/invalid buyer data affect this order only, never the streak."""
    bot.LOG.warning('Заказ #%s требует проверки: %s', oid, message)
    safe_notice(bot, c, f'⚠️ Заказ #{oid}: {message}. Автовыдача этого заказа не начата; остальные продажи работают.',
                dedup_key='order-validation:' + str(oid), incident=str(oid))


def summary(bot):
    with bot.STORE.conn() as db:
        rows = db.execute('SELECT key,value FROM settings WHERE key LIKE ?', (PREFIX + '%',)).fetchall()
    counts = [(r['key'][len(PREFIX):], json.loads(r['value']).get('count', 0)) for r in rows]
    counts = [(name, count) for name, count in counts if count]
    limit = int(bot.CFG.get('consecutive_error_limit', 7))
    return ', '.join(f'{label(name)}: {count}/{limit}' for name, count in counts[:5]) or f'0/{limit}'
