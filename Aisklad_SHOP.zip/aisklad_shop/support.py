"""The same durable support-reply command works in both owner chat surfaces."""
import hashlib
import json
import re
import time


def queue_reply(store,owner_id,actor_id,arguments):
    if not owner_id or int(actor_id)!=int(owner_id):
        return 'Эта команда доступна владельцу. Поддержка магазина — /help.'
    ticket,separator,text=str(arguments).partition(' ')
    text=text.strip()
    if (not separator or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',ticket) or not 1<=len(text)<=2000
            or any(ord(ch)<32 and ch not in '\n\t' for ch in text)):
        return ('Ответ покупателю: <code>/shop_reply НОМЕР_ОБРАЩЕНИЯ текст ответа</code>\n'
                'От 1 до 2000 символов. Номер указан в уведомлении о помощи.')
    digest=hashlib.sha256((ticket+'\x00'+text).encode('utf-8')).hexdigest()
    dedupe='support_reply:'+ticket+':'+digest
    payload={'ticket_id':ticket,'text':'💬 Поддержка Aisklad SHOP\nОбращение '+ticket+'\n\n'+text}
    with store.connection(immediate=True) as db:
        row=db.execute('SELECT user_id FROM support WHERE id=?',(ticket,)).fetchone()
        if row is None:found,inserted=False,False
        else:
            target=int(row['user_id'])
            if target<=0:raise ValueError('Invalid support destination')
            cursor=db.execute('INSERT OR IGNORE INTO outbox(dedupe,user_id,kind,payload,created_at) VALUES(?,?,?,?,?)',
                              (dedupe,target,'support_reply',json.dumps(payload,ensure_ascii=False,separators=(',',':')),time.time()))
            found,inserted=True,cursor.rowcount==1
    if not found:return 'Обращение не найдено. Скопируй номер из уведомления о помощи и повтори команду.'
    if inserted:return '💜 Ответ сохранён и будет доставлен покупателю. Статус заказов и оплаты не изменён.'
    return 'Этот ответ уже сохранён. Повторное сообщение покупателю не создавалось.'
