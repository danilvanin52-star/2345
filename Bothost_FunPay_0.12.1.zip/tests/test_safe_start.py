import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("safe_start", ROOT / "start_steamru.py")
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


class SafeStartTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for folder in ("configs", "storage/plugins", "storage/cache"):
            (self.root / folder).mkdir(parents=True, exist_ok=True)
        (self.root / "configs/_main.cfg").write_text("", encoding="utf-8")
        self.config_path = self.root / "storage/plugins/steamru_stars_config.json"
        self.config_path.write_text(json.dumps({"mode": "dry_run", "capture_paid_orders_in_dry_run": False}))
        (self.root / "storage/cache/tg_authorized_users.json").write_text('{"123": {}}')
        self.original_cwd = Path.cwd()
        self.root_patch = patch.object(launcher, "ROOT", self.root)
        self.env_patch = patch.dict(os.environ, {}, clear=True)
        self.root_patch.start(); self.env_patch.start()

    def tearDown(self):
        os.chdir(self.original_cwd)
        self.root_patch.stop(); self.env_patch.stop()
        self.temp.cleanup()

    def test_live_mode_is_rejected_before_credentials_or_network(self):
        self.config_path.write_text('{"mode":"live","capture_paid_orders_in_dry_run":false}')
        os.environ["STEAMRU_LIVE_CONFIRM"] = "I_ACCEPT_REAL_PURCHASES"
        with patch.object(launcher.getpass, "getpass") as secret_input, patch.object(launcher, "SteamClient") as api, patch("sys.stdout", new=io.StringIO()):
            self.assertEqual(launcher.main(), 2)
        secret_input.assert_not_called(); api.assert_not_called()
        self.assertNotIn("STEAMRU_LIVE_CONFIRM", os.environ)

    def test_missing_authorized_owner_does_not_ask_for_api_secrets(self):
        (self.root / "storage/cache/tg_authorized_users.json").write_text('{}')
        with patch.object(launcher.getpass, "getpass") as secret_input, patch.object(launcher, "SteamClient") as api, patch("sys.stdout", new=io.StringIO()):
            self.assertEqual(launcher.main(), 2)
        secret_input.assert_not_called(); api.assert_not_called()

    def test_credentials_are_process_only_and_cardinal_starts_without_live_confirmation(self):
        key, secret = "FAKE_KEY_FOR_TEST", "FAKE_SECRET_FOR_TEST"
        os.environ["STEAMRU_LIVE_CONFIRM"] = "I_ACCEPT_REAL_PURCHASES"
        def fake_main(*args, **kwargs):
            self.assertEqual(os.environ["STEAMRU_API_KEY"], key)
            self.assertEqual(os.environ["STEAMRU_API_SECRET"], secret)
            self.assertEqual(os.environ["STEAMRU_OWNER_TG_ID"], "123")
            self.assertNotIn("STEAMRU_LIVE_CONFIRM", os.environ)
        with patch.object(launcher.getpass, "getpass", side_effect=[key, secret]), \
             patch.object(launcher, "SteamClient") as api, \
             patch.object(launcher.runpy, "run_path", side_effect=fake_main) as app, \
             patch("sys.stdout", new=io.StringIO()) as output:
            api.return_value.account.return_value = {"balance": "5.96"}
            api.return_value.product.return_value = {"price_usd": "0.0152", "min_count": 50, "max_count": 999999}
            self.assertEqual(launcher.main(), 0)
            app.assert_called_once()
            api.assert_called_once_with(key, secret)  # allow_purchases remains False.
            self.assertNotIn(key, output.getvalue()); self.assertNotIn(secret, output.getvalue())
        for path in self.root.rglob('*'):
            if path.is_file():
                self.assertNotIn(key, path.read_text()); self.assertNotIn(secret, path.read_text())
        self.assertNotIn("STEAMRU_API_KEY", os.environ)
        self.assertNotIn("STEAMRU_API_SECRET", os.environ)

    def test_catalog_error_does_not_start_cardinal_or_leak_keys(self):
        with patch.object(launcher.getpass, "getpass", side_effect=["FAKEKEY", "FAKESECRET"]), \
             patch.object(launcher, "SteamClient") as api, \
             patch.object(launcher.runpy, "run_path") as app, \
             patch("sys.stdout", new=io.StringIO()) as output:
            api.return_value.account.return_value = {"balance": "5.96"}
            api.return_value.product.side_effect = ValueError("Never echo this: FAKESECRET")
            self.assertEqual(launcher.main(), 1)
            app.assert_not_called()
            self.assertNotIn("FAKESECRET", output.getvalue())
