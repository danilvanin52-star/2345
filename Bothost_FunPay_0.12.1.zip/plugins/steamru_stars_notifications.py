# noplug — durable owner notifications and alarms; never purchases or refunds.
import hashlib
import os
import re
import threading
import time
from html import escape

LOCK = threading.RLock()
LAST_SEND = {}


def prepare(bot):
    with bot.STORE.conn() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS owner_notices (
            id TEXT PRIMARY KEY, message TEXT NOT NULL, order_id TEXT NOT NULL,
            urgent INTEGER NOT NULL, state TEXT NOT NULL DEFAULT 'pending',
            attempts INTEGER NOT NULL DEFAULT 0, next_at REAL NOT NULL DEFAULT 0)''')


def silence_routine_backlog(bot):
    """Keep queued order/money/help notices; retire obsolete activity spam."""
    if bot.CFG.get('activity_report',{}).get('immediate',False):
        return 0
    prepare(bot)
    with LOCK, bot.STORE.conn() as db:
        routine=db.execute("UPDATE owner_notices SET state='suppressed' WHERE state='pending' AND urgent=0 AND message LIKE '🛠 %'")
        retired=routine.rowcount
        invalid=db.execute("""UPDATE owner_notices SET state='suppressed'
            WHERE state IN ('pending','alarm') AND (
                message LIKE '%Неподдерживаемая сумма пополнения Steam%'
                OR message LIKE '%Неподдерживаемое количество или сумма заказа%'
                OR message LIKE '%Сумма звёзд выходит за безопасный лимит%')""")
        return retired+invalid.rowcount


def owner(bot, c):
    tg = getattr(c, 'telegram', None)
    uid = os.getenv('STEAMRU_OWNER_TG_ID', '')
    if tg and uid.isdigit() and uid in {str(i) for i in getattr(tg, 'authorized_users', ())}:
        return tg.bot, int(uid)
    return None


def local_sound():
    if os.name == 'nt':
        try:
            import winsound
            for _ in range(3):
                winsound.Beep(1000, 180)
        except Exception:
            pass


def notify(bot, c, message, urgent=False, dedup_key=None, incident=None):
    if bot.STORE is None:
        return
    prepare(bot)
    match = re.search(r'#([A-Za-z0-9_-]{3,90})', message)
    oid = incident or (match.group(1) if match else '')
    key = hashlib.sha256((dedup_key or (str(bool(urgent)) + ':' + message)).encode()).hexdigest()
    with LOCK, bot.STORE.conn() as db:
        db.execute('INSERT OR IGNORE INTO owner_notices(id,message,order_id,urgent) VALUES(?,?,?,?)',
                   (key, message, oid, int(urgent)))
    # Delivery belongs to a separate worker, independent of catalogue/launch locks.
    return key


def dispatch(bot, c, now=None):
    if bot.STORE is None:
        return
    realtime=now is None
    now = time.time() if realtime else now
    prepare(bot)
    target = owner(bot, c)
    if target and now<float(bot.STORE.get_meta('owner_send_cooldown','0')):return
    with LOCK, bot.STORE.conn() as db:
        rows = db.execute("SELECT * FROM owner_notices WHERE state IN ('pending','alarm') AND next_at<=? ORDER BY urgent DESC,CASE WHEN order_id!='' THEN 0 ELSE 1 END,rowid LIMIT 8", (now,)).fetchall()
        # Claim briefly; slow Telegram requests must not block paid order capture.
        for row in rows:
            db.execute('UPDATE owner_notices SET next_at=? WHERE id=?', (now+120, row['id']))
    for row in rows:
        with LOCK, bot.STORE.conn() as db:
            current = db.execute('SELECT state FROM owner_notices WHERE id=?',(row['id'],)).fetchone()
        if not current or current['state'] not in ('pending','alarm'):
            continue
        urgent = bool(row['urgent'])
        if urgent:
            bot.LOG.warning('ТРЕВОГА STEAM.RU: %s', row['message'])
            local_sound()
        success = False
        if target:
            api, uid = target
            text = ('🚨 НУЖНА ТВОЯ ПОМОЩЬ\n' if urgent else '🔔 STEAM.RU\n') + escape(row['message'])
            if row['order_id'] and not row['order_id'].startswith('HELP_'):
                text += '\n<a href="https://funpay.com/orders/' + row['order_id'] + '/">Открыть заказ FunPay</a>'
            if urgent and row['message'].startswith('🆘'):
                text += '\n\nОстановить напоминания после ответа покупателю: /sr_ack ' + (row['order_id'] or 'all')
            elif urgent:
                text += ('\n\n' + ('Новые продажи на паузе. ' if bot.paused() else '') + 'Повторную покупку вручную не создавай без сверки.'
                         '\nПосле проверки: /sr_ack ' + (row['order_id'] or 'all'))
            try:
                if realtime:
                    delay=max(0,1.1-(time.monotonic()-LAST_SEND.get(uid,0)))
                    stop=getattr(bot,'STOP',None)
                    if delay and (stop.wait(delay) if stop is not None else time.sleep(delay)):
                        break
                    LAST_SEND[uid]=time.monotonic()
                sent = api.send_message(uid, text, parse_mode='HTML', disable_notification=False,
                                        disable_web_page_preview=True, timeout=10)
                success = bool(sent)
                if success and urgent and row['attempts'] == 0:
                    try:
                        api.pin_chat_message(uid, sent.message_id, disable_notification=False)
                    except Exception:
                        bot.LOG.warning('Telegram: тревога отправлена, закрепить не удалось')
            except Exception as exc:
                bot.LOG.warning('Уведомление владельцу не доставлено: %s; будет повтор', type(exc).__name__)
                details=getattr(exc,'result_json',None)
                if isinstance(details,dict) and details.get('error_code')==429:
                    try:retry=max(60,int(details.get('parameters',{}).get('retry_after',60)))
                    except (ValueError,TypeError):retry=60
                    bot.STORE.set_meta('owner_send_cooldown',str(now+retry))
        if not success:
            delay, state = 60, row['state']
        elif urgent:
            # First reminder after 1 min, then 5 min, then every 15 min.
            delay, state = (60 if row['attempts'] == 0 else 300 if row['attempts'] == 1 else 900), 'alarm'
        else:
            delay, state = 0, 'sent'
        with LOCK, bot.STORE.conn() as db:
            db.execute("UPDATE owner_notices SET attempts=attempts+1,next_at=?,state=? WHERE id=? AND state IN ('pending','alarm')",
                       (now + delay, state, row['id']))
        if target and now<float(bot.STORE.get_meta('owner_send_cooldown','0')):break


def acknowledge(bot, oid):
    prepare(bot)
    with LOCK, bot.STORE.conn() as db:
        if oid == 'all':
            result = db.execute("UPDATE owner_notices SET state='acknowledged' WHERE urgent=1 AND state IN ('pending','alarm')")
        else:
            result = db.execute("UPDATE owner_notices SET state='acknowledged' WHERE urgent=1 AND order_id=? AND state IN ('pending','alarm')", (oid,))
        return result.rowcount


def resolve(bot, oid):
    # Only supplier-confirmed completion resolves an alarm automatically.
    if bot.STORE is not None:
        prepare(bot)
        with LOCK, bot.STORE.conn() as db:
            db.execute("UPDATE owner_notices SET state='resolved' WHERE urgent=1 AND order_id=? AND state IN ('pending','alarm')", (oid,))


def worker(bot, c):
    while not bot.STOP.wait(10):
        if not bot.enabled(c):
            continue
        try:
            if hasattr(bot,'activity'):bot.activity.hourly(bot,c)
            dispatch(bot, c)
        except Exception as exc:
            bot.LOG.warning('Цикл уведомлений: %s; повтор через 10 секунд', type(exc).__name__)


def register(bot, c, own):
    api = c.telegram.bot

    def cmd_ack(m):
        if not own(m) or bot.STORE is None:
            return
        parts = (m.text or '').split()
        if len(parts) != 2 or not re.fullmatch(r'(?:all|#?[A-Za-z0-9_-]{3,90})', parts[1]):
            api.reply_to(m, 'Формат: /sr_ack НОМЕР_ЗАКАЗА или /sr_ack all')
            return
        count = acknowledge(bot, parts[1].lstrip('#'))
        api.reply_to(m, f'🔕 Тревог отключено: {count}. Пауза и статус заказов сохранены. Эта команда ничего не покупает.')

    def cmd_test(m):
        if not own(m) or bot.STORE is None:
            return
        notify(bot, c, '✅ Проверка связи: уведомления о заказах доставляются владельцу. Покупок нет.')
        api.reply_to(m, 'Проверочное уведомление придёт в течение 10 секунд. Разреши звук уведомлений для этого бота в Telegram.')

    c.telegram.msg_handler(cmd_ack, commands=['sr_ack'])
    c.telegram.msg_handler(cmd_test, commands=['sr_notify_test'])
    c.add_telegram_commands(bot.UUID, [('sr_ack','Отключить напоминания о проверенной тревоге',True),
                                     ('sr_notify_test','Проверить уведомления без покупки',True)])
