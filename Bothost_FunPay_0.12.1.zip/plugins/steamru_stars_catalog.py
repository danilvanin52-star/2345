# noplug — trusted supplier catalogue and FunPay draft creation.
"""Steam key catalogue and RUB packages. Catalogue reads never buy products."""
import json
import re
from urllib.parse import urlsplit, parse_qs
from steamru_stars_engine import D, strict_count, STEAM_CURRENCIES, STEAM_KINDS
from steamru_stars_funpay import FunPayRateLimited

REGIONS = {'GLOBAL': 'Global', 'CIS': 'CIS', 'RU': 'Russia', 'RUSSIA': 'Russia',
           'EU': 'Europe', 'EUROPE': 'Europe'}
COPY_REVISION='color-2026-10-13-help-v1'
COUNTRIES={'RU':'Россия','UA':'Украина','KZ':'Казахстан','BY':'Беларусь','TR':'Турция','AR':'Аргентина',
 'US':'США','GB':'Великобритания','DE':'Германия','FR':'Франция','PL':'Польша','CA':'Канада','AU':'Австралия',
 'CN':'Китай','JP':'Япония','KR':'Южная Корея','BR':'Бразилия','IN':'Индия','AM':'Армения','AZ':'Азербайджан',
 'GE':'Грузия','KG':'Кыргызстан','MD':'Молдова','TJ':'Таджикистан','TM':'Туркменистан','UZ':'Узбекистан',
 'LT':'Литва','LV':'Латвия','EE':'Эстония','CZ':'Чехия','SK':'Словакия','RO':'Румыния','HU':'Венгрия',
 'SE':'Швеция','NO':'Норвегия','FI':'Финляндия','DK':'Дания','ES':'Испания','IT':'Италия','PT':'Португалия',
 'NL':'Нидерланды','BE':'Бельгия','AT':'Австрия','CH':'Швейцария','IE':'Ирландия','NZ':'Новая Зеландия',
 'AE':'ОАЭ','SA':'Саудовская Аравия','EG':'Египет','ZA':'ЮАР','SG':'Сингапур','MY':'Малайзия','PH':'Филиппины',
 'TH':'Таиланд','VN':'Вьетнам','ID':'Индонезия','TW':'Тайвань','HK':'Гонконг','IL':'Израиль'}

def display_title(rule, english=False):
    kind=rule.get('kind','stars')
    auto='Auto' if english else 'Авто'
    region=rule.get('region_label') or rule.get('region','')
    region={'CIS':'СНГ','GLOBAL':'Global','RU':'Россия','RUSSIA':'Россия','EU':'Европа','EUROPE':'Европа'}.get(region,region)
    if english:region={'СНГ':'CIS','Россия':'Russia','Турция':'Turkey','США':'USA','Европа':'Europe'}.get(region,region)
    if kind=='game_key':return f"🎮 {rule['game_name']} | 🔑 Steam · 🌍 {region} · ⚡ {auto}"
    if kind in STEAM_KINDS:
        currency=rule.get('currency','RUB')
        return f"💰 Steam {currency} | {rule['min_count']}–{rule['max_count']} {currency} · ⚡ {auto}"
    if kind=='stars':return f"⭐ {rule['stars_per_unit']} Telegram Stars | 🎁 "+('Gift' if english else 'В подарок')+f' · ⚡ {auto}'
    label=rule['display_name']
    if english:label=label.replace('Алмазов','Diamonds').replace('СНГ','CIS').replace('Россия','Russia').replace('Турция','Turkey').replace('США','USA').replace('Европа','Europe')
    icon='🎁' if kind=='service_code' else '🎯' if rule.get('service')=='pubg-mobile' else '💎'
    return f'{icon} {label} | '+(('🔑 Code' if english else '🔑 Код') if kind=='service_code' else '⚡ '+auto)


def field_matches(value,key,rule):
    expected=rule['match_fields'][key]
    if value==expected:return True
    if key!='summary':return False
    # Accept only exact titles generated for this very SKU, including its region.
    # Keep the original binding unchanged so already paid orders remain valid.
    return value in (display_title(rule),display_title(rule,True),*rule.get('summary_aliases',[]))


def buyer_copy(rule):
    kind=rule.get('kind','stars')
    if kind in ('service_topup','service_code'):
        label=rule['display_name'];region=rule['region_label']
        label_en=label.replace('Алмазов','Diamonds').replace('Робуксов','Robux').replace('СНГ','CIS').replace('Россия','Russia').replace('Турция','Turkey')
        region_en={'СНГ':'CIS','Россия':'Russia','Турция':'Turkey','США':'USA','Европа':'Europe'}.get(region,region)
        if kind=='service_code':
            ru=f'🎁 {label}\n🌍 Регион активации: {region}\n\n⚡ Автоматическая выдача\nПосле оплаты бот отправит код в чат заказа. Ничего дополнительно присылать не нужно.\n\n📌 Активация: {rule["activation"]}\n✅ Перед оплатой проверь регион аккаунта.\n🔒 Логин и пароль не нужны.'
            en=f'🎁 {label_en}\n🌍 Activation region: {region_en}\n\n⚡ Automatic delivery\nPay for the order. The bot sends the code to this chat after processing. No extra details needed.\n\n✅ Check the account region before purchase. Redeem the code in the official app or website.\n🔒 No login or password required.'
            payment_ru='🔑 Заказ оплачен! Код автоматически придёт в этот чат после обработки. Ничего присылать не нужно.'
            payment_en='🔑 Payment received! Your code will be sent automatically to this chat after processing.'
        else:
            labels=' и '.join(f['label'] for f in rule['recipient_fields']);example='123456789 1234' if len(rule['recipient_fields'])==2 else '123456789'
            ru=f'🎮 {label}\n🌍 Регион: {region}\n\n⚡ Как получить\n1️⃣ Оплати заказ.\n2️⃣ Отправь {labels} в чат одним сообщением: {example}.\n3️⃣ Дождись автоматического зачисления.\n\n✅ Проверь ID и регион перед оплатой.\n🔒 Пароль и коды входа не нужны.'
            en=f'🎮 {label_en}\n🌍 Region: {region_en}\n\n⚡ Automatic top-up\nPay, then send your player ID'+(' and server ID' if len(rule['recipient_fields'])==2 else '')+f' in the order chat: {example}. Wait for the credit to arrive.\n\n✅ Check the ID and region before purchase.\n🔒 No password or sign-in codes required.'
            payment_ru=f'🎮 Заказ оплачен! Пришли {labels} одним сообщением: {example}. Пароль и коды не нужны.'
            payment_en='🎮 Payment received! Send your player ID'+(' and server ID' if len(rule['recipient_fields'])==2 else '')+' in this chat. No passwords or sign-in codes.'
    elif kind=='game_key':
        name=rule['game_name'];region=rule['region'];countries=rule.get('countries',[]);excluded=rule.get('excluded_countries',[])
        region_ru={'GLOBAL':'весь мир','CIS':'страны СНГ','RU':'Россия','RUSSIA':'Россия','EU':'Европа','EUROPE':'Европа'}[region]
        activation='только '+', '.join(COUNTRIES.get(x,x) for x in countries) if countries else region_ru
        if excluded:activation+='\n⛔ Не активируется: '+', '.join(COUNTRIES.get(x,x) for x in excluded)
        ru=f'🎮 {name}\n🔑 Цифровой ключ для Steam\n🌍 Активация: {activation}\n\n⚡ Автоматическая выдача\nОплати заказ — бот отправит ключ в этот чат после обработки. Ничего дополнительно отправлять не нужно.\n\n🕹 Активируй код в Steam: «Игры» → «Активировать в Steam».\n🔒 Логин и пароль от аккаунта не нужны.'
        en=f'🎮 {name}\n🔑 Steam digital key\n🌍 Region: {region}'
        if countries:en+='; allowed countries: '+', '.join(countries)
        if excluded:en+='; excluded countries: '+', '.join(excluded)
        en+='\n\n⚡ Automatic delivery\nPay for the order. The bot sends the key to this chat after processing. No extra details needed.\n\n🕹 Activate it in Steam: Games → Activate a Product on Steam.\n🔒 No login or password required.'
        payment_ru='🔑 Заказ оплачен! Бот автоматически отправит ключ в этот чат после обработки. Логин и пароль не нужны.'
        payment_en='🔑 Payment received! The bot sends your key to this chat after processing. No login or password required.'
    elif kind in STEAM_KINDS:
        currency=rule.get('currency','RUB');low,high=rule['min_count'],rule['max_count']
        examples={'RUB':'156 или 492 ₽','USD':'1, 3 или 5 USD','KZT':'650 или 1492 KZT'}[currency]
        ru=f'💰 Пополнение Steam · {currency}\n📌 Цена за 1 {currency} баланса Steam.\n🛒 Любая целая сумма от {low} до {high} {currency} — например, {examples}.\n\n⚡ Как получить\nУкажи логин Steam при покупке и оплати заказ. Бот проверит логин и автоматически выполнит пополнение. Если логин не указан, пришли его в чат заказа.\n\n👤 Нужен логин для входа, а не ник профиля.\n🔒 Пароль и коды Steam Guard не нужны.'
        en=f'💰 Steam wallet top-up · {currency}\n📌 Price per 1 {currency} of Steam balance.\n🛒 Any whole amount from {low} to {high} {currency}.\n\n⚡ Delivery\nEnter your Steam login at checkout and pay. The bot checks the login and automatically processes the top-up. If you did not enter it, send it in the order chat.\n\n👤 Use the sign-in login, not the profile nickname.\n🔒 No password or Steam Guard codes required.'
        payment_ru='💰 Заказ оплачен! Если логин уже указан при покупке, бот выполнит пополнение автоматически. Иначе отправь логин Steam в этот чат. Пароль и коды Steam Guard не присылай.'
        payment_en='💰 Payment received! If your login was entered at checkout, the bot processes the top-up automatically. Otherwise send your Steam login here. No passwords or Steam Guard codes.'
    else:
        n=rule['stars_per_unit']
        ru=f'⭐ {n} Telegram Stars\n🎁 Для себя или в подарок по @username.\n\n⚡ Как получить\n1️⃣ Оплати заказ.\n2️⃣ Отправь @username получателя в чат заказа.\n3️⃣ Дождись зачисления звёзд.\n\n✅ Проверь ник перед отправкой.\n🔒 Пароль и коды Telegram не нужны.'
        en=f'⭐ {n} Telegram Stars\n🎁 For yourself or as a gift by @username.\n\n⚡ Delivery\n1️⃣ Pay for the order.\n2️⃣ Send the recipient @username in the order chat.\n3️⃣ Wait for the Stars to arrive.\n\n✅ Check the username before sending.\n🔒 No Telegram password or codes required.'
        payment_ru=f'⭐ Заказ на {n} Stars оплачен! Отправь @username получателя в этот чат. Пароль и коды не нужны.'
        payment_en=f'⭐ Payment for {n} Stars received! Send the recipient @username in this chat. No passwords or codes required.'
    ru=display_title(rule)+'\n━━━━━━━━━━━━━━\n'+ru.split('\n',1)[-1]+'\n\n💬 Помощь: !помощь — вызов продавца\n📦 Статус заказа: !статус'
    en=display_title(rule,True)+'\n━━━━━━━━━━━━━━\n'+en.split('\n',1)[-1]+'\n\n💬 Help: !help · Order status: !status'
    payment_ru+='\n\n💜 Спасибо за покупку!\n💬 Помощь: !помощь · 📦 Статус: !статус'
    payment_en+='\n\n💜 Thank you! Help: !help · Status: !status'
    return {'ru':ru,'en':en,'payment_ru':payment_ru,'payment_en':payment_en}

def update_copy(fields,rule):
    copy=buyer_copy(rule)
    fields.description_ru=copy['ru'];fields.description_en=copy['en']
    fields.payment_msg_ru=copy['payment_ru'];fields.payment_msg_en=copy['payment_en']
    if 'summary' in rule['match_fields']:
        fields.title_ru=display_title(rule);fields.title_en=display_title(rule,True)
    return fields

class DraftRejected(ValueError):
    pass

class DraftUncertain(ValueError):
    pass

class FormUnavailable(ValueError):
    pass

class CategoryFull(FormUnavailable):
    pass


def eligible_key(game, maximum='5'):
    try:
        return (game.get('platform') == 'steam' and game.get('content_kind') in ('game', 'edition')
                and 0 < D(game.get('price_usd')) <= D(maximum)
                and strict_count(game.get('stock')) >= 1
                and strict_count(game.get('min_quantity')) <= 1 <= strict_count(game.get('max_quantity'))
                and game.get('region') in REGIONS and strict_count(game.get('app_id')) > 0
                and strict_count(game.get('option_id')) > 0 and isinstance(game.get('name'), str)
                and bool(game['name'].strip()))
    except (ValueError, TypeError):
        return False


def key_rule(game):
    name = ' '.join(game['name'].split())[:80]
    region = game['region']
    summary = f'{name} · Ключ Steam · {region}'
    countries = game.get('countries') or []
    excluded = game.get('excluded_countries') or []
    if any(not isinstance(x, str) or len(x) != 2 for x in [*countries, *excluded]):
        raise ValueError('Неверный список стран')
    description = (f'{name}\nЦифровой ключ основной игры или указанного издания для Steam.\n'
                   f'Регион активации: {region}.\n'
                   + ('Разрешённые страны (ISO): ' + ', '.join(countries) + '.\n' if countries else '')
                   + ('Исключённые страны: ' + ', '.join(excluded) + '.\n' if excluded else '')
                   + 'Перед оплатой проверь регион своего Steam. Код будет отправлен автоматически в чат после оплаты и подтверждения поставщиком. Пароль от Steam не нужен.')
    return {'kind': 'game_key', 'subcategory_id': 1008, 'stars_per_unit': 1,
            'app_id': strict_count(game['app_id']), 'option_id': strict_count(game['option_id']),
            'region': region, 'game_name': name, 'countries': countries, 'excluded_countries': excluded,
            'last_price_usd': str(D(game['price_usd'])), 'sell_enabled': True,
            'summary': summary, 'description': description,
            'match_fields': {'summary': summary, 'name': name, 'method': 'Цифровой ключ',
                             'type': 'Игра', 'region2': REGIONS[region]}}


def rub_rule(count, product):
    if count != 1:
        raise ValueError('FunPay продаёт Steam RUB по одному рублю, сумма выбирается покупателем')
    return {'kind': 'steam_rub', 'subcategory_id': 1086, 'stars_per_unit': 1, 'min_count': 100, 'max_count': 500,
            'last_price_usd': str(D(product['price_usd'])), 'sell_enabled': True,
            'description': '💰 Пополнение Steam в рублях\nЛюбая целая сумма от 100 до 500 ₽, например 156 или 492 ₽. Цена указана за 1 ₽ баланса. После оплаты пришли логин Steam в чат заказа. Пароль и коды Steam Guard не нужны.',
            'match_fields': {'currency': 'RUB', 'type': 'by-login'}}


def currency_rule(currency,product):
    if currency not in STEAM_CURRENCIES:raise ValueError('Неизвестная валюта Steam')
    definition=STEAM_CURRENCIES[currency]
    if strict_count(product['product_id'])!=definition['product_id'] or product['name']!='Steam '+currency or product.get('fields'):
        raise ValueError('Изменился товар Steam '+currency)
    rule=rub_rule(1,product)
    rule.update(**definition,currency=currency,stars_per_unit=1,subcategory_id=1086)
    rule['match_fields']={'currency':currency,'type':'by-login'}
    return rule


def catalogue(api, maximum='5', stop=None):
    result, seen, contracts = [], set(), set()
    page = 1
    while True:
        if stop is not None and stop.is_set():
            raise ValueError('Синхронизация остановлена')
        data = api.request('GET', '/catalog/keys', params={'page': page, 'per_page': 100})
        if not isinstance(data.get('games'), list) or strict_count(data.get('page')) != page:
            raise ValueError('Некорректный каталог ключей')
        total_pages = strict_count(data.get('total_pages'), min_count=0, max_count=1000)
        if total_pages == 0:
            if data['games']:
                raise ValueError('Каталог без страниц содержит товары')
            return result
        for game in data['games']:
            if eligible_key(game, maximum):
                code = f"key_{game['app_id']}_{game['option_id']}"
                if code in seen:
                    continue
                rule = key_rule(game)
                contract = tuple(sorted(rule['match_fields'].items()))
                if contract in contracts:
                    continue
                seen.add(code); contracts.add(contract)
                result.append((code, rule))
        if page >= total_pages:
            return result
        page += 1
        if stop is not None and stop.wait(0.8):
            raise ValueError('Синхронизация остановлена')


def form_fields(html, node):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'lxml')
    form = soup.find('form', class_='form-offer-editor')
    if form is None:
        lead = soup.find('p',class_='lead')
        if lead and 'Много предложений' in lead.get_text():
            raise CategoryFull('Достигнут лимит лотов в категории FunPay')
        raise FormUnavailable('Не найдена форма нового лота FunPay')
    fields = {}
    for element in form.find_all(('input', 'select', 'textarea')):
        name = element.get('name')
        if not name:
            continue
        if element.name == 'select':
            option = element.find('option', selected=True) or element.find('option')
            fields[name] = option.get('value', '') if option else ''
        elif element.name == 'textarea':
            fields[name] = element.get_text()
        elif element.get('type') == 'checkbox':
            fields[name] = 'on' if element.has_attr('checked') else ''
        else:
            fields[name] = element.get('value', '')
    if fields.get('node_id') != str(node) or fields.get('offer_id') != '0' or not fields.get('csrf_token'):
        raise ValueError('Неверная форма создания лота')
    return fields


def apply_rule(fields, rule, seller_price):
    result = dict(fields)
    result.update(price=str(D(seller_price)), active='', auto_delivery='', secrets='', amount='1', deleted='')
    result['fields[desc][ru]'] = rule['description']
    if rule['kind'] == 'game_key':
        result['fields[desc][en]'] = (f"Steam digital game key: {rule['game_name']}. Activation region: {rule['region']}. "
            + ('Allowed countries: '+', '.join(rule['countries'])+'. ' if rule['countries'] else '')
            + ('Excluded countries: '+', '.join(rule['excluded_countries'])+'. ' if rule['excluded_countries'] else '')
            + 'Check your Steam region before purchase. The key is sent to this chat automatically after payment and supplier confirmation. No password required.')
    else:
        result['fields[desc][en]'] = 'Steam RUB wallet top-up by login. Price per 1 RUB. Enter a quantity from 100 to 500 RUB. Send your Steam login after payment. No password or Steam Guard codes required.'
    result['fields[payment_msg][ru]'] = ('Ключ будет отправлен в этот чат после подтверждения поставщиком.'
                                      if rule['kind'] == 'game_key' else 'Пришли логин Steam в чат. Пароль и коды не присылай.')
    result['fields[payment_msg][en]'] = ('Your key will be sent to this chat after supplier confirmation.' if rule['kind']=='game_key'
                                       else 'Send your Steam login in this chat. Do not send passwords or codes.')
    for name, value in rule['match_fields'].items():
        if name in ('summary', 'name'):
            result[f'fields[{name}][ru]'] = display_title(rule) if name=='summary' else value
            result[f'fields[{name}][en]'] = display_title(rule,True) if name=='summary' else ((value)
                if rule['kind']=='game_key' else value.replace('Алмазов','Diamonds').replace('СНГ','CIS').replace('Россия','Russia').replace('Турция','Turkey'))
        else:
            result[f'fields[{name}]'] = '%' + value if rule['kind'] in STEAM_KINDS and (name=='type' or name=='currency' and value=='RUB') else value
    copy=buyer_copy(rule)
    result['fields[desc][ru]']=copy['ru'];result['fields[desc][en]']=copy['en']
    result['fields[payment_msg][ru]']=copy['payment_ru'];result['fields[payment_msg][en]']=copy['payment_en']
    return result


def response_offer_id(payload):
    for key in ('offer_id', 'offerId', 'id'):
        value = payload.get(key)
        if isinstance(value, (int, str)) and str(value).isdigit() and int(value) > 0:
            return int(value)
    address = payload.get('url', '')
    if isinstance(address, str):
        parsed = urlsplit(address)
        if parsed.hostname and parsed.hostname != 'funpay.com':
            raise ValueError('Недоверенная ссылка нового лота')
        query = parse_qs(parsed.query)
        for name in ('offer', 'id'):
            if name in query and query[name][0].isdigit():
                return int(query[name][0])
    return None


def reconcile_created(c, node, rule, before_ids):
    candidates = []
    for item in c.account.get_my_subcategory_lots(node):
        if int(item.id) in before_ids:
            continue
        fields = c.account.get_lot_fields(int(item.id), node_id=node)
        if all(field_matches(c.editor_field_value(fields,k),k,rule) for k in rule['match_fields']):
            candidates.append(int(item.id))
    if len(candidates) > 1:
        raise ValueError('Неоднозначный результат создания лота')
    return candidates[0] if candidates else None


def create_draft(bot, c, code, rule, price):
    """One create attempt per durable intent; a timeout is reconciled, not reposted."""
    node = rule['subcategory_id']
    key = 'catalog_intent:' + code
    intent = json.loads(bot.STORE.get_meta(key, '{}'))
    if intent.get('stage') == 'confirmed':
        return strict_count(intent['offer_id'])
    if intent.get('stage') == 'sent':
        proxy = type('Reconcile', (), {'account': c.account, 'editor_field_value': staticmethod(bot.editor_field_value)})()
        found = reconcile_created(proxy, node, rule, set(intent['before_ids']))
        if found is None:
            raise DraftUncertain('Исход создания лота неизвестен: повтор не выполняется')
        checked = c.account.get_lot_fields(found, node_id=node)
        if checked.active:
            checked.active = False
            c.account.save_lot(checked.renew_fields())
        bot.STORE.set_meta(key, json.dumps({'stage': 'confirmed', 'offer_id': found}))
        return found
    before = [int(x.id) for x in c.account.get_my_subcategory_lots(node)]
    response = c.account.method('get', f'lots/offerEdit?node={node}', {}, {}, raise_not_200=True)
    fields = apply_rule(form_fields(response.content.decode(), node), rule, price)
    bot.STORE.set_meta(key, json.dumps({'stage': 'sent', 'before_ids': before}))
    headers = {'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'x-requested-with': 'XMLHttpRequest'}
    try:
        response = c.account.method('post', 'lots/offerSave', headers, fields, raise_not_200=True)
        payload = response.json()
        if payload.get('error') or payload.get('errors'):
            names=[str(x[0]) for x in payload.get('errors',[]) if isinstance(x,(list,tuple)) and x]
            bot.STORE.set_meta(key,json.dumps({'stage':'rejected','error_fields':names}))
            raise DraftRejected('FunPay отклонил поля нового лота: '+', '.join(names))
        offer = response_offer_id(payload)
    except DraftRejected:
        raise
    except FunPayRateLimited:
        # POST was not sent, or the server explicitly rejected it with HTTP 429.
        # A later retry is allowed; an unknown network outcome still stays 'sent'.
        bot.STORE.set_meta(key,json.dumps({'stage':'deferred','before_ids':before}))
        raise
    except Exception:
        offer = None
    if offer is None:
        proxy = type('Reconcile', (), {'account': c.account, 'editor_field_value': staticmethod(bot.editor_field_value)})()
        offer = reconcile_created(proxy, node, rule, set(before))
    if offer is None:
        raise DraftUncertain('Не удалось подтвердить создание: автоматического повтора нет')
    checked = c.account.get_lot_fields(offer, node_id=node)
    if checked.active or any(not field_matches(bot.editor_field_value(checked,k),k,rule) for k in rule['match_fields']):
        raise ValueError('Новый лот не соответствует безопасному черновику')
    bot.STORE.set_meta(key, json.dumps({'stage': 'confirmed', 'offer_id': offer}))
    return offer
