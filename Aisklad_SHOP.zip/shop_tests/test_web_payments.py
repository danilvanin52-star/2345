"""Offline signed website bridge tests: no HTTP or real provider transactions."""
import copy
import hashlib
import hmac
import json
import tempfile
import unittest
from pathlib import Path
from urllib.parse import urlsplit, unquote
from aisklad_shop.catalog import product_id
from aisklad_shop.service import ShopError, ShopService
from aisklad_shop.store import ShopStore, dumps
from aisklad_shop.web_payments import WebPayments, WebPaymentError
from shop_tests.test_merchandising import DemoSupplier


SECRET = "OFFLINE-TEST-ONLY-" + "x" * 40
BASE = "https://shop.example.test"


class Response:
    def __init__(self, value, status=200):
        self.status_code = status
        self.content = value if isinstance(value, bytes) else dumps(value).encode()
        self.closed = False
    def iter_content(self, chunk_size):
        for start in range(0, len(self.content), chunk_size):
            yield self.content[start:start + chunk_size]
    def close(self): self.closed = True


class Bridge:
    def __init__(self, clock, mode="test"):
        self.clock, self.mode = clock, mode
        self.invoices, self.requests, self.events, self.acked, self.deliveries = {}, [], [], [], []
        self.drop_register_once = False; self.drop_ack_once = False; self.drop_delivery_once = False
        self.response_override = None
    def request(self, method, url, data=None, headers=None, **kwargs):
        self.assert_request(method, url, data, headers, kwargs)
        raw = data or b""; path = urlsplit(url).path
        body = json.loads(raw) if raw else None
        self.requests.append((method, url, copy.deepcopy(body)))
        if self.response_override is not None:
            return self.response_override
        if method == "POST" and path == "/api/shop/bridge/invoices":
            order = body["order_id"]
            if order not in self.invoices:
                self.invoices[order] = {"request": copy.deepcopy(body), "mode": self.mode}
            elif self.invoices[order]["request"] != body:
                return Response({"error": "immutable"}, 409)
            stored = self.invoices[order]
            result = {"invoice_id": "shop:" + order, "payment_url": BASE + "/shop/checkout?order_id=" + order + "#token=" + "capability" * 8,
                      "expires_at": stored["request"]["expires_at"], "mode": stored["mode"]}
            if self.drop_register_once:
                self.drop_register_once = False
                raise TimeoutError("private response must not leak")
            return Response(result)
        if method == "GET" and path == "/api/shop/bridge/payments":
            return Response({"events": [event for event in self.events if json.loads(event["raw"])["event_id"] not in self.acked]})
        if method == "POST" and path.endswith("/ack"):
            identity = unquote(path.split("/")[-2]); self.acked.append(identity)
            if self.drop_ack_once:
                self.drop_ack_once = False
                raise TimeoutError("ack response lost")
            return Response({"ok": True})
        if method == "POST" and path == "/api/shop/bridge/delivery":
            self.deliveries.append(copy.deepcopy(body))
            if self.drop_delivery_once:
                self.drop_delivery_once = False
                raise TimeoutError("delivery response lost")
            return Response({"ok": True, "revision": body["revision"]})
        return Response({}, 404)
    def assert_request(self, method, url, raw, headers, kwargs):
        parsed = urlsplit(url)
        path = parsed.path + ("?" + parsed.query if parsed.query else "")
        material = "\n".join((headers["X-Shop-Timestamp"], headers["X-Shop-Nonce"], method, path, hashlib.sha256(raw or b"").hexdigest()))
        expected = hmac.new(SECRET.encode(), material.encode(), hashlib.sha256).hexdigest()
        assert hmac.compare_digest(expected, headers["X-Shop-Signature"])
        assert kwargs["allow_redirects"] is False and kwargs["stream"] is True
        assert abs(int(headers["X-Shop-Timestamp"]) - self.clock()) < 2
    def pay(self, order_id, **override):
        invoice = self.invoices[order_id]; request = invoice["request"]
        payload = {"provider": "aisklad_web", "event_id": "event:" + order_id, "charge_id": "charge:" + order_id,
                   "invoice_id": "shop:" + order_id, "order_id": order_id, "user_id": request["user_id"], "amount": request["amount"],
                   "currency": "RUB", "status": "succeeded", "test": invoice["mode"] == "test"}
        payload.update(override)
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        signature = hmac.new(SECRET.encode(), ("event\n" + raw).encode(), hashlib.sha256).hexdigest()
        event = {"payload": payload, "raw": raw, "signature": signature}; self.events.append(event)
        return event


class WebPaymentsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.now = 1800000000
        self.clock = lambda: self.now
        self.store = ShopStore(Path(self.temp.name) / "shop.sqlite3", clock=self.clock)
        self.supplier = DemoSupplier(); self.bridge = Bridge(self.clock)
        self.payments = WebPayments(BASE, SECRET, session=self.bridge, clock=self.clock)
        self.service = ShopService(self.store, self.supplier, {"enabled": True, "owner_id": 999},
                                   rate_provider=lambda: {"rub_per_usd": "90", "observed_at": self.now},
                                   payment_connector=self.payments, clock=self.clock)
        self.service.sync_catalog()
        self.product = product_id("service", "steam", 1)
    def checkout(self):
        self.service.add_to_cart(100, self.product, 156, {"account": "steam_login"})
        return self.service.checkout(100)
    def event(self, order, **changes): return self.bridge.pay(order["id"], **changes)
    def authorize(self, event):
        return self.service.handle_payment(event["raw"].encode(), {"X-Shop-Event-Signature": event["signature"]})
    def count(self, table):
        with self.store.connection() as db: return db.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]

    def test_invoice_snapshot_binding_lines_sum_activation_and_owner(self):
        order = self.checkout()
        self.assertEqual("awaiting_payment", order["status"])
        self.assertEqual("test", order["payment_mode"])
        saved = self.bridge.invoices[order["id"]]["request"]
        self.assertEqual(100, saved["user_id"])
        self.assertEqual(order["total_rub"], saved["amount"])
        self.assertEqual(saved["amount"], saved["items"][0]["total_rub"])
        self.assertEqual({"account": "steam_login"}, saved["items"][0]["fields"])
        self.assertEqual(900, saved["expires_at"] - saved["created_at"])
        self.assertTrue(saved["items"][0]["activation"])
        self.assertTrue(self.payments.validate_checkout_url(order["payment_url"]))
        with self.assertRaises(ShopError): self.service.order(101, order["id"])

    def test_test_payment_never_authorizes_supplier_even_live_switch_true(self):
        order = self.checkout(); event = self.event(order)
        self.supplier.can_purchase = lambda: True
        self.assertTrue(self.authorize(event)["test"])
        self.service.process_pending()
        self.assertEqual("test_paid", self.service.order(100, order["id"])["status"])
        self.assertEqual(0, self.count("payment_authorizations"))
        self.assertEqual([], self.supplier.posts)
        self.assertTrue(self.authorize(event)["duplicate"])
        self.assertEqual(1, self.count("payment_events"))

    def test_live_verified_payment_sets_ready_exactly_once(self):
        self.payments.mode = "live"; self.bridge.mode = "live"
        order = self.checkout(); event = self.event(order)
        self.authorize(event); self.authorize(event)
        self.assertEqual(1, self.count("payment_authorizations"))
        self.assertEqual("ready", self.service.order(100, order["id"])["items"][0]["status"])
        self.assertEqual([], self.supplier.posts)

    def test_forged_event_signature_payload_and_mode_cannot_unlock(self):
        order = self.checkout()
        for fields in ({"user_id": 101}, {"amount": "0.01"}, {"currency": "USD"}, {"test": False}, {"invoice_id": "shop:other"}):
            event = self.event(order, **fields)
            with self.assertRaises(ShopError): self.authorize(event)
        event = self.event(order); event["signature"] = "0" * 64
        with self.assertRaises(ShopError): self.authorize(event)
        self.assertEqual(0, self.count("payment_authorizations"))
        self.assertEqual("awaiting_payment", self.service.order(100, order["id"])["status"])

    def test_string_test_flag_rejected_not_truthy_interpreted(self):
        order = self.checkout(); event = self.event(order, test="false")
        with self.assertRaises(ShopError): self.authorize(event)

    def test_timeout_recovery_resends_same_immutable_invoice_before_ack(self):
        self.bridge.drop_register_once = True
        with self.assertRaises(ShopError): self.checkout()
        order = self.service.orders(100)["items"][0]
        self.assertEqual("invoice_review", order["status"])
        request = copy.deepcopy(self.bridge.invoices[order["id"]]["request"])
        self.event(order)
        self.payments.synchronize(self.service)
        self.assertFalse(self.bridge.acked)  # registration retry still in backoff
        self.assertEqual(0, self.count("payment_events"))
        self.now += 16
        self.payments.synchronize(self.service)
        self.assertEqual(request, self.bridge.invoices[order["id"]]["request"])
        self.assertEqual(1, len(self.bridge.invoices))
        self.assertEqual(1, len(self.bridge.acked))
        self.assertEqual("test_paid", self.service.order(100, order["id"])["status"])

    def test_restart_disabled_mode_still_accepts_original_test_proof_without_purchase(self):
        order = self.checkout(); self.event(order)
        new_connector = WebPayments(BASE, SECRET, mode="disabled", session=self.bridge, clock=self.clock)
        self.service.payments = new_connector
        new_connector.synchronize(self.service)
        self.assertEqual("test_paid", self.service.order(100, order["id"])["status"])
        self.assertEqual(0, self.count("payment_authorizations"))
        with self.assertRaises(ShopError): self.service.checkout(100)

    def test_ack_loss_redelivery_does_not_repeat_authorization(self):
        self.payments.mode = self.bridge.mode = "live"
        order = self.checkout(); event = self.event(order)
        self.bridge.drop_ack_once = True
        self.payments.synchronize(self.service)
        self.bridge.acked.clear()  # model a lost ack not durably applied at peer
        self.payments.synchronize(self.service)
        self.assertEqual(1, self.count("payment_authorizations"))
        self.assertEqual(1, self.count("payment_events"))

    def test_duplicate_charge_cannot_fund_second_order_even_in_test_mode(self):
        one = self.checkout(); first = self.event(one); self.authorize(first)
        two = self.service.checkout(100); event = self.event(two, charge_id=first["payload"]["charge_id"])
        with self.assertRaises(ShopError): self.authorize(event)
        self.assertEqual("awaiting_payment", self.service.order(100, two["id"])["status"])

    def test_expired_invoice_new_explicit_checkout_retains_old_late_payment(self):
        old = self.checkout(); self.now += 901
        new = self.service.checkout(100)
        self.assertNotEqual(old["id"], new["id"])
        event = self.event(old); self.authorize(event)
        self.assertEqual("test_paid", self.service.order(100, old["id"])["status"])
        self.assertEqual("awaiting_payment", self.service.order(100, new["id"])["status"])

    def test_delivery_revision_persisted_before_request_and_retried_same_then_incremented(self):
        self.payments.mode = self.bridge.mode = "live"
        order = self.checkout(); self.authorize(self.event(order))
        self.bridge.drop_delivery_once = True
        self.payments.synchronize(self.service)
        key = "bridge:delivery:" + order["id"]
        self.assertEqual(1, self.store.get_setting(key)["pending"]["revision"])
        self.payments.synchronize(self.service)
        self.assertEqual([1, 1], [r["revision"] for r in self.bridge.deliveries])
        self.payments.synchronize(self.service)
        self.assertEqual(2, len(self.bridge.deliveries))
        with self.store.connection(immediate=True) as db:
            db.execute("UPDATE orders SET status='needs_review' WHERE id=?", (order["id"],))
        self.payments.synchronize(self.service)
        self.assertEqual(2, self.bridge.deliveries[-1]["revision"])

    def test_test_payment_not_published_as_real_delivery(self):
        order = self.checkout(); self.event(order)
        self.payments.synchronize(self.service)
        self.assertEqual([], self.bridge.deliveries)
        self.assertEqual("test_paid", self.service.order(100, order["id"])["status"])

    def test_ineligible_old_registration_does_not_starve_later_recovery(self):
        self.bridge.drop_register_once = True
        with self.assertRaises(ShopError): self.checkout()
        first = self.service.orders(100)["items"][0]
        self.bridge.drop_register_once = True
        with self.assertRaises(ShopError):
            self.service.add_to_cart(101, self.product, 156, {"account": "other_login"})
            self.service.checkout(101)
        second = self.service.orders(101)["items"][0]
        with self.store.connection(immediate=True) as db:
            value = json.loads(db.execute("SELECT value FROM orders WHERE id=?", (first["id"],)).fetchone()[0])
            value["invoice_retry_after"] = self.now + 300
            db.execute("UPDATE orders SET value=? WHERE id=?", (dumps(value), first["id"]))
        self.now += 16
        result = self.service.retry_pending_invoices(limit=1)
        self.assertEqual(1, result["recovered"])
        self.assertEqual("awaiting_payment", self.service.order(101, second["id"])["status"])

    def test_http_redirect_and_big_body_fail_without_private_error_leak(self):
        self.bridge.response_override = Response({"private": "secret"}, 302)
        with self.assertRaises(WebPaymentError) as error: self.payments.poll_events()
        self.assertNotIn("secret", str(error.exception))
        response = Response(b"x" * (1024 * 1024 + 1)); self.bridge.response_override = response
        with self.assertRaises(WebPaymentError): self.payments.poll_events()
        self.assertTrue(response.closed)

    def test_web_checkout_url_rejects_origin_redirect_and_token_confusion(self):
        order = self.checkout()
        for url in (order["payment_url"].replace("shop.example.test", "evil.example.test"),
                    order["payment_url"] + "&other=secret", "http://shop.example.test/shop/checkout?order_id=x#token=" + "x" * 32,
                    BASE + "/admin?order_id=x#token=" + "x" * 32):
            self.assertFalse(self.payments.validate_checkout_url(url))

    def test_config_private_origin_short_secret_rejected(self):
        for origin in ("http://shop.example.test", "https://localhost", "https://127.0.0.1", "https://10.0.0.1", "https://user:pass@shop.example.test", "https://shop.example.test/path"):
            with self.assertRaises(ValueError): WebPayments(origin, SECRET, session=self.bridge)
        with self.assertRaises(ValueError): WebPayments(BASE, "short", session=self.bridge)


if __name__ == "__main__": unittest.main()
