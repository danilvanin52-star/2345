"""STEAM.RU Stars ↔ FunPayCardinal. Безопасная автовыдача, по умолчанию ВЫКЛЮЧЕНА.
Установить вместе с файлом steamru_stars_engine.py в папку FPC/plugins/.
"""
from __future__ import annotations
import json
import logging
import os
import re
import sys
import threading
import time
import uuid
from html import escape
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING
from types import SimpleNamespace
from requests.exceptions import RequestException

from steamru_stars_engine import (
    Store, SteamClient, ApiFailure, UnknownOutcome, D, money, finances,
    parse_reply, status_name, currency_code, timestamp_fresh, strict_count,
    effective_exchange_rate, username_or_none, STEAM_CURRENCIES, STEAM_KINDS
)
import steamru_stars_pricing as pricing
import steamru_stars_catalog as catalog
import steamru_stars_funpay as funpay_control
import steamru_stars_rotation as rotation
import steamru_stars_services as services
import steamru_stars_controls as controls
import steamru_stars_notifications as notifications
import steamru_customer_messages as customer_messages
import steamru_stars_activity as activity
import steamru_stars_health as health

if TYPE_CHECKING:
    from cardinal import Cardinal

NAME = "STEAM.RU — товары и автовыдача"
VERSION = "0.12.1-beta"
DESCRIPTION = "Stars, Steam RUB, ключи, карты и игровые пополнения; управление товарами через Telegram"
CREDITS = "OpenAI / заказ пользователя"
UUID = "0289a7a9-b4ab-4eb9-93e5-6a45515a722c"
SETTINGS_PAGE = False
BIND_TO_DELETE = None

LOG = logging.getLogger("FPC.SteamRuStars")
DIR = Path("storage/plugins")
CFG_PATH = DIR / "steamru_stars_config.json"
DB_PATH = DIR / "steamru_stars.sqlite3"
STOP = threading.Event()
WORKER = None
MAINTENANCE = None
MAINTENANCE_WAKE = threading.Event()
RESTART_WAITER = None
NOTICE_WORKER = None
RUN_REQUESTED = False
WORKER_LOCK = threading.Lock()
PROCESS_LOCK = threading.RLock()
LOT_WRITE_LOCK = threading.RLock()
RESUME_TASK_LOCK = threading.Lock()
STORE = None
C = None
LIVE_WARNED = False
DEFAULT = {
    "mode": "dry_run",
    "capture_paid_orders_in_dry_run": False,
    "capture_initial_paid_orders": False,
    "service_slug": "telegram-stars",
    "product_id": 55,
    "lots": {"STEAMRU TG STARS 50": 50, "STEAMRU TG STARS 100": 100,
             "STEAMRU TG STARS 150": 150},
    "lot_rules": {},
    "managed_lots": {},
    "activate_lots_on_resume": False,
    "allowed_subcategory_ids": [],
    "max_total_stars": 150,
    "max_single_order_usd": "20",
    "max_daily_usd": "30",
    "withdrawal_fee_pct": "3",
    "rub_per_usd": None,
    "wallet_paid_rub": None,
    "wallet_credited_usd": None,
    "rub_per_usd_updated_at": None,
    "exchange_rate_max_age_hours": 24,
    "funding_rate_policy": "dated",
    "other_cost_per_order_rub": "0.25",
    "min_profit_rub": "3",
    "min_margin_pct": "5",
    "honor_paid_price": False,
    "min_balance_reserve_usd": "0.25",
    "poll_seconds": 25,
    "max_pending_minutes": 60,
    "pause_on_critical_error": True,
    "consecutive_error_limit": 7,
    "auto_disable_lots_on_pause": False,
    "lot_ids_to_disable": [],
    "dry_run_price_usd": None,
    "auto_pricing": {"enabled": False, "interval_seconds": 3600, "watch_topup_rate": False,
                     "payment_method": "sbp", "reference_usd": "100", "step_buyer_rub": "0.01",
                     "min_margin_pct": "0.35", "max_margin_pct": "0.4"},
    "catalog_sync": {"enabled": False, "interval_seconds": 3600, "max_game_price_usd": "5",
                     "key_node_id": 1008, "steam_node_id": 1086,
                     "request_gap_seconds": 3, "cooldown_seconds": 180,
                     "max_new_lots_per_pass": 3, "batch_interval_seconds": 180, "max_key_lots": 20},
    "rotation": {"enabled": False,"interval_seconds":18000,"max_changes":3,"drain_seconds":90},
    "services": {"enabled":False,"selected":[],"max_price_usd":"10"},
    "steam_currencies": {"enabled":False,"selected":["RUB"]},
    "activity_report": {"enabled":False,"interval_seconds":3600,"immediate":False},
    "lot_controls": {},
}
CFG = dict(DEFAULT)


class OrderDataError(ValueError):
    """A safe validation message created locally, never an HTTP/credential error."""


def transient_read_error(exc):
    if isinstance(exc, ApiFailure):
        return exc.code == 'network.error' or exc.status in (408,429,500,502,503,504)
    if isinstance(exc, (RequestException, TimeoutError, ConnectionError)):
        return True
    return getattr(getattr(exc,'response',None),'status_code',None) in (408,429,500,502,503,504)


def retry_before_purchase(c, row, exc):
    """Retry only a read phase: no reservation, supplier UUID or POST allowed."""
    current = STORE.get(row['id'])
    if not current or current['status'] != 'preparing' or current['supplier_uuid'] or current['submitted_at']:
        return False
    if not transient_read_error(exc):
        return False
    key = 'read_retry:' + row['id']
    attempt = int(STORE.get_meta(key,'0')) + 1
    STORE.set_meta(key,str(attempt))
    if attempt > 3:
        return False
    delay = (30,90,300)[attempt-1]
    if isinstance(exc,ApiFailure) and exc.retry_after:
        try:delay=max(delay,min(3600,int(exc.retry_after)))
        except (ValueError,TypeError):pass
    if STORE.set_if_status(row['id'],'preparing',status='ready',retry_after=time.time()+delay,
                           details=f'READ_RETRY_{attempt}: {type(exc).__name__}'):
        critical(c, f"Заказ #{row['id']}: временный сбой до покупки. Повтор через {delay} сек.; списания ещё не было.", scope='purchase')
        return True
    return False


def schedule_order_read(c, s, oid, exc):
    if not transient_read_error(exc):
        return False
    key = 'capture_retry:' + oid
    prior = json.loads(STORE.get_meta(key,'null')) or {}
    attempt = int(prior.get('attempt',0)) + 1
    if attempt > 3:
        STORE.set_meta(key,'null')
        return False
    delay = (30,90,300)[attempt-1]
    STORE.set_meta(key,json.dumps({'id':oid,'buyer_id':str(s.buyer_id),'chat_id':str(s.chat_id),
                                  'category_id':getattr(getattr(s,'subcategory',None),'id',None),
                                  'attempt':attempt,'next_at':time.time()+delay}))
    critical(c,f'Заказ #{oid}: FunPay временно не отдаёт подробности. Повтор через {delay} сек.; покупки не было.',scope='capture')
    return True


def retry_order_reads(c):
    with STORE.conn() as db:
        queued = db.execute("SELECT key,value FROM settings WHERE key LIKE 'capture_retry:%' AND value!='null' LIMIT 100").fetchall()
    for item in queued:
        pending = json.loads(item['value'])
        if time.time() < pending['next_at']:
            continue
        if STORE.get(pending['id']) or STORE.get_meta('manual_order:' + pending['id']):
            STORE.set_meta(item['key'],'null')
            continue
        s = SimpleNamespace(id=pending['id'],status='PAID',description='',buyer_id=pending['buyer_id'],
                            chat_id=pending['chat_id'],subcategory=SimpleNamespace(id=pending['category_id']))
        on_new_order(c,SimpleNamespace(order=s))


def load_settings():
    global CFG
    DIR.mkdir(parents=True, exist_ok=True)
    if CFG_PATH.exists():
        with CFG_PATH.open(encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("Config должен быть JSON-объектом")
        CFG = {**DEFAULT, **data}
    else:
        CFG = dict(DEFAULT)
        CFG_PATH.write_text(json.dumps(CFG, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if CFG["mode"] not in ("dry_run", "live"):
        raise ValueError("mode только dry_run или live")
    strict_count(CFG['consecutive_error_limit'], 1, 100)
    for name in ('auto_pricing', 'catalog_sync','rotation','services','steam_currencies','activity_report'):
        if not isinstance(CFG.get(name), dict):
            raise ValueError(name + ' должен быть словарём')
        CFG[name] = {**DEFAULT[name], **CFG[name]}
    if CFG['auto_pricing']['enabled']:
        low, high = D(CFG['auto_pricing']['min_margin_pct']), D(CFG['auto_pricing']['max_margin_pct'])
        if not 0 <= low <= high < 100 or int(CFG['auto_pricing']['interval_seconds']) < 300:
            raise ValueError('Неверная политика автоматической цены')
    if CFG['catalog_sync']['enabled']:
        options = CFG['catalog_sync']
        if not 0 < D(options['max_game_price_usd']) <= 5 or int(options['interval_seconds']) < 300:
            raise ValueError('Каталог ограничен ключами до 5 USD; интервал минимум 300 секунд')
        if (D(options['request_gap_seconds'])<1 or D(options['cooldown_seconds'])<60
                or not 1<=strict_count(options['max_new_lots_per_pass'])<=10 or D(options['batch_interval_seconds'])<60
                or not 1<=strict_count(options['max_key_lots'])<=20):
            raise ValueError('Недостаточная пауза запросов каталога')
    if CFG['rotation']['enabled'] and (int(CFG['rotation']['interval_seconds'])<18000
            or not 1<=int(CFG['rotation']['max_changes'])<=3 or int(CFG['rotation']['drain_seconds'])<60):
        raise ValueError('Ротация: минимум 5 часов, до 3 игр, пауза перед заменой минимум 60 секунд')
    if not isinstance(CFG.get("lots"), dict):
        raise ValueError("lots должен быть словарём {точное_название:количество}")
    if (not isinstance(CFG['services']['selected'],list) or not set(CFG['services']['selected']).issubset(dict(services.shortlist()))
            or not 0<D(CFG['services']['max_price_usd'])<=30 or not isinstance(CFG.get('lot_controls'),dict)):
        raise ValueError('Неверная настройка новых сервисов или управления товарами')
    if (not isinstance(CFG['steam_currencies']['selected'],list) or not set(CFG['steam_currencies']['selected']).issubset(STEAM_CURRENCIES)
            or len(set(CFG['steam_currencies']['selected']))!=len(CFG['steam_currencies']['selected'])
            or int(CFG['activity_report']['interval_seconds'])<3600):
        raise ValueError('Неверные валюты Steam или интервал отчёта')
    if CFG["service_slug"] != "telegram-stars" or CFG["product_id"] != 55:
        raise ValueError("Этот плагин поддерживает только telegram-stars, product_id=55")
    strict_count(CFG["max_total_stars"], min_count=50, max_count=150)
    for title, units in CFG["lots"].items():
        if not isinstance(title, str) or not title.strip():
            raise ValueError("Название лота должно быть непустой строкой")
        strict_count(units, max_count=150)
    validate_lot_rules(CFG.get("lot_rules", {}))
    if CFG.get("funding_rate_policy") not in ("dated", "deposit_cost"):
        raise ValueError("Неизвестная политика курса")
    if not isinstance(CFG.get("managed_lots"), dict):
        raise ValueError("managed_lots должен быть словарём ID лота → имя правила")
    for offer, rule in CFG["managed_lots"].items():
        strict_count(offer)
        if rule not in CFG["lot_rules"] or strict_count(offer) not in CFG["lot_ids_to_disable"]:
            raise ValueError("Управляемому лоту нужны правило и аварийный ID")
    for key in ("allowed_subcategory_ids", "lot_ids_to_disable"):
        if not isinstance(CFG[key], list):
            raise ValueError(key + " должен быть списком числовых ID")
        for value in CFG[key]:
            strict_count(value)
    if CFG["wallet_paid_rub"] is not None or CFG["wallet_credited_usd"] is not None:
        CFG["rub_per_usd"] = str(effective_exchange_rate(CFG["wallet_paid_rub"], CFG["wallet_credited_usd"]))
    return CFG


def validate_lot_rules(rules):
    if not isinstance(rules, dict):
        raise ValueError("lot_rules должен быть словарём правил")
    for name, rule in rules.items():
        if not isinstance(name, str) or not name.strip() or not isinstance(rule, dict):
            raise ValueError("Правило лота должно иметь имя и настройки")
        strict_count(rule.get("subcategory_id"))
        kind = rule.get('kind', 'stars')
        if kind == 'stars':
            strict_count(rule.get("stars_per_unit"), min_count=50, max_count=150)
        elif kind == 'game_key':
            if rule.get('subcategory_id') != 1008 or rule.get('stars_per_unit') != 1:
                raise ValueError('Неверная привязка ключа Steam')
            strict_count(rule.get('app_id')); strict_count(rule.get('option_id'))
            if not isinstance(rule.get('region'), str) or not rule['region']:
                raise ValueError('Для ключа нужен регион')
        elif kind in STEAM_KINDS:
            if rule.get('subcategory_id') != 1086 or rule.get('stars_per_unit') != 1:
                raise ValueError('Неверная привязка Steam')
            currency=rule.get('currency','RUB');definition=STEAM_CURRENCIES.get(currency)
            if (not definition or kind!=definition['kind'] or rule['match_fields']!={'currency':currency,'type':'by-login'}
                    or rule.get('min_count')!=definition['min_count'] or rule.get('max_count')!=definition['max_count']):
                raise ValueError('Изменились валюта или лимиты Steam')
        elif kind in services.KINDS:
            expected=dict(services.shortlist()).get(name)
            if not expected or any(rule.get(k)!=expected[k] for k in ('kind','service','product_id','product_name','subcategory_id','stars_per_unit','match_fields','recipient_fields','region_label')):
                raise ValueError('Изменилась проверенная привязка нового сервиса')
        else:
            raise ValueError('Неизвестный тип товара')
        fields = rule.get("match_fields")
        if not isinstance(fields, dict) or not fields:
            raise ValueError("Для правила нужны точные значения полей FunPay")
        for key, value in fields.items():
            if not isinstance(key, str) or not key or not isinstance(value, str):
                raise ValueError("Имена и значения полей должны быть строками")


def live_allowed():
    try:
        actual_rate = effective_exchange_rate(CFG["wallet_paid_rub"], CFG["wallet_credited_usd"])
        sane = (D(CFG["rub_per_usd"]) == actual_rate and actual_rate < 1000
                and D(CFG["withdrawal_fee_pct"]) >= 0 and D(CFG["withdrawal_fee_pct"]) < 100
                and D(CFG["max_single_order_usd"]) > 0 and D(CFG["max_daily_usd"]) > 0
                and D(CFG["other_cost_per_order_rub"]) >= 0
                and D(CFG["min_profit_rub"]) >= 0 and D(CFG["min_margin_pct"]) >= 0
                and D(CFG["min_balance_reserve_usd"]) >= 0
                and CFG["pause_on_critical_error"] is True
                and CFG["service_slug"] == "telegram-stars" and CFG["product_id"] == 55
                and 50 <= strict_count(CFG["max_total_stars"]) <= 150
                and bool(CFG["allowed_subcategory_ids"]))
    except Exception:
        sane = False
    if CFG.get('auto_pricing', {}).get('enabled') and CFG['auto_pricing'].get('watch_topup_rate'):
        try:
            pricing.pricing_rate(CFG)
        except Exception:
            sane = False
    # Не допускаем бесконтрольных продаж после аварийной остановки:
    # для LIVE надо настроить отключение собственных лотов по их числовым ID.
    lots_can_pause = bool(CFG.get("auto_disable_lots_on_pause")) and bool(CFG.get("lot_ids_to_disable"))
    try:
        lots_can_pause = lots_can_pause and all(int(i) > 0 for i in CFG["lot_ids_to_disable"])
    except (ValueError, TypeError):
        lots_can_pause = False
    return (sane and lots_can_pause and CFG["mode"] == "live"
            and os.getenv("STEAMRU_LIVE_CONFIRM") == "I_ACCEPT_REAL_PURCHASES"
            and bool(os.getenv("STEAMRU_API_KEY"))
            and bool(os.getenv("STEAMRU_API_SECRET"))
            and bool(os.getenv("STEAMRU_OWNER_TG_ID"))
            and CFG["rub_per_usd"] is not None
            and funding_rate_valid())


def funding_rate_valid():
    if CFG.get("funding_rate_policy", "dated") == "dated":
        return timestamp_fresh(CFG["rub_per_usd_updated_at"], int(CFG["exchange_rate_max_age_hours"]))
    # Это стоимость уже оплаченных USD, а не рыночная котировка на сегодня.
    # Она меняется при следующем пополнении, но не из-за наступления новых суток.
    try:
        stamp = datetime.fromisoformat(CFG["rub_per_usd_updated_at"].replace("Z", "+00:00"))
        return (stamp.tzinfo is not None and stamp <= datetime.now(timezone.utc)
                and D(CFG["rub_per_usd"]) == effective_exchange_rate(CFG["wallet_paid_rub"], CFG["wallet_credited_usd"]))
    except (ValueError, TypeError, KeyError, AttributeError):
        return False


def client(*, allow_purchases=False):
    return SteamClient(os.environ["STEAMRU_API_KEY"], os.environ["STEAMRU_API_SECRET"],
                       allow_purchases=allow_purchases)


def enabled(c):
    plugin = getattr(c, "plugins", {}).get(UUID)
    return bool(plugin and plugin.enabled)


def paused():
    if os.getenv('AISKLAD_SHARED_DB'):
        from aisklad_shop.modules import channel_enabled
        if not channel_enabled('funpay'):return True
    return STORE and STORE.get_meta("paused", "yes") == "yes"


def alert(c, message):
    LOG.warning(message)
    health.safe_notice(sys.modules[__name__], c, str(message))


def buyer_message(c, row, msg):
    try:
        result = c.send_message(row["chat_id"], msg, row["buyer_name"], watermark=False)
        if not result:
            LOG.warning("Нет подтверждения отправки уведомления %s", row["id"])
        return bool(result)
    except Exception:
        LOG.exception("Не удалось отправить сообщение покупателю %s", row["id"])
        return False


def rule_for_title(title):
    if str(title).startswith('rule:'):
        name = str(title)[5:]
        if name not in CFG['lot_rules']:
            raise ValueError('Привязка оплаченного товара отсутствует')
        return CFG['lot_rules'][name]
    return {'kind': 'stars'}


def order_label(row):
    kind = row.get('kind', 'stars')
    if kind in STEAM_KINDS:
        currency=rule_for_title(row['description']).get('currency','RUB')
        return str(row['stars']) + ' ' + ('₽' if currency=='RUB' else currency) + ' на баланс Steam'
    if kind == 'game_key':
        return rule_for_title(row['description']).get('game_name', 'Ключ Steam')
    if kind in services.KINDS:return rule_for_title(row['description'])['display_name']
    return str(row['stars']) + ' Telegram Stars'


def completed_message(row):
    return customer_messages.completion(sys.modules[__name__],row)


def supplier_product(api, rule, count):
    kind = rule.get('kind', 'stars')
    if kind in services.KINDS:return services.product(api,rule)
    if kind == 'game_key':
        product = api.key_product(rule['app_id'], rule['option_id'], rule['region'])
        if (product.get('countries', []) != rule.get('countries', [])
                or product.get('excluded_countries', []) != rule.get('excluded_countries', [])):
            raise ValueError('Изменились страны активации ключа')
        return product
    if kind == 'steam_rub':
        return api.steam_rub_product(max(100, count))
    if kind in STEAM_KINDS:
        return api.steam_currency_product(rule['currency'],max(rule['min_count'],count))
    return api.product('telegram-stars', 55, count)


def persist_settings():
    temporary = CFG_PATH.with_name(CFG_PATH.name + '.maintenance.tmp')
    temporary.write_text(json.dumps(CFG, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(CFG_PATH)


def price_band(rule, unit_usd):
    options = CFG['auto_pricing']
    rate = pricing.pricing_rate(CFG)
    low = max(D(CFG['min_margin_pct']), D(options['min_margin_pct']))
    if rule.get('kind') in STEAM_KINDS:
        # FunPay rounds each RUB unit to kopecks; fixed costs amortize at the minimum top-up.
        fixed = D(CFG['other_cost_per_order_rub']) / rule['min_count']
    else:
        fixed = CFG['other_cost_per_order_rub']
    floor = pricing.seller_floor(unit_usd, rule['stars_per_unit'], rate,
                                 CFG['withdrawal_fee_pct'], fixed, low, CFG['min_profit_rub'])
    ceiling = pricing.seller_ceiling(unit_usd, rule['stars_per_unit'], rate,
                                    CFG['withdrawal_fee_pct'], fixed, options['max_margin_pct'])
    return floor, max(floor, ceiling)


def valid_control(token=None):
    return (not STOP.is_set() and live_allowed() and enabled(C)
            and (STORE.get_meta('resume_token', '') == token if token is not None else not paused()))


def write_seller_price(c, offer, rule, price, token=None):
    with LOT_WRITE_LOCK:
        if not valid_control(token):
            raise ValueError('Пересчёт отменён паузой')
        fields = c.account.get_lot_fields(int(offer), node_id=rule['subcategory_id'])
        if any(not catalog.field_matches(editor_field_value(fields,k),k,rule) for k in rule['match_fields']):
            raise ValueError('Изменились поля привязанного лота')
        if D(fields.price) == D(price):
            return
        previous_price=D(fields.price)
        fields.price = float(D(price))
        c.account.save_lot(fields.renew_fields())
        checked = c.account.get_lot_fields(int(offer))
        if not valid_control(token):
            checked.active = False
            c.account.save_lot(checked.renew_fields())
            raise ValueError('Пересчёт остановлен паузой')
        if D(checked.price) != D(price):
            raise ValueError('FunPay не сохранил рассчитанную цену')
        activity.record(sys.modules[__name__],c,'price',f"💰 {catalog.display_title(rule)}: {previous_price} → {price} ₽ · лот {offer}",offer)


def auto_reprice(c, force=False, resume_token=None):
    if not CFG.get('auto_pricing', {}).get('enabled') or CFG['mode'] != 'live':
        return
    if not force and time.time() - float(STORE.get_meta('last_reprice', '0')) < CFG['auto_pricing']['interval_seconds']:
        return
    if CFG['auto_pricing']['watch_topup_rate']:
        if pricing.TOPUP_CLIENT is None:
            raise ValueError('Не подключён курс партнёрского кошелька')
        pricing.TOPUP_CLIENT.refresh()
    with PROCESS_LOCK:
        if not valid_control(resume_token):
            raise ValueError('Автоцена не запущена или отменена')
        items = [(offer, name) for offer, name in list(CFG['managed_lots'].items())
                 if CFG['lot_rules'][name].get('kind', 'stars') == 'stars'
                 and controls.manual_price(sys.modules[__name__],offer) is None
                 and not controls.disabled(sys.modules[__name__],offer)]
        if not items:
            STORE.set_meta('last_reprice',str(time.time()))
            return
        first = c.account.get_lot_fields(int(items[0][0]), node_id=2418)
        market = c.account.get_subcategory_public_lots(first.subcategory.type, 2418, locale='ru')
        api = client()
        product = api.product('telegram-stars', 55, 50)
        own_ids = set(map(int, CFG['managed_lots']))
        report = []
        for offer, name in items:
            if not valid_control(resume_token):
                raise ValueError('Пересчёт отменён')
            rule = CFG['lot_rules'][name]
            if controls.manual_price(sys.modules[__name__],offer) is not None:continue
            fields = c.account.get_lot_fields(int(offer), node_id=2418)
            floor, ceiling = price_band(rule, product['price_usd'])
            competitor = pricing.comparable_minimum(market, rule['stars_per_unit'], c.account.id, own_ids)
            coefficient = D(fields.calc_result.commission_coefficient)
            plan = pricing.choose_price(floor, competitor, coefficient,
                    lambda price: c.account.calc(fields.subcategory.type, subcategory_id=2418, price=float(price)),
                    step=CFG['auto_pricing']['step_buyer_rub'], ceiling=ceiling)
            verify_price(c, {'stars': rule['stars_per_unit']}, product['price_usd'], plan['seller_price'])
            write_seller_price(c, offer, rule, plan['seller_price'], resume_token)
            rule['last_price_usd'] = str(D(product['price_usd']))
            report.append({'stars': rule['stars_per_unit'], 'seller_price_rub': str(plan['seller_price']),
                           'buyer_price_rub': str(plan['buyer_price']), 'competitor_price_rub': str(plan['competitor_buyer_price']),
                           'reason': plan['reason']})
        STORE.set_meta('last_reprice', str(time.time()))
        STORE.set_meta('pricing_report', json.dumps(report, ensure_ascii=False))
        persist_settings()
        LOG.info('Цены Stars проверены: ' + ', '.join(f"{r['stars']} ⭐ — {r['seller_price_rub']} ₽" for r in report))


def sync_catalog(c):
    if not CFG.get('catalog_sync', {}).get('enabled') or CFG['mode'] != 'live' or not live_allowed():
        return
    api = client()
    desired=[];unavailable=[]
    try:desired=catalog.catalogue(api, CFG['catalog_sync']['max_game_price_usd'], STOP)
    except ApiFailure:unavailable.append('game_key')
    currencies=CFG.get('steam_currencies',{}).get('selected',['RUB']) if CFG.get('steam_currencies',{}).get('enabled') else ['RUB']
    for currency in currencies:
        try:
            product=api.steam_rub_product(100) if currency=='RUB' else api.steam_currency_product(currency,STEAM_CURRENCIES[currency]['min_count'])
            desired.append((STEAM_CURRENCIES[currency]['kind'],catalog.rub_rule(1,product) if currency=='RUB' else catalog.currency_rule(currency,product)))
        except (ApiFailure,ValueError):unavailable.append(STEAM_CURRENCIES[currency]['kind'])
    if CFG['services']['enabled']:
        try:desired+=services.catalogue(api,CFG['services']['selected'],CFG['services']['max_price_usd'])
        except ApiFailure:unavailable.extend(services.KINDS)
    own_keys=c.account.get_my_subcategory_lots(1008)
    capacity=max(0,CFG['catalog_sync']['max_key_lots']-len(own_keys))
    seen, added, remaining = set(), 0, 0
    key_added=0;capacity_waiting=0
    for name, source in desired:
        if STOP.is_set():
            return
        seen.add(name)
        with PROCESS_LOCK:
            if not live_allowed() or not enabled(c):
                return
            existing = CFG['lot_rules'].get(name)
            if existing is not None:
                # Binding and activation country contract of old orders stay immutable.
                if (existing.get('region') != source.get('region') or existing['match_fields'] != source['match_fields']
                        or existing.get('countries') != source.get('countries')
                        or existing.get('excluded_countries') != source.get('excluded_countries')):
                    existing['sell_enabled'] = False
                    continue
                existing.update(last_price_usd=source['last_price_usd'], sell_enabled=not existing.get('history',False))
                if source.get('verified_at'):existing['verified_at']=source['verified_at']
            else:
                if any(r['subcategory_id']==source['subcategory_id'] and r['match_fields']==source['match_fields']
                       for r in CFG['lot_rules'].values()):
                    continue  # A paid order must identify exactly one immutable supplier SKU.
                if source.get('kind')=='game_key' and key_added>=capacity:
                    capacity_waiting+=1
                    continue
                if added >= CFG['catalog_sync']['max_new_lots_per_pass']:
                    remaining+=1
                    continue
                floor, ceiling = price_band(source, source['last_price_usd'])
                price = ceiling
                with LOT_WRITE_LOCK:
                    try:
                        offer = catalog.create_draft(sys.modules[__name__], c, name, source, price)
                    except (catalog.DraftUncertain,catalog.DraftRejected) as exc:
                        if STORE.get_meta('catalog_warning:'+name,'no')!='yes':
                            alert(c,f'Лот {source.get("game_name","Steam RUB")} требует проверки создания; остальные товары продолжают импортироваться.')
                            STORE.set_meta('catalog_warning:'+name,'yes')
                        continue
                    except catalog.CategoryFull:
                        capacity=key_added
                        capacity_waiting+=1
                        continue
                source['description_revision']=catalog.COPY_REVISION
                CFG['lot_rules'][name] = source
                CFG['managed_lots'][str(offer)] = name
                if offer not in CFG['lot_ids_to_disable']:
                    CFG['lot_ids_to_disable'].append(offer)
                if source['subcategory_id'] not in CFG['allowed_subcategory_ids']:
                    CFG['allowed_subcategory_ids'].append(source['subcategory_id'])
                persist_settings()
                added += 1
                activity.record(sys.modules[__name__],c,'catalog',f"🆕 Создан лот {offer}: {catalog.display_title(source)}",offer)
                if source.get('kind')=='game_key':key_added+=1
                if added % 10 == 0:
                    LOG.info('Каталог: создано %s новых лотов. Закупок не было.',added)
        if STOP.wait(0.3):
            return
    with PROCESS_LOCK:
        for name, rule in CFG['lot_rules'].items():
            if rule.get('kind') in ('game_key',*STEAM_KINDS,*services.KINDS) and name not in seen:
                rule['sell_enabled'] = False
        persist_settings()
        STORE.set_meta('last_catalog_sync', str(time.time()))
        delay=CFG['catalog_sync']['batch_interval_seconds'] if remaining else CFG['catalog_sync']['interval_seconds']
        STORE.set_meta('next_catalog_sync',str(time.time()+delay))
        summary=f'Каталог: лотов добавлено {added}; ключей {len(own_keys)+key_added}/{CFG["catalog_sync"]["max_key_lots"]}'
        if capacity_waiting:summary+='; достигнут лимит FunPay, созданные товары работают'
        STORE.set_meta('catalog_summary', summary)
        STORE.set_meta('catalog_error','')
        if unavailable:STORE.set_meta('catalog_error','Недоступны части каталога: '+', '.join(unavailable))
    if added:LOG.info('Каталог: добавлено %s лотов; ещё %s ожидают следующей партии.',added,remaining)


def stock_amount_matches(rule, actual, desired):
    # Missing stock is normal for on-demand services; FunPay has no stored count.
    # Currency lots still need an explicit affordable nominal limit.
    return actual == desired or (actual is None and rule.get('kind') not in STEAM_KINDS)


def maintain_availability(c):
    if paused() or not live_allowed() or STOP.is_set():
        return
    api = client()
    balance = api.balance()
    daily_left = D(CFG['max_daily_usd']) - STORE.today_spend()
    commitments = D('0')
    for row in STORE.rows(('awaiting_username', 'ready', 'preparing', 'submitting'), limit=10000):
        rule = rule_for_title(row['description'])
        price = rule.get('last_price_usd') or CFG.get('dry_run_price_usd')
        if price:
            commitments += D(price) * row['stars']
    available = min(balance - D(CFG['min_balance_reserve_usd']) - commitments, daily_left - commitments)
    STORE.set_meta('last_checked_balance', str(balance))
    last=STORE.get_meta('activity_balance','')
    if not last or D(last)!=balance:
        activity.record(sys.modules[__name__],c,'balance',f'💵 Баланс STEAM.RU: '+(last+' → ' if last else '')+str(balance)+' USD')
        STORE.set_meta('activity_balance',str(balance))
    STORE.set_meta('last_balance_check_at',str(time.time()))
    snapshots = {}
    if hasattr(c.account, 'get_my_subcategory_lots'):
        nodes = {CFG['lot_rules'][name]['subcategory_id'] for name in CFG['managed_lots'].values()}
        for node in nodes:
            lots = c.account.get_my_subcategory_lots(node)
            if isinstance(lots, list):
                snapshots.update({int(lot.id):lot for lot in lots})
    for offer, name in list(CFG['managed_lots'].items()):
        if STOP.is_set() or paused():
            return
        if int(offer) in rotation.busy_offers(sys.modules[__name__]):continue
        rule = CFG['lot_rules'][name]
        needs_copy=rule.get('description_revision')!=catalog.COPY_REVISION
        source_price = rule.get('last_price_usd') or CFG.get('dry_run_price_usd')
        if source_price is None:
            continue
        needed = rule['min_count'] if rule.get('kind') in STEAM_KINDS else rule['stars_per_unit']
        can_sell = (rule.get('sell_enabled', True) and not controls.disabled(sys.modules[__name__],offer)
            and D(source_price) * needed <= min(available,D(CFG['max_single_order_usd'])))
        amount = min(rule['max_count'], int(max(D('0'), min(available,D(CFG['max_single_order_usd']))) / D(source_price))) if rule.get('kind') in STEAM_KINDS else 1
        manual=controls.manual_price(sys.modules[__name__],offer)
        plan_price = manual if manual is not None else (price_band(rule, source_price)[1] if rule.get('kind') in ('game_key',*STEAM_KINDS,*services.KINDS) else None)
        snapshot = snapshots.get(int(offer))
        if not needs_copy and snapshot is not None and snapshot.active == can_sell and (plan_price is None or D(snapshot.price)==plan_price) and (
                not can_sell or rule.get('kind','stars')=='stars' or stock_amount_matches(rule,snapshot.amount,amount)):
            continue
        with PROCESS_LOCK, LOT_WRITE_LOCK:
            if not valid_control():
                return
            fields = c.account.get_lot_fields(int(offer), node_id=rule['subcategory_id'])
            if currency_code(fields.currency) != 'RUB' or fields.auto_delivery:
                raise ValueError('Валюта или автовыдача управляемого лота изменилась')
            if any(not catalog.field_matches(editor_field_value(fields,k),k,rule) for k in rule['match_fields']):
                raise ValueError('Изменились поля управляемого лота')
            changed = False
            notes=[]
            if needs_copy:
                catalog.update_copy(fields,rule);controls.apply_text(sys.modules[__name__],offer,fields);changed=True;notes.append('обновлено оформление')
            if plan_price is not None:
                price = plan_price
                if D(fields.price) != price:
                    notes.append(f'цена {fields.price} → {price} ₽')
                    fields.price = float(price); changed = True
                if rule.get('kind','stars')!='stars' and can_sell and not stock_amount_matches(rule,fields.amount,amount):
                    notes.append(f'наличие {fields.amount} → {amount}')
                    fields.amount = amount; changed = True
            if fields.active != can_sell:
                notes.append('включён' if can_sell else 'выключен по наличию, балансу или лимиту')
                fields.active = can_sell; changed = True
            if changed:
                c.account.save_lot(fields.renew_fields())
                event_kind='price' if any(n.startswith('цена ') for n in notes) else 'appearance' if notes==['обновлено оформление'] else 'availability'
                activity.record(sys.modules[__name__],c,event_kind,catalog.display_title(rule)+' · '+', '.join(notes)+f' · лот {offer}',offer)
                if needs_copy:
                    rule['description_revision']=catalog.COPY_REVISION
                    persist_settings()
                if not valid_control():
                    checked = c.account.get_lot_fields(int(offer))
                    checked.active = False
                    c.account.save_lot(checked.renew_fields())
                    return


def maintenance_worker(c):
    while not STOP.is_set():
        try:
            if os.getenv('AISKLAD_SHARED_DB'):
                from aisklad_shop.modules import channel_enabled
                if not channel_enabled('funpay'):
                    # Hiding existing offers does not require a fresh supplier
                    # FX quote. A disabled channel must not keep selling because
                    # the unrelated rate check is currently unavailable.
                    if enabled(c) and STORE.get_meta('disable_lots_pending','no')=='yes':
                        if time.time()>=float(STORE.get_meta('next_catalog_sync','0')):
                            with PROCESS_LOCK:disable_managed_lots(c)
                    if STOP.wait(20):break
                    continue
            if live_allowed() and enabled(c):
                controls.expire(sys.modules[__name__])
                if STORE.get_meta('disable_lots_pending','no')=='yes':
                    if time.time()>=float(STORE.get_meta('next_catalog_sync','0')):
                        with PROCESS_LOCK:disable_managed_lots(c)
                    if STORE.get_meta('disable_lots_pending','no')=='yes':
                        STOP.wait(20)
                        continue
                if CFG['catalog_sync']['enabled'] and time.time()>=float(STORE.get_meta('next_catalog_sync','0')):
                    try:
                        sync_catalog(c)
                    except funpay_control.FunPayRateLimited:
                        raise
                    except Exception as exc:
                        STORE.set_meta('next_catalog_sync',str(time.time()+1800))
                        STORE.set_meta('catalog_error',type(exc).__name__)
                        LOG.warning('Импорт новых лотов отложен: %s. Запуск существующих продаж не отменяется.',type(exc).__name__)
                if not paused() and CFG['auto_pricing']['enabled']:
                    auto_reprice(c)
                if not paused() and CFG['catalog_sync']['enabled'] and time.time()>=float(STORE.get_meta('next_availability_check','0')):
                    maintain_availability(c)
                    STORE.set_meta('next_availability_check',str(time.time()+60))
                if not paused() and CFG['rotation']['enabled']:
                    try:
                        rotation.run(sys.modules[__name__],c)
                    except funpay_control.FunPayRateLimited:
                        raise
                    except Exception as exc:
                        STORE.set_meta('rotation_summary','Замена игр отложена: '+type(exc).__name__)
                        LOG.warning('Ротация отложена: %s; работа существующих заказов продолжается.',type(exc).__name__)
                health.success(sys.modules[__name__], 'maintenance')
        except funpay_control.FunPayRateLimited as exc:
            until=time.time()+exc.seconds
            STORE.set_meta('next_catalog_sync',str(until))
            STORE.set_meta('next_availability_check',str(until))
            STORE.set_meta('last_reprice',str(time.time()-CFG['auto_pricing']['interval_seconds']+exc.seconds))
            if time.time()>=float(STORE.get_meta('next_rate_limit_notice','0')):
                LOG.warning('FunPay ограничил запросы к лотам. Импорт ждёт %s сек.; созданные лоты сохранены.',exc.seconds)
                STORE.set_meta('next_rate_limit_notice',str(until))
        except Exception as exc:
            LOG.warning('Ошибка управления каталогом: %s', type(exc).__name__)
            critical(c, 'Сбой управления лотами: ' + str(exc)[:180], scope='maintenance')
        if STOP.wait(20):
            break
        if MAINTENANCE_WAKE.is_set():
            MAINTENANCE_WAKE.clear()


def editor_field_value(fields, key):
    if key == 'summary':
        value = fields.title_ru
    elif key == 'name':
        value = fields.fields.get('fields[name][ru]', '')
    else:
        value = fields.fields.get('fields[' + key + ']', '')
    value = str(value).strip()
    return value.lstrip('%') if key in ('currency', 'type') else value


def disable_managed_lots(c):
    failures = []
    snapshots = {}
    if hasattr(c.account,'get_my_subcategory_lots'):
        try:
            nodes={CFG['lot_rules'][name]['subcategory_id'] for name in CFG['managed_lots'].values()}
            for node in nodes:
                lots=c.account.get_my_subcategory_lots(node)
                if isinstance(lots,list):snapshots.update({int(lot.id):lot for lot in lots})
        except funpay_control.FunPayRateLimited as exc:
            if STORE is not None:
                STORE.set_meta('disable_lots_pending','yes')
                STORE.set_meta('next_catalog_sync',str(time.time()+exc.seconds))
            LOG.warning('FunPay ограничил запросы. Снятие лотов продолжится после паузы %s сек.',exc.seconds)
            return list(CFG['lot_ids_to_disable'])
        except Exception:
            pass
    for lot_id in CFG["lot_ids_to_disable"]:
        if int(lot_id) in snapshots and not snapshots[int(lot_id)].active:
            continue
        try:
            with LOT_WRITE_LOCK:
                fields = c.account.get_lot_fields(int(lot_id))
                if fields.active:
                    fields.active = False
                    c.account.save_lot(fields.renew_fields())
                if c.account.get_lot_fields(int(lot_id)).active:
                    raise ValueError("Лот остался активен")
        except funpay_control.FunPayRateLimited as exc:
            if STORE is not None:
                STORE.set_meta('disable_lots_pending','yes')
                STORE.set_meta('next_catalog_sync',str(time.time()+exc.seconds))
            LOG.warning('FunPay ограничил запросы. Снятие оставшихся лотов продолжится после паузы %s сек.',exc.seconds)
            return [int(x) for x in CFG['lot_ids_to_disable'] if int(x) not in snapshots or snapshots[int(x)].active]
        except Exception:
            failures.append(int(lot_id))
            LOG.warning("Не удалось выключить лот %s", lot_id)
    if failures:
        alert(c, "ВЫКЛЮЧИ ЛОТЫ ВРУЧНУЮ: " + ", ".join(map(str, failures)))
    elif STORE is not None:
        STORE.set_meta('disable_lots_pending','no')
    return failures


def critical(c, message, scope='processing', urgent=False, incident=None):
    return health.failure(sys.modules[__name__], c, message, scope, urgent, incident)


def live_offer_check(c):
    """Только чтение перед открытием продаж; никаких закупок."""
    if not live_allowed() or not enabled(c) or STOP.is_set():
        raise ValueError("LIVE или плагин заблокирован")
    if not CFG.get("managed_lots"):
        raise ValueError("Не настроены управляемые лоты")
    runner = getattr(c, "runner", None)
    if runner is None or getattr(runner, "saved_orders", None) is None:
        raise ValueError("FunPay ещё загружает список заказов. Подожди и повтори /sr_resume")
    if not getattr(runner, "make_order_requests", False) or not getattr(runner, "make_msg_requests", False):
        raise ValueError("Нужно включить чтение новых заказов и сообщений FunPay")
    if getattr(c, "autorestore_enabled", False) or getattr(c, "autodelivery_enabled", False):
        raise ValueError("Выключи штатную автовыдачу и автовосстановление Cardinal")
    api = client()  # allow_purchases=False
    flexible = CFG.get('catalog_sync', {}).get('enabled', False)
    balance = api.balance() if flexible else None
    offers = []
    largest = D("0")
    for index,(offer, name) in enumerate(CFG["managed_lots"].items(),1):
        STORE.set_meta('launch_progress',f'Проверяю лоты: {index}/{len(CFG["managed_lots"])}')
        if int(offer) in rotation.busy_offers(sys.modules[__name__]):continue
        rule = CFG["lot_rules"][name]
        if controls.disabled(sys.modules[__name__],offer):continue
        if flexible and not rule.get('sell_enabled', True):
            continue
        fields = c.account.get_lot_fields(int(offer), node_id=int(rule["subcategory_id"]))
        if (int(fields.lot_id) != int(offer) or fields.subcategory.id != rule["subcategory_id"]
                or currency_code(fields.currency) != "RUB"):
            raise ValueError("Изменилась категория или валюта лота")
        if any(not catalog.field_matches(editor_field_value(fields,key),key,rule) for key in rule['match_fields']):
            raise ValueError("Изменились поля пакета")
        if fields.auto_delivery:
            raise ValueError("Встроенная автовыдача FunPay должна быть выключена")
        product = ({'price_usd': rule['last_price_usd']} if flexible and rule.get('kind') == 'game_key'
                   else supplier_product(api, rule, rule['stars_per_unit']))
        count = rule['min_count'] if rule.get('kind') in STEAM_KINDS else rule['stars_per_unit']
        if flexible and D(product['price_usd'])*count>D(CFG['max_single_order_usd']):continue
        if CFG['auto_pricing']['enabled'] and rule.get('kind','stars')!='stars':
            manual=controls.manual_price(sys.modules[__name__],offer)
            target=manual if manual is not None else price_band(rule,product['price_usd'])[1]
            if D(fields.price)!=target:
                with LOT_WRITE_LOCK:
                    fields.price=float(target);c.account.save_lot(fields.renew_fields())
                    checked=c.account.get_lot_fields(int(offer),node_id=rule['subcategory_id'])
                    if D(checked.price)!=target:raise ValueError('Цена нового товара не сохранилась')
                fields=checked
        cost, _ = verify_price(c, {"stars": count}, product["price_usd"], D(fields.price) * count if rule.get('kind') in STEAM_KINDS else fields.price,
                               manual_listing=controls.manual_price(sys.modules[__name__],offer) is not None)
        if cost>D(CFG['max_single_order_usd']):continue
        if flexible and balance < cost + D(CFG['min_balance_reserve_usd']):
            with LOT_WRITE_LOCK:
                if fields.active:
                    fields.active = False
                    c.account.save_lot(fields.renew_fields())
            continue
        if flexible and rule.get('kind') in STEAM_KINDS:
            units=min(rule['max_count'],int(min(balance-D(CFG['min_balance_reserve_usd']),D(CFG['max_single_order_usd']))/D(product['price_usd'])))
            if units<rule['min_count']:continue
            if fields.amount!=units:
                with LOT_WRITE_LOCK:
                    fields.amount=units;c.account.save_lot(fields.renew_fields())
                    checked=c.account.get_lot_fields(int(offer),node_id=rule['subcategory_id'])
                    if checked.amount!=units:raise ValueError('Доступный номинал Steam не сохранился')
                fields=checked
                activity.record(sys.modules[__name__],c,'availability',f'📦 Steam {rule.get("currency","RUB")}: доступно {units} единиц · лот {offer}',offer)
        largest = max(largest, cost)
        offers.append(fields)
    balance = balance if flexible else api.balance()
    if not offers:
        if not flexible:raise ValueError('Нет доступных лотов по текущему балансу')
        STORE.set_meta('last_checked_balance',str(balance))
        STORE.set_meta('last_balance_check_at',str(time.time()))
        return []
    if balance < largest + D(CFG["min_balance_reserve_usd"]):
        raise ValueError("Баланса не хватает на самый большой пакет с резервом")
    previous = STORE.get_meta("last_checked_balance", None)
    if previous is not None and balance > D(previous) + Decimal("0.01") and not CFG.get('auto_pricing', {}).get('watch_topup_rate'):
        raise ValueError("Баланс увеличился: после пополнения перепроверь стоимость USD")
    STORE.set_meta("last_checked_balance", str(balance))
    return offers


def resume_live(c, requested_token=None):
    with PROCESS_LOCK:
        if os.getenv('AISKLAD_SHARED_DB'):
            from aisklad_shop.modules import channel_enabled
            if not channel_enabled('funpay'):
                raise ValueError('Модуль FunPay выключен. Сначала /funpay_on, затем /sr_resume.')
        if STOP.is_set() or not live_allowed() or not enabled(c):
            raise ValueError("LIVE заблокирован")
        if WORKER is None or not WORKER.is_alive():
            raise ValueError("Рабочий процесс ещё не запущен")
        if requested_token is not None and STORE.get_meta('resume_token','')!=requested_token:
            raise ValueError('Запуск отменён командой паузы')
        STORE.set_meta("paused", "yes")
        controls.expire(sys.modules[__name__])
        token = requested_token or uuid.uuid4().hex
        STORE.set_meta("resume_token", token)
        STORE.set_meta('launch_progress','Пересчитываю цены Stars')
        try:
            if STORE.get_meta('disable_lots_pending','no')=='yes' and disable_managed_lots(c):
                raise ValueError('FunPay пока не подтвердил остановку предыдущих лотов; повтори после паузы сайта')
            if CFG.get('auto_pricing', {}).get('enabled'):
                auto_reprice(c, force=True, resume_token=token)
            offers = live_offer_check(c) if CFG.get("activate_lots_on_resume") else []
            if STORE.get_meta("resume_token", "") != token:
                raise ValueError("Запуск отменён командой паузы")
            STORE.set_meta("paused", "no")
            for index,fields in enumerate(offers,1):
                STORE.set_meta('launch_progress',f'Включаю лоты: {index}/{len(offers)}')
                if (paused() or STOP.is_set() or not live_allowed() or not enabled(c)
                        or STORE.get_meta("resume_token", "") != token):
                    raise ValueError("Запуск остановлен")
                with LOT_WRITE_LOCK:
                    name=CFG['managed_lots'][str(fields.lot_id)]
                    rule=CFG['lot_rules'][name]
                    catalog.update_copy(fields,rule)
                    controls.apply_text(sys.modules[__name__],fields.lot_id,fields)
                    fields.active = True
                    c.account.save_lot(fields.renew_fields())
                    rule['description_revision']=catalog.COPY_REVISION
                if not c.account.get_lot_fields(fields.lot_id).active:
                    raise ValueError("Лот не включился")
                activity.record(sys.modules[__name__],c,'availability',f'▶️ Включён лот {fields.lot_id}: '+catalog.display_title(rule),fields.lot_id)
            if (paused() or STOP.is_set() or not live_allowed() or not enabled(c)
                    or STORE.get_meta("resume_token", "") != token):
                raise ValueError("Запуск остановлен")
            STORE.set_meta("last_health_check", str(time.time()))
            if offers:persist_settings()
            health.reset_all(sys.modules[__name__])
            STORE.set_meta('launch_progress',f'Продажи запущены; открыто {len(offers)} лотов')
            return len(offers)
        except Exception:
            STORE.set_meta("paused", "yes")
            if CFG["auto_disable_lots_on_pause"]:
                disable_managed_lots(c)
            raise


def on_post_init(c: "Cardinal"):
    global C, STORE
    C = c
    try:
        load_settings()
        if CFG['catalog_sync']['enabled'] or CFG['auto_pricing']['enabled']:
            funpay_control.install(c.account,gap=CFG['catalog_sync']['request_gap_seconds'],
                                   cooldown=CFG['catalog_sync']['cooldown_seconds'])
        STORE = Store(DB_PATH)
        notifications.silence_routine_backlog(sys.modules[__name__])
        # Crash recovery. Список статусов, которые могут означать уже отправленный запрос, НЕ ретраим.
        for r in STORE.recover_interrupted():
            alert(c, f"Требует ручной проверки после перезапуска: #{r['id']}")
        # Каждый запуск требует осознанного /sr_resume; старую паузу не сбрасываем.
        STORE.set_meta("paused", "yes")
        if CFG["mode"] == "live" and CFG["auto_disable_lots_on_pause"]:
            disable_managed_lots(c)
        if CFG["mode"] == "live" and not live_allowed():
            alert(c, "LIVE отключён: проверьте ключи, подтверждение, свежий курс и автоотключение своих лотов")
        alert(c, f"Инициализирован. mode={CFG['mode']}; paused={paused()}; live_allowed={live_allowed()}")
    except Exception:
        LOG.exception("Ошибка запуска")
        STORE = None
        raise


def on_new_order(c: "Cardinal", e):
    if STORE is None or not enabled(c):
        return
    if CFG["mode"] == "dry_run" and not CFG["capture_paid_orders_in_dry_run"]:
        return
    s = e.order
    preview = str(getattr(s, "description", "") or "")
    category_id = getattr(getattr(s, "subcategory", None), "id", None)
    rules = CFG.get("lot_rules", {})
    could_match_rule = bool(rules) and (category_id is None or any(
        str(rule["subcategory_id"]) == str(category_id) for rule in rules.values()))
    if not any(title in preview for title in CFG["lots"]) and not could_match_rule:
        return
    if status_name(getattr(s, "status", None)) != "PAID":
        return
    oid = str(s.id).lstrip("#")
    if oid.upper() == "ADTEST" or STORE.get(oid) or STORE.get_meta('manual_order:' + oid):
        return
    waiting = json.loads(STORE.get_meta('capture_retry:' + oid,'null'))
    if waiting and time.time() < waiting['next_at']:
        return
    try:
        full = c.account.get_order(oid)
        title, amount, stars, revenue = full_order_data(c, full, oid)
        if str(full.buyer_id) != str(s.buyer_id) or str(full.chat_id) != str(s.chat_id):
            raise ValueError("Краткие и полные данные покупателя не совпали")
        rule = rule_for_title(title)
        health.success(sys.modules[__name__], 'capture')
        STORE.set_meta('capture_retry:' + oid,'null')
        kind = rule.get('kind', 'stars')
        if STORE.insert_order(oid, full.buyer_id, full.chat_id, full.buyer_username or "",
                              title, stars, amount, revenue, captured_mode=CFG["mode"], kind=kind):
            row = STORE.get(oid)
            alert(c, f"Оплачен заказ #{oid} — {order_label(row)}.")
            if kind in ('game_key','service_code'):
                STORE.set_if_status(oid, 'awaiting_username', status='ready')
                buyer_message(c,STORE.get(oid),customer_messages.queue_message(sys.modules[__name__],STORE.get(oid))+'\n🔑 Код придёт в этот чат. Ничего дополнительно присылать не нужно.')
            elif kind=='service_topup':buyer_message(c,row,services.prompt(rule,oid))
            elif kind in STEAM_KINDS:
                account_name = getattr(full,'player',None)
                if isinstance(account_name,str) and re.fullmatch(r'[A-Za-z0-9_.-]{3,64}',account_name.strip()):
                    STORE.set_meta('recipient_from_order:' + oid,'yes')
                    if STORE.set_username(oid,full.buyer_id,full.chat_id,account_name.strip()):
                        buyer_message(c,STORE.get(oid),customer_messages.queue_message(sys.modules[__name__],STORE.get(oid)))
                else:
                    buyer_message(c,row,f"╭─ 💰 СПАСИБО ЗА ПОКУПКУ!\n│ Заказ #{oid} · {order_label(row)}\n╰─ Пришли логин Steam одним сообщением: логин #{oid}.\n\n🔒 Пароль и Steam Guard не нужны.\n\n"+customer_messages.FOOTER)
            else:
                buyer_message(c,row,f"╭─ ⭐ СПАСИБО ЗА ПОКУПКУ!\n│ Заказ #{oid} · {stars} Telegram Stars\n╰─ Пришли @username получателя #{oid}. Если заказ один, можно только @username.\n\n🔒 Пароли и коды Telegram не нужны.\n\n"+customer_messages.FOOTER)
    except Exception as exc:
        if isinstance(exc, OrderDataError):
            STORE.set_meta('capture_retry:' + oid,'null')
            health.order_issue(sys.modules[__name__],c,oid,str(exc))
            return
        if schedule_order_read(c,s,oid,exc):
            return
        STORE.set_meta('capture_retry:' + oid,'null')
        reason = str(exc)[:180] if isinstance(exc, OrderDataError) else type(exc).__name__
        LOG.warning("Заказ %s не принят: %s", oid, reason)
        if CFG["mode"] == "live" and CFG.get("managed_lots") and could_match_rule:
            critical(c, f"Заказ #{oid}: {reason}. Выдача не начата. Открой https://funpay.com/orders/{oid}/ и проверь заказ.",scope='capture')
        else:
            alert(c, f"Заказ #{oid} не прошёл проверку данных FunPay; выдача не начата")


def on_initial_order(c, e):
    # На первом запуске это может быть вся старая история неоплаченных выдач.
    if CFG.get("capture_initial_paid_orders") is True:
        on_new_order(c, e)


def on_new_message(c: "Cardinal", e):
    if STORE is None or not enabled(c):
        return
    m = getattr(e, "message", None)
    if not m or getattr(m,"author_id",None) in (0, getattr(c.account,"id", None)) or getattr(m,"by_bot",False):
        return
    if status_name(getattr(m, "type", None)) != "NON_SYSTEM":
        return
    text = str(getattr(m, "text", "") or "").strip()
    if customer_messages.handle_command(sys.modules[__name__],c,m,text):return
    if services.handle_message(sys.modules[__name__],c,m,text):return
    parsed = parse_reply(text)
    general = re.fullmatch(r'([A-Za-z0-9_.-]{3,64})\s+#([A-Za-z0-9_-]{3,90})', text)
    if not parsed and general:
        parsed = general.groups()
    row = None
    if parsed:
        username, order_id = parsed
        row = STORE.get(order_id)
        if row is None:
            waiting = [r for r in STORE.awaiting_for_buyer(m.author_id) if matching_message_chat(c, m, r)]
            if waiting:
                buyer_message(c, waiting[0], 'Не найден указанный номер заказа. Скопируйте номер из сообщения продавца или отправьте только получателя, если ожидающий заказ один.')
            return
    else:
        username = username_or_none(text) if text.startswith("@") else (text if re.fullmatch(r'[A-Za-z0-9_.-]{3,64}', text) else None)
        if not username:
            return
        matches = [r for r in STORE.awaiting_for_buyer(m.author_id)
                   if matching_message_chat(c, m, r) and
                   ((text.startswith('@') and r.get('kind', 'stars') == 'stars')
                    or (not text.startswith('@') and r.get('kind') in STEAM_KINDS))]
        if len(matches) > 1:
            buyer_message(c, matches[0], "У вас несколько ожидающих заказов. Пришлите @username #НОМЕР_ЗАКАЗА одним сообщением.")
            return
        if len(matches) == 1:
            row = matches[0]
            order_id = row["id"]
    if not row:
        return
    if row.get('kind', 'stars') == 'stars':
        username = username_or_none(username)
    elif row.get('kind') in STEAM_KINDS:
        username = username if re.fullmatch(r'[A-Za-z0-9_.-]{3,64}', username or '') else None
    if not username:
        return
    if not matching_message_chat(c, m, row):
        STORE.event(row["id"], "recipient_rejected", "Покупатель или личный чат не соответствует заказу")
        LOG.warning("Получатель по заказу %s отклонён: другой покупатель или чат", row["id"])
        return
    if row["status"] != "awaiting_username":
        if row["status"] in ("ready", "preparing", "submitting", "supplier_pending"):
            buyer_message(c, row, f"Получатель уже принят для заказа #{row['id']}. Заказ обрабатывается; повторная покупка не создаётся.")
        elif row["status"] == "cancelled":
            buyer_message(c, row, f"Заказ #{row['id']} отменён или возвращён. Выдача по нему остановлена.")
        return
    try:
        preflight(c, row)
    except Exception:
        buyer_message(c, row, f"Не удалось подтвердить оплату заказа #{row['id']}. Проверяем заказ, повторная покупка не запускается.")
        alert(c, f"Получатель #{row['id']} не принят: проверь статус оплаты FunPay")
        return
    if STORE.set_username(order_id, m.author_id, row["chat_id"], username):
        STORE.event(order_id, "username_received", "Введён username покупателем")
        buyer_message(c,STORE.get(order_id),customer_messages.queue_message(sys.modules[__name__],STORE.get(order_id)))


def matching_message_chat(c, message, row):
    """FunPay order node_name and Message numeric chat ID are distinct IDs."""
    if str(getattr(message, "author_id", "")) != row["buyer_id"]:
        return False
    message_chat = str(getattr(message, "chat_id", ""))
    if message_chat == row["chat_id"]:
        return True
    node = re.fullmatch(r"users-(\d+)-(\d+)", row["chat_id"])
    if not node or {node.group(1), node.group(2)} != {str(c.account.id), row["buyer_id"]}:
        return False
    if not message_chat.isdigit() or int(message_chat) <= 0:
        return False
    cid = int(message_chat)
    known = getattr(getattr(c, "runner", None), "users_ids", {}).get(cid)
    interlocutor = getattr(message, "interlocutor_id", None)
    if str(known) == row["buyer_id"] and str(interlocutor) == row["buyer_id"]:
        return True
    try:
        chat = c.account.get_chat(cid, with_history=False)
        return int(chat.id) == cid and str(chat.interlocutor_id) == row["buyer_id"]
    except Exception:
        return False


def on_order_status_change(c: "Cardinal", e):
    if STORE is None:
        return
    oid = str(e.order.id).lstrip("#")
    fpstatus = status_name(e.order.status)
    row = STORE.get(oid)
    if not row:
        if fpstatus == "PAID":
            on_new_order(c, e)
        return
    if fpstatus not in ("REFUNDED", "PARTIALLY_REFUNDED", "UNPAID", "CLOSED"):
        return
    STORE.set(oid, funpay_status=fpstatus)
    # CAS исключает отмену по устаревшему снимку preparing после начала отправки.
    for _ in range(3):
        if row["status"] in ("awaiting_username", "ready", "preparing"):
            target = "needs_review" if fpstatus == "CLOSED" else "cancelled"
            if STORE.set_if_status(oid, row["status"], status=target,
                                   details=f"FunPay {fpstatus} до покупки"):
                if fpstatus == "CLOSED":
                    alert(c, f"FunPay заказ #{oid} закрыт до выдачи; ручная проверка")
                return
            row = STORE.get(oid)
            if not row:
                return
            continue
        if row["status"] in ("cancelled", "simulated", "refunded"):
            return
        if fpstatus == "CLOSED" and row["status"] == "completed":
            return
        # Запрос мог уже уйти: сохраняем исходное состояние и UUID для опроса.
        changes={'details':f"ТРЕВОГА FunPay {fpstatus}; сверить поставщика"}
        if row['status']=='submitting' and not row['supplier_uuid']:
            changes['status']='uncertain'
        STORE.set_if_status(oid, row["status"], **changes)
        critical(c, f"FunPay {fpstatus} ПОСЛЕ начала заказа #{oid}; повторная покупка запрещена",scope='purchase',urgent=True,incident=oid)
        return
    critical(c, f"Состояние заказа #{oid} менялось при отмене; нужна проверка",scope='purchase',urgent=True,incident=oid)


def full_order_data(c, full, oid):
    """Доверяем полному заказу FunPay, а не сумме/количеству из описания события."""
    if str(oid).upper() == "ADTEST":
        raise OrderDataError("Встроенный тест Cardinal не является покупкой")
    if not full:
        raise OrderDataError("FunPay не дал подробности заказа")
    if str(getattr(full, "id", "")).lstrip("#") != oid:
        raise OrderDataError("FunPay вернул другой заказ")
    if status_name(getattr(full, "status", None)) != "PAID":
        raise OrderDataError("Заказ FunPay уже не в статусе PAID")
    if strict_count(getattr(full, "seller_id", None)) != strict_count(c.account.id):
        raise OrderDataError("Заказ принадлежит другому продавцу")
    strict_count(getattr(full, "buyer_id", None))
    category_id = getattr(getattr(full, "subcategory", None), "id", None)
    if category_id is None or strict_count(category_id) not in CFG["allowed_subcategory_ids"]:
        raise OrderDataError("Подкатегория Stars не разрешена в настройках")
    rules = CFG.get("lot_rules", {})
    category_rules = [(name, rule) for name, rule in rules.items()
                      if strict_count(rule["subcategory_id"]) == strict_count(category_id)]
    if category_rules:
        matched = []
        for name, rule in category_rules:
            if all(catalog.field_matches(order_field_value(full,key),key,rule) for key in rule['match_fields']):
                matched.append((name, rule))
        if len(matched) != 1:
            raise OrderDataError("Поля оплаченного товара не соответствуют одному разрешённому лоту")
        name, rule = matched[0]
        title = "rule:" + name
        kind = rule.get('kind', 'stars')
        units = strict_count(rule['stars_per_unit'], min_count=1, max_count=500)
    else:
        title = str(getattr(full, "short_description", "") or "").strip()
        if title not in CFG["lots"]:
            raise OrderDataError("Точное название оплаченного лота не разрешено")
        units = strict_count(CFG["lots"][title], max_count=150)
        kind = 'stars'
    # У штучного лота COMMON API может вернуть amount=None: это один пакет.
    raw_amount = getattr(full, "amount", None)
    if kind == 'stars' and raw_amount is None and units < 50:
        raise OrderDataError("Для продажи по одной звезде количество должно быть явно указано")
    try:
        amount = 1 if raw_amount is None else strict_count(raw_amount)
    except ValueError as exc:
        raise OrderDataError('Неподдерживаемое количество или сумма заказа') from exc
    stars = units * amount
    if currency_code(getattr(full, "currency", None)) != "RUB":
        raise OrderDataError("Поддерживаются только рублёвые заказы FunPay")
    if kind == 'stars' and (stars < 50 or stars > min(150, strict_count(CFG["max_total_stars"], min_count=50, max_count=150))):
        raise OrderDataError("Сумма звёзд выходит за безопасный лимит")
    if kind in ('game_key',*services.KINDS) and (stars != 1 or amount != 1):
        raise OrderDataError('Можно купить только один ключ в заказе')
    if kind in STEAM_KINDS and not rule['min_count'] <= stars <= rule['max_count']:
        raise OrderDataError('Неподдерживаемая сумма пополнения Steam')
    revenue = getattr(full, "sum", None)
    if revenue is None or D(revenue) <= 0:
        raise OrderDataError("Не определена выручка FunPay — запрещено покупать вслепую")
    return title, amount, stars, D(revenue)


def order_field_value(full, key):
    """Значение поля из полного заказа; описание события здесь не используется."""
    field = getattr(full, "fields", {}).get(key)
    if field is None:
        return ""
    value = getattr(field, "value", None)
    if isinstance(value, dict):
        value = value.get("ru", value.get("en", ""))
    if value is None:
        return ""
    if not isinstance(value, str):
        raise OrderDataError("Неожиданный формат поля лота")
    value = value.strip()
    # FunPay API returns the display labels, while the editor uses enum codes.
    # These two aliases were verified on real Steam RUB orders. Never infer
    # currency/method from the event description or strip arbitrary decoration.
    if getattr(getattr(full, 'subcategory', None), 'id', None) == 1086:
        verified = {('currency', 'select', 'RUB🔥'): 'RUB',
                    ('type', 'radio', 'По логину🔥'): 'by-login'}
        value = verified.get((key, getattr(field, 'field_type_id', None), value), value)
    if (getattr(getattr(full,'subcategory',None),'id',None) == 1008 and key == 'region2'
            and getattr(field,'field_type_id',None) == 'select'):
        value = {'СНГ':'CIS','Россия':'Russia','Европа':'Europe'}.get(value,value)
    return value.lstrip('%') if key in ('currency', 'type') else value


def preflight(c, row):
    full = c.account.get_order(row["id"])
    title, amount, stars, revenue = full_order_data(c, full, row["id"])
    if str(full.buyer_id) != row["buyer_id"] or str(full.chat_id) != row["chat_id"]:
        raise ValueError("Изменился покупатель или чат заказа")
    if STORE.get_meta('recipient_from_order:' + row['id']) == 'yes' and str(getattr(full,'player','') or '').strip() != row['username']:
        raise OrderDataError('Изменился логин из оплаченного заказа FunPay')
    if title != row["description"] or amount != row["amount"] or stars != row["stars"]:
        raise ValueError("Изменился лот или количество Stars")
    if rule_for_title(title).get('kind', 'stars') != row.get('kind', 'stars'):
        raise ValueError('Изменился вид товара')
    return revenue


def verify_price(c, row, price_usd, revenue, manual_listing=False):
    if not funding_rate_valid():
        raise ValueError("Курс пополнения депозита устарел")
    rate = pricing.pricing_rate(CFG) if CFG.get('auto_pricing', {}).get('enabled') else D(CFG['rub_per_usd'])
    out = finances(revenue, price_usd, row["stars"], rate,
                   CFG["withdrawal_fee_pct"], CFG["other_cost_per_order_rub"])
    out['rate'] = rate
    honor_paid = (CFG.get("honor_paid_price") is True and row.get("id")
                  and row.get("captured_mode") == "live")
    if not honor_paid and not manual_listing and (out["profit"] < D(CFG["min_profit_rub"]) or out["margin_pct"] < D(CFG["min_margin_pct"])):
        raise ValueError(f"Недостаточная прибыль: {money(out['profit'])} RUB / {out['margin_pct']:.2f}%")
    total_usd = D(price_usd) * int(row["stars"])
    if total_usd > D(CFG["max_single_order_usd"]):
        raise ValueError("Превышен лимит USD на один заказ")
    if row.get('id') and STORE.today_spend() + total_usd > D(CFG["max_daily_usd"]):
        raise ValueError("Превышен ежедневный бюджет")
    return total_usd, out


def process_ready(c):
    if not PROCESS_LOCK.acquire(blocking=False):
        return
    try:
        _process_ready(c)
    finally:
        PROCESS_LOCK.release()


def _process_ready(c):
    if CFG["mode"] != "live" or STOP.is_set() or not live_allowed() or paused() or not enabled(c):
        return
    row = STORE.take_ready()
    if not row:
        return
    oid = row["id"]
    try:
        if row.get("captured_mode") != "live":
            raise ValueError("Тестовый или старый заказ без подтверждённого происхождения не покупается")
        revenue = preflight(c, row)
        api = client(allow_purchases=True)
        rule = rule_for_title(row['description'])
        kind = row.get('kind', 'stars')
        p = supplier_product(api, rule, int(row['stars']))
        if kind == 'stars' and strict_count(p["product_id"]) != 55:
            raise ValueError("Каталог вернул другой товар")
        recipient=services.decode_recipient(row,rule) if kind=='service_topup' else None
        valid = True if kind in ('game_key',*services.KINDS) else (api.check_steam_login(row['username']) if kind in STEAM_KINDS else api.check_username(row['username']))
        if not valid:
            if STORE.set_if_status(oid, "preparing", status="awaiting_username", username=None,
                                   details="Username не найден у поставщика"):
                buyer_message(c,row,f"STEAM.RU не нашёл получателя {row['username']}. Пришлите правильный логин или @username #{oid} одним сообщением.")
            return
        expected_usd = D(p['price_usd']) * row['stars']
        if STORE.today_spend() + expected_usd > D(CFG['max_daily_usd']):
            if STORE.set_if_status(oid, 'preparing', status='ready', retry_after=time.time()+60,
                                   details='WAITING_DAILY_BUDGET') and row.get('details') != 'WAITING_DAILY_BUDGET':
                alert(c, f'Заказ #{oid} ждёт обновления суточного бюджета; покупки ещё не было.')
            return
        total_usd, cash = verify_price(c,row,p["price_usd"],revenue)
        if api.balance() < total_usd + D(CFG["min_balance_reserve_usd"]):
            if STORE.set_if_status(oid, 'preparing', status='ready', retry_after=time.time()+60,
                                   details='WAITING_BALANCE') and row.get('details') != 'WAITING_BALANCE':
                alert(c, f'Заказ #{oid} ждёт пополнения STEAM.RU; покупки ещё не было.')
                notifications.notify(sys.modules[__name__],c,f'Заказ #{oid}: не хватает баланса STEAM.RU. Пополни баланс; бот продолжает проверять его. Покупки ещё не было.',urgent=True)
                buyer_message(c, row, f'Заказ #{oid} сохранён. Обработка задерживается; продавец уведомлён.')
            MAINTENANCE_WAKE.set()
            return
        # ИДЕМПОТЕНТНАЯ ГРАНИЦА. Сохраняем ДО HTTP POST.
        # Перепроверяем FunPay непосредственно перед списанием.
        if preflight(c, row) != revenue:
            raise ValueError("Перед отправкой изменилась сумма FunPay")
        if CFG["mode"] != "live" or STOP.is_set() or not live_allowed() or paused() or not enabled(c):
            STORE.set_if_status(oid, "preparing", status="needs_review", details="Покупка остановлена до POST")
            return
        if not STORE.reserve_submission(oid, total_usd, CFG["max_single_order_usd"], CFG["max_daily_usd"],
                      applied_rate=str(cash['rate']),
                      revenue_rub=str(revenue), cost_rub=str(cash["cost"]), profit_rub=str(cash["profit"]),
                      details=f"kind={kind}; account={row['username']}"):
            raise ValueError("Заказ был отменён во время предпроверки — покупка запрещена")
        STORE.event(oid, "post_started", "Переход в submitting перед сетевой операцией")
        final_row = STORE.get(oid)
        if (CFG["mode"] != "live" or STOP.is_set() or paused() or not enabled(c) or not live_allowed()
                or not final_row or final_row["status"] != "submitting"):
            STORE.set_if_status(oid, "submitting", status="needs_review", details="Пауза после резервирования; POST не начат")
            return
        if kind in services.KINDS:
            result=api.create_service(row['external_id'],rule['service'],rule['product_id'],recipient,
                next(iter(recipient.values())) if recipient else None)
        elif kind == 'game_key':
            result = api.create_game_key(row['external_id'], rule['app_id'], rule['option_id'])
        elif kind == 'steam_rub':
            result = api.create_steam_rub(row['external_id'], row['stars'], row['username'])
        elif kind in STEAM_KINDS:
            result = api.create_steam_currency(row['external_id'],rule['currency'],row['stars'],row['username'])
        else:
            result = api.create(row["external_id"], CFG["service_slug"],p["product_id"],row["stars"],row["username"])
        # Сохраняем uuid НЕМЕДЛЕННО, даже если остальные поля ответа оказались неожиданными.
        STORE.set(oid, status="supplier_pending", supplier_uuid=result["uuid"],
                  supplier_status=str(result.get("status", "created")))
        health.success(sys.modules[__name__], 'purchase')
        STORE.event(oid,"supplier_created",result["uuid"])
        if kind != 'game_key' and result.get("product_id") is not None and int(result["product_id"]) != int(p["product_id"]):
            STORE.set(oid,status='needs_review',details='PRODUCT_MISMATCH: требуется сверка товара по UUID')
            critical(c, f"STEAM.RU ответил с другим продуктом для заказа #{oid}; сверить UUID {result['uuid']}",scope='supplier:'+oid,urgent=True,incident=oid)
            return
        buyer_message(c,STORE.get(oid),f"╭─ ⚡ ЗАКАЗ #{oid} В РАБОТЕ\n│ {order_label(row)}\n╰─ Заявка принята. Ждём подтверждения выполнения.\n\nПовторять данные не нужно.\n"+customer_messages.FOOTER)
        activity.record(sys.modules[__name__],c,'delivery',f'⏳ Заказ #{oid} принят поставщиком: {order_label(row)}')
        process_pending(c, STORE.get(oid), api=api)
    except UnknownOutcome as exc:
        STORE.set(oid,status="uncertain",details=str(exc))
        critical(c, f"НЕОПРЕДЕЛЁННОЕ СПИСАНИЕ #{oid}! Не повторять POST. Сверить с STEAM.RU, external_id={row['external_id']}",scope='purchase',urgent=True,incident=oid)
    except Exception as exc:
        current=STORE.get(oid)
        if current and current["status"] == "submitting":
            # Даже HTTP-ошибки после POST разбираем руками для консервативной безопасности.
            STORE.set(oid,status="uncertain",details=type(exc).__name__+": "+str(exc)[:160])
            critical(c, f"Ошибка POST по заказу #{oid}; исход требует проверки: {type(exc).__name__}",scope='purchase',urgent=True,incident=oid)
        else:
            if isinstance(exc,OrderDataError):
                STORE.set_if_status(oid,'preparing',status='needs_review',details=str(exc))
                health.order_issue(sys.modules[__name__],c,oid,str(exc))
                return
            if retry_before_purchase(c,row,exc):
                return
            STORE.set_if_status(oid, "preparing", status="needs_review", details=type(exc).__name__)
            critical(c, f"Предпроверка #{oid} провалилась: {type(exc).__name__}",scope='purchase')


def simulate_ready(c):
    """Явный тест без запросов к STEAM.RU и без перехода к live при смене режима."""
    if CFG["mode"] != "dry_run" or CFG["dry_run_price_usd"] is None or not enabled(c):
        return
    with PROCESS_LOCK:
        row = STORE.take_ready()
        if not row:
            return
        try:
            if row.get("captured_mode") != "dry_run":
                raise ValueError("Тестировать можно только заказ, принятый в dry_run")
            revenue = preflight(c, row)
            _, cash = verify_price(c, row, CFG["dry_run_price_usd"], revenue)
            STORE.set_if_status(row["id"], "preparing", status="simulated",
                                revenue_rub=str(revenue), cost_rub=str(cash["cost"]),
                                profit_rub=str(cash["profit"]), details="DRY RUN: покупки не было")
            alert(c, f"ТЕСТ #{row['id']}: расчёт выполнен, Stars НЕ покупались и НЕ выдавались")
        except Exception as exc:
            STORE.set_if_status(row["id"], "preparing", status="needs_review", details=type(exc).__name__)
            alert(c, f"ТЕСТ #{row['id']}: проверка не пройдена, покупки не было")


def process_pending(c,row, api=None):
    # После error/review/closed продолжаем только ЧИТАТЬ статус: возврат может
    # случиться позже, и не должен теряться. Повторных POST здесь нет.
    if row["status"] not in ("supplier_pending", "needs_review") or not row["supplier_uuid"]:
        return
    oid=row["id"]
    try:
        api = api or client()
        data=api.get_order(row["supplier_uuid"])
        if str(data.get("uuid")) != str(row["supplier_uuid"]):
            raise ValueError("UUID ответа изменился")
        supplier_status=str(data.get("status", "unknown"))
        if 'PRODUCT_MISMATCH' in (row.get('details') or '') and supplier_status!='refunded':
            critical(c,f'Заказ #{oid}: поставщик ответил другим товаром. Автовыдача этого заказа заблокирована; UUID сохранён.',scope='supplier:'+oid,urgent=True,incident=oid)
            return
        if data.get("amount_charged_usd") is not None and row["quoted_usd"]:
            charged = D(data["amount_charged_usd"])
            if charged < 0:
                raise ValueError("Отрицательное списание поставщика")
            changes = {"charged_usd": str(charged)}
            if row.get("applied_rate") and row["cost_rub"] and row["profit_rub"]:
                prior_charge = D(row.get("charged_usd") or row["quoted_usd"])
                delta = (charged - prior_charge) * D(row["applied_rate"])
                changes.update(cost_rub=str(D(row["cost_rub"]) + delta),
                               profit_rub=str(D(row["profit_rub"]) - delta))
            STORE.set(oid, **changes)
            if charged > D(row["quoted_usd"]) + Decimal("0.01") and row.get("charged_usd") != str(charged):
                critical(c, f"Поставщик списал больше ожидаемого в заказе #{oid}: {data['amount_charged_usd']} USD",scope='purchase',urgent=True,incident=oid)
            row = STORE.get(oid)
        is_key = row.get('kind') in ('game_key','service_code')
        if supplier_status == 'delivered' and is_key or supplier_status == 'completed' and not is_key:
            if is_key:
                voucher = data.get('voucher')
                if not isinstance(voucher, str) or not voucher.strip() or len(voucher) > 10000:
                    STORE.set(oid, status='needs_review', supplier_status=supplier_status, details='Ключ не пришёл в ответе поставщика')
                    critical(c, f"Нет кода ключа по заказу #{oid}; повторять покупку нельзя",scope='supplier:'+oid,urgent=True,incident=oid)
                    return
                STORE.set(oid, voucher=voucher.strip())
                row = STORE.get(oid)
            STORE.set(oid,status="completed",supplier_status=supplier_status)
            health.success(sys.modules[__name__], 'supplier:'+oid)
            row=STORE.get(oid)
            notifications.resolve(sys.modules[__name__], oid)
            if not row["buyer_notified"]:
                if buyer_message(c,row,completed_message(row)):
                    STORE.set(oid,buyer_notified=1)
            alert(c, f"✅ Выполнен #{oid}; прибыль по расчёту ~{row['profit_rub']} ₽")
            activity.record(sys.modules[__name__],c,'delivery',f'✅ Выдан заказ #{oid}: {order_label(row)}',notify_now=False)
        elif supplier_status=="refunded":
            STORE.set(oid,status="refunded",supplier_status=supplier_status)
            critical(c,f"Поставщик вернул заказ #{oid}; требуется решение по покупателю FunPay",scope='supplier:'+oid,urgent=True,incident=oid)
            buyer_message(c,row, f"По заказу #{oid} возникла проблема у поставщика. Мы проверяем ситуацию и свяжемся с вами.")
        elif supplier_status in ("error", "review", "closed", "delivered") or is_key and supplier_status == 'completed':
            # Эти статусы НЕ означают возврат денег. Ждём refunded или completed,
            # но обязательно подключаем поддержку. Не спамим оповещением при poll.
            STORE.set(oid, status="needs_review", supplier_status=supplier_status,
                      details=f"Поставщик: {supplier_status}; деньги НЕ считаются возвращёнными")
            critical(c, f"Заказ #{oid}: статус {supplier_status}. НЕ создавать повтор; проверить через поддержку!",scope='supplier:'+oid,urgent=True,incident=oid)
        elif supplier_status in ("pending", "created", "processing"):
            health.success(sys.modules[__name__], 'supplier:'+oid)
            # Если уже тревога, не сбрасываем статус needs_review без человека.
            if row["status"] == "needs_review":
                STORE.set(oid, supplier_status=supplier_status)
            else:
                STORE.set(oid, supplier_status=supplier_status)
            try:
                born=datetime.strptime(row["submitted_at"] or row["created_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
                minutes=(datetime.now(timezone.utc)-born).total_seconds()/60
                if minutes >= int(CFG["max_pending_minutes"]) and "OVERDUE_ALERTED" not in (row["details"] or ""):
                    STORE.set(oid,details=(row["details"] or "")+" OVERDUE_ALERTED")
                    critical(c,f"ДОЛГАЯ ОБРАБОТКА #{oid}: {minutes:.0f} мин, статус {supplier_status}; уточнить у поддержки",scope='supplier:'+oid,urgent=True,incident=oid)
            except (ValueError,KeyError,TypeError):
                pass
        else:
            STORE.set(oid,status="needs_review",supplier_status=supplier_status)
            critical(c,f"Неизвестный статус поставщика по #{oid}: {supplier_status}",scope='supplier:'+oid,urgent=True,incident=oid)
        STORE.set_meta('pending_read_fail:' + oid,'0')
    except Exception as exc:
        key = 'pending_read_fail:' + oid
        count = int(STORE.get_meta(key,'0')) + 1
        STORE.set_meta(key,str(count))
        critical(c,f'Не удаётся проверить созданный заказ #{oid}. Бот продолжит чтение статуса; покупку не повторять.',scope='supplier:'+oid)
        STORE.event(oid,"poll_error",type(exc).__name__)
        STORE.set(oid, supplier_status=row["supplier_status"])
        LOG.warning("Не удалось проверить статус заказа %s: %s",oid,type(exc).__name__)
        # Не объявляем заказ неудачным из-за временной ошибки GET. Со временем нужна ручная проверка.


def worker(c):
    while not STOP.wait(max(10,int(CFG["poll_seconds"]))):
        if STORE is None or not enabled(c):
            continue
        try:
            retry_order_reads(c)
            if CFG["mode"] == "live" and not paused() and CFG.get("managed_lots"):
                if not live_allowed():
                    critical(c, "Условия LIVE не выполняются. Новые закупки ждут проверки доступа и курса.",scope='live_access')
                elif time.time() - float(STORE.get_meta("last_health_check", "0")) >= 120:
                    health.success(sys.modules[__name__], 'live_access')
                    STORE.set_meta("last_health_check", str(time.time()))
                    try:
                        with PROCESS_LOCK:
                            if not paused():
                                if not CFG['catalog_sync']['enabled']:
                                    live_offer_check(c)
                        health.success(sys.modules[__name__], 'offer_health')
                    except Exception as exc:
                        critical(c, "Проверка доступности продаж не прошла: " + str(exc)[:160],scope='offer_health')
                else:
                    health.success(sys.modules[__name__], 'live_access')
            # Завершение уже созданных заказов важнее режима паузы и устаревшего курса.
            if os.getenv("STEAMRU_API_KEY") and os.getenv("STEAMRU_API_SECRET"):
                for row in STORE.pending_rows(20):
                    if STOP.is_set() or not enabled(c):
                        break
                    process_pending(c,row)
                    if STOP.wait(0.7):
                        break
            for row in STORE.unnotified_completed(20):
                if STOP.is_set() or not enabled(c):
                    break
                if not row["buyer_notified"]:
                    if buyer_message(c,row,completed_message(row)):
                        STORE.set(row["id"], buyer_notified=1)
            if live_allowed():
                process_ready(c)
            elif CFG["mode"] == "dry_run" and not STOP.is_set():
                simulate_ready(c)
            health.success(sys.modules[__name__], 'worker')
        except Exception:
            LOG.exception("Ошибка основного цикла")
            if CFG["mode"] == "live" and CFG.get("managed_lots"):
                try:
                    critical(c, "Сбой рабочего цикла обработки заказов.",scope='worker')
                except Exception:
                    LOG.exception('Не удалось сохранить счётчик ошибок рабочего цикла')


def on_post_start(c):
    global WORKER, MAINTENANCE, RESTART_WAITER, RUN_REQUESTED, NOTICE_WORKER
    if STORE is None:
        return
    with WORKER_LOCK:
        RUN_REQUESTED = True
        if WORKER is not None and WORKER.is_alive():
            if STOP.is_set() and (RESTART_WAITER is None or not RESTART_WAITER.is_alive()):
                RESTART_WAITER = threading.Thread(target=restart_after_stop, args=(c, WORKER),
                                                  name="STEAMRUStarsRestart", daemon=True)
                RESTART_WAITER.start()
            return
        STOP.clear()
        if NOTICE_WORKER is None or not NOTICE_WORKER.is_alive():
            NOTICE_WORKER = threading.Thread(target=notifications.worker,args=(sys.modules[__name__],c),name='STEAMRUNotifications',daemon=True)
            NOTICE_WORKER.start()
        WORKER=threading.Thread(target=worker,args=(c,),name="STEAMRUStarsWorker",daemon=True)
        WORKER.start()
        if (CFG['auto_pricing']['enabled'] or CFG['catalog_sync']['enabled']) and (MAINTENANCE is None or not MAINTENANCE.is_alive()):
            if CFG['auto_pricing']['enabled'] or CFG['catalog_sync']['enabled']:
                MAINTENANCE=threading.Thread(target=maintenance_worker,args=(c,),name='STEAMRUMaintenance',daemon=True)
                MAINTENANCE.start()


def restart_after_stop(c, previous):
    global WORKER, MAINTENANCE, NOTICE_WORKER
    previous.join()
    if MAINTENANCE is not None:
        MAINTENANCE.join()
    if NOTICE_WORKER is not None:
        NOTICE_WORKER.join()
    with WORKER_LOCK:
        if RUN_REQUESTED and WORKER is previous and not previous.is_alive():
            STOP.clear()
            NOTICE_WORKER=threading.Thread(target=notifications.worker,args=(sys.modules[__name__],c),name='STEAMRUNotifications',daemon=True)
            NOTICE_WORKER.start()
            WORKER = threading.Thread(target=worker, args=(c,), name="STEAMRUStarsWorker", daemon=True)
            WORKER.start()
            MAINTENANCE=threading.Thread(target=maintenance_worker,args=(c,),name='STEAMRUMaintenance',daemon=True)
            MAINTENANCE.start()


def on_pre_stop(c):
    global RUN_REQUESTED
    with WORKER_LOCK:
        RUN_REQUESTED = False
        STOP.set()
    if STORE is not None:
        STORE.set_meta("resume_token", "")
        STORE.set_meta("paused", "yes")
    if WORKER is not None and WORKER is not threading.current_thread():
        WORKER.join(timeout=1)
    if MAINTENANCE is not None and MAINTENANCE is not threading.current_thread():
        MAINTENANCE.join(timeout=1)
    if C is not None and CFG["mode"] == "live" and CFG["auto_disable_lots_on_pause"]:
        disable_managed_lots(c)


def on_pre_init(c):
    if getattr(c,'MAIN_CFG',None) is not None:
        customer_messages.configure(c.MAIN_CFG)
    if not c.telegram:
        return
    tg, bot=c.telegram,c.telegram.bot

    def own(message):
        expected=os.getenv("STEAMRU_OWNER_TG_ID")
        authorized = {str(uid) for uid in getattr(tg, "authorized_users", ())}
        return bool(expected and str(message.from_user.id)==expected
                    and expected in authorized and str(message.chat.type)=="private")

    def cmd_status(m):
        if not own(m): return
        if STORE is None:
            bot.reply_to(m,"База ещё не готова, подождите")
            return
        counts=STORE.counts()
        stat=", ".join(f"{k}: {v}" for k,v in sorted(counts.items())) or "заказов пока нет"
        summary = STORE.get_meta('catalog_summary','Каталог ещё обновляется' if CFG['catalog_sync']['enabled'] else 'Каталог выключен')
        report = STORE.get_meta('pricing_report','')
        lines = ''
        if report:
            lines = '\nStars: '+', '.join(f"{x['stars']} ⭐ = {x['seller_price_rub']} ₽" for x in json.loads(report))
        rotation_status=('\nРотация: до '+str(CFG['rotation']['max_changes'])+' игр каждые 5 часов'
                         if CFG['rotation']['enabled'] else '\nРотация выключена')
        if CFG['rotation']['enabled'] and STORE.get_meta('rotation_summary',''):
            rotation_status+='\n'+STORE.get_meta('rotation_summary','')
        bot.reply_to(m,f"STEAM.RU v{VERSION}\nMode: {CFG['mode']}\nLIVE разрешён: {live_allowed()}"
                     f"\nПриостановлен: {paused()}\nОчередь: {stat}\n"
                     f"Ошибки подряд: {health.summary(sys.modules[__name__])}\n"
                     f"{summary}{lines}\nАвтоцена: раз в час, маржа {CFG['auto_pricing']['min_margin_pct']}–{CFG['auto_pricing']['max_margin_pct']}%"
                     +rotation_status
                     + ('\nЗапуск: '+STORE.get_meta('launch_progress','проверка начинается') if RESUME_TASK_LOCK.locked() else '') )

    def cmd_pause(m):
        if not own(m) or STORE is None: return
        STORE.set_meta("resume_token", "")
        STORE.set_meta("paused","yes")
        if CFG["mode"] == "live" and CFG["auto_disable_lots_on_pause"]:
            disable_managed_lots(c)
        bot.reply_to(m,"⏸ Новые покупки на STEAM.RU остановлены. Уже начатые заказы продолжают проверяться.")

    def cmd_resume(m):
        if not own(m) or STORE is None: return
        if not paused() and live_allowed() and not RESUME_TASK_LOCK.locked():
            bot.reply_to(m,'▶️ Продажи уже работают. Текущее состояние: /sr_status.')
            return
        if not RESUME_TASK_LOCK.acquire(blocking=False):
            bot.reply_to(m,'Запуск уже идёт. Прогресс виден в /sr_status; повторять /sr_resume не нужно.')
            return
        try:
            bot.reply_to(m, 'Запускаю продажи. Проверка лотов может занять несколько минут; /sr_status показывает прогресс.')
        except Exception:
            RESUME_TASK_LOCK.release()
            raise
        requested_token=uuid.uuid4().hex
        STORE.set_meta('resume_token',requested_token)
        def launch():
            try:
                STORE.set_meta('launch_progress','Проверяю курс STEAM.RU')
                if CFG['auto_pricing']['watch_topup_rate'] and pricing.TOPUP_CLIENT is not None:
                    pricing.TOPUP_CLIENT.refresh()
                if STOP.is_set() or not live_allowed():
                    raise ValueError('LIVE пока недоступен: проверь запуск и курс STEAM.RU')
                opened=resume_live(c,requested_token=requested_token)
                bot.reply_to(m,f'▶️ Продажи запущены. Открыто лотов: {opened}. Оплаченные заказы обрабатываются автоматически.')
            except Exception as exc:
                STORE.set_meta('launch_progress','Запуск не завершён: '+type(exc).__name__)
                bot.reply_to(m,'Продажи не запущены: '+escape(str(exc)[:220]))
            finally:
                RESUME_TASK_LOCK.release()
        try:
            threading.Thread(target=launch,daemon=True,name='STEAMRUResume').start()
        except Exception:
            RESUME_TASK_LOCK.release()
            raise

    def cmd_orders(m):
        if not own(m) or STORE is None: return
        rows=STORE.rows(limit=12)
        lines=[f"#{r['id']} | {order_label(r)} | {r['status']} | FunPay: {r.get('funpay_status') or '?'} | {r['username'] or 'без получателя'}" for r in rows]
        bot.reply_to(m,"\n".join(lines) if lines else "Заказов пока нет")

    def cmd_probe(m):
        if not own(m): return
        if not os.getenv("STEAMRU_API_KEY") or not os.getenv("STEAMRU_API_SECRET"):
            bot.reply_to(m, "Нет STEAMRU_API_KEY / STEAMRU_API_SECRET. Это безопасная проверка без покупки.")
            return
        bot.reply_to(m, "🔎 Проверяю только баланс и каталог. Ничего не покупаю.")
        def probe():
            try:
                api = client()
                account = api.account()  # официальный GET /account, безопасная проверка
                balance = D(account.get("balance")) if account.get("balance") is not None else api.balance()
                products = api.request("GET", "/catalog/services/" + CFG["service_slug"] + "/products")
                rows = []
                for p in products.get("products", [])[:12]:
                    rows.append(f"ID={p.get('product_id')}: {p.get('name')} | ${p.get('price_usd')}/ед. | "
                                f"{p.get('min_count')}..{p.get('max_count')} | поля={p.get('fields')}")
                bot.send_message(m.chat.id, "✅ STEAM.RU доступен\nБаланс: $" + str(balance) +
                                 "\n" + "\n".join(rows)[:2500])
            except Exception as exc:
                bot.send_message(m.chat.id, "⚠️ Проверка API не прошла: " + type(exc).__name__ +
                                 " (см. логи). Секреты не отправляйте!")
                LOG.warning("API probe error: %s", type(exc).__name__)
        threading.Thread(target=probe,daemon=True,name="STEAMRUProbe").start()

    def cmd_check(m):
        if not own(m) or STORE is None: return
        parts=(m.text or "").split()
        if len(parts)!=2:
            bot.reply_to(m,"Формат: /sr_check НОМЕР_ЗАКАЗА")
            return
        oid=parts[1].lstrip("#")
        row=STORE.get(oid)
        if not row:
            bot.reply_to(m,"Такого заказа нет в базе")
            return
        if not row["supplier_uuid"]:
            bot.reply_to(m,f"Заказ #{oid} имеет статус {row['status']} без UUID поставщика. Если отправка могла состояться — обратитесь в поддержку с external_id={row['external_id']}, НЕ покупайте повторно!")
            return
        bot.reply_to(m,"Проверяю только статус поставщика (без покупки).")
        def check():
            try:
                data=client().get_order(row["supplier_uuid"])
                bot.send_message(m.chat.id, f"STEAM.RU заказ #{oid}: {data.get('status')} | UUID: {row['supplier_uuid']} | списано: ${data.get('amount_charged_usd')}. Это только чтение.")
            except Exception as exc:
                bot.send_message(m.chat.id, "Не удалось проверить статус; см. логи. " + type(exc).__name__)
        threading.Thread(target=check,daemon=True,name="STEAMRUCheck").start()

    tg.msg_handler(cmd_probe,commands=["sr_probe"])
    tg.msg_handler(cmd_check,commands=["sr_check"])
    tg.msg_handler(cmd_status,commands=["sr_status"])
    tg.msg_handler(cmd_pause,commands=["sr_pause"])
    tg.msg_handler(cmd_resume,commands=["sr_resume"])
    tg.msg_handler(cmd_orders,commands=["sr_orders"])
    c.add_telegram_commands(UUID, [
        ("sr_status","STEAM.RU: статус",True),
        ("sr_probe","STEAM.RU: безопасная проверка API",True),
        ("sr_check","STEAM.RU: уточнить заказ по UUID",True),
        ("sr_orders","STEAM.RU: последние заказы",True),
        ("sr_pause","STEAM.RU: пауза",True),
        ("sr_resume","STEAM.RU: продолжить покупки",True)])
    controls.register(sys.modules[__name__],c,own)
    notifications.register(sys.modules[__name__],c,own)
    activity.register(sys.modules[__name__],c,own)
    if os.getenv('AISKLAD_SHARED_DB'):
        from aisklad_shop.modules import register_funpay_commands
        register_funpay_commands(sys.modules[__name__],c,own)


BIND_TO_PRE_INIT=[on_pre_init]
BIND_TO_POST_INIT=[on_post_init]
BIND_TO_POST_START=[on_post_start]
BIND_TO_PRE_STOP=[on_pre_stop]
BIND_TO_NEW_ORDER=[on_new_order]
BIND_TO_INIT_ORDER=[on_initial_order]
BIND_TO_NEW_MESSAGE=[on_new_message]
BIND_TO_ORDER_STATUS_CHANGED=[on_order_status_change]
