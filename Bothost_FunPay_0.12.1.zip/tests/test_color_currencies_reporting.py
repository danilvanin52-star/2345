"""Currency separation, title compatibility, customer support and action reports."""
import json,logging,tempfile,time
import re
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace as N
import unittest
from unittest.mock import Mock,patch
import steamru_stars as bot
import steamru_stars_catalog as catalog
import steamru_stars_activity as activity
import steamru_stars_notifications as notices
import steamru_customer_messages as messages
import steamru_stars_services as services
from steamru_stars_engine import SteamClient,Store,D,STEAM_CURRENCIES,UnknownOutcome
from test_cardinal_compatibility import source_interfaces,full_order,shortcut
from test_safety_integration import Cardinal
import test_catalog_pricing as earlier
import test_live_launch as launches


def steam_product(currency):
    return {'product_id':STEAM_CURRENCIES[currency]['product_id'],'name':'Steam '+currency,
            'price_usd':{'RUB':'.0118','USD':'1','KZT':'.0023'}[currency],
            'min_count':STEAM_CURRENCIES[currency]['min_count'],'max_count':999999,'fields':[]}


class CurrencyOrders(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.types=source_interfaces()
    setUp=earlier.NewProductsTests.setUp
    tearDown=earlier.NewProductsTests.tearDown
    create=earlier.NewProductsTests.create
    capture=earlier.NewProductsTests.capture

    def setup_currency(self,currency,count):
        rule=catalog.currency_rule(currency,steam_product(currency))
        self.api.steam_currency_product=Mock(return_value=steam_product(currency))
        self.api.create_steam_currency=Mock(side_effect=self.create)
        self.capture(rule,count)
        order=self.c.account.order
        order.fields['type']=self.types.LotField('type','По логину🔥',field_type_id='radio')
        bot.STORE.set_username(order.id,12,order.chat_id,'safe_login')
        return rule

    def test_usd_orders_create_only_product_10_and_once(self):
        self.setup_currency('USD',3);bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(self.api.created,[('funpay-ABCD1234','USD',3,'safe_login')])
        self.assertEqual(bot.STORE.get('ABCD1234')['kind'],'steam_usd')
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'completed')

    def test_kzt_arbitrary_integer_1492_keeps_currency_and_nominal(self):
        self.setup_currency('KZT',1492);bot.process_ready(self.c)
        self.assertEqual(self.api.created,[('funpay-ABCD1234','KZT',1492,'safe_login')])
        self.assertIn('1492 KZT',bot.completed_message(bot.STORE.get('ABCD1234')))

    def test_wrong_currency_cannot_match_a_paid_sku(self):
        self.setup_currency('USD',3);self.c.account.order.fields['currency'].value='KZT'
        bot.process_ready(self.c);self.assertEqual(self.api.created,[])

    def test_new_steam_kinds_reject_fractional_or_outside_nominals(self):
        for currency,invalids in [('USD',(0,6,1.5)),('KZT',(599,2501,650.5))]:
            rule=catalog.currency_rule(currency,steam_product(currency));bot.CFG['lot_rules']={'product':rule}
            for amount in invalids:
                order=full_order(self.types,subcategory_id=1086,amount=amount)
                order.fields={k:self.types.LotField(k,v) for k,v in rule['match_fields'].items()}
                with self.subTest(currency=currency,amount=amount),self.assertRaises(ValueError):bot.full_order_data(Cardinal(order),order,order.id)

    def test_old_and_decorated_titles_match_same_sku_and_changed_region_fails(self):
        rule=catalog.key_rule(earlier.game())
        self.capture(rule)
        order=self.c.account.order
        for title in (rule['match_fields']['summary'],catalog.display_title(rule),catalog.display_title(rule,True)):
            order.fields['summary'].value=title
            self.assertEqual(bot.full_order_data(self.c,order,order.id)[0],'rule:product')
        order.fields['summary'].value='🎮 Wrong game | 🔑 Steam · 🌍 Global · ⚡ Auto'
        with self.assertRaises(ValueError):bot.full_order_data(self.c,order,order.id)

    def test_blizzard_templates_have_exact_region_currency_sku(self):
        rules=[r for _,r in services.shortlist() if r['service'].startswith('blizzard-')]
        self.assertEqual({r['product_id'] for r in rules},{11304,11305,109})
        for rule in rules:
            self.assertEqual(rule['kind'],'service_code');self.assertEqual(rule['recipient_fields'],[])
            self.assertEqual(rule['match_fields']['method'],'Подарочная карта')
            text=catalog.buyer_copy(rule)['ru'];self.assertIn(rule['region_label'],text)
            self.assertIn('!помощь',text);self.assertIn('Battle.net',text)

    def test_service_english_descriptions_translate_all_region_names(self):
        for _,rule in services.shortlist():
            with self.subTest(product=rule['product_name'],region=rule['region_label']):
                self.assertIsNone(re.search('[А-Яа-яЁё]',catalog.buyer_copy(rule)['en']))

    def test_help_alarms_once_per_cooldown_and_does_not_pause_or_buy(self):
        self.capture(catalog.rub_rule(1,steam_product('RUB')),156)
        message=N(author_id=12,chat_id='users-7-12',type=N(name='NON_SYSTEM'),by_bot=False,text='!помощь')
        bot.on_new_message(self.c,N(message=message));bot.on_new_message(self.c,N(message=message))
        with bot.STORE.conn() as db:
            urgent=db.execute('SELECT count(*) FROM owner_notices WHERE urgent=1').fetchone()[0]
        self.assertEqual(urgent,1);self.assertFalse(bot.paused());self.assertEqual(self.api.created,[])
        self.assertIn('Продавец уже уведомлён',self.c.messages[-1][1])

    def test_status_only_shows_orders_for_this_buyer_and_verified_chat(self):
        self.capture(catalog.rub_rule(1,steam_product('RUB')),156)
        bot.STORE.insert_order('PRIVATE99',99,'users-7-99','other','rule:product',100,100,'120',captured_mode='live',kind='steam_rub')
        message=N(author_id=12,chat_id='users-7-12',type=N(name='NON_SYSTEM'),by_bot=False,text='!статус')
        bot.on_new_message(self.c,N(message=message))
        self.assertIn('ABCD1234',self.c.messages[-1][1]);self.assertNotIn('PRIVATE99',self.c.messages[-1][1])
        message.chat_id='users-7-99';before=len(self.c.messages)
        bot.on_new_message(self.c,N(message=message));self.assertEqual(len(self.c.messages),before)

    def test_help_before_purchase_is_private_and_no_fake_order_link(self):
        self.c=Cardinal(full_order(self.types))
        message=N(author_id=12,chat_id='users-7-12',type=N(name='NON_SYSTEM'),by_bot=False,text='!помощь')
        bot.on_new_message(self.c,N(message=message))
        with bot.STORE.conn() as db:row=dict(db.execute('SELECT * FROM owner_notices WHERE urgent=1').fetchone())
        self.assertEqual(row['order_id'],'HELP_12');self.assertEqual(self.api.created,[])
        self.assertFalse(bot.paused())

    def test_queue_contains_real_position_and_no_made_up_delivery_time(self):
        self.capture(catalog.key_rule(earlier.game()))
        text=messages.queue_message(bot,bot.STORE.get('ABCD1234'))
        self.assertIn('Позиция в очереди: 1',text);self.assertNotIn('15 сек',text)
        self.assertIn('!помощь',text)


class CurrencyClientTests(unittest.TestCase):
    def test_verified_api_product_ids_match_currency_payload(self):
        client=SteamClient('OFFLINE','OFFLINE',allow_purchases=True)
        client.request=Mock(return_value={'uuid':'safe-offline-uuid'})
        for currency,count,pid in [('USD',3,10),('KZT',1492,9)]:
            client.create_steam_currency('funpay-CUR123',currency,count,'safe_login')
            self.assertEqual(client.request.call_args.kwargs['payload'],{'external_order_id':'funpay-CUR123',
                'service':'steam','product_id':pid,'product_count':count,'account':'safe_login'})

    def test_default_guard_blocks_new_currency_purchase(self):
        client=SteamClient('OFFLINE','OFFLINE')
        for currency,count in [('USD',1),('KZT',600)]:
            with self.assertRaises(PermissionError):client.create_steam_currency('funpay-CUR123',currency,count,'safe_login')

    def test_catalog_must_have_correct_product_name_and_empty_fields(self):
        client=SteamClient('OFFLINE','OFFLINE');product=steam_product('USD')
        client.request=Mock(return_value={'service':'steam','type':'topup','requires_account':True,'products':[product]})
        self.assertEqual(client.steam_currency_product('USD',3)['product_id'],10)
        product['name']='Steam KZT'
        with self.assertRaises(ValueError):client.steam_currency_product('USD',3)
        product['name']='Steam USD';product['fields']=[{'key':'password'}]
        with self.assertRaises(ValueError):client.steam_currency_product('USD',3)

    def test_unknown_currency_response_never_allows_duplicate_post(self):
        client=SteamClient('OFFLINE','OFFLINE',allow_purchases=True);client.request=Mock(return_value={})
        with self.assertRaises(UnknownOutcome):client.create_steam_currency('funpay-CUR123','KZT',600,'safe_login')
        self.assertEqual(client.request.call_count,1)


class HourlyActivityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'state.db')
        self.module=N(STORE=self.store,CFG={'activity_report':{'enabled':True,'interval_seconds':3600},'managed_lots':{'1':'game'}},paused=lambda:False)
        self.target=N(telegram=None)
    def tearDown(self):self.tmp.cleanup()
    def notice_rows(self):
        with self.store.conn() as db:return [dict(r) for r in db.execute('SELECT * FROM owner_notices ORDER BY rowid')]
    def test_every_action_is_saved_and_hourly_report_contains_old_and_new_values(self):
        activity.record(self.module,self.target,'price','Game A: 100 → 101 ₽',1)
        activity.record(self.module,self.target,'rotation','Game A → Game B',1)
        self.store.set_meta('last_checked_balance','5.96')
        activity.hourly(self.module,self.target,now=4000)
        reports=[r for r in self.notice_rows() if r['message'].startswith('📊')]
        self.assertEqual(len(reports),1)
        self.assertIn('100 → 101',reports[0]['message']);self.assertIn('Game A → Game B',reports[0]['message'])
        self.assertIn('$5.96',reports[0]['message'])
        activity.hourly(self.module,self.target,now=4100)
        self.assertEqual(len(self.notice_rows()),1)
    def test_immediate_action_messages_require_explicit_opt_in(self):
        self.module.CFG['activity_report']['immediate']=True
        activity.record(self.module,self.target,'price','Game A: 100 → 101 ₽',1)
        self.assertEqual(len(self.notice_rows()),1)
    def test_hourly_report_collapses_identical_action_noise(self):
        for _ in range(20):activity.record(self.module,self.target,'availability','Same change',1)
        activity.hourly(self.module,self.target,now=4000)
        self.assertEqual(len(self.notice_rows()),1)
        text=self.notice_rows()[0]['message']
        self.assertEqual(text.count('Same change'),1)
        self.assertIn('повторов: 20',text)
    def test_next_hour_reports_even_when_nothing_changed(self):
        activity.hourly(self.module,self.target,now=4000);activity.hourly(self.module,self.target,now=7600)
        self.assertEqual(len(self.notice_rows()),2)
        self.assertIn('Изменений цен',self.notice_rows()[-1]['message'])
    def test_action_journal_and_report_cursor_survive_restart(self):
        activity.record(self.module,self.target,'availability','Лот включён',1,notify_now=False)
        self.module.STORE=Store(self.store.path);activity.hourly(self.module,self.target,now=4000)
        self.assertEqual(self.store.get_meta('activity_report_cursor'),'1')
    def test_long_reports_split_below_telegram_escaped_length(self):
        from html import escape
        parts=list(activity.chunks(['<tag>&'*1800,'emoji 🎮'*1000]))
        self.assertTrue(all(len(escape(p))<=3100 for p in parts));self.assertGreater(len(parts),2)
    def test_report_feature_is_disabled_in_public_default(self):
        self.module.CFG['activity_report']['enabled']=False
        activity.record(self.module,self.target,'price','Price changed')
        activity.hourly(self.module,self.target,now=4000)
        with self.store.conn() as db:self.assertEqual(db.execute("SELECT count(*) FROM sqlite_master WHERE name='owner_notices'").fetchone()[0],0)


class EmptyWalletLaunchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):launches.OfferLifecycleTests.setUpClass.__func__(cls)
    setUp=launches.OfferLifecycleTests.setUp
    tearDown=launches.OfferLifecycleTests.tearDown
    save=launches.OfferLifecycleTests.save
    def test_catalog_mode_stays_running_with_zero_affordable_lots(self):
        bot.CFG['catalog_sync']={**bot.DEFAULT['catalog_sync'],'enabled':True}
        self.api.balance=lambda:D('.10')
        self.assertEqual(bot.resume_live(self.c),0)
        self.assertFalse(bot.paused());self.assertEqual(self.api.created,[])
        self.assertFalse(any(l.active for l in self.offers.values()))


class CurrencyStockTests(unittest.TestCase):
    setUp=earlier.MaintenanceTests.setUp
    tearDown=earlier.MaintenanceTests.tearDown
    fields=earlier.MaintenanceTests.fields
    def test_usd_available_quantity_tracks_wallet_and_reopens_after_funding(self):
        rule=catalog.currency_rule('USD',steam_product('USD'));rule['description_revision']=catalog.COPY_REVISION
        bot.CFG['lot_rules']={'usd':rule};bot.CFG['managed_lots']={'1':'usd'}
        fields=self.fields(1,rule,'90');self.c.account.get_lot_fields.return_value=fields
        self.c.account.get_my_subcategory_lots.return_value=[N(id=1,active=False,amount=1,price=90)]
        self.api.balance.return_value=D('.50');bot.maintain_availability(self.c)
        self.assertFalse(fields.active)
        self.api.balance.return_value=D('4.25');bot.maintain_availability(self.c)
        self.assertTrue(fields.active);self.assertEqual(fields.amount,4)
        self.assertEqual(bot.STORE.get_meta('last_checked_balance'),'4.25')


if __name__=='__main__':unittest.main()
