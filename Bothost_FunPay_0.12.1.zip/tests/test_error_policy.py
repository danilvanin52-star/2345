"""Seven consecutive failures, order isolation and quiet routine maintenance."""
import json
import threading
import unittest
from types import SimpleNamespace as N
from unittest.mock import Mock, patch

import test_safety_integration as orders
import test_catalog_pricing as products
from test_cardinal_compatibility import full_order, shortcut
import steamru_stars as bot
from steamru_stars_engine import Store, D


class FailurePolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): orders.SafetyIntegrationTests.setUpClass()

    def setUp(self):
        self.case=orders.SafetyIntegrationTests();self.case.setUp()
        bot.STOP.clear()

    def tearDown(self): self.case.tearDown()

    def state(self,scope='processing'):
        return json.loads(bot.STORE.get_meta('failure_streak:'+scope,'{}'))

    def test_six_failures_keep_sales_and_seventh_pauses_once(self):
        with patch.object(bot,'disable_managed_lots') as close:
            for i in range(1,7):
                self.assertEqual(bot.critical(self.case.c,'temporary'),i)
                self.assertFalse(bot.paused());close.assert_not_called()
            self.assertEqual(bot.critical(self.case.c,'temporary'),7)
            self.assertTrue(bot.paused());close.assert_called_once()
            bot.critical(self.case.c,'temporary again');close.assert_called_once()
        with bot.STORE.conn() as db:
            rows=db.execute('SELECT * FROM owner_notices').fetchall()
        self.assertEqual(len(rows),2)
        self.assertEqual(sum(row['urgent'] for row in rows),1)

    def test_success_resets_only_its_own_failure_stream(self):
        for _ in range(6):bot.critical(self.case.c,'temporary',scope='purchase')
        bot.health.success(bot,'maintenance')
        self.assertEqual(self.state('purchase')['count'],6)
        bot.health.success(bot,'purchase')
        self.assertEqual(bot.critical(self.case.c,'new failure',scope='purchase'),1)
        self.assertFalse(bot.paused())

    def test_failure_count_survives_database_reopen(self):
        for _ in range(6):bot.critical(self.case.c,'temporary')
        bot.STORE=Store(self.case.store.path)
        with patch.object(bot,'disable_managed_lots'):
            bot.critical(self.case.c,'seventh')
        self.assertTrue(bot.paused())

    def test_notification_failure_cannot_prevent_seventh_failure_pause(self):
        with patch.object(bot.notifications,'notify',side_effect=RuntimeError('outbox unavailable')), \
                patch.object(bot,'disable_managed_lots') as close:
            for _ in range(7):bot.critical(self.case.c,'temporary')
        self.assertTrue(bot.paused());close.assert_called_once()
        self.assertEqual(bot.STORE.get_meta('resume_token'),'')

    def test_parallel_failures_cannot_lose_increments_or_repeat_shutdown(self):
        with patch.object(bot,'disable_managed_lots') as close:
            threads=[threading.Thread(target=bot.critical,args=(self.case.c,'temporary')) for _ in range(10)]
            for thread in threads:thread.start()
            for thread in threads:thread.join(3);self.assertFalse(thread.is_alive())
        self.assertEqual(self.state()['count'],7)
        self.assertTrue(bot.paused());close.assert_called_once()

    def test_unsupported_steam_amounts_never_pause_or_count_or_repeat_notices(self):
        api=self.case.interfaces
        rule=products.catalog.rub_rule(1,{'price_usd':'.0118'})
        bot.CFG.update(lot_rules={'rub':rule},managed_lots={'123':'rub'},allowed_subcategory_ids=[1086])
        for i,amount in enumerate([99,501,156.5,0,600,80,900]):
            oid='BADSUM'+str(i)
            order=full_order(api,oid=oid,subcategory_id=1086,amount=amount)
            order.fields={k:api.LotField(k,v) for k,v in rule['match_fields'].items()}
            self.case.c.account.order=order
            event=shortcut(api,oid=oid);event.subcategory.id=1086
            for _ in range(2):bot.on_new_order(self.case.c,N(order=event))
            self.assertIsNone(bot.STORE.get(oid))
        self.assertFalse(bot.paused());self.assertEqual(self.state('capture'),{})
        self.assertEqual(self.case.api.created,[]);self.assertEqual(self.case.c.account.lot_saves,[])
        with bot.STORE.conn() as db:
            self.assertEqual(db.execute('SELECT count(*) FROM owner_notices').fetchone()[0],7)
            self.assertEqual(db.execute('SELECT count(*) FROM owner_notices WHERE urgent=1').fetchone()[0],0)

    def start_pending(self):
        self.case.api.status='processing';self.case.ready();bot.process_ready(self.case.c)
        self.assertEqual(len(self.case.api.created),1)

    def test_seven_supplier_read_failures_pause_without_repeating_purchase(self):
        self.start_pending()
        with patch.object(self.case.api,'get_order',side_effect=TimeoutError()):
            for i in range(7):
                bot.process_pending(self.case.c,bot.STORE.get('ABCD1234'),self.case.api)
                self.assertEqual(bot.paused(),i==6)
        self.assertEqual(len(self.case.api.created),1)

    def test_supplier_success_between_failures_resets_counter(self):
        self.start_pending()
        with patch.object(self.case.api,'get_order',side_effect=TimeoutError()):
            for _ in range(6):bot.process_pending(self.case.c,bot.STORE.get('ABCD1234'),self.case.api)
        bot.process_pending(self.case.c,bot.STORE.get('ABCD1234'),self.case.api)
        with patch.object(self.case.api,'get_order',side_effect=TimeoutError()):
            bot.process_pending(self.case.c,bot.STORE.get('ABCD1234'),self.case.api)
        self.assertFalse(bot.paused());self.assertEqual(self.state('supplier:ABCD1234')['count'],1)

    def test_supplier_bad_status_seven_times_blocks_order_then_pauses_shop(self):
        self.start_pending();self.case.api.status='error'
        for i in range(7):
            bot.process_pending(self.case.c,bot.STORE.get('ABCD1234'),self.case.api)
            self.assertEqual(bot.paused(),i==6)
            self.assertEqual(bot.STORE.get('ABCD1234')['status'],'needs_review')
        self.assertEqual(len(self.case.api.created),1)
        with bot.STORE.conn() as db:
            self.assertEqual(db.execute('SELECT count(*) FROM owner_notices WHERE urgent=1').fetchone()[0],2)

    def test_action_journal_failure_cannot_turn_successful_purchase_into_error(self):
        self.case.ready()
        with patch.object(bot.activity,'prepare',side_effect=RuntimeError('journal unavailable')):
            bot.process_ready(self.case.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'completed')
        self.assertFalse(bot.paused());self.assertEqual(len(self.case.api.created),1)

    def test_wrong_supplier_product_isolated_without_second_purchase_or_false_delivery(self):
        self.case.ready()
        original=self.case.api.create
        def wrong(*args):
            result=original(*args);result['product_id']=56;return result
        with patch.object(self.case.api,'create',side_effect=wrong):bot.process_ready(self.case.c)
        for _ in range(2):bot.process_pending(self.case.c,bot.STORE.get('ABCD1234'),self.case.api)
        bot.process_ready(self.case.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'needs_review')
        self.assertEqual(bot.STORE.get('ABCD1234')['buyer_notified'],0)
        self.assertFalse(bot.paused());self.assertEqual(len(self.case.api.created),1)

    def test_old_activity_spam_is_suppressed_without_hiding_orders_or_money_alerts(self):
        for message,urgent in [('🛠 наличие None → 1',False),('Оплачен #PAY123',False),
                               ('НЕОПРЕДЕЛЁННОЕ СПИСАНИЕ #PAY123',True),
                               ('Заказ #BAD123: Неподдерживаемая сумма пополнения Steam',True)]:
            bot.notifications.notify(bot,self.case.c,message,urgent=urgent)
        self.assertEqual(bot.notifications.silence_routine_backlog(bot),2)
        self.assertEqual(bot.notifications.silence_routine_backlog(bot),0)
        with bot.STORE.conn() as db:
            states={row['message']:row['state'] for row in db.execute('SELECT * FROM owner_notices')}
        self.assertEqual(states['Оплачен #PAY123'],'pending')
        self.assertEqual(states['НЕОПРЕДЕЛЁННОЕ СПИСАНИЕ #PAY123'],'pending')

    def test_successful_manual_resume_resolves_system_alarm_only(self):
        for _ in range(7):bot.critical(self.case.c,'temporary')
        bot.notifications.notify(bot,self.case.c,'НЕОПРЕДЕЛЁННОЕ СПИСАНИЕ #PAY123',urgent=True)
        bot.health.reset_all(bot)
        with bot.STORE.conn() as db:
            states={row['order_id']:row['state'] for row in db.execute('SELECT * FROM owner_notices WHERE urgent=1')}
        self.assertEqual(states['SYSTEM_processing'],'resolved')
        self.assertEqual(states['PAY123'],'pending')
        self.assertEqual(self.state()['count'],0)


class MissingStockTests(unittest.TestCase):
    setUp=products.MaintenanceTests.setUp
    tearDown=products.MaintenanceTests.tearDown
    fields=products.MaintenanceTests.fields

    def test_on_demand_missing_stock_does_not_cause_repeated_saves_or_notices(self):
        rule=products.catalog.key_rule(products.game());rule['description_revision']=products.catalog.COPY_REVISION
        bot.CFG['lot_rules']={'key':rule};bot.CFG['managed_lots']={'1':'key'}
        _,price=bot.price_band(rule,rule['last_price_usd'])
        fields=self.fields(1,rule,price);fields.active=True;fields.amount=None
        self.c.account.get_lot_fields.return_value=fields
        self.c.account.get_my_subcategory_lots.return_value=[]
        with patch.object(bot.activity,'record') as record:
            for _ in range(3):bot.maintain_availability(self.c)
        self.c.account.save_lot.assert_not_called()
        self.assertFalse(any(call.args[2]=='availability' for call in record.call_args_list))
        self.assertIsNone(fields.amount)

    def test_missing_currency_stock_still_gets_explicit_affordable_limit(self):
        rule=products.catalog.rub_rule(1,{'price_usd':'.0118'});rule['description_revision']=products.catalog.COPY_REVISION
        bot.CFG['lot_rules']={'rub':rule};bot.CFG['managed_lots']={'1':'rub'}
        fields=self.fields(1,rule,'1');fields.amount=None
        self.c.account.get_lot_fields.return_value=fields
        self.c.account.get_my_subcategory_lots.return_value=[]
        bot.maintain_availability(self.c)
        self.assertEqual(fields.amount,483);self.assertTrue(fields.active)


if __name__=='__main__':unittest.main()
