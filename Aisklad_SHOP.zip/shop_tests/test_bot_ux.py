"""Regression coverage for visible replies, contextual search and Steam pricing."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from aisklad_shop.bot import BuyerBot
from aisklad_shop import presentation as p
from shop_tests.test_bot import FakeBot, FakeService, message


class BuyerUXTests(unittest.TestCase):
    def setUp(self):
        self.service, self.bot = FakeService(), FakeBot()
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")

    def click(self, label, uid=10):
        markup = self.bot.sent[-1][2]["reply_markup"]
        data = next(button.callback_data for row in markup.keyboard for button in row if label in button.text)
        self.ui.handle_callback(NS(id="cb", from_user=NS(id=uid), message=message("", uid), data=data))

    def test_each_typed_command_has_new_visible_reply_and_callbacks_still_edit(self):
        edited = []
        self.bot.edit_message_text = lambda text, **kwargs: edited.append((text, kwargs))
        self.ui.handle_message(message("/start", uid=99))
        self.ui.handle_message(message("/start", uid=99))
        self.ui.handle_message(message("/shop_stats", uid=99))
        self.assertEqual(len(self.bot.sent), 3)
        self.assertEqual(edited, [])
        self.click("Обновить статистику", uid=99)
        self.assertEqual(len(self.bot.sent), 3)
        self.assertEqual(edited[-1][1]["message_id"], 3)

    def test_photo_commands_do_not_edit_history_but_button_navigation_reuses_current(self):
        edited = []
        with tempfile.TemporaryDirectory() as directory:
            for name in ("home", "catalog"):
                Path(directory, name + ".jpg").write_bytes(b"offline-image")
            self.ui.assets_dir = Path(directory)
            self.bot.edit_message_media = lambda media, **kwargs: edited.append(kwargs)
            self.ui.handle_message(message("/start"))
            self.ui.handle_message(message("/start"))
            self.assertEqual(len(self.bot.sent), 2)
            self.assertEqual(edited, [])
            self.click("каталог")
            self.assertEqual(len(self.bot.sent), 2)
            self.assertEqual(edited[0]["message_id"], 2)

    def test_plaintext_anywhere_and_assistant_preserve_real_product_buttons(self):
        calls = []
        def answer(uid, text, context=None):
            calls.append((uid, text, context))
            return {"answer": "Нашёл <товар> в каталоге", "items": self.service.items, "actions": [], "context": {"service": "steam"}}
        self.service.assistant_response = answer
        self.ui.handle_message(message("Roblox"))
        self.assertEqual(calls[0][1], "Roblox")
        self.assertIn("&lt;товар&gt;", self.bot.sent[-1][1])
        self.assertNotIn("Открой /menu", self.bot.sent[-1][1])
        self.assertTrue(any("Stars" in button.text for row in self.bot.sent[-1][2]["reply_markup"].keyboard for button in row))
        self.ui.handle_message(message("рубли"))
        self.assertEqual(calls[1][2], {"service": "steam"})

    def test_search_with_typo_no_space_and_unmatched_query_reaches_assistant(self):
        calls = []
        self.service.list_products = lambda *args, **kwargs: {"items": [], "total": 0, "page": 0, "pages": 1}
        self.service.assistant_response = lambda uid, text, context=None: calls.append(text) or {"answer": "Проверь, это Roblox?", "items": self.service.items, "actions": []}
        self.ui.handle_message(message("/searchRoblxo"))
        self.assertEqual(calls, ["Roblxo"])
        self.assertIn("Roblox", self.bot.sent[-1][1])
        self.ui.handle_message(message("/search Steam"))
        self.assertEqual(calls[-1], "Steam")

    def test_forms_and_help_keep_priority_over_assistant(self):
        calls = []
        self.service.assistant_response = lambda *args, **kwargs: calls.append(1) or {"answer": "Assistant"}
        self.ui._begin_buy(10, "stars", {})
        self.ui.handle_message(message("Steam"))
        self.assertEqual(calls, [])
        self.ui.handle_message(message("50"))
        self.ui.handle_message(message("Roblox"))
        self.assertEqual(calls, [])
        self.assertIn("Проверь", self.bot.sent[-1][1])
        self.ui.handle_message(message("!помощь"))
        self.ui.handle_message(message("Steam не пополнился"))
        self.assertEqual(calls, [])
        self.assertEqual(self.service.help[-1][1], "Steam не пополнился")

    def test_explicit_assistant_and_owner_module_alias(self):
        self.ui.handle_message(message("/assistant"))
        self.assertIn("Умный помощник Aisklad", self.bot.sent[-1][1])
        self.assertEqual(self.service.store.get_session(10)["mode"], "assistant")
        class Modules:
            def status(self):
                return {"shop": True, "funpay": True}
        self.ui.module_controller = Modules()
        self.ui.handle_message(message("/aisklad_modules", uid=99))
        self.assertIn("Модули Aisklad", self.bot.sent[-1][1])
        self.ui.handle_message(message("/aisklad_modules", uid=10))
        self.assertIn("владельцу", self.bot.sent[-1][1])

    def test_steam_unit_cost_api_bounds_and_assistant_quantity_not_a_purchase(self):
        item = {"id": "steam-rub", "title": "Steam RUB · Пополнение баланса", "service": "steam", "kind": "topup", "available": True,
                "price_rub": "103.21", "min_total_rub": "103.21", "unit_price_rub": "1.029573", "unit_currency": "RUB", "min_quantity": 100,
                "max_quantity": 500000, "suggested_quantity": 156}
        self.service.items = [item]
        screen = p.product(item)
        self.assertIn("За <b>1 ₽ (RUB)</b>", screen.caption)
        self.assertIn("1,029573 ₽", screen.caption)
        self.assertIn("100–500000 ₽ (RUB)", screen.caption)
        self.assertNotIn("∞", screen.caption)
        self.ui._send_screen(10, screen)
        self.click("Выбрать 156")
        self.assertEqual(self.service.store.get_session(10)["draft"]["quantity"], 156)
        self.assertEqual(self.service._cart, [])
        self.assertEqual(self.service.checkedout, 0)

    def test_assistant_unknown_action_cannot_pay_or_change_module(self):
        screen = p.assistant({"answer": "Выбери товар", "actions": [{"type": "pay", "id": "evil", "label": "Оплатить"},
                                                                 {"type": "module", "id": "shop", "label": "Включить"}]})
        self.assertNotIn("pay", [action.name for row in screen.rows for action in row])
        self.assertNotIn("module", [action.name for row in screen.rows for action in row])

    def test_input_context_clears_after_exception_so_callbacks_keep_working(self):
        self.service.assistant_response = lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("offline"))
        self.ui.handle_message(message("Steam"))
        self.assertIsNone(getattr(self.ui._input_context, "uid", None))
        self.ui.handle_message(message("/start"))
        edited = []
        self.bot.edit_message_text = lambda text, **kwargs: edited.append(kwargs)
        self.click("каталог")
        self.assertEqual(len(edited), 1)

    def test_hundred_plaintext_turns_each_receive_new_answer_without_actions(self):
        calls, edited = [], []
        def helper(uid, text, context=None):
            calls.append(text)
            return {"answer": "Подобрал варианты из каталога.", "items": self.service.items, "actions": [], "context": {"last_service": "steam"}}
        self.service.assistant_response = helper
        self.bot.edit_message_text = lambda text, **kwargs: edited.append(kwargs)
        examples = ["Steam", "Roblox", "стим", "Роблокс", "хочу пополнить на 156 рублей", "подбери подарок", "Steem", "Roblxo", "Telegram Stars", "KZT"]
        for index in range(100):
            self.ui.handle_message(message(examples[index % len(examples)]))
        self.assertEqual(len(calls), 100)
        self.assertEqual(len(self.bot.sent), 100)
        self.assertEqual(edited, [])
        self.assertTrue(all("Подобрал варианты" in text for _, text, _ in self.bot.sent))
        self.assertEqual(self.service.checkedout, 0)
        self.assertEqual(self.service._cart, [])

    def test_steam_is_first_home_action_and_routes_real_service(self):
        calls = []
        original = self.service.list_products
        self.service.list_products = lambda service_id, **kwargs: calls.append(service_id) or original(service_id, **kwargs)
        self.ui.handle_message(message("/start"))
        self.assertEqual(self.bot.sent[-1][2]["reply_markup"].keyboard[0][0].text, "🎮 Пополнить Steam")
        self.click("Пополнить Steam")
        self.assertEqual(calls, ["service:steam"])


if __name__ == "__main__":
    unittest.main()
