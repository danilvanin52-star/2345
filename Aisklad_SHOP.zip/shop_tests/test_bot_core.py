"""UI contracts exercised with the actual durable shop backend, no networks."""
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from aisklad_shop.bot import BuyerBot
from aisklad_shop.service import ShopService
from aisklad_shop.store import ShopStore
from aisklad_shop import presentation as p
from shop_tests.test_bot import FakeBot, message


class Supplier:
    def __init__(self):
        self.purchase_calls = 0

    def brands(self):
        return [{"id": "steam", "name": "Steam"}]

    def services(self):
        return [{"id": "steam", "brand": "steam", "name": "Steam RUB"}]

    def products(self, service):
        return {"service": "steam", "type": "topup", "requires_account": True,
                "products": [{"product_id": 1, "name": "Steam · RUB", "price_usd": "0.011", "min_count": 100, "max_count": 550000, "fields": []}]}

    def keys(self):
        return []

    def gifts(self):
        return []

    def check_account(self, service, account):
        return {"valid": True}

    def balance(self):
        return "5.96"


class BotBackendContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = ShopStore(Path(self.temp.name) / "shop.sqlite3")
        self.supplier = Supplier()
        self.service = ShopService(self.store, self.supplier, settings={"enabled": True, "owner_id": 99, "target_margin_pct": "0.4", "fixed_cost_rub": "0.25"},
                                   rate_provider=lambda: {"rub_per_usd": "90", "observed_at": time.time(), "source": "offline-fixture"})
        self.service.sync_catalog()
        self.bot = FakeBot()
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")

    def tearDown(self):
        self.temp.cleanup()

    def click(self, label, uid=10):
        markup = self.bot.sent[-1][2]["reply_markup"]
        payload = next(b.callback_data for row in markup.keyboard for b in row if label in b.text)
        self.ui.handle_callback(NS(id="c", from_user=NS(id=uid), message=message("", uid), data=payload))

    def test_minimum_price_and_quantity_quote_match_backend_not_price_times_count(self):
        self.ui.handle_message(message("/start"))
        self.click("каталог")
        self.click("Steam")
        self.click("Steam RUB")
        self.click("Steam · RUB")
        self.assertIn("за 100 ₽ (RUB)", self.bot.sent[-1][1])
        self.assertIn("100–550000 ₽ (RUB)", self.bot.sent[-1][1])
        self.assertIn("За <b>1 ₽ (RUB)</b>", self.bot.sent[-1][1])
        self.click("количество")
        self.ui.handle_message(message("156"))
        self.ui.handle_message(message("recipient_name"))
        product = self.service.list_products("service:steam")["items"][0]
        exact = self.service.quote(10, product["id"], quantity=156, fields={"account": "recipient_name"})["total_rub"]
        self.assertIn(p.rub(exact), self.bot.sent[-1][1])
        self.assertEqual(self.service.cart(10)["items"], [])
        self.click("Всё верно")
        self.assertEqual(self.service.cart(10)["total_rub"], exact)
        self.click("оформлению")
        self.click("доступность оплаты")
        self.assertIn("списаний нет", self.bot.sent[-1][1])
        self.assertEqual(self.supplier.purchase_calls, 0)
        self.assertEqual(self.service.orders(10)["items"], [])

    def test_help_detail_is_saved_once_and_owner_event_delivered(self):
        self.ui.handle_message(message("!помощь"))
        self.ui.handle_message(message("Не могу найти нужное пополнение"))
        with self.store.connection() as db:
            rows = db.execute("SELECT message FROM support").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertIn("Не могу найти", rows[0][0])
        self.ui.send_pending_notifications()
        self.assertTrue(any(uid == 99 and "Не могу найти" in text for uid, text, _ in self.bot.sent))
        self.assertEqual(self.service.pending_notifications(), [])

    def test_real_store_restart_preserves_buttons_and_buyer_favorites(self):
        self.ui.handle_message(message("/start"))
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")
        self.click("каталог")
        self.click("Steam")
        self.click("Steam RUB")
        self.click("Steam · RUB")
        self.click("Сохранить")
        self.assertIn("В избранном", str(self.bot.sent[-1][2]["reply_markup"].to_dict()))
        self.assertEqual(self.service.favorites(20)["items"], [])
        self.assertEqual(len(self.service.favorites(10)["items"]), 1)

    def test_real_owner_health_resume_balance_and_stats_without_payment_enable(self):
        self.store.set_setting("shop:health_paused", True)
        self.store.set_setting("health:catalog", 7)
        self.ui.handle_message(message("/shop_resume", uid=10))
        self.assertTrue(self.store.get_setting("shop:health_paused"))
        self.ui.handle_message(message("/shop_resume", uid=99))
        self.assertFalse(self.store.get_setting("shop:health_paused"))
        self.assertTrue(self.service.is_enabled())
        self.assertFalse(self.service.payments.enabled)
        self.ui.handle_message(message("/shop_balance", uid=99))
        self.ui._admin_jobs["balance"].join(2)
        self.assertIn("$5.96", self.bot.sent[-1][1])
        self.ui.handle_message(message("/shop_stats", uid=99))
        self.assertIn("Статистика", self.bot.sent[-1][1])
        self.assertEqual(self.supplier.purchase_calls, 0)

    def test_support_reply_only_owner_and_only_ticket_destination(self):
        ticket = self.service.request_help(10, "Пожалуйста помогите")["ticket_id"]
        self.ui.handle_message(message("/shop_reply " + ticket + " Чужой ответ", uid=20))
        self.ui.handle_message(message("/shop_reply " + ticket + " Групповой ответ", uid=99, group=True))
        self.assertFalse(any(event["kind"] == "support_reply" for event in self.service.pending_notifications()))
        self.ui.handle_message(message("/shop_reply " + ticket + " Ваше пополнение проверим <сегодня>", uid=99))
        events = [event for event in self.service.pending_notifications() if event["kind"] == "support_reply"]
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["user_id"], 10)
        self.assertEqual(events[0]["payload"]["ticket_id"], ticket)
        self.assertNotIn("order_id", events[0]["payload"])
        self.assertEqual(self.service.orders(10)["items"], [])
        self.assertEqual(self.supplier.purchase_calls, 0)

    def test_support_reply_survives_restart_deduplicates_and_preserves_full_text(self):
        ticket = self.service.request_help(10, "Помогите выбрать товар")["ticket_id"]
        response = "Получили вопрос. Напишите название игры <Test>."
        command = "/shop_reply " + ticket + " " + response
        self.ui.handle_message(message(command, uid=99))
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")
        self.ui.send_pending_notifications()
        buyer_replies = [text for uid, text, _ in self.bot.sent if uid == 10]
        self.assertEqual(len(buyer_replies), 1)
        self.assertIn("&lt;Test&gt;", buyer_replies[0])
        self.assertTrue(any(uid == 99 and "/shop_reply " + ticket in text for uid, text, _ in self.bot.sent))
        self.ui.handle_message(message(command, uid=99))
        self.ui.send_pending_notifications()
        self.assertEqual(len([text for uid, text, _ in self.bot.sent if uid == 10]), 1)
        self.assertIn("уже сохранён", self.bot.sent[-1][1])

    def test_support_reply_missing_ticket_and_usage_do_not_queue_anything(self):
        self.ui.handle_message(message("/shop_reply UNKNOWN ответ", uid=99))
        self.assertIn("не найдено", self.bot.sent[-1][1])
        self.ui.handle_message(message("/shop_reply", uid=99))
        self.assertIn("НОМЕР_ОБРАЩЕНИЯ", self.bot.sent[-1][1])
        self.assertEqual(self.service.pending_notifications(), [])

    def test_actual_catalog_helper_finds_rub_156_then_only_fills_recipient_form(self):
        self.ui.handle_message(message("Хочу пополнить Steam на 156 рублей"))
        self.assertIn("помощник", self.bot.sent[-1][1].lower())
        self.assertEqual(self.service.cart(10)["items"], [])
        self.assertEqual(self.service.orders(10)["items"], [])
        self.click("Steam")
        self.assertIn("1 ₽ (RUB)", self.bot.sent[-1][1])
        self.click("Выбрать 156")
        self.assertEqual(self.store.get_session(10)["draft"]["quantity"], 156)
        self.assertEqual(self.store.get_session(10)["mode"], "field")
        self.ui.handle_message(message("recipient_name"))
        exact = self.service.quote(10, self.service.list_products("service:steam")["items"][0]["id"], quantity=156, fields={"account": "recipient_name"})["total_rub"]
        self.assertIn(p.rub(exact), self.bot.sent[-1][1])
        self.assertEqual(self.service.cart(10)["items"], [])
        self.assertEqual(self.supplier.purchase_calls, 0)


if __name__ == "__main__":
    unittest.main()
