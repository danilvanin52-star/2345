"""Buyer-facing copy and screen descriptions, independent of Telegram/network."""
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from html import escape
from typing import Any


BRAND = "Aisklad SHOP"
MENU_KEYS = ("home", "catalog", "search", "favorites", "cart", "checkout", "orders", "profile", "help", "product", "assistant", "about")


def safe(value: Any, limit: int = 350) -> str:
    """External catalogue and buyer content is always escaped before HTML use."""
    text = str(value or "").replace("\x00", "")
    return escape(text if limit is None or len(text) <= limit else text[:limit - 1] + "…", quote=True)


def rub(value: Any) -> str:
    try:
        number = Decimal(str(value)).quantize(Decimal("0.01"))
        if not number.is_finite() or number < 0:
            raise InvalidOperation
        return f"{number:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
    except (InvalidOperation, ValueError, TypeError):
        return "уточняется"


def unit_rub(value: Any) -> str:
    """Exchange-style unit prices retain meaningful sub-kopeck precision."""
    try:
        number = Decimal(str(value)).quantize(Decimal("0.000001"))
        if not number.is_finite() or number <= 0:
            raise InvalidOperation
        return format(number, "f").rstrip("0").rstrip(".").replace(".", ",") + " ₽"
    except (InvalidOperation, ValueError, TypeError):
        return "уточняется"


def currency_label(value):
    return {"RUB": "₽ (RUB)", "KZT": "₸ (KZT)"}.get(str(value), str(value))


@dataclass
class Action:
    label: str
    name: str
    args: dict = field(default_factory=dict)


@dataclass
class Screen:
    caption: str
    image: Any = "home"
    rows: list = field(default_factory=list)


def button(label, name, **args):
    return Action(label, name, args)


def nav():
    return [[button("🛍 Каталог", "catalog"), button("🛒 Корзина", "cart")], [button("⌂ Главное меню", "home")]]


def home(enabled=True):
    state = "Выбирай цифровые товары для любимых игр и сервисов — всё в одном чате." if enabled else "Магазин временно на паузе. Каталог, помощник и история доступны."
    return Screen(
        "<b>✨ Aisklad SHOP</b>\n<i>Твой следующий уровень начинается здесь.</i>\n\n"
        + state + "\n\n🎮 Игры, пополнения и цифровые подарки.\n💎 Цена и данные — на проверке перед покупкой.\n📦 Заказы и выданные коды — в личной истории.\n\n"
        "🤖 Напиши название игры или спроси помощника — подберём варианты из каталога.\n"
        "💬 Нужен человек? <b>!помощь</b>", "home",
        [[button("🎮 Пополнить Steam", "category", category_id="service:steam")], [button("🛍 Открыть каталог", "catalog")], [button("🤖 Помощник", "assistant"), button("🔎 Найти товар", "search")],
         [button("💜 Избранное", "favorites"), button("🛒 Моя корзина", "cart")],
         [button("📦 Мои заказы", "orders"), button("👤 Профиль", "profile")],
         [button("💬 Поддержка", "help"), button("✨ Как покупать", "about")]])


def assistant(data=None):
    data = data or {}
    answer = data.get("answer") or data.get("message") or "Подскажу, что выбрать, найду товар и помогу разобраться с регионом или пополнением. Напиши обычным сообщением — например: «Хочу пополнить Steam на 156 рублей» или «Нужны Robux»."
    rows, product_ids = [], set()
    for action in data.get("actions", [])[:8]:
        kind, identifier = str(action.get("type", "")), str(action.get("id", ""))
        label = str(action.get("label") or "Открыть")[:58]
        if kind == "product" and identifier:
            rows.append([button(label, "product", product_id=identifier, suggested_quantity=action.get("quantity"))])
            product_ids.add(identifier)
        elif kind == "service" and identifier:
            rows.append([button(label, "products", service_id=identifier)])
        elif kind == "category" and identifier:
            rows.append([button(label, "category", category_id=identifier)])
        elif kind in ("help", "orders", "cart"):
            rows.append([button(label, kind)])
    for item in data.get("items", [])[:8]:
        identifier = str(item.get("id", ""))
        if identifier and identifier not in product_ids and len(rows) < 8:
            label = str(item.get("title") or "Товар")[:38]
            if not item.get("has_variants"):
                label += " · от " + rub(item.get("price_rub"))
            rows.append([button(label, "product", product_id=identifier, suggested_quantity=item.get("suggested_quantity"))])
            product_ids.add(identifier)
    if not data:
        rows = [[button("🎮 Пополнить Steam", "assistant_query", query="Хочу пополнить Steam")],
                [button("💎 Найти Robux", "assistant_query", query="Roblox Robux"), button("⭐ Telegram Stars", "assistant_query", query="Telegram Stars")],
                [button("🎁 Помочь выбрать подарок", "assistant_query", query="Хочу подарить игру")]]
    rows += [[button("🛍 Каталог", "catalog"), button("💬 Человек", "help")], [button("⌂ Главное меню", "home")]]
    return Screen("<b>🤖 Умный помощник Aisklad</b>\n\n" + safe(answer, 1000) + "\n\n<i>Можно просто продолжить сообщением.</i>", "assistant", rows)


def about():
    return Screen("<b>✨ Покупки без лишних шагов</b>\n\n<b>1.</b> Найди игру или сервис в каталоге либо напиши помощнику.\n<b>2.</b> Выбери регион и количество, укажи данные получателя.\n<b>3.</b> Проверь итоговую сумму перед оплатой.\n<b>4.</b> Открой заказ: код придёт в чат, пополнение — на указанный аккаунт.\n\n🔐 Пароли и коды входа не нужны.\n💬 Вопросы? Мы рядом: <b>!помощь</b>.", "about", [[button("🤖 Помоги выбрать", "assistant")], [button("🛍 За покупками", "catalog"), button("⌂ Меню", "home")]])


def catalog(data, parent=None):
    rows = [[button(str(item.get("title") or "Категория")[:55], "category", category_id=str(item["id"]))] for item in data.get("items", [])]
    rows += pagination("catalog", data, parent=parent)
    rows += [[button("🔎 Поиск по всему каталогу", "search"), button("⌂ Меню", "home")]]
    total = int(data.get("total", 0))
    return Screen("<b>🛍 Каталог Aisklad SHOP</b>\n\nВыбери категорию. В карточке товара — цена, регион и условия получения.\n\n"
                  + (f"Категорий: <b>{total}</b>" if total else "Каталог обновляется. Попробуй немного позже."), "catalog", rows)


def pagination(action, data, **args):
    page, pages = int(data.get("page", 0)), max(1, int(data.get("pages", 1)))
    row = []
    if page > 0:
        row.append(button("‹ Назад", action, page=page - 1, **args))
    if page + 1 < pages:
        row.append(button("Далее ›", action, page=page + 1, **args))
    return [row] if row else []


def products(data, service_id=None, query=None, favorite=False):
    rows = []
    for item in data.get("items", []):
        prefix = "🎮 " if item.get("kind") in ("key", "key_group", "gift", "gift_group") else "✨ "
        price = "" if item.get("has_variants") else " · от " + rub(item.get("price_rub"))
        rows.append([button(prefix + str(item.get("title") or "Товар")[:38] + price, "product", product_id=str(item["id"]))])
    action = "favorites" if favorite else "products"
    if favorite:
        args = {}
        title, image = "<b>💜 Избранное</b>", "favorites"
        empty = "Сохрани понравившийся товар сердечком в его карточке."
    elif query:
        args = {"query": query, "service_id": service_id}
        title, image = "<b>🔎 Результаты поиска</b>\nЗапрос: " + safe(query, 100), "search"
        empty = "Ничего не нашлось. Попробуй другое название или открой каталог."
    else:
        args = {"service_id": service_id}
        title, image, empty = "<b>✨ Выбери товар</b>", "catalog", "В этой категории пока нет доступных товаров."
    rows += pagination(action, data, **args)
    rows += [[button("🔎 Другой поиск", "search"), button("🛍 Каталог", "catalog")], [button("⌂ Меню", "home")]]
    caption = title + "\n\n" + (f"Найдено: <b>{int(data.get('total', 0))}</b>. Открой карточку для подробностей." if data.get("items") else empty)
    return Screen(caption, image, rows)


def product(item, is_favorite=False):
    title = safe(item.get("title"), 140)
    price = rub(item.get("price_rub"))
    text = f"<b>{'🎮' if item.get('kind') in ('key','key_group','gift','gift_group') else '✨'} {title}</b>\n\n"
    if not item.get("has_variants"):
        minimum = item.get("min_quantity", item.get("min_count", 1)) or 1
        currency = str(item.get("unit_currency") or "")
        if currency in ("RUB", "KZT") and item.get("unit_price_rub") is not None:
            label = currency_label(currency)
            text += "💱 За <b>1 " + safe(label, 20) + "</b>: <b>" + unit_rub(item["unit_price_rub"]) + "</b>\n"
            maximum = item.get("max_quantity", item.get("max_count", minimum)) or minimum
            text += "📥 Сумма пополнения: <b>" + safe(minimum, 20) + "–" + safe(maximum, 20) + " " + safe(label, 20) + "</b>\n"
            text += "От <b>" + rub(item.get("min_total_rub", item.get("price_rub"))) + "</b> за " + safe(minimum, 20) + " " + safe(label, 20) + "\n"
            text += "Итог включает сервисный сбор. Точная стоимость — после выбора суммы.\n"
        else:
            text += f"От <b>{price}</b> за {safe(minimum, 20)} ед.\n"
    if item.get("region"):
        text += "🌍 Регион: <b>" + safe(item["region"], 100) + "</b>\n"
    if item.get("description"):
        text += "\n" + safe(item["description"], 320) + "\n"
    if item.get("warning"):
        text += "\n⚠️ " + safe(item["warning"], 220) + "\n"
    kind = str(item.get("kind") or "")
    if kind in ("key", "code"):
        text += "\n📦 После оплаты и успешной выдачи код появится здесь и в истории заказа."
    elif kind == "gift":
        text += "\n🎁 Игра отправляется подарком Steam выбранного издания и региона. Подготовь ссылку-приглашение."
    elif kind == "topup":
        text += "\n💸 Пополнение отправляется на указанный аккаунт. Статус выполнения появится в заказе. Пароль не нужен."
    rows = []
    if item.get("has_variants"):
        text += "\n\nВыбери издание, регион или номинал:"
        for variant in item.get("variants", [])[:8]:
            rows.append([button(str(variant.get("title") or "Вариант")[:36] + " · " + rub(variant.get("price_rub")), "product", product_id=str(variant["id"]))])
        if len(item.get("variants", [])) > 8:
            rows.append([button("Все варианты ›", "variants", product_id=str(item["id"]), page=0)])
    elif item.get("available", True):
        suggested = item.get("suggested_quantity")
        if suggested is not None:
            label = "🛒 Выбрать " + str(suggested) + (" " + str(item["unit_currency"]) if item.get("unit_currency") in ("RUB", "KZT") else " ед.")
        else:
            label = "🛒 Выбрать количество"
        rows.append([button(label, "begin_buy", product_id=str(item["id"]), suggested_quantity=suggested)])
    else:
        text += "\n\n⏳ Сейчас недоступен для покупки."
    rows += [[button("💜 В избранном" if is_favorite else "♡ Сохранить", "toggle_favorite", product_id=str(item["id"]))]]
    rows += nav()
    return Screen(text, item, rows)


def field_summary(fields, requirements):
    labels = {str(f.get("name")): str(f.get("label") or f.get("name")) for f in requirements}
    return "\n".join("• " + safe(labels.get(str(key), key), 80) + ": <b>" + safe(value, 120) + "</b>" for key, value in fields.items())


def cart(data):
    rows, text = [], "<b>🛒 Твоя корзина</b>\n\n"
    items = data.get("items", [])
    if not items:
        text += "Здесь пока пусто. Выбери что-нибудь в каталоге ✨"
    else:
        for index, item in enumerate(items, 1):
            text += f"<b>{index}. {safe(item.get('title'), 70)}</b>\nКоличество: {safe(item.get('quantity'), 30)} · {rub(item.get('total_rub'))}\n\n"
            rows.append([button("✕ " + str(item.get("title") or "Убрать")[:38], "remove_cart", item_id=str(item["id"]))])
        text += "Итого: <b>" + rub(data.get("total_rub")) + "</b>\nЦена и наличие будут проверены ещё раз перед оплатой."
        rows += [[button("💳 Перейти к оформлению", "checkout")], [button("🧹 Очистить корзину", "clear_cart")]]
    rows += [[button("🛍 Продолжить покупки", "catalog"), button("⌂ Меню", "home")]]
    return Screen(text, "cart", rows)


STATUS = {"awaiting_payment": "Ожидает оплаты", "pending_payment": "Ожидает оплаты", "paid": "Оплачен", "processing": "В работе",
          "completed": "Выполнен", "delivered": "Выдан", "refunded": "Возврат подтверждён", "cancelled": "Отменён", "review": "Проверяет поддержка",
          "error": "Нужна проверка", "pending": "В обработке", "payment_failed": "Оплата не завершена", "fulfilling": "Выполняется",
          "needs_review": "Проверяет поддержка", "uncertain": "Проверяем результат", "refund_required": "Возврат проверяется",
          "invoice_creating": "Создаём страницу заказа", "invoice_review": "Страница оплаты пока недоступна", "unpaid": "Не оплачен",
          "invoice_expired": "Срок создания страницы истёк", "invoice_failed": "Не удалось подключить оплату",
          "invoice_uncertain": "Страница оплаты пока недоступна", "creating_invoice": "Создаём страницу заказа", "partially_completed": "Частично выполнен", "test_paid": "Тестовая оплата подтверждена"}


def invoice_explanation(data):
    """Only stable public reasons; never show remote bodies, URLs or XML."""
    diagnostic = data.get("invoice_diagnostic") or data.get("payment_health") or {}
    diagnostic = diagnostic if isinstance(diagnostic, dict) else {}
    state = str(data.get("invoice_recovery_state") or "")
    code = str(diagnostic.get("code") or "").lower()
    status = diagnostic.get("http_status")
    if state == "expired" or "expired" in code:
        return "Срок создания страницы истёк. Покупка не отправлялась. Обратись в поддержку: нужно проверить сохранённый заказ."
    # Reuse only the fixed, source-controlled diagnostic catalogue. Never echo
    # a remote message or the arbitrary buyer_message stored beside the code.
    from .web_payments import DIAGNOSTICS
    if code.upper() in DIAGNOSTICS:
        return DIAGNOSTICS[code.upper()][1]
    if status in (401, 403) or code in ("bridge_auth", "bridge_unauthorized", "signature_invalid", "authentication_failed"):
        return "Сайт не подтвердил доступ к оформлению. Владельцу нужно проверить подключение магазина."
    if status == 404 or code in ("bridge_not_found", "bridge_route_missing", "route_not_found", "worker_route_missing"):
        return "Страница магазина ещё не подключена на сайте. Владельцу нужно обновить модуль оплаты."
    if status in (400, 422):
        return "Сайт не принял данные счёта. Владельцу нужно проверить версию и настройки модуля оплаты; сохранённый заказ не потерян."
    if state == "configuration_required" or any(word in code for word in ("config", "disabled", "mode", "mismatch")):
        return "Подключение требует проверки настроек владельцем. Не создавай повторную покупку: этот заказ сохранён."
    if status == 429 or "rate" in code:
        return "Сайт попросил сделать паузу. Повторная проверка будет выполнена с задержкой."
    if status in (500, 502, 503, 504) or any(word in code for word in ("timeout", "network", "unavailable")):
        return "Сайт оформления временно не отвечает. Бот сохраняет заказ и повторяет подключение без новой покупки."
    return "Сайт пока не подтвердил создание страницы. Заказ сохранён; повторно собирать корзину не нужно."


def invoice_advice(diagnostic):
    from .web_payments import DIAGNOSTICS
    code = str(diagnostic.get("code") or "").upper() if isinstance(diagnostic, dict) else ""
    return DIAGNOSTICS[code][2] if code in DIAGNOSTICS else ""


def orders(data):
    rows = [[button("📦 " + str(item.get("id"))[:16] + " · " + STATUS.get(str(item.get("status")), "Проверяем статус"), "order", order_id=str(item["id"]))] for item in data.get("items", [])]
    rows += pagination("orders", data)
    rows += [[button("⌂ Главное меню", "home")]]
    return Screen("<b>📦 Мои заказы</b>\n\n" + ("Открой заказ, чтобы увидеть статус и выданный код." if data.get("items") else "Твоих заказов пока нет. Начни с каталога — найдём что-нибудь интересное."), "orders", rows)


def order(data):
    text = "<b>📦 Заказ " + safe(data.get("id"), 50) + "</b>\n\nСтатус: <b>" + safe(STATUS.get(str(data.get("status")), "Проверяем статус")) + "</b>\n"
    text += "Сумма: <b>" + rub(data.get("total_rub")) + "</b>\n"
    per_line_delivery = False
    for item in data.get("items", []):
        text += "\n\n<b>• " + safe(item.get("title"), 100) + "</b> × " + safe(item.get("quantity", 1), 30)
        if item.get("status"):
            text += "\n" + safe(STATUS.get(str(item["status"]), "Проверяем статус"), 60)
        codes = item.get("delivery") or []
        if codes:
            per_line_delivery = True
            text += "\n" + "\n\n".join("<code>" + safe(code, None) + "</code>" for code in codes)
        if codes or str(item.get("status")) in ("completed", "delivered", "fulfilled"):
            steps = item.get("activation") or []
            if steps:
                text += "\n\n<b>Как получить и активировать:</b>\n" + "\n".join(str(index) + ". " + safe(step, None) for index, step in enumerate(steps, 1))
    delivered = data.get("delivery") or []
    invoice_pending = str(data.get("status")) in ("invoice_creating", "invoice_review", "invoice_expired", "invoice_failed")
    if invoice_pending:
        text += "\n\n<b>Оплата ещё не запрошена.</b> Покупка у поставщика не отправлялась.\n" + invoice_explanation(data)
        wait = data.get("invoice_retry_in_seconds")
        if isinstance(wait, int) and not isinstance(wait, bool) and wait > 0 and data.get("invoice_recovery_state") not in ("expired", "configuration_required"):
            text += "\nСледующая проверка — примерно через " + safe(min(wait, 86400), 10) + " сек."
    elif delivered and not per_line_delivery:
        text += "\n\n<b>🎉 Твой товар</b>\n" + "\n\n".join("<code>" + safe(code, None) + "</code>" for code in delivered)
        text += "\n\nСохрани код и проверь регион активации в карточке товара. Спасибо за покупку! 💜"
    elif any(str(item.get("status")) in ("completed", "delivered", "fulfilled") for item in data.get("items", [])):
        text += "\n\nВыполнение отмеченных товаров подтверждено. Проверь аккаунт получателя по инструкции."
    elif not delivered and not per_line_delivery:
        text += "\n\nОбнови статус позже. При задержке нажми «Помощь с заказом» — мы проверим его."
    rows = [[button("↻ Обновить статус", "order", order_id=str(data["id"]))], [button("💬 Помощь с заказом", "help", order_id=str(data["id"]))], [button("📦 Все заказы", "orders"), button("⌂ Меню", "home")]]
    if data.get("status") == "invoice_review" and data.get("invoice_retry_allowed") is True:
        rows.insert(0, [button("↻ Повторить подключение", "retry_invoice", order_id=str(data["id"]))])
    if data.get("external_payment") and data.get("payment_url") and str(data.get("status")) in ("awaiting_payment", "pending_payment", "created"):
        test = data.get("payment_mode") == "test"
        label = "🧪 Открыть тестовую оплату" if test else "Открыть страницу заказа"
        rows.insert(0, [button(label, "open_checkout", url=data["payment_url"], order_id=str(data["id"]))])
        text += "\n\n🧪 Тестовая оплата: реальная выдача товара отключена." if test else "\n\nЛичная страница оформления доступна по кнопке. Вход в аккаунт Aisklad не нужен."
    if data.get("status") == "test_paid":
        text += "\n\n🧪 Проверка оплаты завершена. Реальная покупка у поставщика не выполнялась."
    return Screen(text, "orders", rows)


def gallery_examples():
    """Real screen copy for the root's offline HTML preview; no synthetic live claims."""
    example = {"id": "preview-steam", "title": "Steam · Пополнение баланса", "price_rub": "102.40", "min_quantity": 100, "max_quantity":50000,
               "unit_currency":"RUB","unit_price_rub":"1.02","min_total_rub":"102.40","fixed_charge_rub":"0.40","available": True,
               "region": "Регион аккаунта проверяется перед покупкой", "description": "Укажи логин Steam и сумму пополнения. Пароль и Steam Guard не нужны.", "kind": "topup"}
    return {"home": home(), "assistant": assistant(), "about": about(), "catalog": catalog({"items": [{"id": "steam", "title": "🎮 Steam"}, {"id": "telegram", "title": "⭐ Telegram"}], "total": 2}),
            "search": Screen("<b>🔎 Найдём то самое</b>\n\nОтправь название игры или сервиса. Например: Steam, Telegram, Minecraft.", "search", nav()),
            "favorites": products({"items": [example], "total": 1}, favorite=True), "product": product(example),
            "cart": cart({"items": [{"id": "preview", "title": "Steam · Пополнение баланса", "quantity": 100, "total_rub": "102.40"}], "total_rub": "102.40"}),
            "checkout": Screen("<b>💳 Всё готово к оформлению</b>\n\nПроверь товары, количество и данные получателя.\n\nИтого: <b>102,40 ₽</b>\n\nПлатёжный провайдер ещё не подключён. Деньги не списываются.", "checkout", nav()),
            "orders": orders({"items": [], "total": 0}), "profile": Screen("<b>👤 Твой Aisklad</b>\n\nЗаказы, избранное и помощь — всегда под рукой.", "profile", nav()),
            "help": Screen("<b>💬 Мы рядом</b>\n\nНапиши, что случилось. Не отправляй пароли, коды входа или данные карты.\n\nКоманда <b>!помощь</b> доступна в любой момент.", "help", nav())}
