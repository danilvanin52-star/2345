# Hosting import fix: 0.12.1-bothost.1

The previous launcher waited silently when all three migration files existed
but their contents could not be parsed. A Base64-encoded upload caused this
for both JSON configuration and the binary SQLite database.

The importer now accepts native content or a single strict Base64 wrapper,
including mixed uploads, line-wrapped Base64 and UTF-8 BOM JSON. It checks
the Telegram owner, required configuration, database integrity and schema
before installing any working state. It never replaces a previously imported
working database with staging files. The original uploads remain untouched.

Incomplete or invalid uploads report the affected filename and a fixed,
non-private explanation. Repeated identical warnings are suppressed during
the wait. No uploaded contents, credentials or customer details enter logs.

Only the hosting importer changed. The supplier order client and sales logic
are unchanged. Startup still performs read-only checks and requires the
owner's /sr_resume to enable sales.

For the three-file GitHub layout, replace Bothost_FunPay_0.12.1.zip in the
repository root and perform a full rebuild from Git on Bothost. Keep the
existing files in /app/data; no re-upload or database deletion is needed.
