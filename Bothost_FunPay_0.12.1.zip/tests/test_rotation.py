"""Paid order protection and durable reuse of twenty FunPay slots, offline only."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace as N
from unittest.mock import Mock, patch

import steamru_stars as bot
import steamru_stars_catalog as catalog
import steamru_stars_rotation as rotation
from steamru_stars_engine import Store, D
from test_cardinal_compatibility import source_interfaces, definitions, SOURCE, full_order
from test_catalog_pricing import game


def record(number):
    value=game();value.update(app_id=1000+number,option_id=2000+number,name=f'Game {number}')
    return value


class RotationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.types=source_interfaces()
        definitions(SOURCE/'FunPayAPI/types.py',['LotFields'],cls.types.__dict__)

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.old=bot.CFG,bot.STORE,bot.CFG_PATH,bot.C
        bot.CFG=deepcopy(bot.DEFAULT)
        bot.CFG.update(mode='live',allowed_subcategory_ids=[1008],min_margin_pct='.35',min_profit_rub='0')
        bot.CFG['rotation']['enabled']=True
        bot.CFG_PATH=Path(self.temp.name)/'cfg.json'
        bot.STORE=Store(Path(self.temp.name)/'state.db');bot.STORE.set_meta('paused','no');bot.STOP.clear()
        self.c=N(account=Mock(),telegram=None,plugins={bot.UUID:N(enabled=True)})
        self.c.account.id=7;bot.C=self.c
        self.c.account.get_sales.return_value=(None,[],'ru',{})
        self.offers={};self.saves=[]
        for i in range(20):
            rule=catalog.key_rule(record(i));name=f'key_{i}'
            rule['description_revision']=catalog.COPY_REVISION
            bot.CFG['lot_rules'][name]=rule;bot.CFG['managed_lots'][str(100+i)]=name
            self.offers[100+i]=self.types.LotFields(100+i,catalog.apply_rule({},rule,'300'),
                subcategory=N(id=1008),currency=self.types.Currency.RUB)
            self.offers[100+i].active=True
        self.c.account.get_lot_fields=lambda offer,**kw:deepcopy(self.offers[offer])
        self.c.account.save_lot=self.save
        self.api=Mock();self.api.balance.return_value=D('5.96')
        self.api.key_product.side_effect=lambda app,option,region:record(app-1000)
        self.pool=[(f'key_{i}',catalog.key_rule(record(i))) for i in range(20,25)]
        self.live=patch.object(bot,'live_allowed',return_value=True);self.live.start()
        self.client=patch.object(bot,'client',return_value=self.api);self.client.start()
        self.pool_patch=patch.object(catalog,'catalogue',return_value=self.pool);self.catalog_mock=self.pool_patch.start()
        self.band=patch.object(bot,'price_band',return_value=(D('300'),D('300.10')));self.band.start()
        self.now=100000.0
        self.clock=patch.object(rotation.time,'time',side_effect=lambda:self.now);self.clock.start()

    def tearDown(self):
        self.clock.stop();self.band.stop();self.pool_patch.stop();self.client.stop();self.live.stop()
        bot.CFG,bot.STORE,bot.CFG_PATH,bot.C=self.old;bot.STOP.clear();self.temp.cleanup()

    def save(self,fields):
        self.saves.append((fields.lot_id,fields.title_ru,fields.active))
        self.offers[fields.lot_id]=deepcopy(fields)

    def start(self):
        bot.STORE.set_meta('next_rotation','0');rotation.run(bot,self.c)

    def paid(self,i):
        rule=bot.CFG['lot_rules'][f'key_{i}']
        full=full_order(self.types,title='',subcategory_id=1008,amount=1)
        full.fields={key:self.types.LotField(key,value) for key,value in rule['match_fields'].items()}
        self.c.account.get_sales.return_value=(None,[N(id=full.id)],'ru',{})
        self.c.account.get_order.return_value=full
        return full

    def test_first_rotation_is_five_hours_later_without_purchase(self):
        rotation.run(bot,self.c)
        self.assertEqual(float(bot.STORE.get_meta('next_rotation')),self.now+18000)
        self.catalog_mock.assert_not_called();self.assertEqual(self.saves,[])
        self.api.create_game_key.assert_not_called()

    def test_safe_defaults_pause_and_dry_run_prevent_rotation(self):
        self.assertFalse(bot.DEFAULT['rotation']['enabled'])
        for paused,mode in [('yes','live'),('no','dry_run')]:
            bot.CFG['mode']=mode;bot.STORE.set_meta('paused',paused)
            self.start();self.assertEqual(rotation.jobs(bot),[])
        self.catalog_mock.assert_not_called()

    def test_selection_limits_three_replacements_and_preserves_twenty_slots(self):
        self.start()
        self.assertEqual(len(rotation.jobs(bot)),3)
        self.assertEqual(len(bot.CFG['managed_lots']),20)
        self.assertEqual(self.saves,[])
        self.api.create_game_key.assert_not_called()

    def test_pinned_manual_priced_and_disabled_slots_are_not_rotated(self):
        bot.CFG['lot_controls']={'100':{'rule_name':'key_0','pinned':True},
            '101':{'rule_name':'key_1','manual_price':{'value':'1','expires_at':self.now+1000}},
            '102':{'rule_name':'key_2','owner_disabled':True}}
        self.start()
        self.assertFalse({100,101,102}.intersection(x['offer'] for x in rotation.jobs(bot)))

    def test_paid_funpay_order_blocks_rotation_even_before_local_capture(self):
        self.paid(0);self.start()
        self.assertNotIn('key_0',[x['old_name'] for x in rotation.jobs(bot)])

    def test_local_uncertain_purchase_also_blocks_replacement(self):
        bot.STORE.insert_order('BUSY123',12,'users-7-12','buyer','rule:key_0',1,1,'300',captured_mode='live',kind='game_key')
        bot.STORE.set('BUSY123',status='uncertain');self.start()
        self.assertNotIn('key_0',[x['old_name'] for x in rotation.jobs(bot)])

    def test_pagination_refuses_incomplete_paid_order_check(self):
        self.c.account.get_sales.return_value=('MORE',[],'ru',{})
        with self.assertRaises(rotation.RotationDeferred):self.start()
        self.assertEqual(self.saves,[])

    def test_slot_is_disabled_drained_then_reused_with_historic_binding(self):
        self.start();rotation.run(bot,self.c)
        self.assertEqual(len(self.saves),3)
        self.assertTrue(all(not active for _,_,active in self.saves))
        self.now+=89;rotation.run(bot,self.c);self.assertEqual(len(self.saves),3)
        self.now+=2;rotation.run(bot,self.c)
        self.assertEqual(len(self.saves),6)
        self.assertEqual(rotation.jobs(bot),[])
        self.assertEqual(len(bot.CFG['managed_lots']),20)
        self.assertEqual(bot.CFG['managed_lots']['100'],'key_20')
        self.assertTrue(bot.CFG['lot_rules']['key_0']['history'])
        self.assertEqual(bot.CFG['lot_rules']['key_0']['app_id'],1000)
        self.assertFalse(self.offers[100].active)
        self.assertIn('Автоматическая выдача',self.offers[100].description_ru)
        self.assertEqual(float(bot.STORE.get_meta('next_rotation')),self.now+18000)
        self.api.create_game_key.assert_not_called()

    def test_paid_order_arriving_during_drain_leaves_old_game_untouched(self):
        self.start();rotation.run(bot,self.c);self.paid(0);self.now+=91
        rotation.run(bot,self.c)
        self.assertEqual(bot.CFG['managed_lots']['100'],'key_0')
        self.assertEqual(self.offers[100].title_ru,catalog.display_title(bot.CFG['lot_rules']['key_0']))
        self.assertTrue(catalog.field_matches(self.offers[100].title_ru,'summary',bot.CFG['lot_rules']['key_0']))
        self.assertIn(100,rotation.busy_offers(bot))

    def test_unknown_save_response_reconciles_without_second_edit(self):
        self.start();rotation.run(bot,self.c);self.now+=91
        normal=self.save
        def lost(fields):
            normal(fields);raise TimeoutError('Fictitious lost response')
        self.c.account.save_lot=lost
        with self.assertRaises(TimeoutError):rotation.run(bot,self.c)
        self.assertEqual(rotation.jobs(bot)[0]['stage'],'editing')
        self.c.account.save_lot=normal;rotation.run(bot,self.c)
        self.assertEqual(len([x for x in self.saves if x[0]==100]),2)
        self.assertEqual(bot.CFG['managed_lots']['100'],'key_20')
        self.api.create_game_key.assert_not_called()

    def test_new_price_above_five_dollars_prevents_edit(self):
        self.start();rotation.run(bot,self.c);self.now+=91
        value=record(20);value['price_usd']='5.01';self.api.key_product.side_effect=None
        self.api.key_product.return_value=value
        with self.assertRaises(rotation.RotationDeferred):rotation.run(bot,self.c)
        self.assertEqual(len(self.saves),3)
        self.assertEqual(bot.CFG['managed_lots']['100'],'key_0')

    def test_completion_has_standalone_code_and_activation_steps(self):
        message=bot.completed_message({'id':'KEY123','kind':'game_key','description':'rule:key_0','voucher':'AAAAA-BBBBB-CCCCC'})
        self.assertIn('\n\nAAAAA-BBBBB-CCCCC\n\n',message)
        self.assertIn('Game 0',message);self.assertIn('После успешной активации',message)


class CopyTests(unittest.TestCase):
    def test_region_restrictions_survive_compact_copy(self):
        value=game();value.update(countries=['KZ','AM'],excluded_countries=['RU'])
        copy=catalog.buyer_copy(catalog.key_rule(value))
        for text in ('Казахстан','Армения','Не активируется: Россия','Автоматическая выдача'):
            self.assertIn(text,copy['ru'])
        self.assertIn('excluded countries: RU',copy['en'])
        self.assertLess(len(copy['ru']),650)

    def test_copy_edit_preserves_offer_price_stock_and_activation(self):
        fields=N(price=300.25,amount=1,active=True,auto_delivery=False,title_ru='Original title',fields={'offer_id':'123'})
        before=(fields.price,fields.amount,fields.active,fields.auto_delivery,deepcopy(fields.fields))
        rule=catalog.key_rule(game());catalog.update_copy(fields,rule)
        self.assertEqual(before,(fields.price,fields.amount,fields.active,fields.auto_delivery,fields.fields))
        self.assertEqual(fields.title_ru,catalog.display_title(rule))

    def test_platform_capacity_page_is_recognized(self):
        with self.assertRaises(catalog.CategoryFull):
            catalog.form_fields('<p class="lead">Много предложений в разделе «Ключи»</p>',1008)
