"""Independent, durable shop state. Never reads or migrates Cardinal's orders DB."""
from __future__ import annotations
import json
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path


def dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


class ShopStore:
    def __init__(self, path, clock=time.time):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.clock = clock
        self._lock = threading.RLock()
        with self.connection() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions(user_id INTEGER PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS catalog(id TEXT PRIMARY KEY,group_id TEXT NOT NULL,kind TEXT NOT NULL,value TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS catalog_group ON catalog(group_id);
            CREATE TABLE IF NOT EXISTS cart(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,value TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS cart_owner ON cart(user_id);
            CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL,product_id TEXT NOT NULL,PRIMARY KEY(user_id,product_id));
            CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,status TEXT NOT NULL,created_at REAL NOT NULL,value TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS orders_owner ON orders(user_id,created_at);
            CREATE TABLE IF NOT EXISTS order_lines(id TEXT PRIMARY KEY,order_id TEXT NOT NULL,status TEXT NOT NULL,external_id TEXT NOT NULL UNIQUE,supplier_uuid TEXT,value TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS order_lines_order ON order_lines(order_id);
            CREATE UNIQUE INDEX IF NOT EXISTS order_lines_supplier_uuid ON order_lines(supplier_uuid) WHERE supplier_uuid IS NOT NULL;
            CREATE TABLE IF NOT EXISTS payment_events(provider TEXT NOT NULL,event_id TEXT NOT NULL,order_id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(provider,event_id));
            CREATE TABLE IF NOT EXISTS payment_authorizations(order_id TEXT PRIMARY KEY,provider TEXT NOT NULL,charge_id TEXT NOT NULL,value TEXT NOT NULL,UNIQUE(provider,charge_id));
            CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY AUTOINCREMENT,dedupe TEXT NOT NULL UNIQUE,user_id INTEGER NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,created_at REAL NOT NULL,ack_at REAL);
            CREATE TABLE IF NOT EXISTS support(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,order_id TEXT,message TEXT NOT NULL,created_at REAL NOT NULL);
            """)
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    @contextmanager
    def connection(self, immediate=False):
        with self._lock:
            db = sqlite3.connect(str(self.path), timeout=30)
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("PRAGMA synchronous=FULL")
            db.execute("PRAGMA foreign_keys=ON")
            try:
                if immediate:
                    db.execute("BEGIN IMMEDIATE")
                yield db
                db.commit()
            except Exception:
                db.rollback()
                raise
            finally:
                db.close()

    def get_setting(self, key, default=None):
        with self.connection() as db:
            row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set_setting(self, key, value):
        with self.connection(immediate=True) as db:
            db.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, dumps(value)))

    def get_session(self, user_id):
        with self.connection() as db:
            row = db.execute("SELECT value FROM sessions WHERE user_id=?", (int(user_id),)).fetchone()
        return json.loads(row[0]) if row else {}

    def set_session(self, user_id, value):
        if not isinstance(value, dict):
            raise ValueError("Session must be an object")
        with self.connection(immediate=True) as db:
            db.execute("INSERT INTO sessions VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET value=excluded.value", (int(user_id), dumps(value)))

    def enqueue(self, user_id, kind, payload, dedupe):
        if not user_id:
            return
        with self.connection(immediate=True) as db:
            db.execute("INSERT OR IGNORE INTO outbox(dedupe,user_id,kind,payload,created_at) VALUES(?,?,?,?,?)", (str(dedupe), int(user_id), kind, dumps(payload), self.clock()))

    def pending_notifications(self, limit=50):
        with self.connection() as db:
            rows = db.execute("SELECT * FROM outbox WHERE ack_at IS NULL ORDER BY id LIMIT ?", (min(100, max(1, int(limit))),)).fetchall()
        return [{"id": r["id"], "user_id": r["user_id"], "kind": r["kind"], "payload": json.loads(r["payload"])} for r in rows]

    def ack_notification(self, notification_id):
        with self.connection(immediate=True) as db:
            db.execute("UPDATE outbox SET ack_at=? WHERE id=? AND ack_at IS NULL", (self.clock(), int(notification_id)))

    def order_data(self, order_id, user_id=None):
        with self.connection() as db:
            row = db.execute("SELECT * FROM orders WHERE id=?", (str(order_id),)).fetchone()
            if not row or (user_id is not None and row["user_id"] != int(user_id)):
                return None
            value = json.loads(row["value"])
            value.update(id=row["id"], user_id=row["user_id"], status=row["status"], created_at=row["created_at"])
            lines = db.execute("SELECT * FROM order_lines WHERE order_id=? ORDER BY id", (row["id"],)).fetchall()
        value["items"] = []
        for line in lines:
            item = json.loads(line["value"])
            item.update(id=line["id"], status=line["status"], external_id=line["external_id"], supplier_uuid=line["supplier_uuid"])
            value["items"].append(item)
        return value

    def new_id(self, prefix=""):
        return prefix + uuid.uuid4().hex
