# noplug — customer texts for Cardinal's native confirmation and review hooks.
import time
from datetime import datetime,timezone,timedelta

FOOTER='💬 Нужна помощь? Напиши !помощь\n📦 Проверить заказ: !статус'
REVIEW_TEXTS = {
    5: '💜 Спасибо за покупку и отличный отзыв! Рад, что всё понравилось. Буду рад видеть тебя снова ✨',
    4: '💜 Спасибо за покупку и отзыв! Если чего-то не хватило, напиши в чат заказа — постараюсь улучшить сервис.',
    3: 'Спасибо за обратную связь! Напиши в чат заказа, что можно улучшить — разберусь и помогу.',
    2: 'Спасибо, что сообщил о проблеме. Напиши подробности в чат заказа — я проверю выдачу и помогу разобраться.',
    1: 'Мне жаль, что возникла проблема. Напиши в чат заказа, что произошло — я проверю заказ и помогу разобраться.'
}
CONFIRMED_TEXT = '💜 Спасибо за подтверждение!\n✨ Приятной игры и до новых покупок!\n\nЕсли нужна помощь с этим заказом — напиши !помощь.'


def queue_message(bot,row):
    with bot.STORE.conn() as db:
        ids=[r['id'] for r in db.execute("SELECT id FROM orders WHERE status IN ('ready','preparing') ORDER BY created_at,rowid")]
    position=ids.index(row['id'])+1 if row['id'] in ids else None
    return (f"╭─ ⏳ ЗАКАЗ #{row['id']}\n"
            f"│ Товар: {bot.order_label(row)}\n"
            +(f"│ Получатель: {row['username']}\n" if row.get('username') and row.get('kind') not in ('service_topup',) else '')
            +(f"│ Позиция в очереди: {position}\n" if position else '')
            +'╰─ Данные приняты, проверяем и начинаем выдачу.\n\n'+FOOTER)


def completion(bot,row):
    kind=row.get('kind','stars');rule=bot.rule_for_title(row['description'])
    when=datetime.now(timezone(timedelta(hours=3))).strftime('%d.%m.%Y · %H:%M МСК')
    if row.get('changed_at'):
        try:when=datetime.strptime(row['changed_at'],'%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=3))).strftime('%d.%m.%Y · %H:%M МСК')
        except (ValueError,TypeError):pass
    text=f"╭─ 🎉 ЗАКАЗ #{row['id']} ВЫПОЛНЕН\n│ {bot.order_label(row)}\n╰─ {when}\n\n"
    if kind in ('game_key','service_code'):
        text+='🔑 Твой '+('ключ Steam' if kind=='game_key' else 'код')+':\n\n'+row['voucher']+'\n\n'
        text+=('🕹 Steam → «Игры» → «Активировать в Steam».' if kind=='game_key' else '📌 Активация: '+rule['activation'])
        text+='\n🌍 Регион: '+rule.get('region_label',rule.get('region',''))
        text+='\n\n✅ После успешной активации подтверди выполнение заказа.'
    elif kind in bot.STEAM_KINDS:
        text+='💰 Средства отправлены на кошелёк Steam.\n👤 Логин: '+str(row['username'])+'\n✅ Проверь баланс и подтверди выполнение заказа.'
    elif kind=='service_topup':
        text+='💎 Пополнение выполнено.\n✅ Проверь баланс в игре и подтверди выполнение заказа.'
    else:
        text+='⭐ Звёзды отправлены получателю @'+str(row['username']).lstrip('@')+'.\n✅ Проверь зачисление и подтверди выполнение заказа.'
    text+='\n🔗 https://funpay.com/orders/'+row['id']+'/'
    return text+'\n\n💜 Спасибо за покупку! Если всё понравилось, буду рад твоему отзыву ⭐\n\n'+FOOTER


def handle_command(bot,c,message,text):
    command=text.strip().lower()
    if command not in ('!помощь','!help','!статус','!status'):return False
    buyer=str(getattr(message,'author_id',''))
    shadow={'buyer_id':buyer,'chat_id':f'users-{c.account.id}-{buyer}'}
    if not buyer.isdigit() or not bot.matching_message_chat(c,message,shadow):return True
    rows=[r for r in bot.STORE.rows(limit=10000) if r['buyer_id']==buyer and bot.matching_message_chat(c,message,r)]
    latest=rows[0] if rows else None
    reply_row=latest or {'id':'HELP_'+buyer,'chat_id':message.chat_id,'buyer_name':''}
    if command in ('!статус','!status'):
        labels={'awaiting_username':'ждём данные получателя','ready':'в очереди','preparing':'проверяем данные',
                'submitting':'отправляем заявку','supplier_pending':'поставщик выполняет заказ','completed':'выдача выполнена',
                'needs_review':'продавец проверяет ситуацию','uncertain':'проверяем результат у поставщика',
                'cancelled':'заказ отменён','refunded':'поставщик вернул заказ'}
        content=('📦 Твои заказы\n'+'\n'.join(f"#{r['id']} — {labels.get(r['status'],'проверяем состояние')}" for r in rows[:5])) if rows else '📦 Оплаченных заказов этого бота в чате пока нет.'
        bot.buyer_message(c,reply_row,content+'\n\n💬 Для вызова продавца: !помощь')
        return True
    key='help_cooldown:'+buyer+':'+str(message.chat_id)
    previous=float(bot.STORE.get_meta(key,'0'));now=time.time()
    if now-previous<300:
        bot.buyer_message(c,reply_row,'🆘 Продавец уже уведомлён. Напиши подробности проблемы в этом чате — повторять команду не нужно.')
        return True
    bot.STORE.set_meta(key,str(now))
    incident=latest['id'] if latest else 'HELP_'+buyer
    notice='🆘 ПОКУПАТЕЛЬ ПРОСИТ ПОМОЩЬ\n'+('Заказ #'+latest['id']+' · '+bot.order_label(latest) if latest else 'Обращение из чата покупателя')
    notice+='\nОткрой чат: https://funpay.com/chat/?node=users-'+str(c.account.id)+'-'+buyer
    bot.notifications.notify(bot,c,notice,urgent=True,incident=incident,dedup_key='help:'+key+':'+str(int(now//300)))
    bot.buyer_message(c,reply_row,'╭─ 🆘 ПОМОЩЬ ВЫЗВАНА\n│ Продавцу отправлено срочное уведомление.\n╰─ Опиши проблему в этом чате — он ответит здесь.\n\n📦 Проверить заказ: !статус')
    return True


def configure(cfg):
    if not cfg.has_section('ReviewReply'):
        cfg.add_section('ReviewReply')
    for stars, text in REVIEW_TEXTS.items():
        cfg['ReviewReply'][f'star{stars}Reply'] = '1'
        cfg['ReviewReply'][f'star{stars}ReplyText'] = text
    if not cfg.has_section('OrderConfirm'):
        cfg.add_section('OrderConfirm')
    cfg['OrderConfirm']['sendReply'] = '1'
    cfg['OrderConfirm']['watermark'] = '0'
    cfg['OrderConfirm']['replyText'] = CONFIRMED_TEXT
