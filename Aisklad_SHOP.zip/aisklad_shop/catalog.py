"""Complete reseller catalogue index with atomic publication and lazy game cards."""
from __future__ import annotations
import hashlib
import json
import threading
import time
from decimal import Decimal, InvalidOperation
from urllib.parse import urlsplit
from .store import dumps
from .merchandising import qualified_title


def product_id(*parts):
    return "p" + hashlib.sha256(dumps(list(parts)).encode()).hexdigest()[:24]


def safe_image(value):
    if not isinstance(value, str) or len(value) > 2048:
        return None
    try:
        url = urlsplit(value)
        host = (url.hostname or "").lower()
        if url.scheme != "https" or url.username or url.password or url.port not in (None, 443):
            return None
        allowed = ("steam.ru", "steamstatic.com", "steampowered.com", "akamaihd.net")
        if not any(host == h or host.endswith("." + h) for h in allowed):
            return None
        if url.query or url.fragment:
            return None  # Never forward signed/token-bearing URLs to Telegram.
        return value
    except ValueError:
        return None


def decimal_string(value):
    try:
        amount = Decimal(str(value))
        if amount.is_finite() and amount > 0:
            return str(amount)
    except (ValueError, InvalidOperation):
        pass
    return None


def fields_for(raw, requires_account):
    result = []
    for value in raw or []:
        if not isinstance(value, dict):
            raise ValueError("Malformed product field")
        key = str(value.get("key") or value.get("name") or "")
        if not key or len(key) > 100 or key in {f["name"] for f in result}:
            raise ValueError("Invalid or duplicate product field")
        result.append({"name": key, "label": str(value.get("label") or value.get("name") or key),
                       "type": str(value.get("type", "text")), "required": value.get("required", True) is not False,
                       "options": value.get("options") or [], "min": value.get("min_length", 1),
                       "max": min(255, int(value.get("max_length") or 255)), "pattern": value.get("pattern"),
                       "is_account": value.get("is_account") is True})
    if requires_account and not any(f["is_account"] for f in result):
        result.insert(0, {"name": "account", "label": "Логин / ID получателя", "type": "text", "required": True,
                          "options": [], "min": 1, "max": 255, "pattern": None, "is_account": True})
    return result


class Catalog:
    def __init__(self, store, supplier, clock=time.time):
        self.store, self.supplier, self.clock = store, supplier, clock
        self.sync_lock = threading.Lock()
        self._refresh_guard = threading.Lock()
        self._refresh_locks = {}

    def _card_lock(self, identifier):
        with self._refresh_guard:
            return self._refresh_locks.setdefault(str(identifier), threading.RLock())

    def status(self):
        return {"active": self.store.get_setting("catalog:active", {}), "last_attempt": self.store.get_setting("catalog:attempt", {})}

    def sync(self):
        """Failure leaves the previous complete index usable; never publishes half a list."""
        if not self.sync_lock.acquire(blocking=False):
            return {"state": "busy"}
        started = self.clock()
        rows = []
        attempt = {"state": "syncing", "started_at": started, "indexed": 0}
        self.store.set_setting("catalog:attempt", attempt)
        try:
            brand_map = {}
            for raw in self.supplier.brands():
                identifier = "brand:" + str(raw["id"])
                brand_map[str(raw["id"])] = raw
                rows.append({"id": identifier, "group_id": "root", "kind": "brand", "title": str(raw["name"]),
                             "image_url": safe_image(raw.get("icon")), "category": raw.get("category"), "observed_at": started})
            service_count = 0
            for raw in self.supplier.services():
                slug = str(raw["id"])
                brand_id = str(raw.get("brand") or slug)
                if brand_id not in brand_map:
                    brand_map[brand_id] = {"name": str(raw.get("name") or slug)}
                    rows.append({"id": "brand:" + brand_id, "group_id": "root", "kind": "brand", "title": brand_map[brand_id]["name"], "image_url": None, "observed_at": started})
                image = safe_image(raw.get("image") or raw.get("icon") or brand_map[brand_id].get("icon"))
                rows.append({"id": "service:" + slug, "group_id": "brand:" + brand_id, "kind": "service", "title": str(raw["name"]), "image_url": image, "service": slug, "observed_at": started})
                data = self.supplier.products(slug)
                rows.extend(self.normalize_products(data, image, started))
                service_count += 1
                if service_count % 10 == 0:
                    attempt.update(indexed=len(rows), stage="services")
                    self.store.set_setting("catalog:attempt", attempt)
            rows.extend([
                {"id": "keys", "group_id": "root", "kind": "service", "title": "🎮 Ключи игр и дополнений", "image_url": None, "observed_at": started},
                {"id": "gifts", "group_id": "root", "kind": "service", "title": "🎁 Игры Steam в подарок", "image_url": None, "observed_at": started},
            ])
            for endpoint, iterator, kind in (("keys", self.supplier.keys(), "key_group"), ("gifts", self.supplier.gifts(), "gift_group")):
                for raw in iterator:
                    app = int(raw["app_id"])
                    rows.append({"id": product_id(kind, app), "group_id": endpoint, "kind": kind, "app_id": app,
                                 "title": str(raw["name"]), "image_url": safe_image(raw.get("image")), "observed_at": started,
                                 "price_usd": decimal_string(raw.get("price_usd")), "has_variants": True, "available": False,
                                 "description": "Выберите издание и регион — цена и наличие проверяются при открытии."})
            ids = [r["id"] for r in rows]
            if len(ids) != len(set(ids)):
                raise ValueError("Duplicate catalogue identity")
            generation = hashlib.sha256((str(started) + str(len(rows))).encode()).hexdigest()[:20]
            active = {"state": "complete", "generation": generation, "synced_at": self.clock(), "indexed": len(rows), "services": service_count,
                      "details": "Индекс полный; варианты ключей, издания и регионы подарков загружаются при открытии карточки."}
            with self.store.connection(immediate=True) as db:
                # Keep lazy variants for games which remain in the new complete
                # index: carts/paid lines reference these stable IDs. Every sale
                # still revalidates the card and availability at the supplier.
                parents = set(ids)
                hydrated = [json.loads(r[0]) for r in db.execute("SELECT value FROM catalog WHERE kind IN ('key','gift')").fetchall()]
                hydrated = [r for r in hydrated if r["group_id"] in parents]
                active["hydrated_variants"] = len(hydrated)
                db.execute("DELETE FROM catalog")
                db.executemany("INSERT INTO catalog VALUES(?,?,?,?)", [(r["id"], r["group_id"], r["kind"], dumps(r)) for r in rows + hydrated])
                db.execute("INSERT INTO settings VALUES('catalog:active',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (dumps(active),))
                db.execute("INSERT INTO settings VALUES('catalog:attempt',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (dumps(active),))
            return active
        except Exception as exc:
            failed = {"state": "partial_failed", "started_at": started, "finished_at": self.clock(), "indexed": len(rows), "error_type": type(exc).__name__,
                      "message": "Обновление не завершено; сохранён предыдущий полный каталог."}
            self.store.set_setting("catalog:attempt", failed)
            raise
        finally:
            self.sync_lock.release()

    def normalize_products(self, data, image=None, observed=None):
        result = []
        service = data["service"]
        kind = data["type"]
        for raw in data["products"]:
            supplier_id = int(raw["product_id"])
            fields = fields_for(raw.get("fields"), data.get("requires_account", kind == "topup"))
            if service == "steam":
                for field in fields:
                    if field["is_account"]:
                        field.update(pattern=r"^[A-Za-z0-9_]{3,32}$", label="Логин Steam (не никнейм)")
            elif service == "telegram-stars":
                for field in fields:
                    if field["is_account"]:
                        field.update(pattern=r"^@?[A-Za-z0-9_]{4,32}$", label="Telegram username получателя")
            minimum, maximum = int(raw.get("min_count", 1)), int(raw.get("max_count", 1))
            valid_schema = all(f["type"] in ("text", "select") and (f["type"] != "select" or f["options"]) for f in fields)
            price = decimal_string(raw.get("price_usd"))
            result.append({"id": product_id("service", service, supplier_id), "group_id": "service:" + service,
                           "kind": kind, "service": service, "supplier_product_id": supplier_id,
                           "title": qualified_title(data.get("service_name") or service.replace("-", " ").title(), raw["name"], service),
                           "service_title": str(data.get("service_name") or service.replace("-", " ").title()),
                           "supplier_title": str(raw["name"]),
                           "price_usd": price, "min_quantity": minimum, "max_quantity": maximum, "min_count": minimum, "max_count": maximum,
                           "fields": fields, "image_url": safe_image(raw.get("image")) or image, "observed_at": observed or self.clock(),
                           "available": bool(price and minimum >= 1 and maximum >= minimum and valid_schema and raw.get("available", True) is not False),
                           "description": str(raw.get("description") or ("Автоматическое пополнение по указанным данным." if kind == "topup" else "Цифровой код придёт в этот чат после успешной оплаты и выдачи.")),
                           "warning": "Проверьте регион и данные получателя до оплаты. Пароль и коды входа не нужны."})
        return result

    def all(self, group_id=None):
        with self.store.connection() as db:
            if group_id is None:
                rows = db.execute("SELECT value FROM catalog ORDER BY id").fetchall()
            else:
                rows = db.execute("SELECT value FROM catalog WHERE group_id=? ORDER BY id", (str(group_id),)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def get(self, identifier):
        with self.store.connection() as db:
            row = db.execute("SELECT value FROM catalog WHERE id=?", (str(identifier),)).fetchone()
        return json.loads(row[0]) if row else None

    def put(self, rows, require_parent=None):
        with self.store.connection(immediate=True) as db:
            if require_parent and not db.execute("SELECT 1 FROM catalog WHERE id=?", (require_parent,)).fetchone():
                return False
            for r in rows:
                db.execute("INSERT INTO catalog VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET group_id=excluded.group_id,kind=excluded.kind,value=excluded.value", (r["id"], r["group_id"], r["kind"], dumps(r)))
        return True

    def refresh(self, identifier):
        # Separate from sync: paid fulfilment keeps using the complete index.
        with self._card_lock(identifier):
            item = self.get(identifier)
            if item is None:
                raise KeyError(identifier)
            kind = item["kind"]
            if kind in ("topup", "code"):
                data = self.supplier.products(item["service"])
                rows = self.normalize_products(data, item.get("image_url"))
                if not self.put(rows, require_parent="service:" + item["service"]):
                    raise KeyError(identifier)
                fresh = next((r for r in rows if r["id"] == identifier), None)
                if fresh is None:
                    item["available"] = False
                    self.put([item])
                    raise KeyError(identifier)
                return fresh
            if kind in ("key", "key_group"):
                app = item["app_id"]
                card = self.supplier.key_card(app)
                if int(card.get("app_id", -1)) != app or not isinstance(card.get("variants"), list):
                    raise ValueError("Wrong key card")
                rows = []
                for raw in card["variants"]:
                    option = int(raw["option_id"])
                    content = raw.get("content_kind")
                    if content not in ("game", "edition", "dlc"):
                        continue  # Unknown content is shown only after schema support.
                    price = decimal_string(raw.get("price_usd"))
                    stock = max(0, int(raw.get("stock", 0)))
                    rows.append({"id": product_id("key", app, option), "group_id": product_id("key_group", app), "kind": "key", "app_id": app, "option_id": option,
                                 "title": qualified_title(card.get("name") or item.get("title"), raw["name"]), "price_usd": price, "image_url": safe_image(raw.get("image") or card.get("image")),
                                 "content_kind": content, "platform": raw.get("platform", "steam"), "region": raw.get("region"), "countries": raw.get("countries") or [],
                                 "excluded_countries": raw.get("excluded_countries") or [], "stock": stock,
                                 "min_quantity": int(raw.get("min_quantity", 1)), "max_quantity": min(1, stock, int(raw.get("max_quantity", stock))),
                                 "fields": [{"name": "country", "label": "Страна активации (двухбуквенный код, например RU)", "type": "text", "required": True, "min": 2, "max": 2, "pattern": "^[A-Za-z]{2}$", "options": []}],
                                 "warning": "⚠️ Это дополнение DLC. Для активации нужна основная игра." if content == "dlc" else "Проверьте платформу и регион активации перед оплатой.",
                                 "description": "Цифровой ключ. После выдачи сохранится в истории заказов.", "observed_at": self.clock(), "available": bool(price and stock > 0 and raw.get("platform", "steam") == "steam" and int(raw.get("min_quantity", 1)) <= 1 <= int(raw.get("max_quantity", stock)))})
            elif kind in ("gift", "gift_group"):
                app = item["app_id"]
                card = self.supplier.gift_card(app)
                if int(card.get("app_id", -1)) != app or not isinstance(card.get("editions"), list):
                    raise ValueError("Wrong gift card")
                rows = []
                for edition in card["editions"]:
                    for region in edition.get("regions") or []:
                        code = str(region["code"])
                        ed = str(edition["edition"])
                        price = decimal_string(region.get("price_usd"))
                        rows.append({"id": product_id("gift", app, ed, code), "group_id": product_id("gift_group", app), "kind": "gift", "app_id": app,
                                     "edition": ed, "region": code, "countries": region.get("countries") or [], "title": str(card["name"]) + " · " + str(edition.get("name", ed)) + " · " + code,
                                     "price_usd": price, "image_url": safe_image(card.get("image")), "min_quantity": 1, "max_quantity": 1, "available": bool(price), "observed_at": self.clock(),
                                     "fields": [{"name": "country", "label": "Страна Steam (двухбуквенный код)", "type": "text", "required": True, "min": 2, "max": 2, "pattern": "^[A-Za-z]{2}$", "options": []},
                                                {"name": "invite_url", "label": "Ссылка-приглашение Steam (https://s.team/p/...)", "type": "text", "required": True, "min": 15, "max": 255, "options": []}],
                                     "warning": "Страна аккаунта Steam должна подходить региону подарка. Нужна действующая одноразовая ссылка-приглашение.",
                                     "description": "Игра отправляется подарком Steam выбранного издания и региона. Пароль не нужен."})
            else:
                return item
            parent = product_id("key_group" if kind in ("key", "key_group") else "gift_group", item["app_id"])
            if not self.put(rows, require_parent=parent):
                raise KeyError(identifier)
            if kind.endswith("_group"):
                item["variants"] = rows
                item["observed_at"] = self.clock()
                return item
            fresh = next((r for r in rows if r["id"] == identifier), None)
            if fresh is None:
                item["available"] = False
                self.put([item])
                raise KeyError(identifier)
            return fresh
