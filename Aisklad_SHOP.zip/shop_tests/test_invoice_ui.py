"""Invoices are connection state, never a paid order or a supplier retry."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from aisklad_shop.bot import BuyerBot
from aisklad_shop import presentation as p
from shop_tests.test_bot import FakeBot, FakeService, message


URL = "https://shop.example/shop/checkout?order_id=O1#token=FAKE_CAPABILITY_12345678901234567890"


class InvoiceService(FakeService):
    def __init__(self):
        super().__init__()
        self.invoice = {"id": "O1", "user_id": 10, "status": "invoice_review", "total_rub": "120.00", "items": [{"title": "Steam RUB", "quantity": 156, "status": "unpaid"}],
                        "payment_mode": "live", "external_payment": True, "payment_url": None, "invoice_retry_allowed": True,
                        "invoice_recovery_state": "waiting", "invoice_retry_in_seconds": 15,
                        "invoice_diagnostic": {"code": "bridge_unavailable", "http_status": 503, "buyer_message": "<XML>SECRET</XML>", "private_url": URL}}
        self.retries, self.scheduled, self.diag_reads = 0, 0, 0
        class Payments:
            enabled, provider, mode = True, "aisklad_web", "live"
            def validate_checkout_url(self, value):
                return value == URL
        self.payments = Payments()

    def order(self, uid, oid):
        return copy.deepcopy(self.invoice)

    def retry_invoice(self, uid, oid):
        if uid != 10 or oid != "O1":
            raise ValueError("ownership")
        self.retries += 1
        if not self.scheduled:
            self.scheduled += 1
        return self.order(uid, oid)

    def payment_diagnostics(self):
        self.diag_reads += 1
        return {"configured": True, "mode": "live", "enabled": True, "supplier_live": False, "catalog_active": {"state": "complete"}, "count": 1,
                "payment_health": {"code": "bridge_unauthorized", "http_status": 403, "raw": "<XML>SECRET</XML>", "private_url": URL},
                "supplier_health": {"http_status": 200, "code": "steamru_ok", "method": "GET", "endpoint": "/balance", "reason": "<XML>SECRET</XML>", "action": URL}, "secret": "SECRET"}


class InvoiceUITests(unittest.TestCase):
    def setUp(self):
        self.service, self.bot = InvoiceService(), FakeBot()
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")

    def click(self, label, uid=10, payload=None):
        if payload is None:
            markup = self.bot.sent[-1][2]["reply_markup"]
            payload = next(button.callback_data for row in markup.keyboard for button in row if label in button.text)
        self.ui.handle_callback(NS(id="c", from_user=NS(id=uid), message=message("", uid), data=payload))
        return payload

    def test_real_invoice_statuses_and_unpaid_line_are_clear(self):
        for status, expected in (("invoice_creating", "Создаём страницу заказа"), ("invoice_review", "Страница оплаты пока недоступна")):
            data = dict(self.service.invoice, status=status)
            screen = p.order(data)
            self.assertIn(expected, screen.caption)
            self.assertIn("Не оплачен", screen.caption)
            self.assertIn("Оплата ещё не запрошена", screen.caption)
            self.assertNotIn("Проверяем статус", screen.caption)
            self.assertFalse(any(action.name == "open_checkout" for row in screen.rows for action in row))
            self.assertNotIn("SECRET", screen.caption)
            self.assertNotIn("<XML>", screen.caption)
        listing = p.orders({"items": [self.service.invoice]})
        self.assertIn("недоступна", listing.rows[0][0].label)

    def test_uncertain_checkout_shows_owned_saved_order_without_raw_error(self):
        error = RuntimeError("<XML>SECRET " + URL)
        error.code, error.order_id = "INVOICE_UNCERTAIN", "O1"
        self.ui._error(10, error)
        self.assertIn("Заказ O1", self.bot.sent[-1][1])
        self.assertNotIn("SECRET", self.bot.sent[-1][1])
        self.assertNotIn("FAKE_CAPABILITY", self.bot.sent[-1][1])
        self.assertIn("повторяет подключение", self.bot.sent[-1][1])
        self.assertEqual(self.service.retries, 0)
        self.ui._error(20, error)
        self.assertNotIn("Заказ O1", self.bot.sent[-1][1])

    def test_signed_retry_schedules_same_owned_invoice_no_purchase(self):
        self.ui._send_screen(10, p.order(self.service.invoice))
        payload = self.click("Повторить подключение")
        self.assertEqual(self.service.retries, 1)
        self.assertEqual(self.service.scheduled, 1)
        self.assertEqual(self.service.invoice["id"], "O1")
        self.assertEqual(self.service.checkedout, 0)
        self.click("", payload=payload)
        self.assertEqual(self.service.retries, 1)
        self.click("Повторить подключение")
        self.assertEqual(self.service.scheduled, 1)

    def test_retry_not_offered_for_paid_ready_creating_or_expired(self):
        for status in ("awaiting_payment", "invoice_creating", "test_paid", "completed", "invoice_expired"):
            screen = p.order(dict(self.service.invoice, status=status))
            self.assertFalse(any(action.name == "retry_invoice" for row in screen.rows for action in row))
        screen = p.order(dict(self.service.invoice, invoice_retry_allowed=False, invoice_recovery_state="configuration_required"))
        self.assertNotIn("повторяет подключение", screen.caption)
        self.assertIn("настроек владельцем", screen.caption)

    def test_recovered_outbox_reads_current_owned_db_url_not_payload(self):
        self.service.invoice.update(status="awaiting_payment", payment_url=URL, invoice_recovery_state="registered")
        self.service._notifications = [{"id": "ready1", "user_id": 10, "kind": "order", "payload": {"order_id": "O1"}}]
        self.ui.send_pending_notifications()
        self.assertEqual(self.service.acked, ["ready1"])
        buttons = [button for row in self.bot.sent[-1][2]["reply_markup"].keyboard for button in row]
        self.assertEqual([button.url for button in buttons if button.url], [URL])
        self.assertIn("Ожидает оплаты", self.bot.sent[-1][1])
        self.assertNotIn("FAKE_CAPABILITY", self.bot.sent[-1][1])
        self.assertNotIn("FAKE_CAPABILITY", json.dumps(self.service.store.get_session(10)))

    def test_owner_diagnostics_local_only_and_never_leaks_data(self):
        self.ui.handle_message(message("/shop_diagnostics", uid=10))
        self.ui.handle_message(message("/shop_diagnostics", uid=99, group=True))
        self.assertEqual(self.service.diag_reads, 0)
        self.ui.handle_message(message("/shop_diagnostics", uid=99))
        self.assertEqual(self.service.diag_reads, 1)
        text = self.bot.sent[-1][1]
        self.assertIn("HTTP 403", text)
        self.assertIn("HTTP 200", text)
        self.assertIn("GET /balance", text)
        self.assertIn("steamru_ok", text)
        self.assertIn("проверка STEAM.RU прошла", text)
        self.assertIn("настоящий", text)
        self.assertIn("запросы к сайту и покупки не выполняются", text)
        self.assertNotIn("SECRET", text)
        self.assertNotIn("https://", text)
        self.assertNotIn("<XML>", text)

    def test_supplier_diagnostics_use_fixed_safe_reasons(self):
        for status, phrase in ((401, "не подтвердил доступ"), (403, "не подтвердил доступ"), (429, "частоту"), (500, "временный сбой"), (404, "не найден"), (422, "параметры")):
            reason, action = self.ui._supplier_diagnostic_reason({"http_status": status, "reason": "<XML>SECRET</XML>", "action": URL})
            self.assertIn(phrase, reason)
            self.assertNotIn("SECRET", reason + action)
            self.assertNotIn("https://", reason + action)


class InvoiceUIBackendTests(unittest.TestCase):
    def test_lost_registration_recovers_same_invoice_and_delivers_owned_url(self):
        from aisklad_shop.catalog import product_id
        from aisklad_shop.service import ShopError, ShopService
        from aisklad_shop.store import ShopStore
        from aisklad_shop.web_payments import WebPayments
        from shop_tests.test_merchandising import DemoSupplier
        from shop_tests.test_web_payments import Bridge, BASE, SECRET
        with tempfile.TemporaryDirectory() as directory:
            now = [1800000000]
            clock = lambda: now[0]
            store = ShopStore(Path(directory) / "shop.sqlite3", clock=clock)
            supplier, bridge = DemoSupplier(), Bridge(clock)
            payments = WebPayments(BASE, SECRET, session=bridge, clock=clock)
            service = ShopService(store, supplier, {"enabled": True, "owner_id": 999}, payment_connector=payments,
                                  rate_provider=lambda: {"rub_per_usd": "90", "observed_at": now[0]}, clock=clock)
            service.sync_catalog()
            service.add_to_cart(100, product_id("service", "steam", 1), 156, {"account": "steam_login"})
            bridge.drop_register_once = True
            with self.assertRaises(ShopError) as caught:
                service.checkout(100)
            bot = FakeBot()
            ui = BuyerBot(service, bot=bot, owner_id=999, assets_dir="/no-assets")
            ui._error(100, caught.exception)
            order_id = caught.exception.order_id
            self.assertIn(order_id, bot.sent[-1][1])
            self.assertNotIn("capability", bot.sent[-1][1])
            prior_requests = len(bridge.requests)
            current = service.order(100, order_id)
            if current.get("invoice_retry_allowed"):
                service.retry_invoice(100, order_id)
                self.assertEqual(prior_requests, len(bridge.requests))
            now[0] += 16
            service.retry_pending_invoices()
            restored = service.order(100, order_id)
            self.assertEqual(restored["status"], "awaiting_payment")
            self.assertEqual(len(bridge.invoices), 1)
            ui.send_pending_notifications()
            buyer_messages = [(text, kwargs) for uid, text, kwargs in bot.sent if uid == 100]
            buttons = [button for row in buyer_messages[-1][1]["reply_markup"].keyboard for button in row]
            self.assertEqual([button.url for button in buttons if button.url], [restored["payment_url"]])
            self.assertEqual(supplier.posts, [])
            with store.connection() as db:
                self.assertEqual(db.execute("SELECT COUNT(*) FROM payment_authorizations").fetchone()[0], 0)
            before = len(bridge.requests)
            ui.handle_message(message("/shop_diagnostics", uid=999))
            self.assertEqual(before, len(bridge.requests))


if __name__ == "__main__":
    unittest.main()
