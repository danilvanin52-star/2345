"""STEAM.RU adapter using the verified reseller HMAC implementation."""
from __future__ import annotations
from contextlib import nullcontext
from decimal import Decimal
import threading
import time
from urllib.parse import quote


class SupplierError(RuntimeError):
    pass


class NotSubmitted(SupplierError):
    """Raised exclusively before reaching the POST call; a safe later retry exists."""
    def __init__(self, message, code="PREFLIGHT_WAIT"):
        super().__init__(message)
        self.code = code


class SteamSupplier:
    def __init__(self, client, purchase_lock=None, min_get_interval=.3, get_retries=2, clock=time.monotonic, sleep=time.sleep):
        self.client = client
        self.purchase_lock = purchase_lock
        self.min_get_interval = max(0, float(min_get_interval))
        self.get_retries = min(3, max(0, int(get_retries)))
        self.clock, self.sleep = clock, sleep
        self._get_lock = threading.RLock()
        self._next_get = 0

    def get(self, endpoint, params=None):
        for attempt in range(self.get_retries + 1):
            try:
                with self._get_lock:
                    delay = self._next_get - self.clock()
                    if delay > 30:
                        raise SupplierError("STEAM.RU просит подождать; повторный GET отложен")
                    if delay > 0:
                        self.sleep(delay)
                    self._next_get = self.clock() + self.min_get_interval
                    return self.client.request("GET", endpoint, params=params)
            except Exception as exc:
                status = getattr(exc, "status", None)
                retryable = status == 429 or (isinstance(status, int) and 500 <= status < 600) or getattr(exc, "code", None) == "network.error"
                if not retryable:
                    raise
                try:
                    wait = max(1, float(getattr(exc, "retry_after", None) or (2 ** attempt)))
                except (ValueError, TypeError):
                    wait = 2 ** attempt
                with self._get_lock:
                    self._next_get = max(self._next_get, self.clock() + wait)
                if attempt >= self.get_retries or wait > 30:
                    raise
        raise SupplierError("GET retry budget exhausted")

    def can_purchase(self):
        return getattr(self.client, "allow_purchases", False) is True

    def pages(self, endpoint, key, per_page=100):
        page, seen, received, expected_total = 1, set(), 0, None
        while True:
            data = self.get(endpoint, {"page": page, "per_page": per_page})
            rows = data.get(key)
            if not isinstance(rows, list):
                raise SupplierError("Malformed catalogue page")
            if "page" in data and int(data["page"]) != page:
                raise SupplierError("Supplier returned the wrong page")
            if "total" in data:
                total = int(data["total"])
                if total < 0 or (expected_total is not None and total != expected_total):
                    raise SupplierError("Catalogue changed during pagination")
                expected_total = total
            marker = tuple(str(r.get("id", r.get("app_id", r.get("uuid", "")))) for r in rows)
            if rows and marker in seen:
                raise SupplierError("Supplier repeated a catalogue page")
            seen.add(marker)
            received += len(rows)
            for row in rows:
                if not isinstance(row, dict):
                    raise SupplierError("Malformed catalogue item")
                yield row
            if "total_pages" in data:
                total_pages = int(data["total_pages"])
                if total_pages < 0 or total_pages > 100000 or (page < total_pages and not rows):
                    raise SupplierError("Incomplete catalogue pagination")
                if page >= total_pages:
                    if expected_total is not None and received != expected_total:
                        raise SupplierError("Incomplete catalogue total")
                    break
            elif len(rows) < per_page:
                if expected_total is not None and received != expected_total:
                    raise SupplierError("Incomplete catalogue total")
                break
            page += 1
            if page > 100000:
                raise SupplierError("Unbounded catalogue pagination")

    def brands(self):
        result = self.get("/catalog/brands").get("brands")
        if not isinstance(result, list):
            raise SupplierError("Missing brands")
        return result

    def services(self):
        return self.pages("/catalog/services", "services", 1000)

    def products(self, service):
        data = self.get("/catalog/services/" + quote(str(service), safe="-") + "/products")
        if data.get("service") != service or data.get("type") not in ("topup", "code") or not isinstance(data.get("products"), list):
            raise SupplierError("Wrong catalogue service")
        return data

    def keys(self):
        return self.pages("/catalog/keys", "games")

    def gifts(self):
        return self.pages("/catalog/gifts", "games")

    def key_card(self, app_id):
        return self.get("/catalog/keys/" + str(int(app_id)))

    def gift_card(self, app_id):
        return self.get("/catalog/gifts/" + str(int(app_id)))

    def balance(self):
        value = Decimal(str(self.get("/balance")["balance"]))
        if not value.is_finite() or value < 0:
            raise SupplierError("Invalid supplier balance")
        return value

    def check_account(self, service, account):
        endpoint = {"steam": "/check/steam-account", "telegram-stars": "/check/telegram-username"}.get(service)
        if endpoint:
            data = self.get(endpoint, {"account": account})
            if data.get("valid") is not True:
                raise SupplierError("Получатель не прошёл проверку STEAM.RU")

    def submit(self, product, quantity, fields, external_id, expected_max_usd=None):
        """Exactly one POST. Caller must persist a submitting fence beforehand."""
        if not str(external_id).startswith("aisklad-") or len(external_id) > 100:
            raise ValueError("Invalid shop external id")
        kind = product["kind"]
        payload = {"external_order_id": external_id}
        if kind == "key":
            endpoint = "/orders/game-key"
            payload.update(app_id=int(product["app_id"]), option_id=int(product["option_id"]), quantity=int(quantity))
        elif kind == "gift":
            if int(quantity) != 1:
                raise ValueError("Gift quantity must be one")
            endpoint = "/orders/game-gift"
            payload.update(app_id=int(product["app_id"]), invite_url=fields["invite_url"], region=product["region"], edition=product["edition"])
        elif kind in ("topup", "code"):
            endpoint = "/orders"
            payload.update(service=product["service"], product_id=int(product["supplier_product_id"]), product_count=int(quantity))
            schema = product.get("fields", [])
            extra = {f["name"]: fields[f["name"]] for f in schema if f["name"] != "account" and f["name"] in fields}
            if extra:
                payload["fields"] = extra
            if "account" in fields:
                payload["account"] = fields["account"]
        else:
            raise ValueError("Select a concrete product variant")
        context = self.purchase_lock() if callable(self.purchase_lock) else self.purchase_lock
        post_started = False
        try:
            with context or nullcontext():
                if expected_max_usd is not None:
                    try:
                        sufficient = self.balance() >= Decimal(str(expected_max_usd))
                    except Exception as exc:
                        raise NotSubmitted("Не удалось проверить баланс; POST не выполнялся", "BALANCE_CHECK") from exc
                    if not sufficient:
                        raise NotSubmitted("Недостаточно баланса поставщика; покупка не отправлена", "BALANCE_WAIT")
                post_started = True
            return self.client.request("POST", endpoint, payload=payload, idempotency=external_id, timeout=35)
        except NotSubmitted:
            raise
        except Exception as exc:
            if not post_started:
                raise NotSubmitted("Покупка ещё не отправлялась; предпроверка будет повторена") from exc
            raise

    def order(self, supplier_uuid):
        return self.get("/orders/" + quote(str(supplier_uuid), safe="-"))

    def recover(self, external_id):
        """Read history only; absence is never permission to retry a POST."""
        found = []
        for order in self.pages("/orders", "orders"):
            if order.get("external_order_id") == external_id:
                found.append(order)
        if len(found) > 1:
            raise SupplierError("Ambiguous supplier history")
        return found[0] if found else None
