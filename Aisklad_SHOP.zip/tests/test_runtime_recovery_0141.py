"""Offline regression: maintenance cooldown, quiet failures and useful diagnostics."""
import atexit
from copy import deepcopy
from io import StringIO
import json
import logging
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as N
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_safety_integration as safety
import steamru_stars as bot
from steamru_stars_engine import ApiFailure, Store


class MaintenanceRecoveryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        safety.SafetyIntegrationTests.setUpClass()

    def setUp(self):
        self.case = safety.SafetyIntegrationTests()
        self.case.setUp()
        self.now = 2000000000.0
        self.clock = patch.object(bot.time, 'time', side_effect=lambda: self.now)
        self.clock.start()
        self.env = patch.dict(os.environ, {'AISKLAD_SHARED_DB': '', 'STEAMRU_OWNER_TG_ID': '123'})
        self.env.start()
        bot.CFG = deepcopy(bot.CFG)
        bot.CFG['auto_pricing']['enabled'] = True
        bot.CFG['catalog_sync']['enabled'] = False
        bot.CFG['rotation']['enabled'] = True
        self.expire = patch.object(bot.controls, 'expire').start()
        self.notice = patch.object(bot.notifications, 'notify').start()
        self.addCleanup(patch.stopall)
        self.addCleanup(self.case.tearDown)
        bot.STOP.clear()

    def streak(self):
        return json.loads(bot.STORE.get_meta('failure_streak:maintenance', '{}')).get('count', 0)

    def failure(self, status=404, retry_after=None):
        return ApiFailure('api.error', 'UNSAFE RESPONSE MUST NEVER BE SHOWN', status,
                          retry_after, method='GET', endpoint='/catalog/keys', reason='endpoint' if status == 404 else None)

    def test_404_cooldown_survives_restart_and_skipped_ticks_do_not_count(self):
        with patch.object(bot, 'auto_reprice', side_effect=self.failure()) as reprice, \
                patch.object(bot, 'maintain_availability') as availability, patch.object(bot.rotation, 'run') as rotate:
            self.assertEqual(bot.maintenance_tick(self.case.c), 'retry')
            self.assertEqual(self.streak(), 1)
            self.assertEqual(float(bot.STORE.get_meta('maintenance_retry_at')), self.now + 900)
            bot.STORE = Store(self.case.store.path)
            self.now += 20
            for _ in range(50):
                self.assertEqual(bot.maintenance_tick(self.case.c), 'cooldown')
            self.assertEqual(self.streak(), 1)
            reprice.assert_called_once()
            availability.assert_not_called()
            rotate.assert_not_called()
            self.now += 880
            self.assertEqual(bot.maintenance_tick(self.case.c), 'retry')
            self.assertEqual(self.streak(), 2)
            self.assertEqual(reprice.call_count, 2)
            self.assertFalse(bot.paused())

    def test_server_backoff_and_retry_after_are_persisted(self):
        self.assertEqual([bot.defer_maintenance(self.failure(503)) for _ in range(6)], [60, 120, 240, 480, 900, 900])
        self.assertEqual(bot.defer_maintenance(self.failure(429, '1800')), 1800)
        wrapped = ValueError('local wrapper')
        wrapped.__cause__ = self.failure(429, '2400')
        self.assertEqual(bot.defer_maintenance(wrapped), 2400)
        for status in (401, 403, 404):
            bot.STORE.set_meta('maintenance_failures', '0')
            self.assertEqual(bot.defer_maintenance(self.failure(status)), 900)

    def test_optional_catalog_failure_does_not_fan_out_or_reset_streak(self):
        bot.CFG['catalog_sync']['enabled'] = True
        with patch.object(bot, 'sync_catalog', side_effect=self.failure(403)) as sync, \
                patch.object(bot, 'auto_reprice') as reprice, \
                patch.object(bot, 'maintain_availability') as availability, patch.object(bot.rotation, 'run') as rotate:
            self.assertEqual(bot.maintenance_tick(self.case.c), 'retry')
            self.assertEqual(self.streak(), 1)
            self.assertEqual(bot.maintenance_tick(self.case.c), 'cooldown')
            sync.assert_called_once()
            reprice.assert_not_called()
            availability.assert_not_called()
            rotate.assert_not_called()
            self.assertEqual(self.streak(), 1)

    def test_local_new_offer_form_failure_is_quiet_and_does_not_cancel_resume(self):
        bot.CFG['catalog_sync']['enabled'] = True
        bot.STORE.set_meta('resume_token', 'IN_PROGRESS')
        with patch.object(bot, 'sync_catalog', side_effect=ValueError('No new form')), \
                patch.object(bot, 'auto_reprice') as reprice, \
                patch.object(bot, 'maintain_availability') as availability, \
                patch.object(bot.rotation, 'run') as rotate, patch.object(bot, 'critical') as critical:
            self.assertEqual(bot.maintenance_tick(self.case.c), 'import_deferred')
            self.assertGreater(float(bot.STORE.get_meta('next_catalog_sync')), self.now + 1700)
            self.assertEqual(bot.STORE.get_meta('resume_token'), 'IN_PROGRESS')
            self.assertEqual(self.streak(), 0)
            self.assertFalse(bot.paused())
            critical.assert_not_called()
            reprice.assert_not_called()
            availability.assert_not_called()
            rotate.assert_not_called()

    def test_idle_pass_is_not_success_but_actual_success_resets_own_stream(self):
        bot.critical(self.case.c, 'temporary maintenance', scope='maintenance')
        bot.CFG['auto_pricing']['enabled'] = False
        bot.CFG['rotation']['enabled'] = False
        self.assertEqual(bot.maintenance_tick(self.case.c), 'idle')
        self.assertEqual(self.streak(), 1)
        bot.CFG['auto_pricing']['enabled'] = True
        with patch.object(bot, 'auto_reprice') as reprice:
            self.assertEqual(bot.maintenance_tick(self.case.c), 'ok')
            reprice.assert_called_once()
        self.assertEqual(self.streak(), 0)
        self.assertEqual(bot.STORE.get_meta('maintenance_failures'), '0')

    def test_seven_real_attempts_pause_once_without_warning_spam(self):
        with patch.object(bot, 'auto_reprice', side_effect=self.failure(503)), \
                patch.object(bot, 'disable_managed_lots') as disable, patch.object(bot, 'LOG') as log:
            for index in range(1, 8):
                self.assertEqual(bot.maintenance_tick(self.case.c), 'retry')
                self.assertEqual(self.streak(), index)
                self.assertEqual(bot.paused(), index == 7)
                self.now = float(bot.STORE.get_meta('maintenance_retry_at'))
            disable.assert_called_once()
            self.assertEqual(log.warning.call_count, 2)
            self.assertEqual(log.debug.call_count, 5)
            bot.STORE = Store(self.case.store.path)
            self.assertEqual(self.streak(), 7)
            self.assertTrue(bot.paused())

    def test_tripped_log_reminder_at_most_once_per_fifteen_minutes(self):
        with patch.object(bot, 'LOG') as log, patch.object(bot, 'disable_managed_lots') as disable:
            for _ in range(7):
                bot.critical(self.case.c, 'same outage', scope='maintenance')
            self.assertEqual(log.warning.call_count, 2)
            for _ in range(50):
                bot.critical(self.case.c, 'same outage', scope='maintenance')
            self.assertEqual(log.warning.call_count, 2)
            self.now += 899
            bot.critical(self.case.c, 'same outage', scope='maintenance')
            self.assertEqual(log.warning.call_count, 2)
            self.now += 1
            bot.critical(self.case.c, 'same outage', scope='maintenance')
            self.assertEqual(log.warning.call_count, 3)
            disable.assert_called_once()

    def handlers(self):
        handlers = {}
        telegram = N(reply_to=Mock(), answer_callback_query=Mock())
        def register(handler, **options):
            for command in options.get('commands', []):
                handlers[command] = handler
        self.case.c.telegram = N(bot=telegram, authorized_users={'123': {}}, msg_handler=register, cbq_handler=Mock())
        self.case.c.add_telegram_commands = Mock()
        with patch.object(bot.controls, 'register'), patch.object(bot.notifications, 'register'), patch.object(bot.activity, 'register'):
            bot.on_pre_init(self.case.c)
        return handlers, telegram

    def test_resume_and_status_show_only_typed_safe_http_diagnostic(self):
        handlers, telegram = self.handlers()
        message = N(from_user=N(id=123), chat=N(type='private'))
        bot.STORE.set_meta('paused', 'yes')
        failure = self.failure()
        class InlineThread:
            def __init__(self, target, **kwargs):
                self.target = target
            def start(self):
                self.target()
        with patch.object(bot.threading, 'Thread', InlineThread), patch.object(bot, 'resume_live', side_effect=failure):
            handlers['sr_resume'](message)
        handlers['sr_status'](message)
        replies = '\n'.join(str(call.args[1]) for call in telegram.reply_to.call_args_list)
        self.assertIn('HTTP 404', replies)
        self.assertIn('GET /catalog/keys', replies)
        self.assertNotIn('UNSAFE RESPONSE', replies)
        persisted = bot.STORE.get_meta('last_supplier_diagnostic')
        self.assertNotIn('UNSAFE RESPONSE', persisted)
        self.assertEqual(json.loads(persisted)['http_status'], 404)
        self.assertTrue(bot.paused())
        self.assertEqual(self.case.api.created, [])

    def test_funpay_rate_limit_uses_cooldown_without_adding_health_failures(self):
        failure = bot.funpay_control.FunPayRateLimited(300)
        with patch.object(bot, 'auto_reprice', side_effect=failure) as reprice:
            self.assertEqual(bot.maintenance_tick(self.case.c), 'rate_limited')
            self.assertEqual(self.streak(), 0)
            self.assertEqual(bot.maintenance_tick(self.case.c), 'cooldown')
            reprice.assert_called_once()


class LoggerPropagationTests(unittest.TestCase):
    def test_queue_logs_once_to_console_and_file_without_root_copy(self):
        from Utils import logger as log_module
        previous_disable = logging.root.manager.disable
        root = logging.getLogger()
        root_records = []
        class RootCapture(logging.Handler):
            def emit(self, record):
                root_records.append(record.getMessage())
        root_handler = RootCapture()
        root.addHandler(root_handler)
        self.addCleanup(root.removeHandler, root_handler)
        saved = {name: (list(logging.getLogger(name).handlers), logging.getLogger(name).propagate, logging.getLogger(name).level)
                 for name in log_module.LOGGER_NAMES + ['TeleBot']}
        for name in saved:
            logging.getLogger(name).handlers = []
        real_rotating = logging.handlers.RotatingFileHandler
        stderr = StringIO()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'log.log'
            def handler(**kwargs):
                return real_rotating(filename=path, maxBytes=1024*1024, backupCount=1, encoding='utf-8')
            listener = None
            try:
                logging.disable(logging.NOTSET)
                with patch.object(log_module.logging.handlers, 'RotatingFileHandler', side_effect=handler), patch('sys.stderr', stderr):
                    listener = log_module.configure_logging()
                    logging.getLogger('FPC.recovery_test').warning('unique-runtime-recovery-marker')
                    listener.stop()
                    atexit.unregister(listener.stop)
                    for output in listener.handlers:
                        output.flush()
                    self.assertEqual(stderr.getvalue().count('unique-runtime-recovery-marker'), 1)
                    self.assertEqual(path.read_text(encoding='utf-8').count('unique-runtime-recovery-marker'), 1)
                    self.assertEqual(root_records, [])
                    self.assertTrue(all(logging.getLogger(name).propagate is False for name in log_module.LOGGER_NAMES))
            finally:
                logging.disable(previous_disable)
                if listener is not None:
                    for output in listener.handlers:
                        output.close()
                for name, (handlers, propagate, level) in saved.items():
                    target = logging.getLogger(name)
                    target.handlers, target.propagate = handlers, propagate
                    target.setLevel(level)


if __name__ == '__main__':
    unittest.main()
