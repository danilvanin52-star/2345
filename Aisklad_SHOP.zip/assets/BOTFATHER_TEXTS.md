# Aisklad SHOP: оформление существующего бота

## Description (до Start)

✨ Aisklad SHOP — твой цифровой мир в Telegram!

🎮 Пополнение Steam в RUB и KZT
⭐ Stars и Premium, ключи игр и подарочные карты
🧭 Помощник подберёт услугу по игре, сумме и региону
🛒 Избранное, корзина и история заказов
💬 Поддержка: !помощь

Напиши «пополнить стим на 156 рублей» или «что есть для Roblox?» — помогу найти нужное.
Пароли и коды входа не нужны. Оплата пока готовится к подключению.

## About text

🎮 Steam RUB/KZT, игры, Stars и подарочные карты. Умный подбор, корзина и поддержка — Aisklad SHOP.

## Commands

start - Открыть Aisklad SHOP
menu - Главное меню
assistant - Умный подбор услуги
search - Найти игру или услугу
cart - Моя корзина
orders - Мои заказы
help - Помощь с выбором и заказом
paysupport - Вопрос об оплате
terms - Условия
privacy - Данные

## Картинка до Start

@BotFather → /mybots → Aisklad SHOP → Edit Bot → Edit Description Picture.
Загрузить assets/menus/about-botfather.jpg (640×360).
Текст и команды выставляются автоматически после обновления приложения; фото через BotFather загружается отдельно.
