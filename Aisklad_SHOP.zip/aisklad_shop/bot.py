"""Private buyer Telegram UI. No supplier writes or payment confirmation live here."""
import hashlib
import hmac
import logging
import re
import secrets
import threading
import time
from decimal import Decimal, InvalidOperation
from html import unescape
from pathlib import Path

from . import presentation as p


LOG = logging.getLogger("aisklad.shop.ui")
PUBLIC_ERRORS = {
    "PAYMENT_UNAVAILABLE": "💳 Оплату подключаем. Товар ещё не оплачен, списаний нет. Корзина сохранена.",
    "PAYMENTS_DISABLED": "💳 Оплату подключаем. Товар ещё не оплачен, списаний нет. Корзина сохранена.",
    "SHOP_DISABLED": "⏸ Магазин временно на паузе. Корзина и история сохранены. Поддержка доступна.",
    "SHOP_PAUSED": "⏸ Магазин временно на паузе. Корзина и история сохранены. Поддержка доступна.",
    "MODULE_DISABLED": "⏸ Магазин временно на паузе. Корзина и история сохранены.",
    "EMPTY_CART": "🛒 Корзина пока пуста. Сначала выбери товар в каталоге.",
    "NOT_FOUND": "Этот товар или заказ больше не доступен. Открой каталог или свою историю заново.",
    "UNAVAILABLE": "⏳ Товар сейчас недоступен. Выбери другой вариант или загляни позже.",
    "PRODUCT_UNAVAILABLE": "⏳ Товар сейчас недоступен. Выбери другой вариант или загляни позже.",
    "HIDDEN_PRODUCT": "В магазине доступны пополнения Steam в рублях и тенге. Выбери RUB или KZT в каталоге.",
    "PRICE_CHANGED": "Цена обновилась. Проверь корзину перед оформлением.",
    "QUOTE_CHANGED": "Цена обновилась. Открой корзину и проверь новую сумму перед оформлением.",
    "INVALID_QUANTITY": "Проверь количество: оно должно входить в диапазон товара.",
    "INVALID_FIELDS": "Проверь данные получателя и заполни обязательные поля.",
    "FIELD_REQUIRED": "Заполни обязательное поле получателя. Нажми «Заполнить заново», чтобы исправить данные.",
    "INVALID_FIELD": "Проверь данные получателя. Нажми «Заполнить заново», чтобы исправить данные.",
    "INVALID_OPTION": "Выбери вариант получателя кнопкой из доступного списка.",
    "ACCOUNT_INVALID": "Поставщик не подтвердил получателя. Проверь логин или username и заполни данные заново.",
    "REGION_MISMATCH": "Этот товар не подтверждён для выбранной страны. Выбери подходящий регион в каталоге.",
    "INVITE_INVALID": "Для подарка нужна личная ссылка-приглашение Steam вида https://s.team/p/… . Пароль не нужен.",
    "UNSUPPORTED_FIELD": "Этот товар пока нельзя оформить автоматически. Выбери другой вариант или отправь !помощь.",
    "RATE_UNAVAILABLE": "Не удалось уточнить цену. Попробуй чуть позже; списаний нет.",
    "CART_FULL": "В корзине уже достаточно товаров. Оформи их или убери лишнее.",
    "CART_LIMIT": "В корзине уже достаточно товаров. Оформи их или убери лишнее.",
    "HELP_RATE_LIMIT": "Обращение уже отправлено. Мы его видим; повторять команду не нужно.",
    "SUPPORT_RATE_LIMIT": "Обращение уже отправлено. Мы его видим; повторять команду не нужно.",
}


def _integer(value):
    text = str(value).strip()
    if not re.fullmatch(r"[0-9]{1,9}", text):
        raise ValueError("quantity")
    return int(text)


def _plain(html):
    return unescape(re.sub(r"<[^>]+>", "", html))


class BuyerBot:
    """An injectable TeleBot adapter; instantiate without a token in offline tests.

    The callback action table is persisted per buyer. Each opaque token is signed
    with a persistent UI key and the buyer ID. Old buttons never repeat a write.
    """

    def __init__(self, service, bot=None, token=None, owner_id=0, assets_dir=None,
                 media_resolver=None, module_controller=None, owner_notifier=None):
        self.service, self.store = service, service.store
        self.owner_id = int(owner_id or 0)
        self.assets_dir = Path(assets_dir or Path(__file__).resolve().parent.parent / "assets" / "menus")
        self.media_resolver, self.module_controller = media_resolver, module_controller
        self.owner_notifier = owner_notifier
        if bot is None:
            if not token:
                raise ValueError("Buyer bot token is required")
            import telebot
            bot = telebot.TeleBot(token, parse_mode="HTML", threaded=True, num_threads=4)
        self.bot = bot
        self._locks, self._locks_lock = {}, threading.Lock()
        secret = self.store.get_setting("shop:ui_callback_secret", None)
        if not secret:
            secret = secrets.token_hex(32)
            self.store.set_setting("shop:ui_callback_secret", secret)
        self._secret = str(secret).encode("utf-8")
        self._registered, self._stopped = False, threading.Event()
        self._admin_job_lock, self._admin_jobs = threading.Lock(), {}
        self._input_context = threading.local()

    def _lock(self, user_id):
        with self._locks_lock:
            return self._locks.setdefault(user_id, threading.RLock())

    def _session(self, user_id):
        session = self.store.get_session(user_id)
        return session if isinstance(session, dict) else {}

    def _save(self, user_id, session):
        self.store.set_session(user_id, session)

    @staticmethod
    def _private(message, user_id=None):
        chat = getattr(message, "chat", None)
        sender = getattr(message, "from_user", None)
        uid = int(user_id or getattr(sender, "id", 0) or 0)
        return bool(uid and chat and getattr(chat, "type", None) == "private" and int(getattr(chat, "id", 0)) == uid)

    def _enabled(self):
        try:
            if self.module_controller is not None:
                return bool(self.module_controller.status().get("shop", False))
            state = self.service.status()
            return bool(state.get("enabled", True))
        except Exception:
            return False

    def _signature(self, uid, token):
        return hmac.new(self._secret, f"{uid}:{token}".encode("ascii"), hashlib.sha256).hexdigest()[:16]

    def _keyboard(self, uid, screen, session):
        import telebot.types as types
        keyboard = types.InlineKeyboardMarkup()
        callbacks = {}
        for row in screen.rows:
            buttons = []
            for action in row:
                token = secrets.token_urlsafe(9)
                data = f"as:{token}:{self._signature(uid, token)}"
                assert len(data.encode("utf-8")) <= 64
                callbacks[token] = {"name": action.name, "args": action.args}
                buttons.append(types.InlineKeyboardButton(action.label[:64], callback_data=data))
            if buttons:
                keyboard.row(*buttons)
        session["callbacks"] = callbacks
        session["screen_at"] = int(time.time())
        self._save(uid, session)
        return keyboard

    def _image_path(self, screen):
        if isinstance(screen.image, str) and screen.image in p.MENU_KEYS:
            for suffix in (".jpg", ".png", ".webp"):
                candidate = self.assets_dir / (screen.image + suffix)
                if candidate.is_file():
                    return candidate
            return None
        if self.media_resolver is not None:
            try:
                result = self.media_resolver.resolve(screen.image, fallback="product")
                result = Path(result) if result else None
                if result and result.is_file():
                    return result
            except Exception as exc:
                LOG.warning("Product image unavailable: %s", type(exc).__name__)
        return self._image_path(p.Screen("", "product"))

    def _send_screen(self, uid, screen, session=None, reuse=True):
        # A typed user turn must receive a visible answer BELOW that message.
        # Only button navigation may keep editing the current menu bubble.
        reuse = reuse and getattr(self._input_context, "uid", None) != uid
        session = self._session(uid) if session is None else session
        markup = self._keyboard(uid, screen, session)
        image = self._image_path(screen)
        caption = screen.caption
        message_id = session.get("screen_message_id") if reuse else None
        if message_id and session.get("screen_kind") == ("photo" if image and len(caption) <= 1000 else "text"):
            try:
                if image and len(caption) <= 1000 and hasattr(self.bot, "edit_message_media"):
                    from telebot.types import InputMediaPhoto
                    with image.open("rb") as stream:
                        self.bot.edit_message_media(InputMediaPhoto(stream, caption=caption, parse_mode="HTML"),
                                                    chat_id=uid, message_id=message_id, reply_markup=markup)
                    return
                if not image and len(caption) <= 3900 and hasattr(self.bot, "edit_message_text"):
                    self.bot.edit_message_text(caption, chat_id=uid, message_id=message_id, parse_mode="HTML",
                                               reply_markup=markup, disable_web_page_preview=True)
                    return
            except Exception as exc:
                if "message is not modified" in str(exc).lower():
                    return
                if self._retryable_send_error(exc):
                    raise
        if image:
            try:
                with image.open("rb") as stream:
                    result = self.bot.send_photo(uid, stream, caption=caption if len(caption) <= 1000 else "<b>✨ Aisklad SHOP</b>",
                                                 parse_mode="HTML", reply_markup=markup if len(caption) <= 1000 else None,
                                                 protect_content=False)
                if len(caption) <= 1000:
                    session.update(screen_message_id=getattr(result, "message_id", None), screen_kind="photo")
                    self._save(uid, session)
                    return
            except Exception as exc:
                if self._retryable_send_error(exc):
                    raise
                LOG.warning("Menu photo fallback: %s", type(exc).__name__)
        result = self._send_text(uid, caption, markup)
        session.update(screen_message_id=getattr(result, "message_id", None), screen_kind="text")
        self._save(uid, session)

    @staticmethod
    def _retryable_send_error(exc):
        code = getattr(exc, "error_code", 0) or 0
        return code == 429 or code >= 500 or isinstance(exc, (TimeoutError, ConnectionError)) or type(exc).__name__ in ("ReadTimeout", "ConnectTimeout", "ConnectionError")

    def _send_text(self, uid, text, markup=None):
        if len(text) <= 3900:
            try:
                return self.bot.send_message(uid, text, parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
            except Exception as exc:
                # Retry only formatting errors, never a timeout that may have delivered.
                if "parse entities" not in str(exc).lower() and "can't parse" not in str(exc).lower():
                    raise
        plain = _plain(text)
        chunks = [plain[index:index + 3800] for index in range(0, len(plain), 3800)] or [""]
        for index, chunk in enumerate(chunks):
            result = self.bot.send_message(uid, chunk, parse_mode=None, reply_markup=markup if index == len(chunks) - 1 else None,
                                           disable_web_page_preview=True)
        return result

    def _notice(self, uid, text):
        return self._send_text(uid, text)

    def register_handlers(self):
        if self._registered:
            return self
        self.bot.register_message_handler(self.handle_message, content_types=["text"], func=lambda message: True)
        self.bot.register_callback_query_handler(self.handle_callback, func=lambda call: str(getattr(call, "data", "")).startswith("as:"))
        self._registered = True
        return self

    def run(self):
        self.register_handlers()
        self._stopped.clear()
        self.bot.infinity_polling(timeout=25, long_polling_timeout=25, skip_pending=False, allowed_updates=["message", "callback_query"])

    def stop(self):
        self._stopped.set()
        self.bot.stop_polling()

    def _error(self, uid, exc):
        code = str(getattr(exc, "code", ""))
        text = PUBLIC_ERRORS.get(code, "Не получилось выполнить действие. Попробуй позже или отправь !помощь. Статус заказов — /orders.")
        LOG.warning("Buyer action failed: %s/%s", type(exc).__name__, code if re.fullmatch(r"[A-Z_]{1,40}", code) else "UNKNOWN")
        if self._retryable_send_error(exc):
            return  # A second Telegram request during rate limiting only worsens it.
        session = self._session(uid)
        if session.get("draft"):
            rows = [[p.button("✏️ Заполнить заново", "begin_buy", product_id=session["draft"]["product_id"])]] + p.nav()
            self._send_screen(uid, p.Screen(text, "checkout", rows), session)
        else:
            self._notice(uid, text)

    def handle_message(self, message):
        if not self._private(message):
            return
        uid = int(message.from_user.id)
        text = str(getattr(message, "text", "") or "").strip()
        with self._lock(uid):
            self._input_context.uid = uid
            try:
                self._message(uid, text)
            except Exception as exc:
                self._error(uid, exc)
            finally:
                self._input_context.uid = None

    def _message(self, uid, text):
        command = text.split(None, 1)[0].split("@", 1)[0].lower() if text else ""
        if command in ("/start", "/menu", "/cancel"):
            session = self._session(uid)
            session.pop("draft", None)
            session["mode"] = "navigation"
            self._send_screen(uid, p.home(self._enabled()), session)
            return
        if command == "/shop_reply":
            self._admin_reply(uid, text.partition(" ")[2].strip())
            return
        if command in ("/shop_admin", "/aisklad_modules", "/shop_on", "/shop_off", "/funpay_on", "/funpay_off", "/shop_sync", "/shop_balance", "/shop_stats", "/shop_resume"):
            self._admin(uid, "/shop_admin" if command == "/aisklad_modules" else command)
            return
        if command in ("!помощь", "/help", "/paysupport"):
            detail = text[len(text.split(None, 1)[0]):].strip()
            session = self._session(uid)
            if detail:
                self._help_request(uid, detail)
            else:
                self._help_request(uid, "Покупатель запросил помощь через " + command)
            session["mode"] = "help_text"
            self._send_screen(uid, self._help_screen(), session)
            return
        if command in ("/terms", "/privacy"):
            self._send_screen(uid, self._policy(command))
            return
        if command == "/orders":
            self._send_screen(uid, p.orders(self.service.orders(uid, page=0)))
            return
        if command == "/cart":
            self._send_screen(uid, p.cart(self.service.cart(uid)))
            return
        if command == "/search" or (command.startswith("/search") and len(command) > len("/search")):
            query = text[len("/search"):].strip() if command != "/search" else text.partition(" ")[2].strip()
            if query:
                self._search_results(uid, query)
            else:
                self._search_prompt(uid)
            return
        if command == "/about":
            self._send_screen(uid, p.about())
            return
        if command in ("/assistant", "/ask") or text == "🤖 Помощник":
            query = text.partition(" ")[2].strip() if command in ("/assistant", "/ask") else ""
            if query:
                self._assistant_response(uid, query)
            else:
                self._assistant_prompt(uid)
            return
        session = self._session(uid)
        mode = session.get("mode", "navigation")
        if mode == "search":
            self._search_results(uid, text)
        elif mode == "quantity":
            self._set_quantity(uid, session, text)
        elif mode == "field":
            self._set_field(uid, session, text)
        elif mode == "help_text":
            if not text or len(text) > 2000:
                self._notice(uid, "Опиши вопрос одним сообщением, до 2000 символов. Пароли и коды не отправляй.")
            else:
                self._help_request(uid, text, session.get("help_order"))
                session["mode"] = "navigation"
                self._save(uid, session)
        elif mode == "assistant":
            self._assistant_response(uid, text)
        elif text.startswith("/"):
            self._notice(uid, "Не узнал команду. Можешь просто написать название игры или сервиса — помогу найти. /menu · /assistant · /help")
        else:
            self._assistant_response(uid, text)

    def handle_callback(self, call):
        uid = int(getattr(getattr(call, "from_user", None), "id", 0) or 0)
        if not uid or not self._private(getattr(call, "message", None), uid):
            self._answer(call, "Открой личный чат магазина.")
            return
        raw = str(getattr(call, "data", ""))
        parts = raw.split(":")
        if len(parts) != 3 or parts[0] != "as" or not hmac.compare_digest(parts[2], self._signature(uid, parts[1])):
            self._answer(call, "Кнопка недействительна. Открой /menu.")
            return
        with self._lock(uid):
            session = self._session(uid)
            action = session.get("callbacks", {}).get(parts[1])
            if not action:
                self._answer(call, "Это старое меню. Открой /menu.")
                return
            self._answer(call)
            # Consume all buttons before an action. Repeated callbacks cannot replay checkout/cart writes.
            session["callbacks"] = {}
            self._save(uid, session)
            try:
                self._action(uid, action["name"], action.get("args", {}), session)
            except Exception as exc:
                self._error(uid, exc)

    def _answer(self, call, text=None):
        try:
            self.bot.answer_callback_query(call.id, text=text)
        except Exception:
            pass

    def _action(self, uid, name, args, session):
        if name == "home":
            session["mode"] = "navigation"
            self._send_screen(uid, p.home(self._enabled()), session)
        elif name == "catalog":
            session["mode"] = "navigation"
            data = self.service.categories(parent=args.get("parent"), page=int(args.get("page", 0)), page_size=8)
            self._send_screen(uid, p.catalog(data, args.get("parent")), session)
        elif name == "category":
            category = args["category_id"]
            if category.startswith("brand:"):
                self._action(uid, "catalog", {"parent": category}, session)
            else:
                self._action(uid, "products", {"service_id": category}, session)
        elif name == "products":
            data = self.service.list_products(args.get("service_id"), page=int(args.get("page", 0)), page_size=8, query=args.get("query"))
            self._send_screen(uid, p.products(data, args.get("service_id"), args.get("query")), session)
        elif name in ("product", "toggle_favorite"):
            product_id = args["product_id"]
            if name == "toggle_favorite":
                self.service.toggle_favorite(uid, product_id)
            self._show_product(uid, product_id, session, suggested_quantity=args.get("suggested_quantity"))
        elif name == "variants":
            self._variants(uid, args["product_id"], int(args.get("page", 0)), session)
        elif name == "search":
            self._search_prompt(uid, session)
        elif name == "assistant":
            self._assistant_prompt(uid, session)
        elif name == "assistant_query":
            self._assistant_response(uid, str(args.get("query", "")))
        elif name == "favorites":
            self._send_screen(uid, p.products(self.service.favorites(uid, page=int(args.get("page", 0))), favorite=True), session)
        elif name == "cart":
            session["mode"] = "navigation"
            self._send_screen(uid, p.cart(self.service.cart(uid)), session)
        elif name == "remove_cart":
            self._send_screen(uid, p.cart(self.service.remove_cart(uid, args["item_id"])), session)
        elif name == "clear_cart":
            self._send_screen(uid, p.cart(self.service.clear_cart(uid)), session)
        elif name == "begin_buy":
            self._begin_buy(uid, args["product_id"], session, suggested_quantity=args.get("suggested_quantity"))
        elif name == "quantity":
            self._set_quantity(uid, session, args["quantity"])
        elif name == "quantity_custom":
            session["mode"] = "quantity"
            self._save(uid, session)
            self._notice(uid, "Отправь количество одним числом. Для отмены — /cancel.")
        elif name == "field_select":
            self._set_field(uid, session, args.get("value", ""))
        elif name == "field_skip":
            self._set_field(uid, session, "", skip=True)
        elif name == "field_page":
            if session.get("draft"):
                session["draft"]["field_page"] = int(args.get("page", 0))
                self._next_field(uid, session)
        elif name == "add_cart":
            self._add_cart(uid, session)
        elif name == "checkout":
            self._checkout_preview(uid, session)
        elif name == "confirm_checkout":
            if not self._enabled():
                self._notice(uid, PUBLIC_ERRORS["SHOP_DISABLED"])
                return
            try:
                order = self.service.checkout(uid)
            except Exception as exc:
                if getattr(exc, "code", "") in ("PAYMENT_UNAVAILABLE", "PAYMENTS_DISABLED"):
                    self._send_screen(uid, p.Screen("<b>💳 Оплату подключаем</b>\n\nТовар ещё не оплачен, списаний нет. Твоя корзина сохранена — возвращайся чуть позже 💜", "checkout", p.nav()), session)
                    return
                raise
            self._send_screen(uid, p.order(self._owned_order(uid, str(order["id"]))), session)
        elif name == "orders":
            self._send_screen(uid, p.orders(self.service.orders(uid, page=int(args.get("page", 0)))), session)
        elif name == "order":
            self._send_screen(uid, p.order(self._owned_order(uid, args["order_id"])), session)
        elif name == "profile":
            self._profile(uid, session)
        elif name == "about":
            self._send_screen(uid, p.about(), session)
        elif name == "help":
            order_id = args.get("order_id")
            if order_id:
                self._owned_order(uid, order_id)
            session.update(mode="help_text", help_order=order_id)
            self._send_screen(uid, self._help_screen(order_id), session)
        elif name == "policy":
            self._send_screen(uid, self._policy(args.get("kind", "/terms")), session)
        elif name == "module":
            self._admin_module(uid, args["module"], bool(args["enabled"]))
        elif name == "admin":
            self._admin(uid, args.get("command", "/shop_admin"))
        else:
            self._notice(uid, "Открой /menu и выбери действие заново.")

    def _show_product(self, uid, product_id, session, suggested_quantity=None):
        item = self.service.product(product_id)
        if suggested_quantity is not None:
            minimum, maximum = self._bounds(item)
            try:
                quantity = _integer(suggested_quantity)
                if minimum <= quantity <= maximum:
                    item = dict(item, suggested_quantity=quantity)
            except ValueError:
                pass
        favorite = False
        # The backend exposes this on full cards when available. Avoid scanning all favorites.
        if hasattr(self.service, "is_favorite"):
            favorite = bool(self.service.is_favorite(uid, product_id))
        session["mode"] = "navigation"
        self._send_screen(uid, p.product(item, favorite), session)

    def _variants(self, uid, product_id, page, session):
        item = self.service.product(product_id)
        variants = item.get("variants", [])
        pages = max(1, (len(variants) + 7) // 8)
        page = min(max(page, 0), pages - 1)
        rows = [[p.button(str(v.get("title") or "Вариант")[:36] + " · " + p.rub(v.get("price_rub")), "product", product_id=str(v["id"]))] for v in variants[page * 8:page * 8 + 8]]
        rows += p.pagination("variants", {"page": page, "pages": pages}, product_id=product_id)
        rows += [[p.button("‹ Карточка игры", "product", product_id=product_id)], [p.button("⌂ Меню", "home")]]
        self._send_screen(uid, p.Screen("<b>🎮 " + p.safe(item.get("title"), 150) + "</b>\n\nВыбери издание, номинал или регион. Условия активации указаны в карточке варианта.", item, rows), session)

    def _search_prompt(self, uid, session=None):
        session = self._session(uid) if session is None else session
        session["mode"] = "search"
        self._send_screen(uid, p.Screen("<b>🔎 Найдём то самое</b>\n\nОтправь название игры или сервиса. Например: <b>Steam</b>, <b>Telegram</b>, <b>Minecraft</b>.\n\nДля отмены — /cancel.", "search", p.nav()), session)

    def _search_results(self, uid, query):
        query = query.strip()
        if len(query) < 2 or len(query) > 100:
            self._notice(uid, "Введи от 2 до 100 символов названия товара.")
            return
        data = self.service.list_products(None, page=0, page_size=8, query=query)
        session = self._session(uid)
        session["mode"] = "search"
        if not data.get("items"):
            self._assistant_response(uid, query)
            return
        self._send_screen(uid, p.products(data, query=query), session)

    def _assistant_prompt(self, uid, session=None):
        session = self._session(uid) if session is None else session
        session["mode"] = "assistant"
        self._send_screen(uid, p.assistant(), session)

    def _assistant_response(self, uid, query):
        query = str(query).strip()
        if not query or len(query) > 1000:
            self._notice(uid, "Напиши вопрос или название товара — до 1000 символов. Например: «Хочу пополнить Steam на 156 рублей».")
            return
        session = self._session(uid)
        if not hasattr(self.service, "assistant_response"):
            # Compatibility with offline adapters only; production uses the
            # catalogue-backed assistant and never invents product availability.
            data = self.service.list_products(None, page=0, page_size=8, query=query[:100])
            result = {"answer": "Вот что нашлось в каталоге." if data.get("items") else "Пока не нашёл точного совпадения. Напиши название игры или сервиса иначе — или открой каталог.",
                      "items": data.get("items", []), "actions": [], "context": {}}
        else:
            result = self.service.assistant_response(uid, query, context=session.get("assistant_context"))
        # Backend may persist a safe context too. Merge the current UI session
        # rather than replacing its callback ownership or an unfinished form.
        session = self._session(uid)
        session["mode"] = "assistant"
        session["assistant_context"] = result.get("context") or {}
        self._send_screen(uid, p.assistant(result), session)

    @staticmethod
    def _bounds(item):
        minimum = int(item.get("min_quantity", item.get("min_count", item.get("min", 1))) or 1)
        maximum = int(item.get("max_quantity", item.get("max_count", item.get("max", minimum))) or minimum)
        return max(1, minimum), max(minimum, maximum)

    def _begin_buy(self, uid, product_id, session, suggested_quantity=None):
        if not self._enabled():
            self._notice(uid, PUBLIC_ERRORS["SHOP_DISABLED"])
            return
        item = self.service.product(product_id)
        if item.get("has_variants"):
            self._show_product(uid, product_id, session)
            return
        minimum, maximum = self._bounds(item)
        if not item.get("available", True):
            self._notice(uid, PUBLIC_ERRORS["PRODUCT_UNAVAILABLE"])
            return
        session["draft"] = {"product_id": product_id, "fields": {}, "field_index": 0}
        session["mode"] = "quantity"
        if suggested_quantity is not None:
            try:
                quantity = _integer(suggested_quantity)
                if minimum <= quantity <= maximum:
                    self._set_quantity(uid, session, quantity)
                    return
            except ValueError:
                pass
        if minimum == maximum:
            self._set_quantity(uid, session, minimum)
            return
        choices = sorted({n for n in (minimum, 1, 2, 3, 5, 50, 100, 150, 200, 500) if minimum <= n <= maximum})[:6]
        rows = [[p.button(str(n), "quantity", quantity=n) for n in choices[i:i + 3]] for i in range(0, len(choices), 3)]
        rows += [[p.button("✏️ Другое количество", "quantity_custom")], [p.button("‹ К товару", "product", product_id=product_id)]]
        unit = str(item.get("unit_currency") or "")
        suffix = " " + p.currency_label(unit) if unit in ("RUB", "KZT") else ""
        title = "<b>💸 На какую сумму пополнить?</b>" if unit in ("RUB", "KZT") else "<b>🔢 Сколько нужно?</b>"
        unit_price = "\nЗа 1 " + p.currency_label(unit) + ": <b>" + p.unit_rub(item["unit_price_rub"]) + "</b>." if unit in ("RUB", "KZT") and item.get("unit_price_rub") is not None else ""
        self._send_screen(uid, p.Screen(title + "\n\n" + p.safe(item.get("title"), 140) + f"\nДопустимо: <b>{minimum}–{maximum}{suffix}</b>." + unit_price + "\n\nВыбери кнопку или отправь целое число. Точную стоимость покажем перед добавлением в корзину.", item, rows), session)

    def _set_quantity(self, uid, session, raw):
        draft = session.get("draft")
        if not draft:
            self._notice(uid, "Выбор товара устарел. Открой /menu.")
            return
        item = self.service.product(draft["product_id"])
        minimum, maximum = self._bounds(item)
        try:
            quantity = _integer(raw)
            if not minimum <= quantity <= maximum:
                raise ValueError("bounds")
        except ValueError:
            self._notice(uid, f"Введи целое число от {minimum} до {maximum}. Например: {minimum}.")
            session["mode"] = "quantity"
            self._save(uid, session)
            return
        draft["quantity"] = quantity
        draft["fields"], draft["field_index"] = {}, 0
        self._next_field(uid, session)

    def _requirements(self, product_id):
        return self.service.requirements(product_id) or []

    def _next_field(self, uid, session):
        draft = session["draft"]
        fields = self._requirements(draft["product_id"])
        index = int(draft.get("field_index", 0))
        if index >= len(fields):
            self._draft_review(uid, session)
            return
        field = fields[index]
        session["mode"] = "field"
        label = p.safe(field.get("label") or field.get("name"), 140)
        text = f"<b>📝 Данные получателя · {index + 1}/{len(fields)}</b>\n\n<b>{label}</b>\n"
        if field.get("is_account"):
            text += "Укажи только логин или ID аккаунта. Пароль и коды входа не нужны.\n"
        if field.get("description"):
            text += p.safe(field["description"], 220) + "\n"
        options = self._options(field)
        page = max(0, min(int(draft.get("field_page", 0)), max(0, (len(options) - 1) // 8)))
        rows = [[p.button(str(label)[:58], "field_select", value=value)] for value, label in options[page * 8:page * 8 + 8]]
        rows += p.pagination("field_page", {"page": page, "pages": max(1, (len(options) + 7) // 8)})
        if not field.get("required", True):
            rows.append([p.button("Пропустить", "field_skip")])
        rows += [[p.button("✕ Отменить", "home")]]
        text += "\nВыбери вариант кнопкой." if options else "\nОтправь значение одним сообщением. Перед оформлением всё проверим вместе."
        self._send_screen(uid, p.Screen(text, "checkout", rows), session)

    @staticmethod
    def _options(field):
        options = field.get("options") or []
        if isinstance(options, dict):
            return [(str(k), str(v)) for k, v in options.items()]
        result = []
        for option in options:
            if isinstance(option, dict):
                value = option.get("value", option.get("id", option.get("name", "")))
                label = option.get("label", option.get("title", option.get("name", value)))
                result.append((str(value), str(label)))
            else:
                result.append((str(option), str(option)))
        return result

    def _set_field(self, uid, session, raw, skip=False):
        draft = session.get("draft")
        if not draft:
            self._notice(uid, "Выбор товара устарел. Открой /menu.")
            return
        requirements = self._requirements(draft["product_id"])
        index = int(draft.get("field_index", 0))
        if index >= len(requirements):
            self._draft_review(uid, session)
            return
        field = requirements[index]
        value = str(raw).strip()
        if skip and field.get("required", True):
            self._notice(uid, "Это поле обязательно. Отправь значение.")
            return
        if not value and field.get("required", True):
            self._notice(uid, "Значение не должно быть пустым.")
            return
        if len(value) > 500 or any(ord(ch) < 32 for ch in value):
            self._notice(uid, "Введи значение одной строкой, до 500 символов.")
            return
        options = self._options(field)
        if options and value and value not in {option[0] for option in options}:
            self._notice(uid, "Выбери один из доступных вариантов кнопкой.")
            return
        kind = str(field.get("type", "text")).lower()
        if value and kind == "text":
            minimum = int(field.get("min") or 0)
            maximum = min(500, int(field.get("max") or 500))
            if not minimum <= len(value) <= maximum:
                self._notice(uid, f"Для этого поля нужно от {minimum} до {maximum} символов.")
                return
        if value and kind in ("integer", "int", "number", "numeric"):
            try:
                amount = Decimal(value)
                if not amount.is_finite() or (kind in ("integer", "int") and amount != amount.to_integral_value()):
                    raise InvalidOperation
                if field.get("min") is not None and amount < Decimal(str(field["min"])):
                    raise InvalidOperation
                if field.get("max") is not None and amount > Decimal(str(field["max"])):
                    raise InvalidOperation
            except (InvalidOperation, ValueError):
                self._notice(uid, "Проверь число и допустимый диапазон этого поля.")
                return
        if value and field.get("is_account") and (" " in value or len(value) < 2):
            self._notice(uid, "Укажи логин или ID без пробелов. Пароли не отправляй.")
            return
        # Provider patterns are validated again by the backend. Avoid executing arbitrary regex here.
        draft["fields"][str(field["name"])] = value
        draft["field_index"] = index + 1
        draft["field_page"] = 0
        self._next_field(uid, session)

    def _draft_review(self, uid, session):
        draft = session["draft"]
        item = self.service.product(draft["product_id"])
        quantity = int(draft["quantity"])
        text = "<b>💜 Проверь перед покупкой</b>\n\n<b>" + p.safe(item.get("title"), 140) + f"</b>\nКоличество: <b>{quantity}</b>\n"
        text += p.field_summary(draft["fields"], self._requirements(draft["product_id"]))
        if hasattr(self.service, "quote"):
            quote = self.service.quote(uid, draft["product_id"], quantity=quantity, fields=draft["fields"])
            text += "\n\nСтоимость: <b>" + p.rub(quote.get("total_rub")) + "</b>\nЦена и наличие перепроверяются при оформлении.\n"
        else:
            text += "\n\nИтоговая цена появится в корзине, до оплаты.\n"
        if item.get("warning"):
            text += "\n⚠️ " + p.safe(item["warning"], 200) + "\n"
        text += "\nДанные верны? Добавь в корзину. Это ещё не оплата."
        session["mode"] = "review"
        self._send_screen(uid, p.Screen(text, "checkout", [[p.button("✓ Всё верно · в корзину", "add_cart")], [p.button("✏️ Заполнить заново", "begin_buy", product_id=draft["product_id"])], [p.button("✕ Отмена", "home")]]), session)

    def _add_cart(self, uid, session):
        draft = session.get("draft")
        if session.get("mode") != "review" or not draft:
            self._notice(uid, "Проверь товар заново перед добавлением.")
            return
        data = self.service.add_to_cart(uid, draft["product_id"], quantity=int(draft["quantity"]), fields=draft["fields"])
        session.pop("draft", None)
        session["mode"] = "navigation"
        self._send_screen(uid, p.cart(data), session)

    def _checkout_preview(self, uid, session):
        data = self.service.cart(uid)
        if not data.get("items"):
            self._send_screen(uid, p.cart(data), session)
            return
        text = "<b>💳 Последняя проверка</b>\n\n"
        for item in data["items"][:20]:
            text += "• <b>" + p.safe(item.get("title"), 70) + "</b> × " + p.safe(item.get("quantity"), 15) + "\n"
            for key, value in (item.get("fields") or {}).items():
                text += "  " + p.safe(key, 45) + ": " + p.safe(value, 80) + "\n"
        text += "\nИтого: <b>" + p.rub(data.get("total_rub")) + "</b>\n\nПосле подключения оплаты здесь будет доступно оформление. Сейчас товар ещё не оплачен, списаний нет.\n\nОформляя заказ, проверь регион и данные получателя. /terms · /privacy · /paysupport"
        self._send_screen(uid, p.Screen(text, "checkout", [[p.button("💳 Проверить доступность оплаты", "confirm_checkout")], [p.button("‹ В корзину", "cart")], [p.button("💬 Поддержка", "help")]]), session)

    def _owned_order(self, uid, order_id):
        order = self.service.order(uid, order_id)
        owner = order.get("user_id", order.get("buyer_id", uid))
        if int(owner) != uid:
            raise ValueError("Order ownership mismatch")
        return order

    def _profile(self, uid, session):
        self._send_screen(uid, p.Screen("<b>👤 Твой Aisklad</b>\n\nЗаказы, избранное и помощь — всегда под рукой.\n\n🔐 Магазин не запрашивает пароль аккаунта, Steam Guard или данные банковской карты в сообщениях.\n\nПравила: /terms\nДанные: /privacy\nВопрос об оплате: /paysupport", "profile", [[p.button("📦 Мои заказы", "orders"), p.button("💜 Избранное", "favorites")], [p.button("💬 Поддержка", "help")], [p.button("⌂ Меню", "home")]]), session)

    @staticmethod
    def _help_screen(order_id=None):
        detail = "\nЗаказ: <b>" + p.safe(order_id, 50) + "</b>\n" if order_id else ""
        return p.Screen("<b>💬 Мы рядом</b>\n" + detail + "\nОпиши вопрос одним сообщением. Если есть заказ — укажи его номер. Обращение увидит владелец магазина.\n\nНе отправляй пароли, коды входа или данные карты.\n\nКоманда <b>!помощь</b> доступна в любой момент.", "help", [[p.button("📦 Мои заказы", "orders"), p.button("⌂ Меню", "home")]])

    def _help_request(self, uid, text, order_id=None):
        if order_id:
            self._owned_order(uid, order_id)
        result = self.service.request_help(uid, text[:2000], order_id=order_id)
        ticket = result.get("ticket_id") if isinstance(result, dict) else ""
        self._notice(uid, "💜 Обращение " + ("<b>" + p.safe(ticket, 40) + "</b> " if ticket else "") + "отправлено. Пожалуйста, не повторяй команду — сообщение уже сохранено.")

    @staticmethod
    def _policy(command):
        if command == "/privacy":
            caption = "<b>🔐 Твои данные</b>\n\nДля заказа сохраняются Telegram ID, выбранный товар, данные получателя, история оплаты и выдачи. Данные получателя передаются поставщику для исполнения заказа. Пароли аккаунтов и данные карты в чате не нужны.\n\nДля вопроса о своих данных и их удалении отправь /help. Сведения об исполненных и спорных заказах могут понадобиться для проверки обращения."
        else:
            caption = "<b>📋 Перед покупкой</b>\n\nПроверь товар, регион, издание, количество и данные получателя. Ключи и коды выдаются в личном чате; пополнения отправляются на указанный аккаунт. Ожидай именно подтверждения выдачи, а не только оплаты.\n\nЕсли возникла проблема с оплатой или получением, используй /paysupport и укажи номер заказа. Условия конкретного товара указаны в его карточке.\n\nПока оплата не подключена, покупки и списания недоступны."
        return p.Screen(caption, "help", [[p.button("💬 Поддержка", "help"), p.button("⌂ Меню", "home")]])

    def _admin(self, uid, command):
        if not self.owner_id or uid != self.owner_id:
            self._notice(uid, "Эта команда доступна владельцу. Каталог магазина — /menu.")
            return
        if command == "/shop_sync":
            self._admin_sync(uid)
            return
        if command == "/shop_balance":
            self._admin_balance(uid)
            return
        if command == "/shop_stats":
            self._admin_stats(uid)
            return
        if command == "/shop_resume":
            self.service.reset_health()
            if self.module_controller is not None:
                self.module_controller.set_enabled("shop", True, uid)
            else:
                self.service.set_enabled(True)
            self._notice(uid, "▶️ Оформление в Aisklad SHOP разрешено. Счётчики сбоев сброшены. Настройки оплаты не изменены; уже оплаченные заказы продолжают обрабатываться.")
            self._admin(uid, "/shop_admin")
            return
        if command != "/shop_admin":
            module, enabled = command[1:].rsplit("_", 1)
            self._admin_module(uid, module, enabled == "on")
            return
        if self.module_controller is None:
            self._notice(uid, "Управление модулями пока недоступно. Повтори позже.")
            return
        state = self.module_controller.status()
        rows = []
        for module, label in (("shop", "Telegram-магазин"), ("funpay", "FunPay")):
            enabled = bool(state.get(module, False))
            rows.append([p.button(("⏸ Отключить " if enabled else "▶️ Включить ") + label, "module", module=module, enabled=not enabled)])
        rows += [[p.button("↻ Обновить каталог", "admin", command="/shop_sync"), p.button("💵 Баланс STEAM.RU", "admin", command="/shop_balance")],
                 [p.button("📊 Статистика", "admin", command="/shop_stats"), p.button("▶️ Снять паузу сбоев", "admin", command="/shop_resume")],
                 [p.button("⌂ В магазин", "home")]]
        text = "<b>⚙️ Модули Aisklad</b>\n\nTelegram-магазин: <b>" + ("включён" if state.get("shop") else "выключен") + "</b>\nFunPay: <b>" + ("включён" if state.get("funpay") else "выключен") + "</b>\n\nОтключение магазина запрещает новые покупки. Выполнение уже оплаченных заказов и проверка их статуса продолжаются."
        status = self.service.status()
        active = (status.get("catalog") or {}).get("active") or {}
        text += "\n\nКаталог: <b>" + str(int(active.get("indexed", 0) or 0)) + "</b> позиций"
        text += "\nОбновление: <b>" + self._catalog_state(status.get("catalog") or {}) + "</b>"
        text += "\nПауза после сбоев: <b>" + ("да" if status.get("health_paused") else "нет") + "</b>"
        text += "\nОплата: <b>" + ("подключена" if status.get("payment_enabled") else "не подключена") + "</b>"
        self._send_screen(uid, p.Screen(text, "profile", rows))

    @staticmethod
    def _catalog_state(catalog):
        attempt = catalog.get("last_attempt") or catalog.get("active") or {}
        state = str(attempt.get("state", "empty"))
        return {"syncing": "обновляется", "complete": "готов", "error": "предыдущее обновление не завершено", "failed": "предыдущее обновление не завершено", "busy": "обновляется", "empty": "ожидает загрузки"}.get(state, "ожидает проверки")

    def _start_admin_job(self, uid, key, notice, task):
        """Owner I/O runs independently of buyer handlers, one job of each type."""
        with self._admin_job_lock:
            prior = self._admin_jobs.get(key)
            if prior is not None and prior.is_alive():
                self._notice(uid, "⏳ Эта проверка уже идёт. Дождись итогового сообщения.")
                return
            self._notice(uid, notice)
            def run_job():
                try:
                    text = task()
                    if not self._stopped.is_set():
                        self._notice(uid, text)
                except Exception as exc:
                    LOG.warning("Owner shop job failed: %s/%s", key, type(exc).__name__)
                    if not self._stopped.is_set():
                        try:
                            self._notice(uid, "Не удалось завершить проверку. Секретные данные в сообщениях не показываются. Попробуй позже; оплаченные заказы остаются в базе.")
                        except Exception:
                            pass
            worker = threading.Thread(target=run_job, name="aisklad-admin-" + key, daemon=True)
            self._admin_jobs[key] = worker
            worker.start()

    def _admin_sync(self, uid):
        def sync():
            result = self.service.sync_catalog()
            if result.get("state") == "busy":
                return "⏳ Каталог уже обновляется в фоне. Состояние можно посмотреть через /shop_stats."
            return "✅ Каталог обновлён.\nПозиций: <b>" + str(int(result.get("indexed", 0) or 0)) + "</b>\nСервисов: <b>" + str(int(result.get("services", 0) or 0)) + "</b>\nВарианты игр проверяются при открытии карточки."
        self._start_admin_job(uid, "catalog", "↻ Обновляю полный каталог STEAM.RU. Старый каталог доступен до завершения загрузки; повторять команду не нужно.", sync)

    def _admin_balance(self, uid):
        def balance():
            data = self.service.balance()
            try:
                amount = Decimal(str(data["balance_usd"]))
                if not amount.is_finite() or amount < 0:
                    raise InvalidOperation
            except (KeyError, ValueError, InvalidOperation):
                raise ValueError("Invalid balance") from None
            return "<b>💵 Баланс STEAM.RU</b>\n\nДоступно: <b>$" + p.safe(format(amount, "f"), 40) + "</b>\nБаланс общий для магазина и FunPay. Эта проверка ничего не покупает."
        self._start_admin_job(uid, "balance", "💵 Проверяю текущий баланс STEAM.RU…", balance)

    def _admin_stats(self, uid):
        data = self.service.stats()
        status = self.service.status()
        catalog = data.get("catalog") or status.get("catalog") or {}
        active = catalog.get("active") or {}
        text = "<b>📊 Aisklad SHOP · Статистика</b>\n\nКаталог: <b>" + str(int(active.get("indexed", 0) or 0)) + "</b> позиций\nОбновление: <b>" + self._catalog_state(catalog) + "</b>\n"
        text += "Заказов: <b>" + str(int(data.get("orders_total", 0) or 0)) + "</b>\nПокупателей: <b>" + str(int(data.get("customers", 0) or 0)) + "</b>\n"
        for state, count in sorted((data.get("order_statuses") or {}).items()):
            text += "• " + p.safe(p.STATUS.get(str(state), "Проверяется"), 60) + ": <b>" + str(int(count)) + "</b>\n"
        health = data.get("health") or {}
        text += "\nПауза после сбоев: <b>" + ("да" if status.get("health_paused") else "нет") + "</b>\nПоследовательные сбои (порог 7):\n"
        names = {"catalog": "Каталог", "product_read": "Проверка товаров", "fulfillment_read": "Проверка выдачи"}
        text += "\n".join("• " + p.safe(names.get(str(scope), "Модуль магазина"), 60) + ": <b>" + str(int(count)) + "/7</b>" for scope, count in sorted(health.items())) if health else "• Ошибок нет"
        self._send_screen(uid, p.Screen(text, "profile", [[p.button("↻ Обновить статистику", "admin", command="/shop_stats")], [p.button("⚙️ Управление", "admin", command="/shop_admin")], [p.button("⌂ В магазин", "home")]]))

    def _admin_module(self, uid, module, enabled):
        if uid != self.owner_id or not self.owner_id:
            self._notice(uid, "Команда доступна владельцу.")
            return
        if module not in ("shop", "funpay") or self.module_controller is None:
            self._notice(uid, "Управление модулем недоступно.")
            return
        self.module_controller.set_enabled(module, bool(enabled), uid)
        if module == "funpay" and enabled:
            self._notice(uid, "Модуль FunPay разрешён. В управляющем боте проверь /sr_status и используй /sr_resume для включения продаж.")
        self._admin(uid, "/shop_admin")

    def _admin_reply(self, uid, arguments):
        """Both bot entrypoints use the same guarded, durable support queue."""
        from .support import queue_reply
        self._notice(uid, queue_reply(self.store, self.owner_id, uid, arguments))

    def send_pending_notifications(self, limit=50):
        """At-least-once delivery of an existing order; never creates supplier orders.

        If Telegram accepted a send but the connection died before acknowledgement,
        the same existing voucher can reappear. A purchase cannot repeat here.
        """
        for event in self.service.pending_notifications(limit=limit):
            uid = int(event.get("user_id", 0) or 0)
            if uid <= 0:
                continue
            payload = event.get("payload") or {}
            if not isinstance(payload, dict):
                continue
            try:
                with self._lock(uid):
                    kind = str(event.get("kind") or "")
                    owner_event = kind.startswith("owner:") or (uid == self.owner_id and kind in ("support", "support_detail", "system", "alert"))
                    if owner_event:
                        if uid != self.owner_id or not self.owner_id:
                            continue
                        text = "<b>🔔 Aisklad SHOP</b>\n\n" + p.safe(payload.get("text") or "Есть обновление магазина.", 2200)
                        if payload.get("order_id"):
                            text += "\nЗаказ: <b>" + p.safe(payload["order_id"], 60) + "</b>"
                        if payload.get("ticket_id"):
                            text += "\nОбращение: <b>" + p.safe(payload["ticket_id"], 60) + "</b>"
                            if re.fullmatch(r"[A-Za-z0-9_-]{1,100}", str(payload["ticket_id"])):
                                text += "\n\nОтветить: <code>/shop_reply " + p.safe(payload["ticket_id"], 100) + " текст ответа</code>"
                        if payload.get("user_id"):
                            text += "\nПокупатель: <code>" + p.safe(payload["user_id"], 30) + "</code>"
                        if self.owner_notifier is not None:
                            chunks = [text] if len(text) <= 3900 else [p.safe(_plain(text)[i:i + 600], None) for i in range(0, len(_plain(text)), 600)]
                            for chunk in chunks:
                                if self.owner_notifier(uid, chunk) is False:
                                    raise RuntimeError("Owner notification rejected")
                        else:
                            self._notice(uid, text)
                    elif payload.get("order_id"):
                        order = self._owned_order(uid, str(payload["order_id"]))
                        self._send_screen(uid, p.order(order), reuse=False)
                    else:
                        text = str(payload.get("text") or "Есть обновление по заказу. Открой /orders.")
                        self._notice(uid, p.safe(text, 2400))
                self.service.ack_notification(event["id"])
            except Exception as exc:
                LOG.warning("Shop notification retained: %s", type(exc).__name__)
