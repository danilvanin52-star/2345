"""Buyer-facing copy and screen descriptions, independent of Telegram/network."""
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from html import escape
from typing import Any


BRAND = "Aisklad SHOP"
MENU_KEYS = ("home", "catalog", "search", "favorites", "cart", "checkout", "orders", "profile", "help", "product")


def safe(value: Any, limit: int = 350) -> str:
    """External catalogue and buyer content is always escaped before HTML use."""
    text = str(value or "").replace("\x00", "")
    return escape(text if limit is None or len(text) <= limit else text[:limit - 1] + "…", quote=True)


def rub(value: Any) -> str:
    try:
        number = Decimal(str(value)).quantize(Decimal("0.01"))
        if not number.is_finite() or number < 0:
            raise InvalidOperation
        return f"{number:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
    except (InvalidOperation, ValueError, TypeError):
        return "уточняется"


@dataclass
class Action:
    label: str
    name: str
    args: dict = field(default_factory=dict)


@dataclass
class Screen:
    caption: str
    image: Any = "home"
    rows: list = field(default_factory=list)


def button(label, name, **args):
    return Action(label, name, args)


def nav():
    return [[button("🛍 Каталог", "catalog"), button("🛒 Корзина", "cart")], [button("⌂ Главное меню", "home")]]


def home(enabled=True):
    state = "Выбирай товар — подскажем данные и покажем итоговую цену перед оплатой." if enabled else "Магазин временно на паузе. Каталог и история доступны; новые покупки пока закрыты."
    return Screen(
        "<b>✨ Aisklad SHOP</b>\n<i>Игры. Пополнения. Цифровые подарки.</i>\n\n"
        + state + "\n\n🔐 Только необходимые данные. Пароли и коды входа не нужны.\n"
        "💬 Нужен человек? Отправь <b>!помощь</b>.", "home",
        [[button("🛍 Открыть каталог", "catalog")], [button("🔎 Найти товар", "search"), button("💜 Избранное", "favorites")],
         [button("🛒 Моя корзина", "cart"), button("📦 Мои заказы", "orders")],
         [button("👤 Профиль", "profile"), button("💬 Поддержка", "help")]])


def catalog(data, parent=None):
    rows = [[button(str(item.get("title") or "Категория")[:55], "category", category_id=str(item["id"]))] for item in data.get("items", [])]
    rows += pagination("catalog", data, parent=parent)
    rows += [[button("🔎 Поиск по всему каталогу", "search"), button("⌂ Меню", "home")]]
    total = int(data.get("total", 0))
    return Screen("<b>🛍 Каталог Aisklad SHOP</b>\n\nВыбери категорию. В карточке товара — цена, регион и условия получения.\n\n"
                  + (f"Категорий: <b>{total}</b>" if total else "Каталог обновляется. Попробуй немного позже."), "catalog", rows)


def pagination(action, data, **args):
    page, pages = int(data.get("page", 0)), max(1, int(data.get("pages", 1)))
    row = []
    if page > 0:
        row.append(button("‹ Назад", action, page=page - 1, **args))
    if page + 1 < pages:
        row.append(button("Далее ›", action, page=page + 1, **args))
    return [row] if row else []


def products(data, service_id=None, query=None, favorite=False):
    rows = []
    for item in data.get("items", []):
        prefix = "🎮 " if item.get("kind") in ("key", "key_group", "gift", "gift_group") else "✨ "
        price = "" if item.get("has_variants") else " · от " + rub(item.get("price_rub"))
        rows.append([button(prefix + str(item.get("title") or "Товар")[:38] + price, "product", product_id=str(item["id"]))])
    action = "favorites" if favorite else "products"
    if favorite:
        args = {}
        title, image = "<b>💜 Избранное</b>", "favorites"
        empty = "Сохрани понравившийся товар сердечком в его карточке."
    elif query:
        args = {"query": query, "service_id": service_id}
        title, image = "<b>🔎 Результаты поиска</b>\nЗапрос: " + safe(query, 100), "search"
        empty = "Ничего не нашлось. Попробуй другое название или открой каталог."
    else:
        args = {"service_id": service_id}
        title, image, empty = "<b>✨ Выбери товар</b>", "catalog", "В этой категории пока нет доступных товаров."
    rows += pagination(action, data, **args)
    rows += [[button("🔎 Другой поиск", "search"), button("🛍 Каталог", "catalog")], [button("⌂ Меню", "home")]]
    caption = title + "\n\n" + (f"Найдено: <b>{int(data.get('total', 0))}</b>. Открой карточку для подробностей." if data.get("items") else empty)
    return Screen(caption, image, rows)


def product(item, is_favorite=False):
    title = safe(item.get("title"), 140)
    price = rub(item.get("price_rub"))
    text = f"<b>{'🎮' if item.get('kind') in ('key','key_group','gift','gift_group') else '✨'} {title}</b>\n\n"
    if not item.get("has_variants"):
        minimum = item.get("min_quantity", item.get("min_count", 1)) or 1
        text += f"От <b>{price}</b> за {safe(minimum, 20)} ед.\n"
    if item.get("region"):
        text += "🌍 Регион: <b>" + safe(item["region"], 100) + "</b>\n"
    if item.get("description"):
        text += "\n" + safe(item["description"], 320) + "\n"
    if item.get("warning"):
        text += "\n⚠️ " + safe(item["warning"], 220) + "\n"
    text += "\n📦 Ключ или код придёт сюда после подтверждённой оплаты и выдачи поставщиком. Пополнение отправляется на указанный аккаунт."
    rows = []
    if item.get("has_variants"):
        text += "\n\nВыбери издание, регион или номинал:"
        for variant in item.get("variants", [])[:8]:
            rows.append([button(str(variant.get("title") or "Вариант")[:36] + " · " + rub(variant.get("price_rub")), "product", product_id=str(variant["id"]))])
        if len(item.get("variants", [])) > 8:
            rows.append([button("Все варианты ›", "variants", product_id=str(item["id"]), page=0)])
    elif item.get("available", True):
        rows.append([button("🛒 Выбрать количество", "begin_buy", product_id=str(item["id"]))])
    else:
        text += "\n\n⏳ Сейчас недоступен для покупки."
    rows += [[button("💜 В избранном" if is_favorite else "♡ Сохранить", "toggle_favorite", product_id=str(item["id"]))]]
    rows += nav()
    return Screen(text, item, rows)


def field_summary(fields, requirements):
    labels = {str(f.get("name")): str(f.get("label") or f.get("name")) for f in requirements}
    return "\n".join("• " + safe(labels.get(str(key), key), 80) + ": <b>" + safe(value, 120) + "</b>" for key, value in fields.items())


def cart(data):
    rows, text = [], "<b>🛒 Твоя корзина</b>\n\n"
    items = data.get("items", [])
    if not items:
        text += "Здесь пока пусто. Выбери что-нибудь в каталоге ✨"
    else:
        for index, item in enumerate(items, 1):
            text += f"<b>{index}. {safe(item.get('title'), 70)}</b>\nКоличество: {safe(item.get('quantity'), 30)} · {rub(item.get('total_rub'))}\n\n"
            rows.append([button("✕ " + str(item.get("title") or "Убрать")[:38], "remove_cart", item_id=str(item["id"]))])
        text += "Итого: <b>" + rub(data.get("total_rub")) + "</b>\nЦена и наличие будут проверены ещё раз перед оплатой."
        rows += [[button("💳 Перейти к оформлению", "checkout")], [button("🧹 Очистить корзину", "clear_cart")]]
    rows += [[button("🛍 Продолжить покупки", "catalog"), button("⌂ Меню", "home")]]
    return Screen(text, "cart", rows)


STATUS = {"awaiting_payment": "Ожидает оплаты", "pending_payment": "Ожидает оплаты", "paid": "Оплачен", "processing": "В работе",
          "completed": "Выполнен", "delivered": "Выдан", "refunded": "Возврат подтверждён", "cancelled": "Отменён", "review": "Проверяет поддержка",
          "error": "Нужна проверка", "pending": "В обработке", "payment_failed": "Оплата не завершена", "fulfilling": "Выполняется",
          "needs_review": "Проверяет поддержка", "uncertain": "Проверяем результат", "refund_required": "Возврат проверяется",
          "invoice_uncertain": "Проверяем создание счёта", "creating_invoice": "Создаётся счёт", "partially_completed": "Частично выполнен"}


def orders(data):
    rows = [[button("📦 " + str(item.get("id"))[:16] + " · " + STATUS.get(str(item.get("status")), "Проверяем статус"), "order", order_id=str(item["id"]))] for item in data.get("items", [])]
    rows += pagination("orders", data)
    rows += [[button("⌂ Главное меню", "home")]]
    return Screen("<b>📦 Мои заказы</b>\n\n" + ("Открой заказ, чтобы увидеть статус и выданный код." if data.get("items") else "Твоих заказов пока нет. Начни с каталога — найдём что-нибудь интересное."), "orders", rows)


def order(data):
    text = "<b>📦 Заказ " + safe(data.get("id"), 50) + "</b>\n\nСтатус: <b>" + safe(STATUS.get(str(data.get("status")), "Проверяем статус")) + "</b>\n"
    text += "Сумма: <b>" + rub(data.get("total_rub")) + "</b>\n"
    for item in data.get("items", [])[:10]:
        text += "\n• " + safe(item.get("title"), 100) + " × " + safe(item.get("quantity", 1), 30)
    delivered = data.get("delivery") or []
    if delivered:
        text += "\n\n<b>🎉 Твой товар</b>\n" + "\n\n".join("<code>" + safe(code, None) + "</code>" for code in delivered)
        text += "\n\nСохрани код и проверь регион активации в карточке товара. Спасибо за покупку! 💜"
    else:
        text += "\n\nОбнови статус позже. При задержке нажми «Помощь с заказом» — мы проверим его."
    rows = [[button("↻ Обновить статус", "order", order_id=str(data["id"]))], [button("💬 Помощь с заказом", "help", order_id=str(data["id"]))], [button("📦 Все заказы", "orders"), button("⌂ Меню", "home")]]
    return Screen(text, "orders", rows)


def gallery_examples():
    """Real screen copy for the root's offline HTML preview; no synthetic live claims."""
    example = {"id": "preview-steam", "title": "Steam · Пополнение баланса", "price_rub": "102.40", "min_quantity": 100, "available": True,
               "region": "Регион аккаунта проверяется перед покупкой", "description": "Укажи логин Steam и сумму пополнения. Пароль и Steam Guard не нужны.", "kind": "topup"}
    return {"home": home(), "catalog": catalog({"items": [{"id": "steam", "title": "🎮 Steam"}, {"id": "telegram", "title": "⭐ Telegram"}], "total": 2}),
            "search": Screen("<b>🔎 Найдём то самое</b>\n\nОтправь название игры или сервиса. Например: Steam, Telegram, Minecraft.", "search", nav()),
            "favorites": products({"items": [example], "total": 1}, favorite=True), "product": product(example),
            "cart": cart({"items": [{"id": "preview", "title": "Steam · Пополнение баланса", "quantity": 100, "total_rub": "102.40"}], "total_rub": "102.40"}),
            "checkout": Screen("<b>💳 Всё готово к оформлению</b>\n\nПроверь товары, количество и данные получателя.\n\nИтого: <b>102,40 ₽</b>\n\nПлатёжный провайдер ещё не подключён. Деньги не списываются.", "checkout", nav()),
            "orders": orders({"items": [], "total": 0}), "profile": Screen("<b>👤 Твой Aisklad</b>\n\nЗаказы, избранное и помощь — всегда под рукой.", "profile", nav()),
            "help": Screen("<b>💬 Мы рядом</b>\n\nНапиши, что случилось. Не отправляй пароли, коды входа или данные карты.\n\nКоманда <b>!помощь</b> доступна в любой момент.", "help", nav())}
