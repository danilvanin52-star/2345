"""Stars category fields observed on the user's disabled FunPay offer."""
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace as N
from unittest.mock import patch

from test_cardinal_compatibility import source_interfaces, full_order, shortcut
from test_safety_integration import Cardinal, API
import steamru_stars as bot
from steamru_stars_engine import Store, effective_exchange_rate


def rule(stars):
    return {"subcategory_id": 2418, "stars_per_unit": stars,
            "match_fields": {"quantity": f"{stars} звёзд", "quantity2": "", "method": "По username"}}


class Stars2418Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api_types = source_interfaces()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / "orders.db")
        self.store.set_meta("paused", "no")
        self.old = bot.CFG, bot.STORE
        bot.STORE = self.store
        bot.STOP.clear()
        bot.CFG = {**bot.DEFAULT, "mode": "dry_run", "capture_paid_orders_in_dry_run": True,
                   "allowed_subcategory_ids": [2418], "lot_rules": {"stars50": rule(50)},
                   "wallet_paid_rub": "521.01", "wallet_credited_usd": "5.96",
                   "rub_per_usd": str(effective_exchange_rate("521.01", "5.96")),
                   "rub_per_usd_updated_at": datetime.now(timezone.utc).isoformat(),
                   "dry_run_price_usd": "0.0152"}
        self.order = full_order(self.api_types, title="", amount=None, subcategory_id=2418)
        self.order.fields = {"quantity": self.api_types.LotField("quantity", "50 звёзд"),
                             "quantity2": self.api_types.LotField("quantity2", ""),
                             "method": self.api_types.LotField("method", "По username")}
        self.order.sum = Decimal("75")
        self.c = Cardinal(self.order)

    def tearDown(self):
        bot.CFG, bot.STORE = self.old
        self.temp.cleanup()

    def capture(self):
        event_order = shortcut(self.api_types, description="50 звёзд, По username")
        event_order.subcategory.id = 2418
        bot.on_new_order(self.c, self.api_types.NewOrderEvent("offline", event_order))
        return self.store.get("ABCD1234")

    def test_real_order_without_summary_uses_exact_package_fields(self):
        title, amount, stars, revenue = bot.full_order_data(self.c, self.order, "ABCD1234")
        self.assertEqual((title, amount, stars, revenue), ("rule:stars50", 1, 50, Decimal("75")))

    def test_generated_shortcut_description_is_not_required_to_equal_title(self):
        row = self.capture()
        self.assertEqual(row["description"], "rule:stars50")
        self.assertEqual(row["stars"], 50)
        self.assertEqual(row["captured_mode"], "dry_run")

    def test_explicit_dry_run_simulates_package_without_any_supplier_client(self):
        self.capture()
        self.store.set_username("ABCD1234", 12, "users-7-12", "recipient123")
        with patch.object(bot, "client", side_effect=AssertionError("No supplier calls")):
            bot.simulate_ready(self.c)
        self.assertEqual(self.store.get("ABCD1234")["status"], "simulated")
        self.assertEqual(self.store.get("ABCD1234")["supplier_uuid"], None)

    def test_three_explicit_packages_are_supported(self):
        bot.CFG["lot_rules"] = {f"stars{n}": rule(n) for n in (50, 100, 150)}
        for stars in (50, 100, 150):
            self.order.fields["quantity"].value = f"{stars} звёзд"
            self.assertEqual(bot.full_order_data(self.c, self.order, "ABCD1234")[2], stars)

    def test_wrong_method_or_custom_quantity_is_rejected(self):
        for field, bad in (("method", "По ссылке"), ("quantity2", "100"), ("quantity", "250 звёзд")):
            old = self.order.fields[field].value
            self.order.fields[field].value = bad
            try:
                with self.assertRaises(ValueError):
                    bot.full_order_data(self.c, self.order, "ABCD1234")
            finally:
                self.order.fields[field].value = old

    def test_missing_quantity_is_rejected(self):
        del self.order.fields["quantity"]
        with self.assertRaises(ValueError):
            bot.full_order_data(self.c, self.order, "ABCD1234")

    def test_summary_cannot_override_wrong_package_fields(self):
        self.order.fields["summary"] = self.api_types.LotField("summary", "STEAMRU TG STARS 50")
        self.order.fields["quantity"].value = "250 звёзд"
        with self.assertRaises(ValueError):
            bot.full_order_data(self.c, self.order, "ABCD1234")

    def test_ambiguous_rules_are_rejected(self):
        bot.CFG["lot_rules"]["duplicate50"] = rule(50)
        with self.assertRaises(ValueError):
            bot.full_order_data(self.c, self.order, "ABCD1234")

    def test_changed_package_after_capture_is_rejected(self):
        row = self.capture()
        bot.CFG["lot_rules"]["stars100"] = rule(100)
        self.order.fields["quantity"].value = "100 звёзд"
        with self.assertRaises(ValueError):
            bot.preflight(self.c, row)

    def test_multiple_units_cannot_exceed_150(self):
        self.order.amount = 4
        with self.assertRaises(ValueError):
            bot.full_order_data(self.c, self.order, "ABCD1234")
        self.order.amount = 3
        self.assertEqual(bot.full_order_data(self.c, self.order, "ABCD1234")[2], 150)

    def test_72_rub_is_blocked_and_75_passes_current_margin(self):
        with self.assertRaises(ValueError):
            bot.verify_price(self.c, {"stars": 50}, "0.0152", Decimal("72"))
        total, cash = bot.verify_price(self.c, {"stars": 50}, "0.0152", Decimal("75"))
        self.assertEqual(total, Decimal("0.7600"))
        self.assertGreater(cash["profit"], Decimal("6"))

    def test_72_rub_passes_explicit_user_margin_four_percent(self):
        bot.CFG["min_margin_pct"] = "4"
        _, cash = bot.verify_price(self.c, {"stars": 50}, "0.0152", Decimal("72"))
        self.assertGreater(cash["profit"], Decimal("3"))
        self.assertGreater(cash["margin_pct"], Decimal("4"))

    def test_invalid_rules_do_not_load(self):
        invalid = ([], {"x": {}}, {"x": {**rule(50), "stars_per_unit": 250}},
                   {"x": {**rule(50), "match_fields": {}}})
        for item in invalid:
            with self.assertRaises(ValueError):
                bot.validate_lot_rules(item)
