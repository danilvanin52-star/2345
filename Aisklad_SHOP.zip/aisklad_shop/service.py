"""Buyer shop use cases. All network and payment actions cross explicit boundaries."""
from __future__ import annotations
import hashlib
import json
import re
import sqlite3
import threading
import time
from dataclasses import asdict
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from urllib.parse import urlsplit
from .catalog import Catalog
from .payments import DisabledPayments, validate_event
from .store import dumps
from .supplier import NotSubmitted


class ShopError(RuntimeError):
    def __init__(self, code, message):
        self.code, self.message = code, message
        super().__init__(message)


def number(value):
    try:
        result = Decimal(str(value))
    except (ValueError, TypeError, InvalidOperation) as exc:
        raise ShopError("INVALID_NUMBER", "Нужно указать число.") from exc
    if not result.is_finite():
        raise ShopError("INVALID_NUMBER", "Нужно указать конечное число.")
    return result


def pages(items, page=0, page_size=8):
    page_size = min(50, max(1, int(page_size)))
    total = len(items)
    count = max(1, (total + page_size - 1) // page_size)
    page = min(count - 1, max(0, int(page)))
    return {"items": items[page * page_size:(page + 1) * page_size], "page": page, "pages": count, "total": total}


class ShopService:
    def __init__(self, store, supplier, settings=None, rate_provider=None, payment_connector=None, clock=time.time):
        self.store, self.supplier, self.settings = store, supplier, dict(settings or {})
        self.rate_provider, self.payments, self.clock = rate_provider, payment_connector or DisabledPayments(), clock
        self.catalog = Catalog(store, supplier, clock=clock)
        self._checkout_lock = threading.RLock()
        self._worker_lock = threading.Lock()

    def is_enabled(self):
        return self.store.get_setting("module:shop", self.settings.get("enabled", False)) is True

    def set_enabled(self, enabled):
        self.store.set_setting("module:shop", enabled is True)

    def status(self):
        return {"enabled": self.is_enabled(), "payment_enabled": self.payments.enabled is True,
                "payment_message": getattr(self.payments, "reason", ""), "catalog": self.catalog.status(),
                "health_paused": self.store.get_setting("shop:health_paused", False),
                "payment_currency": self.payments.currency, "target_margin_pct": str(self.settings.get("target_margin_pct", "0.4"))}

    def balance(self):
        try:
            value = number(self.supplier.balance())
            if value < 0:
                raise ValueError("negative balance")
            return {"balance_usd": str(value), "observed_at": self.clock()}
        except Exception as exc:
            raise ShopError("BALANCE_UNAVAILABLE", "Сейчас не удалось прочитать баланс STEAM.RU.") from exc

    def stats(self):
        """Owner UI guards this local diagnostic; contains no customer fields/codes."""
        with self.store.connection() as db:
            statuses = {r[0]: r[1] for r in db.execute("SELECT status,COUNT(*) FROM orders GROUP BY status")}
            customers = db.execute("SELECT COUNT(DISTINCT user_id) FROM sessions").fetchone()[0]
            health = {r[0][7:]: json.loads(r[1]) for r in db.execute("SELECT key,value FROM settings WHERE key LIKE 'health:%'")}
            support = db.execute("SELECT COUNT(*) FROM support").fetchone()[0]
        return {"orders_total": sum(statuses.values()), "order_statuses": statuses, "customers": customers,
                "catalog": self.catalog.status(), "health": health, "support_total": support}

    def _health(self, scope, success):
        key = "health:" + scope
        with self.store.connection(immediate=True) as db:
            row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            count = 0 if success else (int(json.loads(row[0])) if row else 0) + 1
            db.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, dumps(count)))
            if count >= 7:
                db.execute("INSERT INTO settings VALUES('shop:health_paused','true') ON CONFLICT(key) DO UPDATE SET value='true'")
        if count == 7:
            self._notify_owner("system", {"text": "В Aisklad SHOP 7 последовательных сбоев в одном модуле. Новое оформление приостановлено; оплаченные заказы продолжают проверяться.", "scope": scope}, "health:" + scope + ":" + str(int(self.clock() // 3600)))

    def reset_health(self):
        with self.store.connection(immediate=True) as db:
            db.execute("DELETE FROM settings WHERE key LIKE 'health:%'")
            db.execute("INSERT INTO settings VALUES('shop:health_paused','false') ON CONFLICT(key) DO UPDATE SET value='false'")

    def _notify_owner(self, kind, payload, dedupe):
        self.store.enqueue(self.settings.get("owner_id"), "owner:" + kind, payload, dedupe)

    def sync_catalog(self):
        try:
            result = self.catalog.sync()
            if result.get("state") != "busy":
                self._health("catalog", True)
            return result
        except Exception as exc:
            self._health("catalog", False)
            raise ShopError("CATALOG_SYNC", "Поставщик не завершил обновление. Предыдущий полный каталог сохранён.") from exc

    def _rate(self):
        if self.rate_provider is None:
            raise ShopError("RATE_UNAVAILABLE", "Цена временно недоступна: ожидаем актуальный курс пополнения.")
        try:
            raw = self.rate_provider()
            rate = number(raw["rub_per_usd"])
            stamp = raw["observed_at"]
            if isinstance(stamp, str):
                stamp = datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
            age = self.clock() - float(stamp)
            if rate <= 0 or not 0 <= age <= int(self.settings.get("rate_ttl_seconds", 3600)):
                raise ValueError("stale")
            return rate, {"rub_per_usd": str(rate), "observed_at": float(stamp), "source": str(raw.get("source", "configured"))}
        except ShopError:
            raise
        except Exception as exc:
            raise ShopError("RATE_UNAVAILABLE", "Ожидаем свежий курс пополнения. Покупка по старому курсу недоступна.") from exc

    def _quote(self, item, quantity):
        rate, rate_meta = self._rate()
        fee, margin = number(self.settings.get("payment_fee_pct", "0")), number(self.settings.get("target_margin_pct", "0.4"))
        fixed = number(self.settings.get("fixed_cost_rub", "0.25"))
        if not 0 <= fee < 100 or not 0 <= margin < 100 or fee + margin >= 100 or fixed < 0:
            raise ShopError("PRICE_CONFIG", "Настройки цены требуют проверки владельцем.")
        cost_usd = number(item.get("price_usd")) * int(quantity)
        if cost_usd <= 0:
            raise ShopError("UNAVAILABLE", "Сейчас этот товар недоступен.")
        sale = ((cost_usd * rate + fixed) / (1 - (fee + margin) / 100)).quantize(Decimal("0.01"), rounding=ROUND_CEILING)
        return {"total_rub": str(sale), "cost_usd": str(cost_usd), "quantity": int(quantity), "quoted_at": self.clock(), "rate": rate_meta,
                "fee_pct": str(fee), "target_margin_pct": str(margin)}

    def _view(self, item):
        view = dict(item)
        view["requirements"] = list(view.get("fields", []))
        view["min"] = view.get("min_quantity", 1)
        view["max"] = view.get("max_quantity", 1)
        view["price_rub"] = None
        if view.get("price_usd"):
            try:
                view["price_rub"] = self._quote(view, max(1, int(view.get("min_quantity", 1))))["total_rub"]
            except ShopError as exc:
                view["available"] = False
                view["availability_reason"] = exc.message
                view["availability_code"] = exc.code
        if view.get("variants"):
            view["variants"] = [self._view(v) for v in view["variants"]]
        return view

    def categories(self, parent=None, page=0, page_size=8):
        items = self.catalog.all(parent or "root")
        items.sort(key=lambda p: p["title"].casefold())
        result = pages(items, page, page_size)
        result["sync"] = self.catalog.status()
        return result

    def list_products(self, service_id=None, page=0, page_size=8, query=None):
        group = service_id
        if group and group not in ("keys", "gifts") and not group.startswith(("service:", "p")):
            group = "service:" + group
        items = self.catalog.all(group)
        items = [p for p in items if p["kind"] not in ("brand", "service")]
        if query:
            query = str(query).strip()[:100].casefold()
            items = [p for p in items if query in (p["title"] + " " + p.get("service", "")).casefold()]
        items.sort(key=lambda p: p["title"].casefold())
        result = pages(items, page, page_size)
        result["items"] = [self._view(p) for p in result["items"]]
        return result

    def product(self, identifier):
        try:
            fresh = self.catalog.refresh(str(identifier))
            self._health("product_read", True)
            return self._view(fresh)
        except KeyError as exc:
            raise ShopError("NOT_FOUND", "Этот товар больше не доступен. Откройте каталог заново.") from exc
        except ShopError:
            raise
        except Exception as exc:
            self._health("product_read", False)
            raise ShopError("PRODUCT_UNAVAILABLE", "Не удалось проверить товар у поставщика. Попробуйте немного позже.") from exc

    def requirements(self, identifier):
        return self.product(identifier).get("fields", [])

    def quote(self, user_id, product_id, quantity=1, fields=None):
        """Read-only form confirmation; does not create a cart item, invoice or order."""
        item = self.product(product_id)
        count, clean = self._validate(item, quantity, fields or {})
        value = self._quote(item, count)
        value.update(product_id=item["id"], title=item["title"], fields=clean, currency="RUB")
        return value

    def _validate(self, item, quantity, values):
        count = number(quantity)
        minimum, maximum = int(item.get("min_quantity", 1)), int(item.get("max_quantity", 1))
        if count != count.to_integral_value() or not minimum <= count <= maximum:
            raise ShopError("INVALID_QUANTITY", f"Доступное количество: от {minimum} до {maximum}.")
        if item["kind"] == "code" and count != 1:
            raise ShopError("INVALID_QUANTITY", "Цифровой код оформляется по одному.")
        if item.get("has_variants"):
            raise ShopError("SELECT_VARIANT", "Сначала выберите издание и регион товара.")
        if not item.get("available"):
            raise ShopError(item.get("availability_code", "UNAVAILABLE"), item.get("availability_reason", "Сейчас этот товар недоступен."))
        if not isinstance(values, dict):
            raise ShopError("INVALID_FIELDS", "Заполните данные получателя.")
        schema = item.get("fields", [])
        allowed = {f["name"] for f in schema}
        if set(values) - allowed:
            raise ShopError("INVALID_FIELDS", "В форме есть неизвестные поля. Откройте товар заново.")
        clean = {}
        for field in schema:
            name = field["name"]
            value = str(values.get(name, "")).strip()
            if not value and field.get("required", True):
                raise ShopError("FIELD_REQUIRED", "Заполните поле: " + field.get("label", name))
            if not value:
                continue
            if len(value) < int(field.get("min") or 0) or len(value) > int(field.get("max") or 255) or any(ord(ch) < 32 for ch in value):
                raise ShopError("INVALID_FIELD", "Проверьте поле: " + field.get("label", name))
            if field.get("type") == "select":
                options = {str(o.get("value")) for o in field.get("options", [])}
                if value not in options:
                    raise ShopError("INVALID_OPTION", "Выберите вариант кнопкой: " + field.get("label", name))
            elif field.get("type") != "text":
                raise ShopError("UNSUPPORTED_FIELD", "Этот товар пока нельзя оформить автоматически.")
            if field.get("pattern"):
                try:
                    valid = re.fullmatch(field["pattern"], value)
                except re.error as exc:
                    raise ShopError("FIELD_SCHEMA", "Форма товара требует проверки владельцем.") from exc
                if not valid:
                    raise ShopError("INVALID_FIELD", "Проверьте поле: " + field.get("label", name))
            clean[name] = value
        if item["kind"] in ("key", "gift"):
            country = clean.get("country", "").upper()
            clean["country"] = country
            countries = {str(c).upper() for c in item.get("countries", [])}
            excluded = {str(c).upper() for c in item.get("excluded_countries", [])}
            if country in excluded or (countries and country not in countries) or (not countries and item.get("region") != "GLOBAL"):
                raise ShopError("REGION_MISMATCH", "Этот товар не подтверждён для выбранной страны. Выберите другой регион.")
        if item["kind"] == "gift":
            try:
                url = urlsplit(clean["invite_url"])
                valid = url.scheme == "https" and url.hostname in ("s.team", "steamcommunity.com") and not url.username and not url.password and url.port in (None, 443)
                valid = valid and (url.path.startswith("/p/") if url.hostname == "s.team" else url.path.startswith("/invite/"))
            except ValueError:
                valid = False
            if not valid:
                raise ShopError("INVITE_INVALID", "Нужна ссылка-приглашение Steam: https://s.team/p/…")
        account = next((clean.get(f["name"]) for f in schema if f.get("is_account") and clean.get(f["name"])), None)
        if account and item.get("service") in ("steam", "telegram-stars"):
            try:
                self.supplier.check_account(item["service"], account)
            except Exception as exc:
                raise ShopError("ACCOUNT_INVALID", "Поставщик не подтвердил получателя. Проверьте логин или username.") from exc
        return int(count), clean

    def add_to_cart(self, user_id, product_id, quantity=1, fields=None):
        item = self.product(product_id)
        count, clean = self._validate(item, quantity, fields or {})
        quote = self._quote(item, count)
        value = {"product_id": item["id"], "title": item["title"], "quantity": count, "fields": clean, "quote": quote,
                 "total_rub": quote["total_rub"], "image_url": item.get("image_url"), "added_at": self.clock()}
        with self.store.connection(immediate=True) as db:
            size = db.execute("SELECT COUNT(*) FROM cart WHERE user_id=?", (int(user_id),)).fetchone()[0]
            if size >= int(self.settings.get("max_cart_items", 20)):
                raise ShopError("CART_LIMIT", "В корзине уже много товаров. Оформите или удалите часть позиций.")
            identifier = self.store.new_id("c")
            db.execute("INSERT INTO cart VALUES(?,?,?)", (identifier, int(user_id), dumps(value)))
        return self.cart(user_id)

    def cart(self, user_id):
        with self.store.connection() as db:
            rows = db.execute("SELECT id,value FROM cart WHERE user_id=? ORDER BY rowid", (int(user_id),)).fetchall()
        items = []
        for r in rows:
            item = json.loads(r["value"])
            item["id"] = r["id"]
            items.append(item)
        return {"items": items, "total_rub": str(sum((number(i["total_rub"]) for i in items), Decimal(0)).quantize(Decimal("0.01"))), "currency": "RUB", "payment_enabled": self.payments.enabled is True}

    def remove_cart(self, user_id, item_id):
        with self.store.connection(immediate=True) as db:
            db.execute("DELETE FROM cart WHERE id=? AND user_id=?", (str(item_id), int(user_id)))
        return self.cart(user_id)

    def clear_cart(self, user_id):
        with self.store.connection(immediate=True) as db:
            db.execute("DELETE FROM cart WHERE user_id=?", (int(user_id),))
        return self.cart(user_id)

    def checkout(self, user_id):
        if not self.is_enabled() or self.store.get_setting("shop:health_paused", False):
            raise ShopError("SHOP_PAUSED", "Оформление новых заказов временно приостановлено. Оплаченные заказы продолжают обрабатываться.")
        if self.payments.enabled is not True:
            raise ShopError("PAYMENT_UNAVAILABLE", getattr(self.payments, "reason", "Оплата пока не подключена."))
        if self.payments.currency != "RUB":
            raise ShopError("PAYMENT_CURRENCY", "Конвертация цены для этого способа оплаты ещё не настроена.")
        with self._checkout_lock:
            cart = self.cart(user_id)
            if not cart["items"]:
                raise ShopError("EMPTY_CART", "Корзина пока пуста.")
            fingerprint = hashlib.sha256(dumps(cart["items"]).encode()).hexdigest()
            lines = []
            changed = False
            key_totals = {}
            gift_invites = set()
            for entry in cart["items"]:
                item = self.product(entry["product_id"])
                qty, clean = self._validate(item, entry["quantity"], entry["fields"])
                quote = self._quote(item, qty)
                if item["kind"] == "key":
                    key_totals[item["id"]] = key_totals.get(item["id"], 0) + qty
                    if key_totals[item["id"]] > int(item.get("stock", 0)):
                        raise ShopError("INSUFFICIENT_STOCK", "В корзине больше одинаковых ключей, чем осталось у поставщика. Уменьшите количество позиций.")
                if item["kind"] == "gift":
                    if clean["invite_url"] in gift_invites:
                        raise ShopError("INVITE_REUSED", "Каждому подарку нужна отдельная действующая ссылка-приглашение Steam.")
                    gift_invites.add(clean["invite_url"])
                if quote["total_rub"] != entry["total_rub"]:
                    changed = True
                    entry.update(quote=quote, total_rub=quote["total_rub"])
                    with self.store.connection(immediate=True) as db:
                        saved = dict(entry)
                        saved.pop("id", None)
                        db.execute("UPDATE cart SET value=? WHERE id=? AND user_id=?", (dumps(saved), entry["id"], int(user_id)))
                lines.append({"product": item, "title": item["title"], "quantity": qty, "fields": clean, "quote": quote, "cart_id": entry["id"], "attempts": 0})
            if changed:
                raise ShopError("QUOTE_CHANGED", "Цена обновилась у поставщика. Корзина пересчитана — проверьте сумму и подтвердите ещё раз.")
            total = sum((number(line["quote"]["total_rub"]) for line in lines), Decimal(0))
            order_id = self.store.new_id("A")
            value = {"total_rub": str(total), "currency": "RUB", "cart_fingerprint": fingerprint, "invoice_id": None, "payment_url": None, "delivery": []}
            with self.store.connection(immediate=True) as db:
                existing = db.execute("SELECT id,value,status FROM orders WHERE user_id=? AND status IN ('invoice_creating','awaiting_payment','invoice_review') ORDER BY created_at DESC", (int(user_id),)).fetchall()
                for row in existing:
                    if json.loads(row["value"]).get("cart_fingerprint") == fingerprint:
                        return self.order(user_id, row["id"])
                db.execute("INSERT INTO orders VALUES(?,?,?,?,?)", (order_id, int(user_id), "invoice_creating", self.clock(), dumps(value)))
                for index, line in enumerate(lines):
                    line_id = order_id + "-" + str(index + 1)
                    db.execute("INSERT INTO order_lines VALUES(?,?,?,?,?,?)", (line_id, order_id, "unpaid", "aisklad-" + line_id, None, dumps(line)))
            try:
                invoice = self.payments.create_invoice(order_id=order_id, amount=str(total), currency="RUB", user_id=int(user_id))
                if not invoice.get("invoice_id"):
                    raise ValueError("missing invoice")
                value.update(invoice_id=str(invoice["invoice_id"]), payment_url=invoice.get("payment_url"), invoice_expires_at=invoice.get("expires_at"))
                with self.store.connection(immediate=True) as db:
                    db.execute("UPDATE orders SET status='awaiting_payment',value=? WHERE id=? AND status='invoice_creating'", (dumps(value), order_id))
            except Exception as exc:
                with self.store.connection(immediate=True) as db:
                    db.execute("UPDATE orders SET status='invoice_review' WHERE id=?", (order_id,))
                raise ShopError("INVOICE_UNCERTAIN", "Платёжный сервис не подтвердил создание счёта. Покупка не отправлялась; обратитесь в поддержку.") from exc
            return self.order(user_id, order_id)

    def handle_payment(self, raw_body, headers):
        """Transport adapter only. No UI/admin command may call a mark-paid method."""
        if self.payments.enabled is not True or self.payments.verifier is None:
            raise ShopError("PAYMENT_DISABLED", "Платёжный обработчик отключён.")
        try:
            event = validate_event(self.payments.verifier.verify(raw_body, headers))
        except Exception as exc:
            raise ShopError("PAYMENT_UNVERIFIED", "Платёж не прошёл проверку подлинности.") from exc
        if event.provider != self.payments.provider:
            raise ShopError("PAYMENT_UNVERIFIED", "Неизвестный платёжный провайдер.")
        encoded = dumps(asdict(event))
        with self.store.connection(immediate=True) as db:
            prior = db.execute("SELECT value FROM payment_events WHERE provider=? AND event_id=?", (event.provider, event.event_id)).fetchone()
            if prior:
                if prior[0] != encoded:
                    raise ShopError("PAYMENT_REPLAY", "Содержимое повторного события отличается.")
                return {"accepted": True, "duplicate": True}
            row = db.execute("SELECT * FROM orders WHERE id=?", (event.order_id,)).fetchone()
            if not row:
                raise ShopError("PAYMENT_ORDER", "Счёт не найден.")
            value = json.loads(row["value"])
            if row["user_id"] != event.user_id or value.get("invoice_id") != event.invoice_id or value["currency"] != event.currency or number(value["total_rub"]) != number(event.amount):
                raise ShopError("PAYMENT_MISMATCH", "Платёж не соответствует счёту.")
            if row["status"] != "awaiting_payment":
                raise ShopError("PAYMENT_STATE", "Счёт уже обработан или требует проверки.")
            auth = db.execute("SELECT order_id FROM payment_authorizations WHERE provider=? AND charge_id=?", (event.provider, event.charge_id)).fetchone()
            if auth:
                raise ShopError("PAYMENT_REPLAY", "Этот платёж уже использован.")
            db.execute("INSERT INTO payment_events VALUES(?,?,?,?)", (event.provider, event.event_id, event.order_id, encoded))
            db.execute("INSERT INTO payment_authorizations VALUES(?,?,?,?)", (event.order_id, event.provider, event.charge_id, encoded))
            db.execute("UPDATE orders SET status='paid' WHERE id=?", (event.order_id,))
            db.execute("UPDATE order_lines SET status='ready' WHERE order_id=? AND status='unpaid'", (event.order_id,))
            for line in db.execute("SELECT value FROM order_lines WHERE order_id=?", (event.order_id,)).fetchall():
                db.execute("DELETE FROM cart WHERE id=? AND user_id=?", (json.loads(line[0])["cart_id"], event.user_id))
            db.execute("INSERT OR IGNORE INTO outbox(dedupe,user_id,kind,payload,created_at) VALUES(?,?,?,?,?)", ("paid:" + event.order_id, event.user_id, "order", dumps({"order_id": event.order_id, "status": "paid", "text": "Оплата подтверждена. Заказ передаётся в обработку."}), self.clock()))
        self._notify_owner("order", {"order_id": event.order_id, "text": "Новый оплаченный заказ Aisklad SHOP"}, "owner:paid:" + event.order_id)
        return {"accepted": True, "duplicate": False}

    def orders(self, user_id, page=0, page_size=8):
        with self.store.connection() as db:
            rows = db.execute("SELECT id FROM orders WHERE user_id=? ORDER BY created_at DESC", (int(user_id),)).fetchall()
        result = pages([r[0] for r in rows], page, page_size)
        result["items"] = [self.order(user_id, i) for i in result["items"]]
        return result

    def order(self, user_id, identifier):
        value = self.store.order_data(identifier, user_id)
        if value is None:
            raise ShopError("NOT_FOUND", "Заказ не найден.")
        value["delivery"] = [str(code) for item in value["items"] if item["status"] == "completed" for code in item.get("delivery", [])]
        return value

    def favorites(self, user_id, page=0, page_size=8):
        with self.store.connection() as db:
            ids = [r[0] for r in db.execute("SELECT product_id FROM favorites WHERE user_id=? ORDER BY rowid DESC", (int(user_id),)).fetchall()]
        items = [self.catalog.get(i) for i in ids]
        return pages([self._view(i) for i in items if i], page, page_size)

    def toggle_favorite(self, user_id, identifier):
        if not self.catalog.get(identifier):
            raise ShopError("NOT_FOUND", "Товар не найден.")
        with self.store.connection(immediate=True) as db:
            row = db.execute("SELECT 1 FROM favorites WHERE user_id=? AND product_id=?", (int(user_id), str(identifier))).fetchone()
            if row:
                db.execute("DELETE FROM favorites WHERE user_id=? AND product_id=?", (int(user_id), str(identifier)))
            else:
                db.execute("INSERT INTO favorites VALUES(?,?)", (int(user_id), str(identifier)))
        return {"favorite": row is None}

    def is_favorite(self, user_id, identifier):
        with self.store.connection() as db:
            row = db.execute("SELECT 1 FROM favorites WHERE user_id=? AND product_id=?", (int(user_id), str(identifier))).fetchone()
        return row is not None

    def request_help(self, user_id, text, order_id=None):
        if order_id is not None:
            self.order(user_id, order_id)
        text = str(text).strip()
        if not 3 <= len(text) <= 3000:
            raise ShopError("HELP_LENGTH", "Опишите вопрос сообщением от 3 до 3000 символов.")
        with self.store.connection(immediate=True) as db:
            prior = db.execute("SELECT id,message FROM support WHERE user_id=? AND created_at>? ORDER BY created_at DESC LIMIT 1", (int(user_id), self.clock() - 60)).fetchone()
            if prior:
                if text not in prior["message"]:
                    db.execute("UPDATE support SET message=? WHERE id=?", ((prior["message"] + "\n" + text)[-6000:], prior["id"]))
                    owner = self.settings.get("owner_id")
                    if owner:
                        db.execute("INSERT OR IGNORE INTO outbox(dedupe,user_id,kind,payload,created_at) VALUES(?,?,?,?,?)", ("support_detail:" + prior["id"], int(owner), "owner:support_detail", dumps({"ticket_id": prior["id"], "user_id": int(user_id), "text": text}), self.clock()))
                return {"ticket_id": prior[0], "duplicate": True, "updated": True}
            identifier = self.store.new_id("H")
            db.execute("INSERT INTO support VALUES(?,?,?,?,?)", (identifier, int(user_id), order_id, text, self.clock()))
        self._notify_owner("support", {"ticket_id": identifier, "user_id": int(user_id), "order_id": order_id, "text": text}, "support:" + identifier)
        return {"ticket_id": identifier, "duplicate": False}

    def pending_notifications(self, limit=50):
        return self.store.pending_notifications(limit)

    def ack_notification(self, identifier):
        self.store.ack_notification(identifier)

    def _save_line(self, identifier, status, value, supplier_uuid=None):
        with self.store.connection(immediate=True) as db:
            db.execute("UPDATE order_lines SET status=?,supplier_uuid=COALESCE(?,supplier_uuid),value=? WHERE id=?", (status, supplier_uuid, dumps(value), identifier))

    def _accept_supplier(self, row, line, result):
        uuid = result.get("uuid")
        if not isinstance(uuid, str) or not re.fullmatch(r"[0-9a-fA-F-]{32,36}", uuid):
            raise ShopError("SUPPLIER_UUID", "Поставщик не подтвердил идентификатор заказа; повторная покупка запрещена.")
        previous_uuid = row["supplier_uuid"]
        if previous_uuid and previous_uuid != uuid:
            line.update(review_reason="PRODUCT_MISMATCH", unexpected_supplier_uuid=uuid, poll_after=self.clock() + 60)
            self._save_line(row["id"], "needs_review", line)  # Preserve the original UUID forever.
            return
        # Persist the supplier UUID before inspecting any optional response fields.
        try:
            self._save_line(row["id"], "supplier_pending", line, uuid)
        except sqlite3.IntegrityError:
            line.update(review_reason="DUPLICATE_SUPPLIER_UUID", unexpected_supplier_uuid=uuid, poll_after=self.clock() + 60)
            self._save_line(row["id"], "needs_review", line)
            return
        product = line["product"]
        # Reject a mismatched response even if it claims completion. Keep UUID for reconciliation.
        mismatch = False
        if product["kind"] in ("topup", "code"):
            mismatch = ((result.get("product_id") is not None and str(result["product_id"]) != str(product["supplier_product_id"])) or
                        (result.get("product_count") is not None and str(result["product_count"]) != str(line["quantity"])) or
                        (result.get("transfer_service") is not None and str(result["transfer_service"]) != str(product["service"])))
        elif product["kind"] == "key":
            mismatch = (result.get("app_id") is not None and str(result["app_id"]) != str(product["app_id"])) or (result.get("option_id") is not None and str(result["option_id"]) != str(product["option_id"]))
        elif product["kind"] == "gift":
            mismatch = ((result.get("app_id") is not None and str(result["app_id"]) != str(product["app_id"])) or
                        (result.get("region") is not None and str(result["region"]) != str(product["region"])) or
                        (result.get("edition") is not None and str(result["edition"]) != str(product["edition"])))
        if result.get("external_order_id") is not None and result["external_order_id"] != row["external_id"]:
            mismatch = True
        expected_account = next((line["fields"].get(f["name"]) for f in product.get("fields", []) if f.get("is_account") and line["fields"].get(f["name"])), None)
        if expected_account and result.get("account") is not None and str(result["account"]) != str(expected_account):
            mismatch = True
        if product["kind"] == "key" and result.get("quantity") is not None and str(result["quantity"]) != str(line["quantity"]):
            mismatch = True
        if product["kind"] == "gift" and result.get("invite_url") is not None and result["invite_url"] != line["fields"].get("invite_url"):
            mismatch = True
        line["last_supplier_status"] = str(result.get("status", "unknown"))
        line["last_checked_at"] = self.clock()
        status = line["last_supplier_status"]
        line["poll_after"] = self.clock() + (60 if status in ("error", "review", "closed") else 15)
        if (mismatch or line.get("review_reason") == "PRODUCT_MISMATCH") and status != "refunded":
            line["review_reason"] = "PRODUCT_MISMATCH"
            self._save_line(row["id"], "needs_review", line, uuid)
            return
        if status == "refunded":
            line["supplier_refunded"] = True
            # Supplier refund is not a refund of the buyer's separate payment.
            line["review_reason"] = "SUPPLIER_REFUNDED_BUYER_REFUND_REQUIRED"
            self._save_line(row["id"], "refund_required", line, uuid)
        elif (status == "delivered" and product["kind"] in ("key", "code")) or (status == "completed" and product["kind"] in ("topup", "gift")):
            code = result.get("voucher")
            codes = result.get("vouchers") or ([code] if code else [])
            if product["kind"] in ("key", "code") and (not isinstance(codes, list) or len(codes) < (line["quantity"] if product["kind"] == "key" else 1) or any(not isinstance(c, str) or not c.strip() or len(c) > 10000 for c in codes)):
                line["review_reason"] = "MISSING_DELIVERY"
                self._save_line(row["id"], "needs_review", line, uuid)
                return
            line["delivery"] = [str(c) for c in codes]
            self._save_line(row["id"], "completed", line, uuid)
        elif status in ("error", "review", "closed", "delivered", "completed"):
            line["review_reason"] = "SUPPLIER_" + status.upper()
            self._save_line(row["id"], "needs_review", line, uuid)
        elif status in ("created", "processing", "pending"):
            self._save_line(row["id"], "supplier_pending", line, uuid)
        else:
            line["review_reason"] = "UNEXPECTED_SUPPLIER_STATUS"
            self._save_line(row["id"], "needs_review", line, uuid)

    def process_pending(self):
        """Runs even with the storefront switched off; never buys an unpaid order."""
        if not self._worker_lock.acquire(blocking=False):
            return {"processed": 0, "state": "busy"}
        processed = 0
        try:
            with self.store.connection() as db:
                rows = db.execute("SELECT l.* FROM order_lines l JOIN payment_authorizations p ON p.order_id=l.order_id WHERE l.status IN ('ready','submitting','uncertain','supplier_pending','needs_review') ORDER BY l.id").fetchall()
            for row in rows:
                line = json.loads(row["value"])
                if float(line.get("poll_after", 0)) > self.clock():
                    continue
                processed += 1
                try:
                    if row["status"] == "ready":
                        allowed = self.supplier.can_purchase() if hasattr(self.supplier, "can_purchase") else True
                        if not allowed:
                            # Explicit launch gate. No fence, no supplier call and
                            # no fake unknown-outcome state when LIVE is disabled.
                            line.update(review_reason="LIVE_DISABLED", poll_after=self.clock() + 30)
                            self._save_line(row["id"], "ready", line)
                            continue
                        # The buyer's RUB charge is already fixed. Refresh the supplier
                        # USD quote, but an expired display FX quote cannot strand it.
                        fresh = self.catalog.refresh(line["product"]["id"])
                        qty, clean = self._validate(fresh, line["quantity"], line["fields"])
                        # Paid prices are fixed; a configurable supplier-cost ceiling bounds owner exposure.
                        ceiling = number(line["quote"]["cost_usd"]) * (1 + number(self.settings.get("max_paid_cost_increase_pct", "0")) / 100)
                        cost = number(fresh["price_usd"]) * qty
                        if cost > ceiling:
                            line["review_reason"] = "PAID_QUOTE_INCREASE"
                            self._save_line(row["id"], "needs_review", line)
                            continue
                        line["product"], line["fields"], line["attempts"] = fresh, clean, 1
                        line["submitting_at"] = self.clock()
                        with self.store.connection(immediate=True) as db:
                            current = db.execute("SELECT status FROM order_lines WHERE id=?", (row["id"],)).fetchone()
                            if not current or current[0] != "ready":
                                continue
                            db.execute("UPDATE order_lines SET status='submitting',value=? WHERE id=?", (dumps(line), row["id"]))
                        # From this point any exception leaves a durable unknown-outcome fence.
                        result = self.supplier.submit(fresh, qty, clean, row["external_id"], expected_max_usd=str(cost))
                        self._accept_supplier(row, line, result)
                    elif row["supplier_uuid"]:
                        result = self.supplier.order(row["supplier_uuid"])
                        self._accept_supplier(row, line, result)
                    else:
                        if row["status"] == "needs_review":
                            continue  # No POST was sent, owner resolution required.
                        result = self.supplier.recover(row["external_id"])
                        if result:
                            self._accept_supplier(row, line, result)
                        else:
                            line.update(review_reason="UNKNOWN_SUBMISSION", poll_after=self.clock() + 60)
                            self._save_line(row["id"], "uncertain", line)
                    self._health("fulfillment_read", True)
                except Exception as exc:
                    with self.store.connection() as db:
                        current = db.execute("SELECT status,supplier_uuid,value FROM order_lines WHERE id=?", (row["id"],)).fetchone()
                    current_status = current["status"]
                    line = json.loads(current["value"])
                    line.update(last_error_code=getattr(exc, "code", type(exc).__name__), poll_after=self.clock() + 60)
                    if isinstance(exc, NotSubmitted) or (current_status == "ready" and not isinstance(exc, (ShopError, KeyError, ValueError))):
                        line["preflight_failures"] = int(line.get("preflight_failures", 0)) + 1
                        next_status = "ready" if getattr(exc, "code", None) == "BALANCE_WAIT" or line["preflight_failures"] < 7 else "needs_review"
                    else:
                        next_status = "uncertain" if current_status in ("submitting", "uncertain") else ("needs_review" if current_status == "ready" else current_status)
                    self._save_line(row["id"], next_status, line)
                    if isinstance(exc, NotSubmitted):
                        self._notify_owner("alert", {"order_id": row["order_id"], "text": "Оплаченный заказ ждёт предпроверки/баланса STEAM.RU. POST ещё не отправлялся; бот безопасно повторит проверку."}, "preflightwait:" + row["order_id"])
                    # Bad user data and isolated unsupported amounts do not trip a global gate.
                    if not isinstance(exc, ShopError):
                        self._health("fulfillment_read", False)
                finally:
                    self._update_order(row["order_id"])
            return {"processed": processed, "state": "ok"}
        finally:
            self._worker_lock.release()

    def _update_order(self, identifier):
        order = self.store.order_data(identifier)
        if not order:
            return
        states = [line["status"] for line in order["items"]]
        status = "completed" if states and all(s == "completed" for s in states) else ("needs_review" if any(s in ("uncertain", "needs_review", "refund_required") for s in states) else "processing")
        with self.store.connection(immediate=True) as db:
            db.execute("UPDATE orders SET status=? WHERE id=? AND EXISTS(SELECT 1 FROM payment_authorizations p WHERE p.order_id=orders.id)", (status, identifier))
            if order["status"] != status:
                text = {"completed": "Заказ выполнен! Спасибо за покупку в Aisklad SHOP 💜", "needs_review": "Заказу нужна дополнительная проверка. Владелец уже получит уведомление; повторно оплачивать не нужно.", "processing": "Заказ в работе. Сообщим, когда он будет выполнен."}[status]
                db.execute("INSERT OR IGNORE INTO outbox(dedupe,user_id,kind,payload,created_at) VALUES(?,?,?,?,?)", ("order:" + identifier + ":" + status, order["user_id"], "order", dumps({"order_id": identifier, "status": status, "text": text}), self.clock()))
        if status == "needs_review":
            self._notify_owner("alert", {"order_id": identifier, "text": "⚠️ Оплаченный заказ Aisklad SHOP требует проверки. Повторная покупка заблокирована до установления исхода."}, "alert:" + identifier)
