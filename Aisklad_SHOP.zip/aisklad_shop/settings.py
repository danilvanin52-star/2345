"""Environment configuration; secrets never appear in repr/logging/public files."""
from dataclasses import dataclass, field
from pathlib import Path
import os


def boolean(value, default=False):
    if value is None or value=='':return default
    if str(value).lower() in ('1','true','yes','on'):return True
    if str(value).lower() in ('0','false','no','off'):return False
    raise ValueError('Переключатель должен быть true или false.')


@dataclass(repr=False)
class Settings:
    data_dir: Path
    shop_token: str=field(default='',repr=False)
    admin_token: str=field(default='',repr=False)
    api_key: str=field(default='',repr=False)
    api_secret: str=field(default='',repr=False)
    partner_email: str=field(default='',repr=False)
    partner_password: str=field(default='',repr=False)
    owner_id: int=0
    run_mode: str='all'
    shop_live: bool=False
    shop_enabled: bool=True
    sync_seconds: int=3600
    worker_seconds: int=15
    margin_pct: str='0.4'
    payment_fee_pct: str='0'
    fixed_cost_rub: str='0.25'
    support_username: str=''

    @classmethod
    def from_env(cls,env=None):
        env=os.environ if env is None else env
        owner=env.get('STEAMRU_OWNER_TG_ID','0')
        if not str(owner).isdigit():raise ValueError('STEAMRU_OWNER_TG_ID должен быть числом.')
        mode=env.get('AISKLAD_RUN_MODE','all').lower()
        if mode not in ('all','shop','funpay'):raise ValueError('AISKLAD_RUN_MODE: all, shop или funpay.')
        shop_token=env.get('AISKLAD_SHOP_TOKEN','').strip()
        admin_token=env.get('BOT_TOKEN','').strip()
        if shop_token and shop_token==admin_token:
            raise ValueError('Для покупателей нужен отдельный токен AISKLAD_SHOP_TOKEN.')
        if shop_token and (':' not in shop_token or '\n' in shop_token):
            raise ValueError('Проверь AISKLAD_SHOP_TOKEN в настройках хостинга.')
        return cls(
            data_dir=Path(env.get('FPC_DATA_DIR',env.get('DATA_DIR','/app/data'))).resolve(),
            shop_token=shop_token,admin_token=admin_token,
            api_key=env.get('STEAMRU_API_KEY',''),api_secret=env.get('STEAMRU_API_SECRET',''),
            partner_email=env.get('STEAMRU_PARTNER_EMAIL',''),partner_password=env.get('STEAMRU_PARTNER_PASSWORD',''),
            owner_id=int(owner),run_mode=mode,
            shop_live=boolean(env.get('AISKLAD_SHOP_LIVE'),False),
            shop_enabled=boolean(env.get('AISKLAD_SHOP_ENABLED'),True),
            sync_seconds=max(300,int(env.get('AISKLAD_SYNC_SECONDS','3600'))),
            worker_seconds=max(5,int(env.get('AISKLAD_WORKER_SECONDS','15'))),
            margin_pct=env.get('AISKLAD_MARGIN_PCT','0.4'),
            payment_fee_pct=env.get('AISKLAD_PAYMENT_FEE_PCT','0'),
            fixed_cost_rub=env.get('AISKLAD_FIXED_COST_RUB','0.25'),
            support_username=env.get('AISKLAD_SUPPORT_USERNAME','').lstrip('@'),
        )

    @property
    def shop_dir(self):return self.data_dir/'aisklad'

    @property
    def funpay_dir(self):return self.data_dir/'cardinal'

    @property
    def db_path(self):return self.shop_dir/'shop.sqlite3'

    def public_status(self):
        return {'run_mode':self.run_mode,'buyer_bot_configured':bool(self.shop_token),
                'api_configured':bool(self.api_key and self.api_secret),
                'live_purchases_allowed':self.shop_live,'payment_connector':'disabled',
                'owner_configured':self.owner_id>0}

    def __repr__(self):return 'Settings('+str(self.public_status())+')'
