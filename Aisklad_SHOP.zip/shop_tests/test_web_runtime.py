import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock
from unittest.mock import patch

from aisklad_shop.runtime import ShopWorker
from aisklad_shop.settings import Settings


class WebRuntimeTests(unittest.TestCase):
    def test_configuration_defaults_safe_and_never_prints_bridge_secret(self):
        value=Settings.from_env({})
        self.assertEqual(value.web_payments_mode,'disabled')
        self.assertFalse(value.shop_live)
        secret='private-bridge-value-'*3
        value=Settings.from_env({'AISKLAD_WEB_PAYMENTS_MODE':'test',
            'AISKLAD_WEB_PAYMENTS_URL':'https://worker.example',
            'AISKLAD_WEB_PAYMENTS_SECRET':secret})
        self.assertNotIn(secret,repr(value))
        self.assertEqual(value.public_status()['payment_connector'],'test')

    def test_invalid_bridge_origin_or_short_secret_rejected(self):
        env={'AISKLAD_WEB_PAYMENTS_MODE':'live','AISKLAD_WEB_PAYMENTS_SECRET':'x'*48}
        for url in ('http://worker.example','https://key@worker.example',
                    'https://worker.example/api','https://worker.example?secret=x',
                    'https://worker.example/#x','https://worker.example:444'):
            with self.subTest(url=url),self.assertRaises(ValueError):
                Settings.from_env(dict(env,AISKLAD_WEB_PAYMENTS_URL=url))
        with self.assertRaises(ValueError):
            Settings.from_env(dict(env,AISKLAD_WEB_PAYMENTS_URL='https://worker.example',
                                  AISKLAD_WEB_PAYMENTS_SECRET='short'))

    def test_bridge_outage_backs_off_and_sends_one_alert_after_seven_failures(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings(Path(tmp))
            service=Mock();service.payments.synchronize.side_effect=TimeoutError('offline')
            worker=ShopWorker(service,Mock(),Mock(),settings,clock=lambda:100)
            for attempt in range(1,9):
                worker._payment_task()
                self.assertGreater(worker.next_payment,100)
            self.assertEqual(service._notify_owner.call_count,1)
            service.payments.synchronize.side_effect=None
            worker._payment_task()
            self.assertNotIn('payment',worker.failures)

    def test_worker_honours_retry_after_longer_than_generic_backoff(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings(Path(tmp));service=Mock()
            service.payments.synchronize.side_effect=TimeoutError('offline')
            service.record_payment_diagnostic.return_value={'code':'BRIDGE_RATE_LIMIT','http_status':429,'retry_after':1000}
            worker=ShopWorker(service,Mock(),Mock(),settings,clock=lambda:100)
            worker._payment_task()
            self.assertEqual(worker.next_payment,1100)

    def test_owned_retry_wake_runs_even_during_previous_bridge_backoff(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings(Path(tmp));service=Mock()
            service.store.get_setting.return_value=1234567890
            worker=ShopWorker(service,Mock(),Mock(),settings,clock=lambda:100)
            worker.next_payment=worker.next_rate=worker.next_sync=1000
            with patch.object(worker,'_schedule') as schedule:
                worker.tick()
            self.assertEqual(schedule.call_args.args[0],'payment')
            self.assertEqual(worker.last_payment_wake,1234567890)


if __name__=='__main__':unittest.main()
