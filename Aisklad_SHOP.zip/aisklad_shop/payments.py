"""Payment boundary. No production connector is enabled in this release.

Digital goods sold inside Telegram must use Telegram Stars. An arbitrary Aisklad
HTTP callback, buyer message or admin command is never proof of payment. A future
connector must authenticate the transport and bind a successful charge to the
server-created invoice. This interface does not supply a payment bypass.
"""
from dataclasses import dataclass
from decimal import Decimal
from typing import Mapping, Protocol


class PaymentUnavailable(RuntimeError):
    pass


@dataclass(frozen=True)
class VerifiedPaymentEvent:
    provider: str
    event_id: str
    charge_id: str
    invoice_id: str
    order_id: str
    user_id: int
    amount: str
    currency: str
    status: str


class PaymentVerifier(Protocol):
    def verify(self, raw_body: bytes, headers: Mapping[str, str]) -> VerifiedPaymentEvent:
        """Authenticate server transport/signature before returning this object."""


class DisabledPayments:
    enabled = False
    provider = "disabled"
    currency = "RUB"
    verifier = None
    reason = "Оплата ещё не подключена. Каталог, избранное и корзина доступны."

    def create_invoice(self, **kwargs):
        raise PaymentUnavailable(self.reason)


def validate_event(event):
    if not isinstance(event, VerifiedPaymentEvent):
        raise ValueError("Only authenticated payment events are accepted")
    if event.status != "succeeded" or not all((event.provider, event.event_id, event.charge_id, event.invoice_id, event.order_id)):
        raise ValueError("Payment is not a successful identified charge")
    amount = Decimal(str(event.amount))
    if not amount.is_finite() or amount <= 0 or event.user_id <= 0:
        raise ValueError("Invalid payment value")
    return event
