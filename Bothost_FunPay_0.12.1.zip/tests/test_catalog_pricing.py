"""Offline contracts for hourly prices, catalogue creation and new fulfilment."""
from copy import deepcopy
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as N
import unittest
from unittest.mock import Mock, patch

from test_cardinal_compatibility import source_interfaces, full_order, shortcut
from test_safety_integration import Cardinal, API
import steamru_stars as bot
import steamru_stars_catalog as catalog
import steamru_stars_pricing as pricing
from steamru_stars_engine import Store, SteamClient, D, finances


def game(**changes):
    return dict(app_id=945360, option_id=313, name='Among Us', platform='steam', content_kind='game',
                region='GLOBAL', countries=[], excluded_countries=[], stock=9, min_quantity=1,
                max_quantity=9, price_usd='3.277', **changes)


TOPUP = '''<form id="topup-form" action="https://partner.steam.ru/wallet/topup" data-rate="83.92000000">
<input id="topup-amount" min="5.96" max="5958"/>
<div data-fee-percent="4" data-fee-fix="0"><input name="payment_service_id" value="sbp"/></div></form>'''
FORM = '''<form class="form-offer-editor"><input name="node_id" value="1008"/>
<input name="offer_id" value="0"/><input name="csrf_token" value="FICTITIOUS_TOKEN"/>
<select name="fields[type]"><option value="">Choose</option><option value="Игра">Game</option></select></form>'''


class PricingTests(unittest.TestCase):
    def test_effective_sbp_quote_includes_fee_and_invoice_rounding(self):
        quote = pricing.parse_topup(TOPUP)
        self.assertEqual(quote['invoice_rub'], '8741.67')
        self.assertEqual(quote['effective_rub_per_usd'], '87.4167')
        self.assertTrue(quote['read_only'])

    def test_quote_minimum_is_respected(self):
        self.assertEqual(pricing.parse_topup(TOPUP, reference='1')['reference_usd'], '5.96')

    def test_missing_quote_form_or_fee_is_rejected(self):
        for html in ('<html>Login</html>', TOPUP.replace('data-fee-percent="4"', ''), TOPUP.replace('83.92000000', 'NaN')):
            with self.subTest(html=html), self.assertRaises(ValueError):
                pricing.parse_topup(html)

    def test_price_band_covers_cost_with_small_margin_for_all_products(self):
        for unit, count in (('.0152', 50), ('.0152', 100), ('.0152', 150), ('3.277', 1), ('.0118', 100), ('.0118', 500)):
            with self.subTest(unit=unit, count=count):
                floor = pricing.seller_floor(unit, count, '87.41778523489933', '3', '.25', '.35')
                ceiling = pricing.seller_ceiling(unit, count, '87.41778523489933', '3', '.25', '.4')
                low = finances(floor, unit, count, '87.41778523489933', '3', '.25')
                high = finances(max(floor, ceiling), unit, count, '87.41778523489933', '3', '.25')
                self.assertGreaterEqual(low['margin_pct'], D('.35'))
                self.assertLessEqual(high['margin_pct'], D('.4'))

    def test_competitors_are_exact_package_method_rub_and_other_seller(self):
        def lot(id, price, **changes):
            data = dict(id=id, price=price, seller=N(id=22), currency='RUB', amount=1,
                        attributes={'f-quantity': '50 звёзд', 'f-method': 'По username'})
            data.update(changes); return N(**data)
        lots = [lot(1, '90'), lot(2, '89'), lot(3, '1', seller=N(id=7)), lot(4, '2', currency='USD'),
                lot(5, '3', amount=0), lot(6, '4', attributes={'f-quantity': '100 звёзд'}), lot(7, 'NaN')]
        self.assertEqual(pricing.comparable_minimum(lots, 50, 7, {2}), (D('90'), 1))

    def test_customer_fee_is_used_and_price_stays_in_band(self):
        def quote(price):
            return N(min_price_with_commission=None, min_price_currency='RUB',
                     methods=[N(price=price * D('1.14'), currency='RUB')])
        plan = pricing.choose_price('70', (D('80.5'), 4), '1.14', quote, ceiling='70.03')
        self.assertEqual(plan['seller_price'], D('70.03'))
        self.assertEqual(plan['buyer_price'], D('79.83'))
        low = pricing.choose_price('70', (D('70'), 4), '1.14', quote, ceiling='70.03')
        self.assertEqual(low['seller_price'], D('70')); self.assertEqual(low['reason'], 'margin_floor')

    def test_funded_cost_is_conservative_and_stale_quote_is_rejected(self):
        cfg = {**bot.DEFAULT, 'wallet_paid_rub': '521.01', 'wallet_credited_usd': '5.96',
               'auto_pricing': {'enabled': True, 'watch_topup_rate': True}}
        quote = pricing.parse_topup(TOPUP)
        with patch.object(pricing, 'TOPUP_CLIENT', N(snapshot=quote)):
            self.assertEqual(pricing.pricing_rate(cfg), D('521.01') / D('5.96'))
            quote['effective_rub_per_usd'] = '90'
            self.assertEqual(pricing.pricing_rate(cfg), D('90'))
            quote['verified_at'] = (datetime.now(timezone.utc)-timedelta(hours=3)).isoformat()
            with self.assertRaises(ValueError): pricing.pricing_rate(cfg)

    def test_partner_requests_cannot_submit_payments_or_follow_foreign_redirect(self):
        session = Mock()
        session.request.return_value = N(status_code=302,headers={'Location': 'https://evil.invalid/dashboard'})
        client = pricing.PartnerTopupClient('LOCAL_EMAIL', 'LOCAL_PASSWORD', session=session)
        with self.assertRaises(ValueError): client._request('POST', '/wallet/topup')
        session.request.assert_not_called()
        with self.assertRaises(ValueError): client._request('GET', '/wallet/topup')
        self.assertFalse(session.request.call_args.kwargs['allow_redirects'])
        client.close(); self.assertEqual(client._password, '')
        session.cookies.clear.assert_called_once()

    def test_partner_login_uses_token_and_rechecks_quote_without_payment(self):
        session = Mock()
        session.request.side_effect = [N(status_code=302, headers={'Location':'/login'}),
            N(status_code=200, headers={}, text='<form action="/login"><input name="_token" value="TEST"/></form>'),
            N(status_code=302, headers={'Location':'/dashboard'}), N(status_code=200, headers={}, text=TOPUP)]
        client = pricing.PartnerTopupClient('LOCAL_EMAIL', 'LOCAL_PASSWORD', session=session)
        self.assertEqual(client.refresh()['invoice_rub'], '8741.67')
        calls = session.request.call_args_list
        self.assertEqual([c.args[0] for c in calls], ['GET','GET','POST','GET'])
        self.assertTrue(calls[2].args[1].endswith('/login'))
        self.assertEqual(calls[2].kwargs['headers']['Origin'],'https://partner.steam.ru')
    def test_login_accepts_intended_same_host_redirect_and_verifies_form(self):
        session=Mock();session.request.side_effect=[N(status_code=302,headers={'Location':'/login'}),
            N(status_code=200,headers={},text='<form action="/login"><input name="_token" value="TEST"/></form>'),
            N(status_code=302,headers={'Location':'https://partner.steam.ru/'}),
            N(status_code=200,headers={},text=TOPUP)]
        client=pricing.PartnerTopupClient('LOCAL_EMAIL','LOCAL_PASSWORD',session=session)
        self.assertEqual(client.refresh()['invoice_rub'],'8741.67')
    def test_http_login_redirect_is_not_followed_and_wallet_is_verified_over_https(self):
        session=Mock();session.request.side_effect=[N(status_code=302,headers={'Location':'/login'}),
            N(status_code=200,headers={},text='<form action="/login"><input name="_token" value="TEST"/></form>'),
            N(status_code=302,headers={'Location':'http://partner.steam.ru/dashboard'}),
            N(status_code=200,headers={},text=TOPUP)]
        client=pricing.PartnerTopupClient('LOCAL_EMAIL','LOCAL_PASSWORD',session=session)
        self.assertEqual(client.refresh()['invoice_rub'],'8741.67')
        self.assertTrue(all(c.args[1].startswith('https://partner.steam.ru/') for c in session.request.call_args_list))
        self.assertTrue(all(c.kwargs['allow_redirects'] is False for c in session.request.call_args_list))
        self.assertEqual(client.trace[2]['redirect_scheme'],'http')
    def test_login_rejection_has_safe_specific_message_and_no_extra_attempts(self):
        session=Mock();session.request.side_effect=[N(status_code=302,headers={'Location':'/login'}),
            N(status_code=200,headers={},text='<form action="/login"><input name="_token" value="TEST"/></form>'),
            N(status_code=302,headers={'Location':'/login'})]
        client=pricing.PartnerTopupClient('LOCAL_EMAIL','LOCAL_PASSWORD',session=session)
        with self.assertRaises(pricing.PartnerFailure) as caught:client.refresh()
        self.assertEqual(caught.exception.code,'login_denied')
        self.assertNotIn('LOCAL_EMAIL',str(caught.exception));self.assertNotIn('LOCAL_PASSWORD',str(caught.exception))
        self.assertEqual(len(session.request.call_args_list),3)
    def test_http_200_login_page_does_not_fake_success(self):
        session=Mock();session.request.return_value=N(status_code=200,headers={},text='<input name="password">')
        client=pricing.PartnerTopupClient('LOCAL_EMAIL','LOCAL_PASSWORD',session=session)
        with self.assertRaises(pricing.PartnerFailure) as caught:client.refresh()
        self.assertEqual(caught.exception.code,'login_denied')
        self.assertIsNone(client.snapshot)
    def test_authenticated_form_with_real_minimum_precision_matches_invoice(self):
        html=TOPUP.replace('min="5.96"','min="5.95999999999999996447286"').replace('max="5958"','max="5958.05000000000018189894"')
        self.assertEqual(pricing.parse_topup(html)['invoice_rub'],'8741.67')


class CatalogTests(unittest.TestCase):
    def test_games_over_five_dlc_unknown_region_and_no_stock_are_skipped(self):
        self.assertTrue(catalog.eligible_key(game()))
        for key, value in [('price_usd','5.01'), ('price_usd','NaN'), ('content_kind','dlc'),
                           ('stock',0), ('platform','xbox'), ('region','UNKNOWN'), ('min_quantity',2)]:
            record=game(); record[key]=value
            with self.subTest(key=key): self.assertFalse(catalog.eligible_key(record))

    def test_key_description_discloses_regions_and_no_supplier_identifiers(self):
        record=game(); record['excluded_countries']=['RU']
        rule=catalog.key_rule(record)
        self.assertIn('GLOBAL',rule['description']); self.assertIn('RU',rule['description'])
        self.assertEqual(rule['match_fields']['method'],'Цифровой ключ')
        self.assertNotIn('313',rule['description'])

    def test_pagination_deduplicates_and_uses_only_get(self):
        api=Mock()
        api.request.side_effect=[{'page':1,'total_pages':2,'games':[game()]},
                                 {'page':2,'total_pages':2,'games':[game()]}]
        self.assertEqual(len(catalog.catalogue(api)),1)
        self.assertTrue(all(c.args[0]=='GET' for c in api.request.call_args_list))
    def test_duplicate_public_identity_never_creates_ambiguous_keys(self):
        record=game();other=game();other['option_id']=314
        api=Mock();api.request.return_value={'page':1,'total_pages':1,'games':[record,other]}
        self.assertEqual(len(catalog.catalogue(api)),1)
    def test_explicit_server_rejection_is_recorded_for_corrected_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            store=Store(Path(temp)/'state.db');module=N(STORE=store,editor_field_value=bot.editor_field_value)
            account=Mock();account.get_my_subcategory_lots.return_value=[]
            account.method.side_effect=[N(content=FORM.encode()),N(json=lambda:{'error':'Invalid English description','errors':[['fields[desc][en]','invalid']]})]
            with self.assertRaises(catalog.DraftRejected):catalog.create_draft(module,N(account=account),'key',catalog.key_rule(game()),'300')
            self.assertEqual(json.loads(store.get_meta('catalog_intent:key'))['stage'],'rejected')

    def test_draft_is_inactive_single_key_without_builtin_delivery(self):
        fields=catalog.apply_rule(catalog.form_fields(FORM,1008),catalog.key_rule(game()),'300')
        self.assertEqual(fields['active'],''); self.assertEqual(fields['auto_delivery'],'')
        self.assertEqual(fields['secrets'],''); self.assertEqual(fields['amount'],'1')
        self.assertIn('Automatic delivery',fields['fields[desc][en]'])
        self.assertIn('No extra details needed',fields['fields[desc][en]'])

    def test_steam_packages_are_rub_only_with_real_editor_prefixes(self):
        rule=catalog.rub_rule(1,{'price_usd':'.0118'})
        fields=catalog.apply_rule({},rule,'214')
        self.assertEqual(fields['fields[currency]'],'%RUB')
        self.assertEqual(fields['fields[type]'],'%by-login')
        self.assertNotIn('quantity',rule['match_fields'])
        with self.assertRaises(ValueError): catalog.rub_rule(100,{'price_usd':'.0118'})

    def test_create_timeout_is_never_reposted_and_can_be_reconciled(self):
        with tempfile.TemporaryDirectory() as temp:
            store=Store(Path(temp)/'state.db')
            module=N(STORE=store,editor_field_value=bot.editor_field_value)
            account=Mock(); c=N(account=account)
            account.get_my_subcategory_lots.return_value=[]
            account.method.side_effect=[N(content=FORM.encode()),TimeoutError('lost create response')]
            rule=catalog.key_rule(game())
            with self.assertRaises(ValueError): catalog.create_draft(module,c,'key_1',rule,'300')
            with self.assertRaises(ValueError): catalog.create_draft(module,c,'key_1',rule,'300')
            self.assertEqual(account.method.call_count,2)
            account.get_my_subcategory_lots.return_value=[N(id=123)]
            fields=N(active=False,title_ru=rule['summary'],fields={f'fields[{k}]':v for k,v in rule['match_fields'].items()})
            fields.fields['fields[name][ru]']=rule['game_name']
            account.get_lot_fields.return_value=fields
            self.assertEqual(catalog.create_draft(module,c,'key_1',rule,'300'),123)
            self.assertEqual(catalog.create_draft(module,c,'key_1',rule,'300'),123)
            self.assertEqual(account.method.call_count,2)


class NewProductsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.types=source_interfaces()
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.old=bot.CFG,bot.STORE,bot.C
        bot.STORE=Store(Path(self.temp.name)/'state.db');bot.STORE.set_meta('paused','no');bot.STOP.clear()
        bot.CFG=deepcopy(bot.DEFAULT)
        bot.CFG.update(mode='live',honor_paid_price=True,allowed_subcategory_ids=[1008,1086],min_profit_rub='0',
            wallet_paid_rub='521.01',wallet_credited_usd='5.96',rub_per_usd=str(D('521.01')/D('5.96')),
            funding_rate_policy='deposit_cost',rub_per_usd_updated_at=datetime.now(timezone.utc).isoformat())
        self.api=API()
        self.api.key_product=Mock(return_value=game()); self.api.steam_rub_product=Mock(return_value={'product_id':1,'price_usd':'.0118'})
        self.api.create_game_key=Mock(side_effect=self.create); self.api.create_steam_rub=Mock(side_effect=self.create)
        self.api.check_steam_login=Mock(return_value=True)
        self.api.get_order=lambda uid:{'uuid':uid,'status':self.api.status,'voucher':'AAAAA-BBBBB-CCCCC'}
        self.live=patch.object(bot,'live_allowed',return_value=True);self.live.start()
        self.client=patch.object(bot,'client',return_value=self.api);self.client.start()
    def tearDown(self):
        self.client.stop();self.live.stop();bot.CFG,bot.STORE,bot.C=self.old;bot.STOP.clear();self.temp.cleanup()
    def create(self,*args):
        self.api.created.append(args);return {'uuid':'cf6a7f78-b460-4cb3-92ce-38bccd3c1ea6'}
    def capture(self,rule,count=1):
        bot.CFG['lot_rules']={'product':rule}
        order=full_order(self.types,title='',subcategory_id=rule['subcategory_id'],amount=count)
        order.fields={key:self.types.LotField(key,value) for key,value in rule['match_fields'].items()}
        order.sum=D('10') # Paid sale below current margin must still be honoured.
        self.c=Cardinal(order);bot.C=self.c
        event=shortcut(self.types,description='product');event.subcategory.id=rule['subcategory_id']
        bot.on_new_order(self.c,self.types.NewOrderEvent('offline',event))
        return bot.STORE.get('ABCD1234')
    def test_paid_key_needs_no_username_delivers_code_once(self):
        self.api.status='delivered'
        row=self.capture(catalog.key_rule(game())); self.assertEqual(row['status'],'ready')
        bot.process_ready(self.c);bot.process_ready(self.c)
        row=bot.STORE.get(row['id'])
        self.assertEqual(row['status'],'completed');self.assertEqual(len(self.api.created),1)
        self.assertEqual(row['voucher'],'AAAAA-BBBBB-CCCCC')
        self.assertEqual(sum('AAAAA-BBBBB-CCCCC' in text for _,text in self.c.messages),1)
    def test_key_delivered_without_voucher_requires_review_not_repeat(self):
        self.api.status='delivered';self.capture(catalog.key_rule(game()))
        self.api.get_order=lambda uid:{'uuid':uid,'status':'delivered'}
        bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'needs_review')
        self.assertEqual(len(self.api.created),1)
    def test_steam_rub_plain_login_and_completed_flow(self):
        row=self.capture(catalog.rub_rule(1,{'price_usd':'.0118'}),200)
        self.assertEqual(row['status'],'awaiting_username')
        message=N(text='steam_login',author_id=12,chat_id='users-7-12',type=N(name='NON_SYSTEM'),by_bot=False)
        bot.on_new_message(self.c,N(message=message));bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'completed')
        self.assertEqual(self.api.created,[('funpay-ABCD1234',200,'steam_login')])
    def test_steam_refunded_before_post_never_bought(self):
        row=self.capture(catalog.rub_rule(1,{'price_usd':'.0118'}),100)
        bot.STORE.set_username(row['id'],12,row['chat_id'],'steam_login')
        self.c.account.order.status=self.types.OrderStatuses.REFUNDED
        bot.process_ready(self.c);self.assertEqual(self.api.created,[])
    def test_rub_nominal_outside_supplier_limits_is_never_captured(self):
        for count in (1,99,501):
            self.capture(catalog.rub_rule(1,{'price_usd':'.0118'}),count)
            self.assertIsNone(bot.STORE.get('ABCD1234'))
        self.assertEqual(self.api.created,[])
    def test_low_balance_waits_then_recovers_without_duplicate(self):
        self.api.status='delivered';self.capture(catalog.key_rule(game()))
        self.api.balance=lambda:D('0')
        bot.process_ready(self.c)
        row=bot.STORE.get('ABCD1234');self.assertEqual(row['status'],'ready');self.assertFalse(bot.paused())
        bot.process_ready(self.c);self.assertEqual(self.api.created,[])
        bot.STORE.set(row['id'],retry_after=0);self.api.balance=lambda:D('100')
        bot.process_ready(self.c);self.assertEqual(len(self.api.created),1)
    def test_deferred_order_does_not_starve_other_orders(self):
        self.capture(catalog.key_rule(game()));bot.STORE.set('ABCD1234',retry_after=10**12)
        bot.STORE.insert_order('OTHER123',12,'users-7-12','buyer','rule:product',1,1,'100',captured_mode='live',kind='game_key')
        bot.STORE.set('OTHER123',status='ready')
        self.assertEqual(bot.STORE.take_ready()['id'],'OTHER123')
    def test_key_error_review_closed_are_not_refunds(self):
        for status in ('error','review','closed','completed'):
            with self.subTest(status=status):
                bot.STORE=Store(Path(self.temp.name)/(status+'.db'));bot.STORE.set_meta('paused','no')
                self.api.status=status;self.capture(catalog.key_rule(game()));bot.process_ready(self.c)
                self.assertEqual(bot.STORE.get('ABCD1234')['status'],'needs_review')


class SupplierPayloadTests(unittest.TestCase):
    def test_key_and_rub_payloads_and_default_no_purchase_guard(self):
        client=SteamClient('OFFLINE_KEY','OFFLINE_SECRET')
        with self.assertRaises(PermissionError):client.create_game_key('funpay-ABC123',945360,313)
        with self.assertRaises(PermissionError):client.create_steam_rub('funpay-ABC123',100,'steam_login')
        client=SteamClient('OFFLINE_KEY','OFFLINE_SECRET',allow_purchases=True)
        client.request=Mock(return_value={'uuid':'offline-uuid'})
        client.create_game_key('funpay-ABC123',945360,313)
        self.assertEqual(client.request.call_args.kwargs['payload'],{'external_order_id':'funpay-ABC123','app_id':945360,'option_id':313,'quantity':1})
        client.create_steam_rub('funpay-ABC124',500,'steam_login')
        self.assertEqual(client.request.call_args.kwargs['payload'],{'external_order_id':'funpay-ABC124','service':'steam','product_id':1,'product_count':500,'account':'steam_login'})

    def test_official_openapi_matches_request_contract_and_voucher_status(self):
        schema=json.loads((Path(__file__).parent/'fixtures/steamru_openapi.json').read_text(encoding='utf-8'))
        definitions=schema['components']['schemas']
        self.assertTrue({'external_order_id','app_id'}.issubset(definitions['CreateGameKeyOrderRequest']['required']))
        self.assertTrue({'option_id','quantity'}.issubset(definitions['CreateGameKeyOrderRequest']['properties']))
        self.assertTrue({'service','product_id','product_count','account'}.issubset(definitions['CreateOrderRequest']['properties']))
        self.assertIn('voucher',definitions['Order']['properties'])
        self.assertIn('delivered',definitions['Order']['properties']['status']['enum'])
        self.assertIn('/check/steam-account',schema['paths'])


class MaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=bot.CFG,bot.STORE,bot.C,bot.CFG_PATH
        bot.CFG=deepcopy(bot.DEFAULT)
        bot.CFG.update(mode='live',wallet_paid_rub='521.01',wallet_credited_usd='5.96',min_margin_pct='.35',min_profit_rub='0')
        bot.CFG['auto_pricing']['enabled']=True
        bot.STORE=Store(Path(self.temp.name)/'state.db');bot.STORE.set_meta('paused','no');bot.STOP.clear()
        bot.CFG_PATH=Path(self.temp.name)/'cfg.json'
        self.c=N(account=Mock(),plugins={bot.UUID:N(enabled=True)},telegram=None)
        bot.C=self.c
        self.c.account.id=7
        self.live=patch.object(bot,'live_allowed',return_value=True);self.live.start()
        self.api=Mock();self.api.balance.return_value=D('5.96')
        self.client=patch.object(bot,'client',return_value=self.api);self.client.start()
    def tearDown(self):
        self.client.stop();self.live.stop();bot.CFG,bot.STORE,bot.C,bot.CFG_PATH=self.old;bot.STOP.clear();self.temp.cleanup()
    def fields(self,oid,rule,price):
        value=N(lot_id=oid,price=float(price),active=False,amount=1,auto_delivery=False,currency='RUB',
            subcategory=N(type='COMMON',id=rule['subcategory_id']),title_ru=rule.get('summary',''),
            fields={f'fields[{k}]':v for k,v in rule['match_fields'].items()},
            calc_result=N(commission_coefficient=1.14))
        value.renew_fields=lambda:value
        if rule.get('game_name'):
            value.fields['fields[name][ru]']=rule['game_name']
        return value
    def test_hourly_scheduler_does_not_fetch_or_write_twice(self):
        bot.STORE.set_meta('last_reprice',str(bot.time.time()))
        bot.auto_reprice(self.c)
        self.client.stop();self.c.account.get_subcategory_public_lots.assert_not_called()
        self.c.account.save_lot.assert_not_called()
    def test_pause_prevents_price_write(self):
        bot.STORE.set_meta('paused','yes')
        with self.assertRaises(ValueError): bot.write_seller_price(self.c,1,{},'100')
        self.c.account.save_lot.assert_not_called()
    def test_reprice_reads_market_once_saves_seller_price_and_cadence(self):
        rule={'subcategory_id':2418,'stars_per_unit':50,'match_fields':{'quantity':'50 звёзд','quantity2':'','method':'По username'}}
        bot.CFG['lot_rules']={'stars':rule};bot.CFG['managed_lots']={'1':'stars'}
        fields=self.fields(1,rule,'72')
        self.c.account.get_lot_fields.return_value=fields
        self.c.account.get_subcategory_public_lots.return_value=[N(id=2,seller=N(id=22),amount=1,currency='RUB',price='80',
                    attributes={'f-quantity':'50 звёзд','f-method':'По username'})]
        self.c.account.calc.side_effect=lambda *args,**kw:N(min_price_with_commission=kw['price']*1.14,min_price_currency='RUB',methods=[])
        self.api.product.return_value={'price_usd':'.0152'}
        with patch.object(bot,'funding_rate_valid',return_value=True):bot.auto_reprice(self.c)
        margin=finances(fields.price,'.0152',50,D('521.01')/D('5.96'),'3','.25')['margin_pct']
        self.assertTrue(D('.35') <= margin <= D('.4'))
        self.assertTrue(bot.STORE.get_meta('last_reprice'))
        bot.auto_reprice(self.c)
        self.c.account.get_subcategory_public_lots.assert_called_once()
        self.c.account.save_lot.assert_called_once()
    def test_rub_lot_stock_limits_nominal_to_affordable_balance(self):
        rule=catalog.rub_rule(1,{'price_usd':'.0118'})
        bot.CFG['lot_rules']={'rub':rule};bot.CFG['managed_lots']={'1':'rub'}
        fields=self.fields(1,rule,price='1')
        self.c.account.get_lot_fields.return_value=fields
        bot.maintain_availability(self.c)
        self.assertTrue(fields.active);self.assertEqual(fields.amount,483)
        self.assertEqual(D(fields.price),D('1.07'))
        self.assertEqual(self.api.create.call_count,0)
    def test_stock_disappearance_turns_key_off_without_purchase(self):
        rule=catalog.key_rule(game());rule['sell_enabled']=False
        bot.CFG['lot_rules']={'key':rule};bot.CFG['managed_lots']={'1':'key'}
        fields=self.fields(1,rule,'300');fields.active=True
        self.c.account.get_lot_fields.return_value=fields
        bot.maintain_availability(self.c)
        self.assertFalse(fields.active);self.api.create_game_key.assert_not_called()
    def test_catalog_adds_small_batches_and_keeps_existing_binding(self):
        self.c.account.get_my_subcategory_lots.return_value=[]
        bot.CFG['catalog_sync']['enabled']=True
        rub=catalog.rub_rule(1,{'price_usd':'.0118'})
        bot.CFG['lot_rules']={'steam_rub':rub};bot.CFG['managed_lots']={'50':'steam_rub'}
        self.api.steam_rub_product.return_value={'price_usd':'.0118'}
        desired=[]
        for i in range(5):
            record=game();record['app_id']=1000+i;record['name']='Game '+str(i)
            desired.append(('key_'+str(i),catalog.key_rule(record)))
        with patch.object(catalog,'catalogue',return_value=desired),patch.object(catalog,'create_draft',side_effect=[1,2,3]) as create:
            bot.sync_catalog(self.c)
        self.assertEqual(create.call_count,3)
        self.assertEqual(bot.CFG['managed_lots']['50'],'steam_rub')
        self.assertEqual(len(bot.CFG['managed_lots']),4)
        self.assertTrue(bot.time.time()<float(bot.STORE.get_meta('next_catalog_sync'))<=bot.time.time()+181)

    def test_twenty_key_slots_prevent_twenty_first_creation_without_stopping_existing_sales(self):
        bot.CFG['catalog_sync']['enabled']=True
        rub=catalog.rub_rule(1,{'price_usd':'.0118'})
        bot.CFG['lot_rules']={'steam_rub':rub};bot.CFG['managed_lots']={'50':'steam_rub'}
        self.c.account.get_my_subcategory_lots.return_value=[N(id=i) for i in range(20)]
        self.api.steam_rub_product.return_value={'price_usd':'.0118'}
        with patch.object(catalog,'catalogue',return_value=[('new_key',catalog.key_rule(game()))]), \
             patch.object(catalog,'create_draft') as create:
            bot.sync_catalog(self.c)
        create.assert_not_called();self.assertFalse(bot.paused())
        self.assertEqual(bot.CFG['managed_lots'],{'50':'steam_rub'})
        self.assertIn('20/20',bot.STORE.get_meta('catalog_summary'))

