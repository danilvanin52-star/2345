"""Bothost entry point: two independently supervised Telegram sales channels."""
from pathlib import Path
import argparse
import logging
import os
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'plugins')]

from aisklad_shop.settings import Settings

LOG=logging.getLogger('aisklad.supervisor')


def component_environment(settings,env=None):
    result=dict(os.environ if env is None else env)
    result['FPC_DATA_DIR']=str(settings.data_dir)
    result['AISKLAD_SHARED_DB']=str(settings.db_path)
    result['AISKLAD_PURCHASE_LOCK']=str(settings.shop_dir/'supplier-purchases.lock')
    result['AISKLAD_RATE_FILE']=str(settings.shop_dir/'partner_rate.json')
    result['PYTHONUNBUFFERED']='1'
    return result


def check(settings):
    # No network, Telegram polling, supplier writes or subprocesses.
    import json
    from PIL import Image
    missing=[]
    for key in ('home','catalog','search','favorites','cart','checkout','orders','profile','help','product','assistant','about'):
        path=ROOT/'assets/menus'/(key+'.png')
        if not path.is_file():missing.append(key);continue
        with Image.open(path) as image:image.verify()
    if missing:raise ValueError('Нет изображений меню: '+', '.join(missing))
    print(json.dumps(settings.public_status(),ensure_ascii=False,indent=2))
    print('Файлы готовы. Проверка без сети, оплат и запуска ботов.')
    return 0


def supervise(settings,process_factory=subprocess.Popen,clock=time.monotonic,sleep=time.sleep):
    from aisklad_shop.store import ShopStore
    from steamru_instance import InstanceLock
    settings.shop_dir.mkdir(parents=True,exist_ok=True)
    ShopStore(settings.db_path)
    environment=component_environment(settings)
    components=[]
    if settings.run_mode in ('all','funpay'):components.append('funpay')
    if settings.run_mode in ('all','shop') and settings.shop_token:components.append('shop')
    if settings.run_mode=='shop' and not settings.shop_token:
        raise ValueError('Для AISKLAD_RUN_MODE=shop нужен AISKLAD_SHOP_TOKEN.')
    if settings.run_mode=='all' and not settings.shop_token:
        LOG.warning('Токен магазина пока не задан. FunPay работает отдельно; добавь AISKLAD_SHOP_TOKEN для витрины.')
    children={};restart_at={name:0 for name in components};failures={name:0 for name in components}
    stopping=False
    def stop(*args):
        nonlocal stopping
        stopping=True
    old_term=signal.signal(signal.SIGTERM,stop);old_int=signal.signal(signal.SIGINT,stop)
    with InstanceLock(settings.shop_dir/'supervisor'):
        try:
            while not stopping:
                for name in components:
                    process=children.get(name)
                    if process is not None:
                        code=process.poll()
                        if code is None:continue
                        children.pop(name,None);failures[name]+=1
                        delay=min(300,10*2**min(failures[name]-1,5));restart_at[name]=clock()+delay
                        LOG.warning('Модуль %s завершился (код %s). Повтор через %s сек.; второй модуль работает.',name,code,delay)
                    if clock()>=restart_at[name] and name not in children:
                        children[name]=process_factory([sys.executable,'-u',str(ROOT/'run_aisklad.py'),'--component',name],
                                                       cwd=str(ROOT),env=environment)
                sleep(1)
        finally:
            for process in children.values():
                if process.poll() is None:process.terminate()
            for process in children.values():
                try:process.wait(timeout=45)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
            signal.signal(signal.SIGTERM,old_term);signal.signal(signal.SIGINT,old_int)
    return 0


def main(argv=None):
    parser=argparse.ArgumentParser(description='Aisklad SHOP + FunPay')
    parser.add_argument('--component',choices=('shop','funpay'))
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(name)s: %(message)s')
    try:
        settings=Settings.from_env()
        if args.check:return check(settings)
        if args.component:
            os.environ.update(component_environment(settings))
            if args.component=='shop':
                from aisklad_shop.runtime import run_shop
                return run_shop(settings) or 0
            import start_bothost
            return start_bothost.main()
        return supervise(settings)
    except KeyboardInterrupt:return 0
    except Exception as exc:
        # Telegram/HTTP exceptions may embed a token-bearing URL. Never dump them.
        LOG.error('Запуск не завершён: %s. Проверь настройки модуля; секреты в журнал не выводятся.',type(exc).__name__)
        if isinstance(exc,ValueError) and type(exc).__module__ in ('builtins','aisklad_shop.settings'):
            LOG.error('Нужны корректные токены, ID владельца и параметры из hosting.env.example.')
        return 2


if __name__=='__main__':sys.exit(main())
