"""Activation, private payment links and isolated guest browser UX. No network."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from aisklad_shop.activation import activation_instructions
from aisklad_shop.bot import BuyerBot
from aisklad_shop import presentation as p
from shop_tests.test_bot import FakeBot, FakeService


ROOT = Path(__file__).resolve().parents[1]
HTML = next((path for path in (ROOT / "assets" / "shop-checkout.html", ROOT.parent / "Aisklad_PAYMENTS_0.14.0" / "shop-checkout.html") if path.is_file()), ROOT / "assets" / "shop-checkout.html")
NODE = shutil.which("node")

HARNESS = r"""
const fs=require('fs'),vm=require('vm');const html=fs.readFileSync(process.argv[1],'utf8'),script=html.match(/<script>([\s\S]*?)<\/script>/)[1],scenario=JSON.parse(process.argv[2]);
class Element{constructor(tag='div'){this.tag=tag;this.children=[];this.attrs={};this.listeners={};this.disabled=false;this.hidden=false;this._text=''}set textContent(value){this._text=String(value);this.children=[]}get textContent(){return this._text+this.children.map(c=>c.textContent||'').join('')}set innerHTML(_){throw Error('unsafe_innerHTML')}append(...nodes){this.children.push(...nodes)}replaceChildren(...nodes){this._text='';this.children=nodes}setAttribute(k,v){this.attrs[k]=String(v)}addEventListener(k,v){this.listeners[k]=v}}
const nodes={},listeners={},requests=[],navigations=[],clipboard=[],storage=new Map(),history=[];const document={hidden:false,getElementById:id=>nodes[id]||(nodes[id]=new Element()),createElement:tag=>new Element(tag),createTextNode:text=>({textContent:text}),addEventListener:(name,fn)=>listeners[name]=fn};
let mode=scenario.mode||'test';const response={order_id:'O1',status:scenario.status||'awaiting_payment',amount:'120.50',currency:'RUB',items:[{id:'i1',title:'<img src=x onerror=alert(1)>',quantity:156,fields:{account:'buyer<&>'},total_rub:'120.50',kind:'key',status:scenario.lineStatus||'completed',delivery:scenario.delivery===false?[]:['LONG-CODE-<&>-END'],activation:['Открой Steam','https://store.steampowered.com/account/registerkey','https://evil.test/steal']}],providers:['robokassa','yookassa','evil'],mode,expires_at:Date.now()/1000+600};
const timers=new Map();let timerId=0;const location={origin:'https://shop.example',pathname:'/shop/checkout',search:'?order_id=O1&payment=success',hash:'#token=FAKE_CAPABILITY_12345678901234567890',assign:u=>navigations.push(u)};
const context={document,location,history:{replaceState:(_a,_b,url)=>history.push(url)},sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},navigator:{clipboard:{writeText:async value=>clipboard.push(value)}},URL,URLSearchParams,Date,Set,Map,Math,JSON,String,Number,Object,Array,Promise,Error,encodeURIComponent,
setTimeout:(fn,ms)=>{timers.set(++timerId,{fn,ms});return timerId},clearTimeout:id=>timers.delete(id),window:{addEventListener:(name,fn)=>listeners[name]=fn},
fetch:async(url,options)=>{requests.push({url,options});if(url.endsWith('/pay')){if(scenario.alreadyPaid){response.status=scenario.afterPayStatus||'paid';return{ok:true,status:200,json:async()=>({payment_url:'https://shop.example/shop/checkout?order_id=O1',status:scenario.payResultStatus||'paid'})}}return{ok:true,status:200,json:async()=>({payment_url:scenario.badUrl?'https://evil.test/pay':'https://auth.robokassa.ru/Merchant/Index.aspx?InvId=123'})}};return{ok:true,status:200,json:async()=>response}}};
vm.createContext(context);new vm.Script(script).runInContext(context);
const settle=async()=>{for(let i=0;i<8;i++)await new Promise(resolve=>setImmediate(resolve))};
function walk(node,result=[]){result.push(node);for(const child of node.children||[])walk(child,result);return result}
(async()=>{await settle();if(scenario.pay){await nodes.pay.listeners.click();await settle()}if(scenario.copy){const button=walk(nodes.items).find(n=>n.tag==='button'&&n.textContent==='Скопировать');if(button)await button.listeners.click();await settle()}if(scenario.visibility){document.hidden=true;await nodes.refresh.listeners.click();await settle();const hiddenRequests=requests.length;document.hidden=false;listeners.visibilitychange();await settle();scenario.hiddenRequests=hiddenRequests}
const all=walk(nodes.items),out={amount:nodes.amount.textContent,status:nodes['status-title'].textContent,detail:nodes['status-detail'].textContent,text:nodes.items.textContent,providerCount:nodes.providers.children.length,payLabel:nodes.pay.textContent,payDisabled:nodes.pay.disabled,mode:nodes.mode.textContent,error:nodes.error.textContent,history,stored:[...storage.keys()],requestCount:requests.length,paths:requests.map(r=>r.url),privateRequests:requests.every(r=>r.options.credentials==='omit'&&r.options.cache==='no-store'&&r.options.redirect==='error'&&r.options.headers.Authorization==='Bearer FAKE_CAPABILITY_12345678901234567890'),navigations,clipboard,linkHosts:all.filter(n=>n.tag==='a').map(n=>new URL(n.href).hostname),scenario,delays:[...timers.values()].map(t=>t.ms)};process.stdout.write(JSON.stringify(out))})().catch(()=>{process.stderr.write('UI harness failed');process.exitCode=1});
"""


class ActivationTests(unittest.TestCase):
    def test_known_instructions_without_invented_links_or_region(self):
        fixtures = [(dict(kind="key", platform="steam", content_kind="dlc"), "DLC"),
                    (dict(kind="gift"), "подар"), (dict(kind="topup", service="steam", unit_currency="KZT"), "тенге"),
                    (dict(kind="topup", service="telegram-stars"), "звёзд"), (dict(kind="topup", service="telegram-premium"), "Premium"),
                    (dict(kind="code", title="Blizzard Battle.net Gift Card"), "Battle.net")]
        for product, expected in fixtures:
            steps = activation_instructions(product)
            self.assertIn(expected, " ".join(steps))
            self.assertFalse(any("https:" in step for step in steps))
        unknown = " ".join(activation_instructions({"kind": "code", "title": "Unknown <brand>"}))
        self.assertIn("соответствующего сервиса", unknown)
        self.assertNotIn("Steam", unknown)

    def test_nonsteam_key_not_given_steam_activation(self):
        self.assertNotIn("«Активировать в Steam»", " ".join(activation_instructions({"kind": "key", "platform": "epic"})))

    def test_steam_wallet_code_is_not_a_game_key(self):
        text = " ".join(activation_instructions({"kind": "code", "title": "Steam Gift Card"}))
        self.assertIn("пополнение кошелька", text)
        self.assertNotIn("«Активировать в Steam»", text)

    def test_perline_delivery_and_activation_no_duplicate_or_truncation(self):
        code = "X" * 5000 + "-END"
        screen = p.order({"id": "O1", "status": "partially_completed", "total_rub": "120", "delivery": [code],
                          "items": [{"title": "Key", "quantity": 1, "status": "completed", "delivery": [code], "activation": ["Открой <Steam>"]},
                                    {"title": "Pending", "quantity": 1, "status": "processing", "activation": ["Not yet"]}]})
        self.assertEqual(screen.caption.count(code), 1)
        self.assertIn("&lt;Steam&gt;", screen.caption)
        self.assertNotIn("Not yet", screen.caption)

    def test_web_button_requires_registered_connector_and_order_ownership(self):
        service, bot = FakeService(), FakeBot()
        url = "https://shop.example/shop/checkout?order_id=O1#token=FAKE_CAPABILITY_12345678901234567890"
        class Connector:
            provider, enabled, mode = "aisklad_web", True, "test"
            def validate_checkout_url(self, value):
                return value == url
        service.payments = Connector()
        service.order = lambda uid, oid: {"id": "O1", "user_id": 10, "status": "awaiting_payment", "total_rub": "120", "payment_url": url, "payment_mode": "test", "external_payment": True}
        ui = BuyerBot(service, bot=bot, owner_id=99, assets_dir="/no-assets")
        ui._send_screen(10, p.order(service.order(10, "O1")))
        buttons = [b for row in bot.sent[-1][2]["reply_markup"].keyboard for b in row]
        self.assertEqual([b.url for b in buttons if b.url], [url])
        self.assertNotIn("FAKE_CAPABILITY", bot.sent[-1][1])
        self.assertFalse(ui._valid_checkout_url(20, url, "O1"))
        self.assertFalse(ui._valid_checkout_url(10, "https://evil.test", "O1"))
        self.assertNotIn("FAKE_CAPABILITY", json.dumps(service.store.get_session(10)))


@unittest.skipUnless(NODE, "Node is required for isolated browser checks")
class GuestCheckoutTests(unittest.TestCase):
    def browser(self, **scenario):
        run = subprocess.run([NODE, "-e", HARNESS, str(HTML), json.dumps(scenario)], capture_output=True, text=True, encoding="utf-8", timeout=15, check=False)
        self.assertEqual(run.returncode, 0, run.stderr)
        return json.loads(run.stdout)

    def test_private_capability_scrub_auth_server_total_and_xss_safe_render(self):
        state = self.browser()
        self.assertEqual(state["amount"], "120,50 ₽")
        self.assertEqual(state["history"], ["/shop/checkout?order_id=O1"])
        self.assertEqual(state["stored"], ["aisklad.shop.checkout:https://shop.example:O1"])
        self.assertTrue(state["privateRequests"])
        self.assertIn("<img src=x onerror=alert(1)>", state["text"])
        self.assertEqual(state["linkHosts"], ["store.steampowered.com"])
        self.assertEqual(state["providerCount"], 2)
        self.assertEqual(state["status"], "Ждём оплату")  # return ?payment=success is not proof.

    def test_test_disabled_and_test_paid_never_claim_real_delivery(self):
        state = self.browser(mode="disabled", delivery=False, lineStatus="pending")
        self.assertTrue(state["payDisabled"])
        state = self.browser(mode="test", delivery=False, lineStatus="pending")
        self.assertIn("Тестовая", state["payLabel"])
        state = self.browser(status="test_paid", delivery=False, lineStatus="pending")
        self.assertIn("Тестовая", state["status"])
        self.assertIn("Реальный товар не выдавался", state["detail"])
        self.assertTrue(state["payDisabled"])

    def test_pay_navigates_only_approved_provider_and_copies_exact_code(self):
        state = self.browser(pay=True, copy=True)
        self.assertEqual(state["paths"], ["/api/shop/orders/O1", "/api/shop/orders/O1/pay"])
        self.assertEqual(state["navigations"], ["https://auth.robokassa.ru/Merchant/Index.aspx?InvId=123"])
        self.assertEqual(state["clipboard"], ["LONG-CODE-<&>-END"])
        state = self.browser(pay=True, badUrl=True)
        self.assertEqual(state["navigations"], [])
        self.assertIn("Не удалось открыть", state["error"])

    def test_hidden_page_does_not_poll_and_visibility_refreshes_once(self):
        state = self.browser(visibility=True)
        self.assertEqual(state["scenario"]["hiddenRequests"], 1)
        self.assertEqual(state["requestCount"], 2)
        self.assertEqual(len(state["delays"]), 1)

    def test_already_paid_race_refreshes_get_without_trusting_post_status(self):
        state = self.browser(pay=True, alreadyPaid=True, payResultStatus="completed", afterPayStatus="processing", delivery=False, lineStatus="pending")
        self.assertEqual(state["paths"], ["/api/shop/orders/O1", "/api/shop/orders/O1/pay", "/api/shop/orders/O1"])
        self.assertEqual(state["navigations"], [])
        self.assertEqual(state["error"], "")
        self.assertEqual(state["status"], "Заказ выполняется")

    def test_standalone_security_policy_has_no_external_scripts_or_html_sink(self):
        source = HTML.read_text(encoding="utf-8")
        self.assertIn('name="referrer" content="no-referrer"', source)
        self.assertIn("connect-src 'self'", source)
        self.assertNotIn("innerHTML", source)
        self.assertNotIn("<script src=", source)
        self.assertIn("cache:'no-store'", source)


if __name__ == "__main__":
    unittest.main()
