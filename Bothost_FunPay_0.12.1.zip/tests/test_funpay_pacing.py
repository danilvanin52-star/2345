"""Respect actual 429 responses without suppressing successful lot creation."""
import ast,json,tempfile
from pathlib import Path
from types import SimpleNamespace as N
import unittest
from unittest.mock import Mock

from test_cardinal_compatibility import SOURCE
from test_catalog_pricing import FORM,game
import steamru_stars as bot
import steamru_stars_catalog as catalog
from steamru_stars_engine import Store
from steamru_stars_funpay import LotRequestPacer,FunPayRateLimited,install

class FunPayPacingTests(unittest.TestCase):
    def clock(self):
        tick=[0.0]
        return tick,lambda:tick[0],lambda seconds:tick.__setitem__(0,tick[0]+seconds)
    def test_lot_requests_are_spaced_and_order_poll_is_not_delayed(self):
        tick,clock,sleep=self.clock();times=[]
        def request(**kwargs):times.append((clock(),kwargs['url']));return N(status_code=200,headers={})
        pacer=LotRequestPacer(request,clock=clock,sleep=sleep,gap=3)
        pacer(method='get',url='https://funpay.com/lots/offerEdit?offer=1')
        pacer(method='post',url='https://funpay.com/api/orders/get')
        pacer(method='post',url='https://funpay.com/lots/offerSave')
        self.assertEqual([x[0] for x in times],[0,0,3])
    def test_429_stops_current_batch_and_blocks_transport_during_cooldown(self):
        tick,clock,sleep=self.clock();request=Mock(side_effect=[N(status_code=429,headers={'Retry-After':'300'}),N(status_code=200,headers={})])
        pacer=LotRequestPacer(request,clock=clock,sleep=sleep)
        with self.assertRaises(FunPayRateLimited) as caught:pacer(method='post',url='https://funpay.com/lots/offerSave')
        self.assertTrue(caught.exception.server_rejected);self.assertEqual(caught.exception.seconds,300)
        with self.assertRaises(FunPayRateLimited):pacer(method='get',url='https://funpay.com/lots/1008/trade')
        self.assertEqual(request.call_count,1)
        tick[0]=300;pacer(method='get',url='https://funpay.com/lots/1008/trade');self.assertEqual(request.call_count,2)
    def test_real_cardinal_method_does_not_enter_429_retry_log_loop(self):
        tree=ast.parse((SOURCE/'FunPayAPI/account.py').read_text(encoding='utf-8-sig'))
        account=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Account')
        method=next(x for x in account.body if isinstance(x,ast.FunctionDef) and x.name=='method')
        module=ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),method],type_ignores=[]))
        logger=Mock();sdk_time=Mock();namespace={'logger':logger,'time':sdk_time}
        exec(compile(module,'actual_cardinal_method','exec'),namespace)
        tick,clock,sleep=self.clock();transport=Mock(return_value=N(status_code=429,headers={}))
        fake=N(is_funpay_api_method=lambda _:False,golden_key='OFFLINE_COOKIE',cookies={},phpsessid=None,
            user_agent=None,proxy=None,requests_timeout=1,locale='ru',normalize_url=lambda _: 'https://funpay.com/lots/1008/trade',
            session=N(request=LotRequestPacer(transport,clock=clock,sleep=sleep)))
        setattr(fake,'__set_locale','ru');setattr(fake,'__update_cookies',lambda _:None)
        with self.assertRaises(FunPayRateLimited):namespace['method'](fake,'get','lots/1008/trade',{}, {},raise_not_200=True)
        self.assertEqual(transport.call_count,1);sdk_time.sleep.assert_not_called();logger.warning.assert_not_called()
    def test_install_is_idempotent(self):
        original=Mock();account=N(session=N(request=original))
        first=install(account);second=install(account)
        self.assertIs(first,second);self.assertIs(account.session.request,first)
    def test_order_poll_is_allowed_while_catalog_is_cooling_down(self):
        tick,clock,sleep=self.clock();transport=Mock(side_effect=[N(status_code=429,headers={}),N(status_code=200,headers={})])
        pacer=LotRequestPacer(transport,clock=clock,sleep=sleep)
        with self.assertRaises(FunPayRateLimited):pacer(method='get',url='https://funpay.com/lots/1008/trade')
        response=pacer(method='post',url='https://funpay.com/api/orders/get')
        self.assertEqual(response.status_code,200);self.assertEqual(tick[0],0)
    def test_explicit_429_creation_can_retry_without_unknown_post_retry(self):
        with tempfile.TemporaryDirectory() as temporary:
            store=Store(Path(temporary)/'state.db');module=N(STORE=store,editor_field_value=bot.editor_field_value)
            account=Mock();account.get_my_subcategory_lots.return_value=[]
            account.method.side_effect=[N(content=FORM.encode()),FunPayRateLimited(180,server_rejected=True)]
            rule=catalog.key_rule(game())
            with self.assertRaises(FunPayRateLimited):catalog.create_draft(module,N(account=account),'key',rule,'300')
            self.assertEqual(json.loads(store.get_meta('catalog_intent:key'))['stage'],'deferred')
            fields=N(active=False,title_ru=rule['summary'],fields={f'fields[{k}]':v for k,v in rule['match_fields'].items()})
            fields.fields['fields[name][ru]']=rule['game_name'];account.get_lot_fields.return_value=fields
            account.method.side_effect=[N(content=FORM.encode()),N(json=lambda:{'id':123})]
            self.assertEqual(catalog.create_draft(module,N(account=account),'key',rule,'300'),123)
