"""Local shopping consultant: intents, entities, context and real catalogue IDs.

No language model, external chat service, fabricated products or side effects.
The only persisted conversation state is a small canonical shopping context;
raw buyer messages, account credentials and payment claims are never saved.
"""
from __future__ import annotations
import re
from decimal import Decimal, InvalidOperation
from .merchandising import BRANDS, brand_of, buyer_visible, item_brand, normalize, query_terms, ranked, relevance


_SENSITIVE = re.compile(
    r"(?:парол[ьяь]|password|passwd|api[_ -]?secret|golden[_ -]?key|cookie|token|токен|код\s+(?:входа|подтверждения|из\s+смс))\s*(?:[:=]\s*|у\s+меня\s+|это\s+|is\s+)[^\n\s]+"
    r"|\b\d{5,14}:[A-Za-z0-9_-]{20,}\b|\bBearer\s+[A-Za-z0-9._-]{15,}",
    re.IGNORECASE,
)
_RUB = re.compile(r"\b(?:rub|rur|р|r|руб\w*|rubl\w*|roubl\w*|rubles?|rubley)\b")
_KZT = re.compile(r"\b(?:kzt|тенге|тенге\w*|теньге|тнг|tenge)\b")
_USD = re.compile(r"\b(?:usd|доллар\w*|dollars?|бакс\w*|bucks?)\b")
_COUNTRIES = {
    "RU": ("россия", "россии", "россию", "рф", "russia", "russian", "ru"),
    "KZ": ("казахстан", "казахстана", "казахстане", "казахстану", "kazakhstan", "kazakh", "kz"),
    "DE": ("германия", "германии", "германию", "germany", "german", "de"),
    "TR": ("турция", "турции", "турцию", "turkey", "turkish", "tr"),
    "US": ("сша", "америка", "америке", "usa", "united states", "us"),
    "UA": ("украина", "украине", "украины", "ukraine", "ua"),
    "PL": ("польша", "польше", "польши", "poland", "pl"),
    "GB": ("британия", "британии", "англия", "англии", "united kingdom", "uk", "gb"),
}
_GENERIC = {"покажи", "товары", "каталог", "игры", "магазин", "что есть", "каталог товаров", "весь каталог", "catalog", "catalogue", "browse", "shop", "menu", "меню", "all", "all products", "ассортимент"}
_GREETINGS = {"привет", "здравствуйте", "здравствуй", "добрый день", "добрый вечер", "доброе утро", "прив", "хай", "hello", "hi", "hey", "good morning", "добрый", "ку", "начать", "start"}
_ORDER = ("где заказ", "статус заказа", "мой заказ", "мои заказы", "заказ не", "заказа не", "номер заказа", "история заказов", "историю заказов", "не приш", "не получил", "не зачисл", "не достав", "не выдал", "не получил", "потерял ключ", "уже оплатил", "оплатил а", "заплатил а", "paid but", "order status", "my order", "where is my", "not received", "not delivered", "missing order", "история покупок", "историю покупок")
_SUPPORT = ("помощ", "поддерж", "оператор", "человек", "менеджер", "продавец", "продавцом", "связаться", "проблема", "не работает", "ошибка", "help", "support", "human", "operator", "contact", "complaint", "жалоб")
_PAYMENT = ("оплат", "платеж", "платить", "заплат", "платежк", "картой", "привязать карту", "сбп", "крипт", "usdt", "способ оплаты", "способы оплаты", "qiwi", "юmoney", "payment", "pay ", "paying", "checkout", "credit card", "bank card", "invoice", "касс")
_REFUND = ("возврат", "вернут", "вернуть деньги", "возмест", "отменить заказ", "отмена заказа", "refund", "chargeback", "cancel order")
_DELIVERY = ("как получить", "куда придет", "куда приходит", "куда пришл", "как отдают", "как выда", "как достав", "сколько ждать", "как долго", "когда придет", "где будет ключ", "delivery", "how long", "how to receive", "where is the key", "время выдачи")
_SAFETY = ("нужен пароль", "нужны пароль", "пароль нужен", "пароль от", "steam guard", "стим гуард", "код входа", "пароли", "безопасно", "пароль давать", "какие данные", "что нужно указать", "what data", "password required", "need password", "is it safe", "security")
_RECOMMEND = ("посовет", "порекоменд", "подбери", "подберите", "что выбрать", "что купить", "что подарить", "не знаю", "интересн", "популярн", "известн", "recommend", "suggest", "something", "popular", "best game", "что нибудь", "что-нибудь")


def _has(text, expressions):
    return any(normalize(part) in text for part in expressions)


def _currency(text):
    found = [name for name, regex in (("RUB", _RUB), ("KZT", _KZT), ("USD", _USD)) if regex.search(text)]
    return found[0] if len(found) == 1 else ("AMBIGUOUS" if len(found) > 1 else None)


def _country(text):
    for code, aliases in _COUNTRIES.items():
        if any((" " + normalize(a) + " ") in (" " + text + " ") for a in aliases):
            return code
    return None


def _amount(text):
    text = re.sub(r"(?<=\d)[ \u00a0](?=\d{3}(?:\D|$))", "", text)
    text = re.sub(r"(?<=\d)(?=[a-zа-я₽₸$])|(?<=[a-zа-я])(?=\d)", " ", text)
    candidates = re.findall(r"(?<![a-zа-я0-9])\d+(?:[.,]\d+)?(?![a-zа-я0-9])", text)
    # A single number is unambiguous; app titles such as GTA 5 are not wallet amounts.
    if len(candidates) != 1:
        return None
    try:
        amount = Decimal(candidates[0].replace(",", "."))
        return str(amount) if amount.is_finite() and 0 < amount <= 1000000000 else None
    except InvalidOperation:
        return None


def _budget(text):
    text = re.sub(r"(?<=\d)[ \u00a0](?=\d{3}(?:\D|$))", "", text)
    raw = re.search(r"(?:до|не дороже|не больше|бюджет(?:ом)?|максимум|under|below|budget(?: is)?|less than)\s*(\d+(?:[.,]\d+)?)", text)
    if raw:
        return str(Decimal(raw.group(1).replace(",", ".")))
    return None


def _is_short_followup(clean):
    allowed = set("а в во на за и мне я хочу надо нужно можно еще уже только тогда да этот подробнее пожалуйста сумма пополнение пополнить накинь рублей рубля рубль тенге tг rub kzt usd r р еще давайте давай it in for and please amount more to на сумму до не дороже дешевле максимум бюджет бюджетом больше under below budget less than".split())
    countries = {normalize(alias) for aliases in _COUNTRIES.values() for alias in aliases}
    for token in clean.split():
        if token in allowed or token in countries or token.isdigit() or _currency(token):
            continue
        return False
    return len(clean.split()) <= 9


class ShopAssistant:
    def __init__(self, service):
        self.service = service

    def _reply(self, uid, intent, answer, actions=None, items=None, context=None, clarification=False, save=True):
        context = {k: v for k, v in (context or {}).items() if k in ("brand", "currency", "country", "quantity", "budget", "kind", "query") and isinstance(v, (str, int))}
        if save:
            session = self.service.store.get_session(uid)
            session["assistant_context"] = context
            self.service.store.set_session(uid, session)
        return {"intent": intent, "answer": answer, "message": answer, "actions": actions or [], "items": items or [],
                "context": context, "needs_clarification": bool(clarification), "source": "catalog_rules"}

    def _products(self):
        return [p for p in self.service.catalog.all() if buyer_visible(p) and p.get("kind") not in ("brand", "service")]

    @staticmethod
    def _actions(items):
        return [{"type": "product", "id": item["id"], "label": item["title"],
                 **({"quantity": int(item["suggested_quantity"])} if item.get("suggested_quantity") else {})} for item in items]

    def _views(self, rows, limit=6):
        return [self.service._view(row) for row in rows[:limit]]

    def respond(self, user_id, text, context=None):
        uid = int(user_id)
        raw = str(text or "").strip()[:1500]
        if uid <= 0:
            raise ValueError("A private buyer identity is required")
        if _SENSITIVE.search(raw) or re.fullmatch(r"[a-fA-F0-9]{32,128}", raw):
            return self._reply(uid, "sensitive", "Пароли, cookie, API-ключи и коды входа сюда не нужны. Не отправляй их. Для выбора товара достаточно названия, суммы и региона; получатель вводится в форме товара.", [{"type": "help", "label": "Поддержка"}], save=False)
        clean = normalize(raw)
        old = context if isinstance(context, dict) else self.service.store.get_session(uid).get("assistant_context", {})
        old = {k: v for k, v in (old or {}).items() if k in ("brand", "currency", "country", "quantity", "budget", "kind", "query") and isinstance(v, (str, int))}
        if not clean:
            return self._reply(uid, "clarify", "Напиши, что ищешь: например, «Steam 156 рублей», «робуксы» или «ключ игры до 1000 ₽».", context=old, clarification=True)
        if _has(clean, _ORDER):
            return self._reply(uid, "orders", "Проверь сохранённый заказ в истории. Если выдача задержалась, открой помощь и укажи номер заказа. Повторно оплачивать или покупать тот же товар не нужно.", [{"type": "orders", "label": "Мои заказы"}, {"type": "help", "label": "Помощь с заказом"}], context=old)
        if _has(clean, _REFUND):
            return self._reply(uid, "refund", "Возврат проверяется по конкретному заказу. Открой историю и отправь его номер в поддержку. Ошибка поставщика сама по себе не подтверждает возврат денег; обещать возврат без проверки я не буду.", [{"type": "orders", "label": "История"}, {"type": "help", "label": "Обратиться за возвратом"}], context=old)
        if _has(clean, _SAFETY):
            return self._reply(uid, "safety", "Пароль аккаунта, Steam Guard и коды входа не нужны. Для пополнения Steam указывается логин; для звёзд — username; для подарка — страна и ссылка-приглашение. Нужные поля показаны в карточке выбранного товара.", [{"type": "category", "id": "", "label": "Открыть каталог"}], context=old)
        if _has(clean, _SUPPORT) and not _has(clean, ("как работает помощник", "что умеет помощник")):
            return self._reply(uid, "support", "Открой поддержку и опиши вопрос одним сообщением. Обращение сохранится, владелец получит уведомление и сможет ответить в этот чат.", [{"type": "help", "label": "Написать в поддержку"}], context=old)
        if _has(clean, _PAYMENT):
            enabled = self.service.status().get("payment_enabled") is True
            answer = "Способ и итоговая сумма показываются при оформлении. Сообщение «я оплатил» не подтверждает платёж: требуется проверка платёжного сервиса." if enabled else "Оплата в магазине пока не подключена. Можно выбрать товары и собрать корзину, но настоящий счёт, списание и выдача из Telegram ещё недоступны."
            return self._reply(uid, "payment", answer, [{"type": "cart", "label": "Корзина"}, {"type": "help", "label": "Вопрос об оплате"}], context=old)
        if _has(clean, _DELIVERY):
            return self._reply(uid, "delivery", "После подтверждённой оплаты пополнение отправляется на указанного получателя, а ключ или код приходит в этот чат и сохраняется в истории. Подарку Steam нужна подходящая страна и ссылка-приглашение. Точный срок зависит от поставщика; готовность подтверждается сообщением о выполнении.", [{"type": "orders", "label": "История заказов"}, {"type": "category", "id": "", "label": "Выбрать товар"}], context=old)
        if "корзин" in clean or clean in ("cart", "my cart", "basket"):
            return self._reply(uid, "cart", "Открой корзину: там сохранены выбранные позиции и рассчитанная сумма. Я не добавляю и не оплачиваю товары без отдельного подтверждения.", [{"type": "cart", "label": "Открыть корзину"}], context=old)
        if clean in _GREETINGS:
            return self._reply(uid, "greeting", "Привет! Помогу найти товар в Aisklad SHOP. Напиши игру, сервис, сумму или регион: «Steam в рублях», «Roblox» или «подарок для Казахстана».", [{"type": "category", "id": "", "label": "Каталог"}], context={})
        if clean in _GENERIC:
            return self._reply(uid, "catalog", "В каталоге есть пополнения, цифровые коды, ключи и подарки, которые доступны нашему ключу STEAM.RU. Первые разделы подобраны вручную для удобства; это не рейтинг продаж. Можно искать по названию игры или сервиса.", [{"type": "category", "id": "", "label": "Все разделы"}, {"type": "service", "id": "keys", "label": "Ключи игр"}, {"type": "service", "id": "gifts", "label": "Подарки Steam"}], context={})
        if _has(clean, ("что ты умеешь", "как пользоваться", "как выбрать товар", "ты ии", "ты нейросеть", "как работает помощник", "what can you do", "how to use", "are you ai")):
            return self._reply(uid, "capabilities", "Я локальный помощник каталога: распознаю названия, суммы, валюты и регионы, подбираю реальные товары и помогаю уточнить выбор. Внешней нейросети здесь нет. Напиши, например, «Steam 156 рублей», «Roblox» или «подарок для Казахстана». Покупки и оплату я сам не подтверждаю.", [{"type": "category", "id": "", "label": "Каталог"}], context={})

        gift = bool(re.search(r"\b(?:гифт\w*|gift\w*|подар\w*)\b", clean))
        key = bool(re.search(r"\b(?:ключ\w*|keys?|dlc|длс|дополнени\w*)\b", clean))
        products = self._products()
        if clean in ("star", "стар"):
            choices = self._brand_actions(products, ("telegram-stars",))
            choices.append({"type": "service", "id": "keys", "label": "Игры со словом Star"})
            return self._reply(uid, "clarify_star", "Уточни: Telegram Stars или игра со словом Star в названии? Полное название поможет выбрать нужный товар.", choices, context={}, clarification=True)
        direct_brand = brand_of(clean)
        needle = " ".join(query_terms(clean))
        exact_games = [p for p in products if p.get("kind") in ("key", "key_group", "gift", "gift_group") and needle and (" " + needle + " ") in (" " + normalize(p.get("title")) + " ")]
        # Real titles outrank a guessed fuzzy brand: Stairs/Star Wars are not
        # Telegram Stars. A generic Minecraft request can still show its brand.
        explicit_games = exact_games if (key or gift or not direct_brand) else []
        brand = None if explicit_games else (direct_brand or (None if key or gift else brand_of(clean, fuzzy=True)))
        currency, country, quantity, budget = _currency(clean), _country(clean), _amount(raw.casefold()), _budget(raw.casefold())
        # Short followups can complete an explicit earlier question. A new brand
        # replaces context rather than inheriting a previous product's amount.
        followup = not brand and _is_short_followup(clean) and (currency or country or quantity or clean in ("пополнение", "пополнить", "да", "этот", "подробнее"))
        state = dict(old) if followup else {}
        if brand:
            state["brand"] = brand
        brand = brand or (state.get("brand") if followup else None)
        if currency:
            state["currency"] = currency
        if country:
            state["country"] = country
        if quantity and brand in ("steam", "telegram-stars") and not budget:
            state["quantity"] = quantity
        if budget:
            state["budget"] = budget
        elif followup and quantity and state.get("budget") and brand != "steam":
            state["budget"] = quantity
        if gift:
            state["kind"] = "gift"
        elif key:
            state["kind"] = "key"
        currency = currency or state.get("currency")
        country = country or state.get("country")
        quantity = state.get("quantity")
        budget = budget or state.get("budget")

        if not products:
            return self._reply(uid, "catalog_loading", "Полный каталог ещё не загружен или поставщик пока недоступен. Я не буду придумывать товары и цены. Попробуй каталог немного позже или напиши в поддержку.", [{"type": "category", "id": "", "label": "Каталог"}, {"type": "help", "label": "Поддержка"}], context=state)

        if brand == "steam" and not gift and not key and state.get("kind") not in ("key", "gift"):
            return self._steam(uid, state, products, currency, quantity)
        if brand == "telegram":
            return self._reply(uid, "clarify_telegram", "Для Telegram нужны звёзды или Premium? Выбери вариант — покажу только товары, которые действительно есть в каталоге.", self._brand_actions(products, ("telegram-stars", "telegram-premium")), context={"brand": "telegram"}, clarification=True)
        if budget and currency not in (None, "RUB"):
            return self._reply(uid, "budget_currency", "Цены магазина показываются в рублях. Уточни бюджет в RUB, чтобы не сравнивать доллары или тенге с рублёвой ценой. Например: «до 1000 рублей».", [{"type": "service", "id": "gifts" if state.get("kind") == "gift" else "keys", "label": "Открыть игры"}], context=state, clarification=True)

        selected = explicit_games or products
        intent = "search"
        if brand and not (brand == "steam" and state.get("kind") in ("gift", "key")):
            selected = [p for p in selected if item_brand(p) == brand]
            intent = "brand"
        requested_kind = state.get("kind")
        if requested_kind:
            allowed = ("gift", "gift_group") if requested_kind == "gift" else ("key", "key_group")
            selected = [p for p in selected if p.get("kind") in allowed]
            intent = "gifts" if requested_kind == "gift" else "keys"
        elif not brand and (budget or _has(clean, _RECOMMEND)):
            selected = [p for p in selected if p.get("kind") in ("key", "key_group", "gift", "gift_group")]
            intent = "recommendations"

        # Specific title retrieval is necessary for unfamiliar games too. Remove
        # semantic-only words without discarding a real multiword game title.
        scoring_query = state.get("query") if followup and state.get("kind") in ("key", "gift") and state.get("query") else clean
        if selected:
            scored = ranked(selected, scoring_query)
            if not scored and (brand or requested_kind or budget or _has(clean, _RECOMMEND)):
                scored = ranked(selected)
        else:
            scored = []
        if not brand and not requested_kind and not budget and not _has(clean, _RECOMMEND):
            scored = ranked(explicit_games or products, clean)
        if country:
            def fits(item):
                countries = {str(c).upper() for c in item.get("countries", [])}
                excluded = {str(c).upper() for c in item.get("excluded_countries", [])}
                return country not in excluded and (not countries or country in countries)
            scored = [p for p in scored if fits(p)]
        views = self._views(scored, limit=6) if not budget else []
        unknown_budget = False
        if budget:
            ceiling = Decimal(str(budget))
            within = []
            # Search the complete candidate list before taking the first screen:
            # an affordable game must not disappear behind twelve costly ones.
            for candidate in scored:
                item = self.service._view(candidate)
                price = item.get("price_rub")
                if price is None or item.get("kind") == "gift_group":
                    unknown_budget = True
                elif Decimal(str(price)) <= ceiling:
                    within.append(item)
                    if len(within) >= 6:
                        break
            views = within[:6]
        if not views:
            if budget and unknown_budget:
                return self._reply(uid, "budget_needs_check", "У подарков цена зависит от издания и страны. Без проверки карточки не обещаю уложиться в бюджет. Выбери игру и регион — там будет реальная цена.", [{"type": "service", "id": "gifts" if requested_kind == "gift" else "keys", "label": "Открыть игры"}], context=state, clarification=True)
            return self._reply(uid, "not_found", "Не нашёл подтверждённого совпадения в текущем каталоге. Попробуй полное название игры или сервиса; можно также открыть все разделы. Отсутствующий товар и цену я не выдумываю.", [{"type": "category", "id": "", "label": "Весь каталог"}, {"type": "help", "label": "Спросить у поддержки"}], context=state, clarification=True)
        # Persist an actual matched game only when the user named it, not the
        # first curated suggestion from a generic "gift" request.
        if requested_kind and (state.get("query") or relevance(scored[0], scoring_query) >= 6):
            state["query"] = views[0]["title"][:150]
        if brand == "telegram-stars" and quantity and len(views) == 1:
            value = Decimal(str(quantity))
            item = views[0]
            minimum, maximum = int(item.get("min_quantity", 1)), int(item.get("max_quantity", 1))
            if value != value.to_integral_value() or not minimum <= value <= maximum:
                return self._reply(uid, "brand_amount", f"Для этого товара нужна целая сумма от {minimum} до {maximum} звёзд. Уточни количество или открой карточку.", self._actions(views), views, state, clarification=True)
            item["suggested_quantity"] = int(value)
        answer = "Нашёл подходящие товары из текущего каталога. Открой карточку и проверь издание, регион и данные получателя."
        if budget:
            answer = "Вот найденные варианты с предварительной ценой в пределах указанного бюджета. Окончательная сумма и наличие проверяются при открытии карточки; цена «от» относится к базовому варианту."
        if requested_kind == "gift" and not country:
            answer += " Для подарка уточни страну аккаунта Steam, например Казахстан или Германия."
        elif requested_kind == "key":
            answer += " DLC — дополнение, для которого нужна основная игра; регион активации указан в карточке."
        if intent == "recommendations":
            answer += " Подборка основана на настройках витрины и совпадении с запросом, а не на выдуманной статистике продаж."
        return self._reply(uid, intent, answer, self._actions(views), views, state, clarification=requested_kind == "gift" and not country)

    def _brand_actions(self, products, brands):
        result = []
        for brand in brands:
            item = next(iter(ranked([p for p in products if item_brand(p) == brand])), None)
            if item:
                result.append({"type": "product", "id": item["id"], "label": item["title"]})
        return result

    def _steam(self, uid, state, products, currency, quantity):
        rows = [p for p in products if p.get("service") == "steam" and str(p.get("supplier_product_id")) in ("1", "9")]
        if currency in ("USD", "AMBIGUOUS"):
            return self._reply(uid, "steam_currency", "В этом Telegram-магазине пополнение Steam предлагается в RUB и KZT. Уточни одну валюту зачисления: рубли или тенге. USD в новой витрине не продаётся.", self._actions(self._views(ranked(rows))), context={**state, "currency": ""}, clarification=True)
        if currency not in ("RUB", "KZT"):
            return self._reply(uid, "steam_currency", "В какой валюте нужно зачислить баланс Steam: RUB (рубли) или KZT (тенге)? Сумма указывается в единицах выбранной валюты, от 100 или выше минимального лимита поставщика.", self._actions(self._views(ranked(rows))), context=state, clarification=True)
        selected_id = "1" if currency == "RUB" else "9"
        item = next((p for p in rows if str(p.get("supplier_product_id")) == selected_id), None)
        if item is None:
            return self._reply(uid, "not_found", "Выбранная валюта сейчас не подтверждена каталогом. Не буду подменять её другой. Проверь доступные варианты или обратись в поддержку.", self._actions(self._views(ranked(rows))), context=state)
        # A current, read-only product lookup can confirm price and API bounds.
        try:
            view = self.service.product(item["id"])
            fresh = True
        except Exception:
            view, fresh = self.service._view(item), False
        minimum, maximum = int(view.get("min_quantity", 100)), int(view.get("max_quantity", 0))
        if quantity:
            value = Decimal(str(quantity))
            if value != value.to_integral_value() or not minimum <= value <= maximum:
                return self._reply(uid, "steam_amount", f"Для этого предложения нужна целая сумма от {minimum} до {maximum} {currency}. Можно любую целую сумму внутри этих границ, не только готовый пакет.", self._actions([view]), [view], state, clarification=True)
            view["suggested_quantity"] = int(value)
            if fresh and view.get("available"):
                quote = self.service._quote(view, int(value))
                view["estimated_total_rub"] = quote["total_rub"]
                answer = f"Нашёл пополнение Steam на {int(value)} {currency}. По текущей проверке сумма к оплате — {quote['total_rub']} ₽. Перед оформлением она проверится ещё раз. Нужен логин Steam, пароль и Steam Guard не нужны."
            else:
                answer = f"Нашёл вариант Steam на {int(value)} {currency}, но свежую цену сейчас подтвердить не удалось. Открой карточку позднее; покупку по неподтверждённой цене не предлагаю."
        else:
            answer = f"Это пополнение Steam в {currency}: от {minimum} до {maximum} единиц зачисления. Подойдёт любая целая сумма в этих пределах. Напиши сумму или открой карточку; нужен логин Steam."
        return self._reply(uid, "steam_topup", answer, self._actions([view]), [view], state, clarification=quantity is None)
