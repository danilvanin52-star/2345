"""Isolated shop worker; the legacy FunPay process retains its own lifecycle."""
import logging
import os
from pathlib import Path
import signal
import threading
import time

from .bot import BuyerBot
from .media import MediaResolver
from .modules import ModuleController
from .rates import RateProvider
from .service import ShopService
from .store import ShopStore
from .supplier import SteamSupplier

LOG=logging.getLogger('aisklad.shop.runtime')


def build_shop(settings,bot=None,supplier=None,rate_provider=None):
    settings.shop_dir.mkdir(parents=True,exist_ok=True);settings.shop_dir.chmod(0o700)
    store=ShopStore(settings.db_path)
    if supplier is None:
        from plugins.steamru_stars_engine import SteamClient
        if not settings.api_key or not settings.api_secret:
            raise ValueError('В настройках Bothost нужны STEAMRU_API_KEY и STEAMRU_API_SECRET.')
        supplier=SteamSupplier(SteamClient(settings.api_key,settings.api_secret,allow_purchases=settings.shop_live))
    rates=rate_provider or RateProvider(settings)
    service=ShopService(store,supplier,settings={
        'enabled':settings.shop_enabled,'owner_id':settings.owner_id,'target_margin_pct':settings.margin_pct,
        'payment_fee_pct':settings.payment_fee_pct,'fixed_cost_rub':settings.fixed_cost_rub,
        'rate_ttl_seconds':3600,'quote_ttl_seconds':300,'max_cart_items':20,
        'support_username':settings.support_username,
    },rate_provider=rates)
    controller=ModuleController(store,settings.owner_id,settings.funpay_dir,settings.shop_enabled)
    media=MediaResolver(settings.shop_dir/'image_cache',Path(__file__).resolve().parent.parent/'assets/menus')
    owner_notifier=None
    if settings.admin_token and bot is None and settings.run_mode!='shop':
        import telebot
        manager=telebot.TeleBot(settings.admin_token,parse_mode='HTML')
        def owner_notifier(uid,text):
            if int(uid)!=settings.owner_id:raise PermissionError('Owner notification only')
            manager.send_message(uid,text,parse_mode='HTML')
    ui=BuyerBot(service,bot=bot,token=settings.shop_token,owner_id=settings.owner_id,
                media_resolver=media,module_controller=controller,owner_notifier=owner_notifier)
    return service,ui,rates


class ShopWorker:
    def __init__(self,service,ui,rates,settings,stop=None,clock=time.monotonic):
        self.service,self.ui,self.rates,self.settings=service,ui,rates,settings
        self.stop=stop or threading.Event();self.clock=clock
        self.next_sync=0;self.next_rate=0;self.failures={}
        self.tasks={}

    def _rate_task(self):
        now=self.clock()
        try:
            self.rates.refresh();self.next_rate=now+900;self.failures.pop('rate',None)
        except Exception as exc:
            self.failures['rate']=self.failures.get('rate',0)+1
            self.next_rate=now+min(900,60*2**min(self.failures['rate']-1,4))
            LOG.warning('Чтение курса: %s; следующий запрос отложен.',type(exc).__name__)

    def _catalog_task(self):
        now=self.clock()
        try:
            result=self.service.sync_catalog()
            self.next_sync=now+self.settings.sync_seconds;self.failures.pop('catalog',None)
            LOG.info('Каталог Aisklad: %s; позиций: %s.',result.get('state'),result.get('indexed',0))
        except Exception as exc:
            self.failures['catalog']=self.failures.get('catalog',0)+1
            self.next_sync=now+min(3600,60*2**min(self.failures['catalog']-1,6))
            LOG.warning('Каталог не обновлён: %s. Предыдущий снимок сохранён.',type(exc).__name__)

    def _schedule(self,name,target):
        previous=self.tasks.get(name)
        if previous is not None and previous.is_alive():return
        task=threading.Thread(target=target,name='Aisklad'+name.title(),daemon=True)
        self.tasks[name]=task;task.start()

    def tick(self):
        # A catalogue can contain thousands of games. Its GET requests must not
        # stop delivery reconciliation or owner/buyer notifications for minutes.
        self.service.process_pending()
        self.ui.send_pending_notifications(limit=50)
        now=self.clock()
        if now>=self.next_rate:self._schedule('rate',self._rate_task)
        if now>=self.next_sync:self._schedule('catalog',self._catalog_task)

    def run(self):
        while not self.stop.is_set():
            try:self.tick()
            except Exception as exc:LOG.warning('Обработка магазина: %s; история сохранена.',type(exc).__name__)
            self.stop.wait(self.settings.worker_seconds)


def run_shop(settings):
    if not settings.shop_token:raise ValueError('Укажи AISKLAD_SHOP_TOKEN отдельного покупательского бота.')
    if not settings.owner_id:raise ValueError('Укажи STEAMRU_OWNER_TG_ID владельца.')
    from steamru_instance import InstanceLock
    with InstanceLock(settings.shop_dir/'buyer_process'):
        service,ui,rates=build_shop(settings)
        from .profile import configure_public_profile
        configure_public_profile(ui.bot,service.store,settings.owner_id)
        stop=threading.Event();worker=ShopWorker(service,ui,rates,settings,stop)
        def stop_handler(*args):stop.set();ui.stop()
        signal.signal(signal.SIGTERM,stop_handler)
        signal.signal(signal.SIGINT,stop_handler)
        thread=threading.Thread(target=worker.run,name='AiskladWorker',daemon=True)
        try:
            ui.register_handlers();thread.start()
            LOG.info('Aisklad SHOP v0.13.1 запущен. Локальный помощник готов; оплата отключена.')
            return ui.run()
        finally:
            stop.set();ui.stop();thread.join(timeout=45)
            for task in worker.tasks.values():task.join(timeout=15)
            rates.close()
