from io import BytesIO
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch

from PIL import Image,ImageDraw
from aisklad_shop.media import clean_product_image,MediaResolver
from aisklad_shop.profile import configure_public_profile,DESCRIPTION,SHORT_DESCRIPTION,REVISION
from aisklad_shop.store import ShopStore
from aisklad_shop.rates import RateProvider,atomic_json
from aisklad_shop.settings import Settings
from datetime import datetime,timezone


class ProfileTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.store=ShopStore(self.root/'shop.sqlite3');self.bot=Mock()
    def tearDown(self):self.tmp.cleanup()
    def test_prestart_description_within_telegram_limits_and_only_set_once(self):
        self.assertLessEqual(len(DESCRIPTION),512);self.assertLessEqual(len(SHORT_DESCRIPTION),120)
        self.assertTrue(configure_public_profile(self.bot,self.store,123))
        self.assertEqual(self.store.get_setting('profile:revision'),REVISION)
        self.assertFalse(configure_public_profile(self.bot,self.store,123))
        self.bot.set_my_name.assert_called_once_with(name='Aisklad SHOP')
        self.assertEqual(self.bot.set_my_description.call_count,2)
        commands=self.bot.set_my_commands.call_args_list
        self.assertEqual(commands[0].kwargs['scope'].type,'all_private_chats')
        self.assertEqual(commands[1].kwargs['scope'].chat_id,123)
        self.assertNotIn('shop_admin',[c.command for c in commands[0].args[0]])
        self.assertIn('assistant',[c.command for c in commands[0].args[0]])
    def test_failed_profile_update_never_marks_success_or_spams_retries(self):
        self.bot.set_my_name.side_effect=RuntimeError('DO_NOT_LOG_TOKEN')
        with patch('aisklad_shop.profile.LOG.warning') as warning:
            self.assertFalse(configure_public_profile(self.bot,self.store,123,clock=lambda:10))
        warning.assert_called_once()
        self.assertNotIn('DO_NOT_LOG_TOKEN',str(warning.call_args))
        self.assertIsNone(self.store.get_setting('profile:revision'))
        self.assertFalse(configure_public_profile(self.bot,self.store,123,clock=lambda:20))
        self.bot.set_my_name.assert_called_once()


class FooterCropTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.image=Image.new('RGB',(600,600),(20,50,90))
        ImageDraw.Draw(self.image).rectangle((400,550,599,599),fill='white')
    def tearDown(self):self.tmp.cleanup()
    def test_supplier_bottom_mark_is_excluded_and_original_is_unchanged(self):
        cropped=clean_product_image(self.image,'https://partner.steam.ru/catalog/cover.png')
        self.assertEqual(cropped.size,(600,516))
        self.assertEqual(cropped.getpixel((550,515)),(20,50,90))
        self.assertEqual(self.image.size,(600,600));self.assertEqual(self.image.getpixel((550,570)),(255,255,255))
    def test_clean_steam_cover_and_tiny_brand_icons_are_not_cropped(self):
        self.assertEqual(clean_product_image(self.image,'https://shared.akamai.steamstatic.com/a.jpg').size,(600,600))
        tiny=Image.new('RGB',(64,64))
        self.assertEqual(clean_product_image(tiny,'https://steam.ru/a.png').size,(64,64))
    def test_old_watermarked_cache_is_not_used_and_official_steam_cover_preferred(self):
        assets=self.root/'assets';assets.mkdir();self.image.save(assets/'product.png')
        cache=self.root/'cache';cache.mkdir()
        source='https://cdn.steam.ru/a.png'
        self.image.save(cache/(hashlib.sha256(source.encode()).hexdigest()+'.jpg'))
        session=Mock();response=Mock(status_code=200,headers={'Content-Type':'image/png'})
        data=BytesIO();self.image.save(data,format='PNG');response.iter_content.return_value=[data.getvalue()]
        session.get.return_value=response
        resolver=MediaResolver(cache,assets,session=session)
        with patch('aisklad_shop.media.socket.getaddrinfo',return_value=[(None,None,None,None,('1.1.1.1',443))]):
            output=resolver.resolve(source)
        with Image.open(output) as image:self.assertEqual(image.size,(600,516))
        with patch('aisklad_shop.media.socket.getaddrinfo',return_value=[(None,None,None,None,('1.1.1.1',443))]):
            resolver.resolve({'app_id':550,'image_url':source})
        self.assertIn('/apps/550/header.jpg',session.get.call_args.args[0])


class SharedRateCacheTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.now=[1800000000]
        self.settings=Settings(self.root);self.rates=RateProvider(self.settings,clock=lambda:self.now[0])
        self.config=self.settings.funpay_dir/'storage/plugins/steamru_stars_config.json'
        atomic_json(self.config,{'wallet_paid_rub':'850','wallet_credited_usd':'10'})
        atomic_json(self.rates.path,{'effective_rub_per_usd':'90','verified_at':datetime.fromtimestamp(self.now[0]-3599,timezone.utc).isoformat()})
    def tearDown(self):self.tmp.cleanup()
    def test_many_catalogue_quotes_share_parse_but_never_extend_rate_freshness(self):
        with patch.object(self.rates,'_funded',wraps=self.rates._funded) as funded:
            for _ in range(200):self.assertEqual(self.rates()['rub_per_usd'],'90')
            self.assertEqual(funded.call_count,1)
        self.now[0]+=2
        with self.assertRaises(ValueError):self.rates()
    def test_deposit_cost_file_change_invalidates_hot_cache(self):
        self.assertEqual(self.rates()['rub_per_usd'],'90')
        atomic_json(self.config,{'wallet_paid_rub':'1000','wallet_credited_usd':'10'})
        self.assertEqual(self.rates()['rub_per_usd'],'100')
    def test_bad_quote_file_cannot_keep_an_old_cached_rate(self):
        self.rates();self.rates.path.write_text('{broken',encoding='utf-8')
        with self.assertRaises(ValueError):self.rates()


class CachedCatalogueTitleTests(unittest.TestCase):
    def test_preupgrade_amount_only_titles_are_qualified_without_waiting_for_sync(self):
        from aisklad_shop.merchandising import apply_buyer_policy
        old={'id':'existing-id','kind':'topup','service':'afk-journey','title':'3150 Кристаллов дракона'}
        view=apply_buyer_policy(old)
        self.assertIn('afk journey',view['title'].casefold());self.assertIn('3150',view['title'])
        self.assertEqual(view['id'],old['id']);self.assertEqual(old['title'],'3150 Кристаллов дракона')
        self.assertEqual(apply_buyer_policy(view)['title'],view['title'])


if __name__=='__main__':unittest.main()
