"""Execute actual CMD launchers with harmless substitutes, never supplier code."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent.parent

class WindowsBatchTests(unittest.TestCase):
    def test_distributed_batch_files_use_windows_line_endings(self):
        for source in ROOT.glob('*.bat'):
            with self.subTest(file=source.name):
                data=source.read_bytes()
                self.assertNotIn(b'\n',data.replace(b'\r\n',b''))
                self.assertFalse(data.startswith(b'\xef\xbb\xbf'))

    def test_cmd_executes_default_and_check_branch_from_unicode_path(self):
        self.assertEqual(os.name,'nt','This regression check must run on Windows')
        with tempfile.TemporaryDirectory(prefix='Проверка запуска ') as temporary:
            folder=Path(temporary)
            scripts=folder/'.venv/Scripts';scripts.mkdir(parents=True)
            executable=Path(sys.executable)
            venv_cfg=executable.parents[1]/'pyvenv.cfg'
            self.assertTrue(venv_cfg.is_file(),'Run these tests with the project virtual environment')
            shutil.copy2(executable,scripts/'python.exe')
            shutil.copy2(venv_cfg,folder/'.venv/pyvenv.cfg')
            (folder/'check_install.py').write_text("print('OFFLINE_CHECK_OK')\n",encoding='utf-8')
            for name,entry in [('Start_STEAMRU_LIVE.bat','start_steamru_live.py'),('Start_STEAMRU.bat','start_steamru.py')]:
                shutil.copy2(ROOT/name,folder/name)
                (folder/entry).write_text("print('OFFLINE_ENTRY_OK')\n",encoding='utf-8')
                for flag in ('',' --check-launcher'):
                    with self.subTest(file=name,flag=flag):
                        env={k:v for k,v in os.environ.items() if not k.startswith('STEAMRU_')}
                        env['STEAMRU_TEST_BATCH']=str(folder/name)
                        command='"'+os.environ['COMSPEC']+'" /d /c call "%STEAMRU_TEST_BATCH%"'+flag
                        run=subprocess.run(command,
                            input='\n',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,
                            encoding='utf-8',errors='replace',cwd=folder.parent,env=env,timeout=20)
                        self.assertEqual(run.returncode,0,run.stdout)
                        self.assertIn('OFFLINE_CHECK_OK',run.stdout)
                        self.assertNotIn('is not recognized',run.stdout)
                        self.assertEqual('OFFLINE_ENTRY_OK' in run.stdout,not bool(flag))
                        if flag:self.assertIn('Launcher OK',run.stdout)
