# noplug — explicit service bindings and recipient validation.
"""Only approved catalogue products can be offered; reads never buy anything."""
import json,re
from copy import deepcopy
from steamru_stars_engine import D,strict_count,ApiFailure

KINDS=('service_topup','service_code')

def field(key,label,maximum=20):
    return {'key':key,'type':'text','label':label,'pattern':r'[0-9]{3,'+str(maximum)+'}'}

def template(slug,product,name,price,node,match,label,region,fields=None,activation=''):
    return {'kind':'service_topup' if fields else 'service_code','service':slug,'product_id':product,
        'product_name':name,'last_price_usd':price,'subcategory_id':node,'stars_per_unit':1,
        'match_fields':match,'display_name':label,'region_label':region,'recipient_fields':fields or [],
        'activation':activation,'description':'','sell_enabled':False,'verified_at':0}

def shortlist():
    result=[]
    for pid,name,price in [(11,'60 UC','.9062'),(18689,'325 UC','4.5114')]:
        result.append(template('pubg-mobile',pid,name,price,1013,
            {'quantity2':name,'quantity3':'','method':'Пополнение по ID'},'PUBG Mobile · '+name,'Global',
            [field('id_igroka','ID игрока')]))
    for pid,name,price,band in [(18038,'42 Алмазов','.7107','5+ алмазов'),
        (18026,'78 + 8 Алмазов','1.2449','50+ алмазов'),(18025,'156 + 16 Алмазов','2.4599','100+ алмазов'),
        (18024,'234 + 23 Алмазов','3.5628','250+ алмазов')]:
        label='Mobile Legends · '+name+' · Global'
        # 234+23 = 257: choose the corresponding FunPay range.
        result.append(template('mobile-legends-global',pid,name,price,948,
            {'summary':label,'region':'Global','method':'Пополнение по ID','number':band},label,'Global',
            [field('player_id','ID игрока'),field('server_id','ID сервера',10)]))
    for pid,name,price,quantity in [(16232,'110 Алмазов','.8961','110 алмазов'),
        (16233,'341 Алмазов','2.6883','Другое количество'),(16234,'572 Алмазов','4.4805','Другое количество')]:
        label='Free Fire · '+name+' · СНГ'
        result.append(template('free-fire-cis',pid,name,price,998,
            {'summary':label,'region':'СНГ','method':'Пополнение по ID','quantity':quantity},label,'СНГ',
            [field('id_igroka','ID игрока')]))
    for pid,name,price,number in [(20351,'50 Robux','1.0549','50'),(20350,'100 Robux','2.4884','100'),
        (20025,'199 Робуксов','2.8438','199'),(20026,'255 Робуксов','3.3894','255')]:
        result.append(template('roblox-ru',pid,name,price,1264,
            {'quantity':'100 робуксов' if number=='100' else 'Другое количество',
             'quantity2':'' if number=='100' else number,'region':'Россия'},
             'Roblox · '+number+' Robux · Россия','Россия',activation='roblox.com/redeem'))
    for slug,pid,name,price,currency,region in [('apple-id-tr',11036,'50 TRY','1.1124','TRY','Турция'),
        ('apple-id-tr',93,'100 TRY','2.0764','TRY','Турция'),('apple-id-tr',11039,'200 TRY','4.1612','TRY','Турция'),
        ('app-store-itunes-ru',6658,'500 RUB','7.1469','RUB','Россия')]:
        match={k:'' for k in ['usd','eur','try','rub','pln','inr','cad','brl','kzt','usd2','eur2','try2','rub2','pln2','inr2']}
        match.update(currency=currency,**{currency.lower():name})
        match['summary']='Apple ID · '+name+' · '+region
        result.append(template(slug,pid,name,price,1316,match,'Apple ID · '+name+' · '+region,region,
                              activation='App Store → профиль → «Погасить подарочную карту или код»'))
    for slug,pid,name,price,currency,region in [('blizzard-us',11304,'USD 5','5.1191','USD','США'),
        ('blizzard-us',11305,'USD 10','10.2382','USD','США'),('blizzard-eur',109,'EUR 20','23.1441','EUR','Европа')]:
        label='Blizzard · '+name+' · '+region
        result.append(template(slug,pid,name,price,889,{'summary':label,'type':currency,'method':'Подарочная карта'},
            label,region,activation='Официальный аккаунт Battle.net → «Погасить код». Валюта аккаунта должна совпадать с валютой карты.'))
    return [(f"service_{r['service']}_{r['product_id']}",r) for r in result]

def schema_contract(fields):
    if not isinstance(fields,list):raise ValueError('Нет схемы полей товара')
    result={}
    for f in fields:
        key=f.get('key');kind=f.get('type')
        if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',key) or key in result or kind not in ('text','select'):
            raise ValueError('Неизвестная схема данных получателя')
        options=tuple(sorted(str(x['value']) for x in f.get('options',[]))) if kind=='select' else ()
        result[key]=(kind,options)
    return result

def verify_product(rule,product):
    if strict_count(product.get('product_id'))!=rule['product_id'] or product.get('name')!=rule['product_name']:
        raise ValueError('Изменился выбранный товар STEAM.RU')
    if not strict_count(product.get('min_count'))<=1<=strict_count(product.get('max_count')) or D(product.get('price_usd'))<=0:
        raise ValueError('Пакет недоступен по одной штуке')
    if schema_contract(product.get('fields',[]))!=schema_contract(rule['recipient_fields']):
        raise ValueError('Изменились обязательные поля товара')
    return product

def product(api,rule):
    data=api.request('GET','/catalog/services/'+rule['service']+'/products')
    p=next((p for p in data.get('products',[]) if p.get('product_id')==rule['product_id']),None)
    if p is None:raise ValueError('Товар отсутствует в доступном каталоге')
    return verify_product(rule,p)

def catalogue(api,selected,maximum='10'):
    import time
    sources=dict(shortlist());wanted={name:sources[name] for name in selected if name in sources}
    known=api.request('GET','/catalog/services')
    services={s['id']:s for s in known.get('services',[])};cache={};result=[]
    for name,source in wanted.items():
        service=source['service'];expected='topup' if source['kind']=='service_topup' else 'code'
        if service not in services or services[service].get('type')!=expected:continue
        if service not in cache:
            try:cache[service]=api.request('GET','/catalog/services/'+service+'/products').get('products',[])
            except ApiFailure:cache[service]=[]
        p=next((p for p in cache[service] if p.get('product_id')==source['product_id']),None)
        try:
            verify_product(source,p or {})
            if D(p['price_usd'])>D(maximum):continue
        except (ValueError,TypeError,KeyError):continue
        rule=deepcopy(source);rule.update(last_price_usd=str(D(p['price_usd'])),sell_enabled=True,verified_at=time.time())
        result.append((name,rule))
    return result

def prompt(rule,oid=None):
    labels=[f['label'] for f in rule['recipient_fields']]
    example='123456789 1234' if len(labels)==2 else '123456789'
    return '╭─ 💎 СПАСИБО ЗА ПОКУПКУ!\n│ '+rule['display_name']+'\n╰─ Пришли '+ ' и '.join(labels)+' одним сообщением:\n'+example+(f' #{oid}' if oid else '')+'\n\n🔒 Пароль и коды входа не нужны.\n💬 Помощь: !помощь · 📦 Статус: !статус'

def parse_recipient(text,rule):
    values=text.split();schema=rule['recipient_fields']
    if len(values)!=len(schema):raise ValueError('Нужны: '+', '.join(f['label'] for f in schema))
    result={}
    for f,value in zip(schema,values):
        if f['type']=='text' and not re.fullmatch(f.get('pattern',r'[0-9]{3,20}'),value):raise ValueError('Проверь '+f['label'])
        if f['type']=='select' and value not in [str(x['value']) for x in f['options']]:raise ValueError('Проверь '+f['label'])
        result[f['key']]=value
    return result

def decode_recipient(row,rule):
    value=json.loads(row['username'])
    if not isinstance(value,dict) or set(value)!={f['key'] for f in rule['recipient_fields']}:raise ValueError('Нет сохранённых данных получателя')
    return parse_recipient(' '.join(value[f['key']] for f in rule['recipient_fields']),rule)

def handle_message(bot,c,message,text):
    tagged=re.search(r'\s+#([A-Za-z0-9_-]{3,90})$',text)
    if tagged:
        row=bot.STORE.get(tagged.group(1));value=text[:tagged.start()].strip()
        if not row or row.get('kind')!='service_topup':return False
        if not bot.matching_message_chat(c,message,row):return True
    else:
        waiting=[r for r in bot.STORE.awaiting_for_buyer(message.author_id)
                 if r.get('kind')=='service_topup' and bot.matching_message_chat(c,message,r)]
        if not waiting or not re.fullmatch(r'[0-9 ]+',text):return False
        if len(waiting)>1:
            bot.buyer_message(c,waiting[0],'Есть несколько заказов. Добавь #номер заказа после ID.');return True
        row=waiting[0];value=text
    if row['status']!='awaiting_username':
        bot.buyer_message(c,row,'Данные этого заказа уже приняты или заказ остановлен. Повторная покупка не создаётся.');return True
    rule=bot.rule_for_title(row['description'])
    try:recipient=parse_recipient(value,rule);bot.preflight(c,row)
    except Exception:
        bot.buyer_message(c,row,prompt(rule,row['id']));return True
    if bot.STORE.set_service_recipient(row['id'],message.author_id,row['chat_id'],recipient):
        bot.buyer_message(c,row,'✅ Данные приняты. Проверяем оплату и выполняем пополнение.');return True
    return True
