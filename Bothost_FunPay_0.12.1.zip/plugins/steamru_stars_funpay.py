# noplug — paced lot requests and explicit FunPay cooldowns.
"""Rate-limit only lot management; chat/order polling remains independent."""
import logging
import threading
import time
from urllib.parse import urlsplit


class FunPayRateLimited(RuntimeError):
    def __init__(self, seconds, *, server_rejected=False):
        self.seconds=max(1,int(seconds))
        self.server_rejected=server_rejected
        super().__init__(f'FunPay ограничил запросы к лотам; следующая попытка через {self.seconds} сек.')


class LotRequestPacer:
    def __init__(self, request, *, gap=3, cooldown=180, clock=time.monotonic, sleep=time.sleep):
        self.request=request;self.gap=max(1,float(gap));self.cooldown=max(60,float(cooldown))
        self.clock=clock;self.sleep=sleep;self.lock=threading.RLock()
        self.next_request=0;self.until=0

    @staticmethod
    def handles(kwargs):
        url=kwargs.get('url','')
        if not isinstance(url,str):return False
        parsed=urlsplit(url)
        if parsed.hostname not in ('funpay.com','www.funpay.com'):return False
        path=parsed.path
        for locale in ('/en/','/uk/'):
            if path.startswith(locale):path='/'+path[len(locale):]
        return path.startswith('/lots/')

    def __call__(self,*args,**kwargs):
        if not self.handles(kwargs):return self.request(*args,**kwargs)
        with self.lock:
            now=self.clock()
            if now<self.until:raise FunPayRateLimited(self.until-now)
            delay=self.next_request-now
            if delay>0:self.sleep(delay)
            self.next_request=self.clock()+self.gap
            response=self.request(*args,**kwargs)
            if response.status_code==429:
                retry=response.headers.get('Retry-After','0')
                try:retry=float(retry)
                except (ValueError,TypeError):retry=0
                wait=min(3600,max(self.cooldown,retry))
                self.until=self.clock()+wait
                # Abort this job before Cardinal's unbounded 429 retry loop sees the response.
                raise FunPayRateLimited(wait,server_rejected=True)
            return response


def install(account, *, gap=3,cooldown=180):
    existing=getattr(account,'_steamru_lot_pacer',None)
    if isinstance(existing,LotRequestPacer):return existing
    pacer=LotRequestPacer(account.session.request,gap=gap,cooldown=cooldown)
    account.session.request=pacer
    account._steamru_lot_pacer=pacer
    return pacer
