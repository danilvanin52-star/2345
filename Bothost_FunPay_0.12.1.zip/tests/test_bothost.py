"""Hosting preflight/import tests: fictitious state only, no accounts/network."""
import base64
import configparser
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

import start_bothost as host
sys.path.insert(0,str(host.SOURCE/'plugins'))
from steamru_stars_engine import Store
import test_live_launch as legacy


class BothostTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name)
        self.data=self.base/'data';self.data.mkdir();self.runtime=self.data/'cardinal'
        self.env={name:'dummy' for name in host.REQUIRED_ENV}
        self.env.update(BOT_TOKEN='123456:TEST_TOKEN',FUNPAY_GOLDEN_KEY='a'*32,STEAMRU_OWNER_TG_ID='123')
        self.cfg={'mode':'live','managed_lots':{'42':'product'},'personal_marker':'preserve-me'}
        self.upload()
    def tearDown(self):self.tmp.cleanup()
    def upload(self):
        (self.data/host.INPUT_FILES[0]).write_text(json.dumps(self.cfg),encoding='utf-8')
        (self.data/host.INPUT_FILES[2]).write_text('{"123":{}}',encoding='utf-8')
        self.store=Store(self.data/host.INPUT_FILES[1])
        self.store.set_meta('paused','yes');self.store.set_meta('manual_order:OLD123','fulfilled')
        self.store.insert_order('DONE123',12,'users-7-12','buyer','sample',50,1,'90',captured_mode='live')
        self.store.set('DONE123',status='completed',supplier_uuid='saved-uuid')
    def test_missing_secrets_fail_by_name_without_echoing_values(self):
        env=dict(self.env);del env['STEAMRU_API_KEY']
        with self.assertRaises(host.HostingSetupError) as caught:host.validate_environment(env)
        self.assertIn('STEAMRU_API_KEY',str(caught.exception));self.assertNotIn(env['BOT_TOKEN'],str(caught.exception))
    def test_foreign_telegram_owner_is_rejected_before_database_import(self):
        with self.assertRaises(host.HostingSetupError):host.import_state(self.data,self.runtime,'999')
        self.assertFalse((self.runtime/host.STATE_PATHS[1]).exists())
    def test_missing_or_partly_uploaded_files_do_not_create_empty_history(self):
        (self.data/host.INPUT_FILES[0]).write_text('{',encoding='utf-8')
        self.assertFalse(host.import_state(self.data,self.runtime,'123'))
        self.assertFalse((self.runtime/host.STATE_PATHS[1]).exists())
    def test_import_preserves_order_uuid_manual_exclusions_and_personal_configuration(self):
        self.assertTrue(host.import_state(self.data,self.runtime,'123'))
        saved=Store(self.runtime/host.STATE_PATHS[1])
        self.assertEqual(saved.get('DONE123')['supplier_uuid'],'saved-uuid')
        self.assertEqual(saved.get('DONE123')['status'],'completed')
        self.assertEqual(saved.get_meta('manual_order:OLD123'),'fulfilled')
        self.assertEqual(json.loads((self.runtime/host.STATE_PATHS[0]).read_text()),self.cfg)
    def test_base64_uploads_preserve_history_and_leave_original_files_untouched(self):
        original={name:(self.data/name).read_bytes() for name in host.INPUT_FILES}
        for name,payload in original.items():(self.data/name).write_bytes(base64.b64encode(payload))
        uploaded={name:(self.data/name).read_bytes() for name in host.INPUT_FILES}
        reports=[]
        self.assertTrue(host.import_state(self.data,self.runtime,'123',report=reports.append))
        saved=Store(self.runtime/host.STATE_PATHS[1])
        self.assertEqual(saved.get('DONE123')['supplier_uuid'],'saved-uuid')
        self.assertEqual(saved.get('DONE123')['status'],'completed')
        self.assertEqual(saved.get_meta('manual_order:OLD123'),'fulfilled')
        self.assertEqual(saved.get_meta('paused'),'yes')
        self.assertEqual(json.loads((self.runtime/host.STATE_PATHS[0]).read_text()),self.cfg)
        self.assertEqual(json.loads((self.runtime/host.STATE_PATHS[2]).read_text()),{'123':{}})
        self.assertEqual({name:(self.data/name).read_bytes() for name in host.INPUT_FILES},uploaded)
        self.assertTrue(any('Base64' in line for line in reports))
        self.assertFalse(list(self.data.glob('.bothost-import-*')))
    def test_mixed_native_and_base64_uploads_are_supported(self):
        original={name:(self.data/name).read_bytes() for name in host.INPUT_FILES}
        for mask in range(8):
            with self.subTest(encoded_files=mask):
                for i,name in enumerate(host.INPUT_FILES):
                    (self.data/name).write_bytes(base64.b64encode(original[name]) if mask & (1<<i) else original[name])
                runtime=self.data/('case-'+str(mask))
                self.assertTrue(host.import_state(self.data,runtime,'123'))
                self.assertEqual(Store(runtime/host.STATE_PATHS[1]).get('DONE123')['supplier_uuid'],'saved-uuid')
    def test_bom_json_and_line_wrapped_base64_are_supported(self):
        config=self.data/host.INPUT_FILES[0]
        config.write_bytes(b'\xef\xbb\xbf'+config.read_bytes())
        db=self.data/host.INPUT_FILES[1]
        db.write_bytes(base64.encodebytes(db.read_bytes()))
        self.assertTrue(host.import_state(self.data,self.runtime,'123'))
        self.assertEqual(Store(self.runtime/host.STATE_PATHS[1]).get('DONE123')['supplier_uuid'],'saved-uuid')
    def test_corrupt_base64_reports_filename_without_private_contents_or_empty_database(self):
        private_marker='PRIVATE_VALUE_NEVER_LOG'
        (self.data/host.INPUT_FILES[0]).write_bytes(base64.b64encode(('{'+private_marker).encode()))
        reports=[]
        self.assertFalse(host.import_state(self.data,self.runtime,'123',report=reports.append))
        self.assertIn(host.INPUT_FILES[0],reports[0])
        self.assertNotIn(private_marker,'\n'.join(reports))
        self.assertFalse((self.runtime/host.STATE_PATHS[1]).exists())
        self.assertFalse((self.runtime/'.bothost-imported.json').exists())
    def test_truncated_encoded_database_waits_and_recovers_after_upload_finishes(self):
        db=self.data/host.INPUT_FILES[1];complete=db.read_bytes()
        db.write_bytes(base64.b64encode(complete[:100]))
        reports=[]
        self.assertFalse(host.import_state(self.data,self.runtime,'123',report=reports.append))
        self.assertIn(host.INPUT_FILES[1],reports[0])
        self.assertFalse((self.runtime/host.STATE_PATHS[1]).exists())
        self.assertFalse(list(self.data.glob('.bothost-import-*')))
        db.write_bytes(base64.b64encode(complete))
        self.assertTrue(host.import_state(self.data,self.runtime,'123'))
    def test_unreadable_file_reason_is_logged_once_until_file_changes(self):
        config=self.data/host.INPUT_FILES[0];complete=config.read_bytes()
        config.write_text('{PRIVATE_VALUE_NEVER_LOG',encoding='utf-8')
        waits=[]
        def finish_upload(seconds):
            waits.append(seconds)
            if len(waits)==3:config.write_bytes(base64.b64encode(complete))
        output=io.StringIO()
        with redirect_stdout(output),patch.object(host.time,'sleep',side_effect=finish_upload), \
                patch.object(host,'run_live',return_value=0) as start:
            self.assertEqual(host.run_host(data=self.data,env=self.env),0)
        text=output.getvalue()
        self.assertEqual(text.count('файл пока не читается'),1)
        self.assertEqual(text.count('Ожидаю перенос.'),1)
        self.assertIn('Распознан формат загрузки Base64',text)
        self.assertNotIn('PRIVATE_VALUE_NEVER_LOG',text)
        start.assert_called_once_with(self.runtime)
    def test_encoded_foreign_owner_still_cannot_import_history(self):
        owner=self.data/host.INPUT_FILES[2]
        owner.write_bytes(base64.b64encode(owner.read_bytes()))
        with self.assertRaises(host.HostingSetupError):host.import_state(self.data,self.runtime,'999')
        self.assertFalse((self.runtime/host.STATE_PATHS[1]).exists())
    def test_restart_does_not_decode_or_reimport_changed_staging_files(self):
        host.import_state(self.data,self.runtime,'123')
        saved=Store(self.runtime/host.STATE_PATHS[1]);saved.set_meta('new-marker','keep')
        for name in host.INPUT_FILES:(self.data/name).write_bytes(base64.b64encode(b'corrupt-old-upload'))
        self.assertTrue(host.import_state(self.data,self.runtime,'123'))
        self.assertEqual(saved.get_meta('new-marker'),'keep')
    def test_restart_never_reimports_old_database_or_prices(self):
        host.import_state(self.data,self.runtime,'123')
        saved=Store(self.runtime/host.STATE_PATHS[1]);saved.set_meta('new-order-marker','keep')
        config=self.runtime/host.STATE_PATHS[0];config.write_text('{"changed":true}')
        host.import_state(self.data,self.runtime,'123')
        self.assertEqual(saved.get_meta('new-order-marker'),'keep')
        self.assertEqual(json.loads(config.read_text()),{'changed':True})
    def test_missing_imported_database_requires_restore_and_is_not_silently_recreated(self):
        host.import_state(self.data,self.runtime,'123')
        (self.runtime/host.STATE_PATHS[1]).unlink()
        with self.assertRaises(host.HostingSetupError):host.import_state(self.data,self.runtime,'123')
    def test_lost_marker_cannot_replace_current_database_with_old_upload(self):
        host.import_state(self.data,self.runtime,'123')
        saved=Store(self.runtime/host.STATE_PATHS[1]);saved.set_meta('new-order-marker','keep')
        (self.runtime/'.bothost-imported.json').unlink()
        with self.assertRaises(host.HostingSetupError):host.import_state(self.data,self.runtime,'123')
        self.assertEqual(saved.get_meta('new-order-marker'),'keep')
    def test_code_update_does_not_overwrite_existing_runtime_state(self):
        host.import_state(self.data,self.runtime,'123')
        before=(self.runtime/host.STATE_PATHS[1]).read_bytes()
        host.prepare_code(host.SOURCE,self.runtime)
        self.assertEqual((self.runtime/host.STATE_PATHS[1]).read_bytes(),before)
        self.assertTrue((self.runtime/'plugins/steamru_stars_health.py').exists())
    def test_config_uses_environment_and_keeps_native_delivery_disabled(self):
        host.import_state(self.data,self.runtime,'123')
        host.configure_cardinal(host.SOURCE,self.runtime,self.env)
        cfg=configparser.ConfigParser(delimiters=(':',),interpolation=None)
        cfg.read(self.runtime/'configs/_main.cfg',encoding='utf-8')
        self.assertEqual(cfg['FunPay']['golden_key'],'a'*32)
        self.assertEqual(cfg['Telegram']['token'],self.env['BOT_TOKEN'])
        self.assertFalse(cfg.getboolean('FunPay','autoDelivery'));self.assertFalse(cfg.getboolean('FunPay','autoRestore'))
        self.assertTrue(cfg.getboolean('Telegram','blockLogin'))
    def test_preflight_never_starts_cardinal_or_connects_accounts(self):
        with patch.object(host,'run_live') as start:
            self.assertEqual(host.run_host(data=self.data,env=self.env,check_only=True),0)
        start.assert_not_called()
    def test_normal_host_boot_calls_live_launcher_without_prompts(self):
        with patch.object(host,'run_live',return_value=0) as start, \
                patch('builtins.input',side_effect=AssertionError('No console input')):
            self.assertEqual(host.run_host(data=self.data,env=self.env,wait=False),0)
        start.assert_called_once_with(self.runtime)
    def test_second_instance_cannot_replace_state_or_start_sales(self):
        with host.InstanceLock(self.runtime),patch.object(host,'run_live') as start:
            with self.assertRaises(host.AlreadyRunning):host.run_host(data=self.data,env=self.env,wait=False)
        start.assert_not_called()
    def test_partner_credentials_can_be_supplied_by_environment(self):
        case=legacy.LiveEntryTests();case.setUp()
        try:
            cfg=legacy.config()
            cfg['auto_pricing']={**legacy.bot.DEFAULT['auto_pricing'],'enabled':True,'watch_topup_rate':True}
            case.cfg_path.write_text(json.dumps(cfg),encoding='utf-8')
            with patch.dict(os.environ,self.env), \
                    patch.object(legacy.entry.getpass,'getpass',side_effect=AssertionError('No console')) as prompt, \
                    patch.object(legacy.entry,'SteamClient') as api, \
                    patch.object(legacy.entry.pricing,'PartnerTopupClient') as partner, \
                    patch.object(legacy.entry.runpy,'run_path') as cardinal:
                api.return_value.account.return_value={'balance':'100'}
                api.return_value.product.return_value={'product_id':55,'price_usd':'.0152'}
                partner.return_value.refresh.return_value={'effective_rub_per_usd':'88.45'}
                self.assertEqual(legacy.entry.main(),0)
                prompt.assert_not_called();cardinal.assert_called_once()
                self.assertEqual(partner.call_args.args[:2],('dummy','dummy'))
                api.return_value.create.assert_not_called()
        finally:case.tearDown()


if __name__=='__main__':unittest.main()
