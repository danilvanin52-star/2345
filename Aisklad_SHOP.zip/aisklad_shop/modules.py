"""Independent persisted sales switches; both bots remain controllable."""
import os
from pathlib import Path
from functools import lru_cache


@lru_cache(maxsize=4)
def gate_store(path):
    from .store import ShopStore
    return ShopStore(Path(path))


class ModuleController:
    def __init__(self,store,owner_id,funpay_dir=None,shop_default=True):
        self.store=store;self.owner_id=int(owner_id);self.funpay_dir=Path(funpay_dir) if funpay_dir else None
        self.shop_default=shop_default

    def status(self):
        return {'shop':bool(self.store.get_setting('module:shop',self.shop_default)),
                'funpay':bool(self.store.get_setting('module:funpay',True))}

    def set_enabled(self,module,enabled,actor_id):
        if not self.owner_id or int(actor_id)!=self.owner_id:raise PermissionError('Только владелец магазина.')
        if module not in ('shop','funpay') or not isinstance(enabled,bool):raise ValueError('Неизвестный модуль.')
        if module=='funpay' and not enabled and self.funpay_dir:
            # Pause is persisted before the shared gate: stale resume tasks are
            # cancelled and the normal FunPay maintenance worker hides offers.
            path=self.funpay_dir/'storage/plugins/steamru_stars.sqlite3'
            if path.is_file():
                from plugins.steamru_stars_engine import Store
                legacy=Store(path)
                legacy.set_meta('resume_token','')
                legacy.set_meta('paused','yes')
                legacy.set_meta('disable_lots_pending','yes')
                legacy.set_meta('next_catalog_sync','0')
        self.store.set_setting('module:'+module,enabled)
        return self.status()


def channel_enabled(name,default=True):
    """Optional bridge: old standalone Cardinal keeps working without SHOP."""
    database=os.getenv('AISKLAD_SHARED_DB')
    if not database:return default
    try:
        return bool(gate_store(database).get_setting('module:'+name,default))
    except Exception:
        # A damaged shared gate must not authorize new supplier purchases.
        return False


def register_funpay_commands(plugin,cardinal,own):
    database=os.getenv('AISKLAD_SHARED_DB')
    if not database:return
    from .store import ShopStore
    controller=ModuleController(ShopStore(Path(database)),int(os.getenv('STEAMRU_OWNER_TG_ID','0')),
                                Path(os.getenv('FPC_DATA_DIR','/app/data'))/'cardinal')
    def status(message):
        if not own(message):return
        flags=controller.status()
        cardinal.telegram.bot.reply_to(message,
            '🛍 Aisklad SHOP: '+('включён' if flags['shop'] else 'пауза')+
            '\n🎮 FunPay: '+('разрешён' if flags['funpay'] else 'пауза')+
            '\n\n/shop_on · /shop_off\n/funpay_on · /funpay_off\n'
            'После /funpay_on отправь /sr_resume.')
    def change(module,value):
        def handler(message):
            if not own(message):return
            controller.set_enabled(module,value,message.from_user.id)
            status(message)
        return handler
    telegram=cardinal.telegram
    telegram.msg_handler(status,commands=['aisklad_modules','shop_status'])
    def support_reply(message):
        if not own(message):return
        from .support import queue_reply
        arguments=(message.text or '').partition(' ')[2]
        cardinal.telegram.bot.reply_to(message,queue_reply(controller.store,controller.owner_id,
                                                           message.from_user.id,arguments),parse_mode='HTML')
    telegram.msg_handler(support_reply,commands=['shop_reply'])
    for name,module,value in [('shop_on','shop',True),('shop_off','shop',False),
                              ('funpay_on','funpay',True),('funpay_off','funpay',False)]:
        telegram.msg_handler(change(module,value),commands=[name])
