"""Public buyer bot metadata. No account credentials or supplier data leave here."""
import hashlib
import logging
import time

LOG=logging.getLogger('aisklad.shop.profile')
BOT_NAME='Aisklad SHOP'
SHORT_DESCRIPTION='🎮 Steam RUB/KZT, игры, Stars и подарочные карты. Умный подбор, корзина и поддержка — Aisklad SHOP.'
DESCRIPTION=(
    '✨ Aisklad SHOP — твой цифровой мир в Telegram!\n\n'
    '🎮 Пополнение Steam в RUB и KZT\n'
    '⭐ Stars и Premium, ключи игр и подарочные карты\n'
    '🧭 Помощник подберёт услугу по игре, сумме и региону\n'
    '🛒 Избранное, корзина и история заказов\n'
    '💬 Поддержка: !помощь\n\n'
    'Напиши «пополнить стим на 156 рублей» или «что есть для Roblox?» — помогу найти нужное.\n'
    'Пароли и коды входа не нужны. Оплата пока готовится к подключению.'
)
COMMANDS=[('start','Открыть Aisklad SHOP'),('menu','Главное меню'),('assistant','Умный подбор услуги'),
          ('search','Найти игру или услугу'),('cart','Моя корзина'),('orders','Мои заказы'),
          ('help','Помощь с выбором и заказом'),('paysupport','Вопрос об оплате'),('terms','Условия'),('privacy','Данные')]
REVISION='profile-0.13.1-'+hashlib.sha256((DESCRIPTION+SHORT_DESCRIPTION+str(COMMANDS)).encode()).hexdigest()[:16]


def configure_public_profile(bot,store,owner_id=0,clock=time.time):
    """Apply once after successful changes. A transient error never stops polling."""
    assert len(DESCRIPTION)<=512 and len(SHORT_DESCRIPTION)<=120
    if store.get_setting('profile:revision')==REVISION:return False
    if clock()<float(store.get_setting('profile:retry_after',0)):return False
    from telebot.types import BotCommand,BotCommandScopeAllPrivateChats,BotCommandScopeChat
    try:
        bot.set_my_name(name=BOT_NAME)
        for language in ('','ru'):
            bot.set_my_description(description=DESCRIPTION,language_code=language)
            bot.set_my_short_description(short_description=SHORT_DESCRIPTION,language_code=language)
        commands=[BotCommand(name,title) for name,title in COMMANDS]
        bot.set_my_commands(commands,scope=BotCommandScopeAllPrivateChats())
        if owner_id:
            owner_commands=commands+[BotCommand('shop_admin','Управление магазином'),BotCommand('shop_stats','Каталог и заказы'),
                                     BotCommand('shop_sync','Обновить каталог'),BotCommand('shop_balance','Баланс STEAM.RU')]
            bot.set_my_commands(owner_commands,scope=BotCommandScopeChat(int(owner_id)))
        store.set_setting('profile:revision',REVISION)
        store.set_setting('profile:retry_after',0)
        return True
    except Exception as exc:
        store.set_setting('profile:retry_after',clock()+3600)
        LOG.warning('Описание бота пока не обновлено: %s. Магазин продолжает работать.',type(exc).__name__)
        return False
