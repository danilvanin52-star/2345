"""Aisklad SHOP: separate Telegram storefront and shared channel controls."""
__version__ = '0.13.1'
