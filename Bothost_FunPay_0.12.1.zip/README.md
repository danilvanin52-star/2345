# FunPayCardinal + STEAM.RU for Bothost

Based on FunPayCardinal 0.1.17.15 and the customized STEAM.RU plugin 0.12.1-beta.
See UPSTREAM_CARDINAL.md for upstream information and credits.

Start file: start_bothost.py. Python: 3.11. Use the included Dockerfile.
No web domain or webhook is needed for the polling bot.

Set BOT_TOKEN (from the hosting token field), FUNPAY_GOLDEN_KEY,
STEAMRU_API_KEY, STEAMRU_API_SECRET, STEAMRU_PARTNER_EMAIL,
STEAMRU_PARTNER_PASSWORD and STEAMRU_OWNER_TG_ID in the hosting environment.
Never commit these values or private runtime files.

Upload the existing steamru_stars_config.json, steamru_stars.sqlite3 and
tg_authorized_users.json directly into /app/data using the private file manager.
The launcher waits for these files before starting the ordinary read-only
startup checks. Working state lives in /app/data/cardinal. Git updates and
restarts do not re-import stale snapshots. Preserve and back up all of data.

Hosting import fix 0.12.1-bothost.1 accepts native files and files whose
contents were Base64-encoded by an upload tool. It validates JSON, owner,
SQLite integrity and the orders schema before importing a private snapshot.
Uploaded originals are preserved. An unreadable file is now named in the
logs without printing its contents; unchanged warnings are not repeated.

Stop the local copy before migration. After startup, send /sr_status, then
/sr_resume once, and /sr_notify_test. Every process restart requires /sr_resume.
Do not run the local and hosted copy simultaneously.

Offline tests use fictitious accounts only. A real Bothost Docker build and
supplier login must still be verified during deployment. No purchases are
performed by packaging, tests, or initial startup checks.
