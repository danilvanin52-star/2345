import base64
from contextlib import closing
from datetime import datetime,timezone,timedelta
from io import BytesIO
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock,patch

from PIL import Image
from aisklad_shop.coordination import PurchaseLock,PurchaseBusy
from aisklad_shop.media import MediaResolver,safe_image_url,MAX_BYTES
from aisklad_shop.modules import ModuleController,channel_enabled
from aisklad_shop.rates import RateProvider,atomic_json
from aisklad_shop.runtime import ShopWorker
from aisklad_shop.settings import Settings
from aisklad_shop.store import ShopStore
import run_aisklad


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.settings=Settings(self.root,owner_id=123,shop_token='1:buyer',admin_token='2:admin')
        self.store=ShopStore(self.settings.db_path)
    def tearDown(self):self.tmp.cleanup()

    def test_separate_tokens_and_repr_never_expose_credentials(self):
        settings=Settings.from_env({'AISKLAD_SHOP_TOKEN':'1:TOP_SECRET','BOT_TOKEN':'2:ADMIN_SECRET',
                                   'STEAMRU_API_SECRET':'API_SECRET','FPC_DATA_DIR':str(self.root)})
        for secret in ('TOP_SECRET','ADMIN_SECRET','API_SECRET'):self.assertNotIn(secret,repr(settings))
        with self.assertRaises(ValueError):Settings.from_env({'AISKLAD_SHOP_TOKEN':'1:same','BOT_TOKEN':'1:same'})
        with self.assertRaises(ValueError):Settings.from_env({'AISKLAD_SHOP_LIVE':'perhaps'})
        self.assertFalse(settings.shop_live)

    def test_module_switches_independent_persistent_and_owner_only(self):
        controller=ModuleController(self.store,123,self.settings.funpay_dir)
        with self.assertRaises(PermissionError):controller.set_enabled('shop',False,999)
        controller.set_enabled('shop',False,123)
        self.assertEqual(controller.status(),{'shop':False,'funpay':True})
        controller=ModuleController(ShopStore(self.settings.db_path),123,self.settings.funpay_dir)
        controller.set_enabled('funpay',False,123)
        controller.set_enabled('shop',True,123)
        self.assertEqual(controller.status(),{'shop':True,'funpay':False})
        self.assertFalse((self.settings.funpay_dir/'storage/plugins/steamru_stars.sqlite3').exists())

    def test_disabling_funpay_pauses_native_sales_without_losing_order_history(self):
        from plugins.steamru_stars_engine import Store
        legacy=Store(self.settings.funpay_dir/'storage/plugins/steamru_stars.sqlite3')
        legacy.set_meta('manual_order:OLD','fulfilled');legacy.set_meta('resume_token','old')
        ModuleController(self.store,123,self.settings.funpay_dir).set_enabled('funpay',False,123)
        self.assertEqual(legacy.get_meta('paused'),'yes')
        self.assertEqual(legacy.get_meta('disable_lots_pending'),'yes')
        self.assertEqual(legacy.get_meta('resume_token'),'')
        self.assertEqual(legacy.get_meta('manual_order:OLD'),'fulfilled')
        with patch.dict('os.environ',{'AISKLAD_SHARED_DB':str(self.settings.db_path)}):
            self.assertFalse(channel_enabled('funpay'))
            self.assertTrue(channel_enabled('shop'))

    def test_shared_post_serialization_does_not_lock_independent_accounts(self):
        locked=threading.Event();release=threading.Event();errors=[]
        def holder():
            try:
                with PurchaseLock(self.root/'purchase.lock',timeout=.2):locked.set();release.wait(2)
            except BaseException as exc:errors.append(exc)
        thread=threading.Thread(target=holder);thread.start();self.assertTrue(locked.wait(1))
        try:
            with self.assertRaises(PurchaseBusy):
                with PurchaseLock(self.root/'purchase.lock',timeout=.05):pass
            with PurchaseLock(self.root/'other.lock',timeout=.05):pass
        finally:release.set();thread.join(2)
        self.assertFalse(errors)
        with PurchaseLock(self.root/'purchase.lock',timeout=.05):pass

    def test_funpay_switch_hides_offers_even_if_supplier_rate_cannot_be_read(self):
        import steamru_stars as native
        store=Mock();store.get_meta.side_effect=lambda key,default=None:{'disable_lots_pending':'yes','next_catalog_sync':'0'}.get(key,default)
        stop=Mock();stop.is_set.return_value=False;stop.wait.return_value=True
        with patch.dict('os.environ',{'AISKLAD_SHARED_DB':str(self.settings.db_path)}), \
             patch('aisklad_shop.modules.channel_enabled',return_value=False), \
             patch.object(native,'STORE',store),patch.object(native,'STOP',stop), \
             patch.object(native,'enabled',return_value=True), \
             patch.object(native,'live_allowed',side_effect=AssertionError('Unrelated FX must not block hiding')), \
             patch.object(native,'disable_managed_lots') as hide:
            native.maintenance_worker(Mock())
        hide.assert_called_once()

    def test_rate_uses_greater_of_funded_actual_cost_and_fresh_quote(self):
        config=self.settings.funpay_dir/'storage/plugins/steamru_stars_config.json'
        atomic_json(config,{'wallet_paid_rub':'900','wallet_credited_usd':'10'})
        rate=RateProvider(self.settings)
        atomic_json(rate.path,{'effective_rub_per_usd':'85','verified_at':datetime.now(timezone.utc).isoformat()})
        with patch.object(rate,'refresh',side_effect=AssertionError('No network')):
            self.assertEqual(rate()['rub_per_usd'],'90')
        atomic_json(rate.path,{'effective_rub_per_usd':'95','verified_at':datetime.now(timezone.utc).isoformat()})
        self.assertEqual(rate()['rub_per_usd'],'95')
        atomic_json(rate.path,{'effective_rub_per_usd':'95','verified_at':(datetime.now(timezone.utc)-timedelta(hours=2)).isoformat()})
        with self.assertRaises(ValueError):rate()

    def test_native_post_wrapper_uses_same_lock_and_safe_mode_still_prevents_write(self):
        from plugins.steamru_stars_engine import SteamClient
        client=SteamClient('dummy','dummy',session=Mock(),allow_purchases=False)
        with patch.dict('os.environ',{'AISKLAD_PURCHASE_LOCK':str(self.root/'shared.lock')}):
            with self.assertRaises(PermissionError):client.request('POST','/orders',payload={})
        client.session.request.assert_not_called()

    def test_catalogue_refresh_does_not_block_paid_worker_or_notifications(self):
        blocked=threading.Event();release=threading.Event()
        service=Mock();service.sync_catalog.side_effect=lambda:(blocked.set(),release.wait(2),{'state':'complete','indexed':30})[-1]
        rates=Mock();ui=Mock();worker=ShopWorker(service,ui,rates,self.settings)
        try:
            worker.tick();self.assertTrue(blocked.wait(1));worker.tick()
            self.assertEqual(service.process_pending.call_count,2)
            self.assertEqual(ui.send_pending_notifications.call_count,2)
            self.assertEqual(service.sync_catalog.call_count,1)
        finally:
            release.set()
            for task in worker.tasks.values():task.join(2)

    def test_component_environment_sets_shared_persistent_paths_without_mixing_tokens(self):
        result=run_aisklad.component_environment(self.settings,{'BOT_TOKEN':'admin','AISKLAD_SHOP_TOKEN':'buyer'})
        self.assertEqual(result['BOT_TOKEN'],'admin');self.assertEqual(result['AISKLAD_SHOP_TOKEN'],'buyer')
        self.assertEqual(Path(result['AISKLAD_SHARED_DB']),self.settings.db_path)
        self.assertTrue(Path(result['AISKLAD_PURCHASE_LOCK']).is_relative_to(self.root))

    def test_supervisor_restarts_failed_funpay_without_restarting_buyer_bot(self):
        now=[0];calls=[]
        failed=Mock();failed.poll.return_value=2
        buyer=Mock();buyer.poll.return_value=None
        recovered=Mock();recovered.poll.return_value=None
        processes=iter([failed,buyer,recovered])
        def spawn(argv,**kwargs):
            calls.append((argv[-1],kwargs['env']))
            return next(processes)
        def advance(seconds):
            now[0]+=20
            if now[0]>=60:raise KeyboardInterrupt
        with self.assertRaises(KeyboardInterrupt):
            run_aisklad.supervise(self.settings,process_factory=spawn,clock=lambda:now[0],sleep=advance)
        self.assertEqual([name for name,env in calls],['funpay','shop','funpay'])
        buyer.terminate.assert_called_once();recovered.terminate.assert_called_once()
        failed.terminate.assert_not_called()

    def test_absent_buyer_token_does_not_stop_existing_funpay(self):
        self.settings.shop_token='';calls=[]
        process=Mock();process.poll.return_value=None
        def spawn(argv,**kwargs):calls.append(argv[-1]);return process
        with self.assertRaises(KeyboardInterrupt):
            run_aisklad.supervise(self.settings,process_factory=spawn,
                                 sleep=Mock(side_effect=KeyboardInterrupt))
        self.assertEqual(calls,['funpay']);process.terminate.assert_called_once()

    def test_shop_only_requires_new_buyer_token_before_starting_any_process(self):
        self.settings.run_mode='shop';self.settings.shop_token='';spawn=Mock()
        with self.assertRaises(ValueError):run_aisklad.supervise(self.settings,process_factory=spawn)
        spawn.assert_not_called()


class MediaTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.assets=self.root/'assets';self.assets.mkdir()
        self.image=BytesIO();Image.new('RGB',(320,180),(20,30,40)).save(self.image,format='PNG')
        (self.assets/'product.png').write_bytes(self.image.getvalue())
        self.session=Mock();self.media=MediaResolver(self.root/'cache',self.assets,session=self.session)
    def tearDown(self):self.tmp.cleanup()
    def test_images_reject_private_ips_credentials_unknown_hosts_and_ports(self):
        for url in ('http://steam.ru/a.png','https://127.0.0.1/a.png','https://localhost/a.png',
                    'https://api.steam.ru:444/a.png','https://key:secret@steam.ru/a.png',
                    'https://steam.ru.evil.test/a.png','https://example.com/a.png'):
            self.assertFalse(safe_image_url(url),url)
            self.assertEqual(self.media.resolve(url),self.assets/'product.png')
        self.session.get.assert_not_called()
    def test_verified_image_cached_then_served_offline(self):
        response=Mock(status_code=200,headers={'Content-Type':'image/png'})
        response.iter_content.return_value=[self.image.getvalue()]
        self.session.get.return_value=response
        with patch('aisklad_shop.media.socket.getaddrinfo',return_value=[(None,None,None,None,('1.1.1.1',443))]):
            first=self.media.resolve('https://cdn.steam.ru/a.png')
        self.assertTrue(first.is_file());self.assertEqual(first.suffix,'.jpg')
        self.assertEqual(self.media.resolve('https://cdn.steam.ru/a.png'),first)
        self.assertEqual(self.session.get.call_count,1)
    def test_redirect_to_private_host_never_fetched(self):
        response=Mock(status_code=302,headers={'Location':'https://127.0.0.1/secret'})
        self.session.get.return_value=response
        with patch('aisklad_shop.media.socket.getaddrinfo',return_value=[(None,None,None,None,('1.1.1.1',443))]):
            self.assertEqual(self.media.resolve('https://cdn.steam.ru/a.png'),self.assets/'product.png')
        self.assertEqual(self.session.get.call_count,1)
    def test_oversize_upload_and_nonimage_payload_use_local_banner(self):
        response=Mock(status_code=200,headers={'Content-Type':'image/png','Content-Length':str(MAX_BYTES+1)})
        self.session.get.return_value=response
        with patch('aisklad_shop.media.socket.getaddrinfo',return_value=[(None,None,None,None,('1.1.1.1',443))]):
            self.assertEqual(self.media.resolve('https://cdn.steam.ru/a.png'),self.assets/'product.png')
        response.headers={'Content-Type':'image/png'};response.iter_content.return_value=[b'not an image']
        with patch('aisklad_shop.media.socket.getaddrinfo',return_value=[(None,None,None,None,('1.1.1.1',443))]):
            self.assertEqual(self.media.resolve('https://cdn.steam.ru/b.png'),self.assets/'product.png')


if __name__=='__main__':unittest.main()
