# noplug — вспомогательный модуль плагина STEAM.RU Stars для FunPayCardinal.
"""API клиент / хранилище / финансовые проверки. Только стандартная библиотека + requests."""
from __future__ import annotations
import hashlib
import hmac
import json
import os
import re
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
from urllib.parse import urlencode, urlsplit

try:
    import requests
except ImportError:
    requests = None

BASE_URL = "https://api.steam.ru/api/reseller/v1"
# Формат из фактического скриншота STEAM.RU; существование проверяет /check.
USER_RE = re.compile(r"^@?([A-Za-z0-9_]{4,32})$")
REPLY_RE = re.compile(r"^\s*@?([A-Za-z0-9_]{4,32})\s+#([A-Za-z0-9_-]{3,90})\s*$")
ORDER_RE = re.compile(r"^[A-Za-z0-9_-]{3,90}$")
OPEN = ("awaiting_username", "ready", "preparing", "submitting", "supplier_pending", "uncertain", "needs_review")
FINAL = ("simulated", "completed", "refunded", "cancelled")


def D(value):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("Ожидалось конечное число") from exc
    if not result.is_finite():
        raise ValueError("NaN и бесконечные значения запрещены")
    return result


def strict_count(value, min_count=1, max_count=None):
    number = D(value)
    if number != number.to_integral_value():
        raise ValueError("Количество должно быть целым числом")
    if number < min_count or (max_count is not None and number > max_count):
        raise ValueError("Количество вне разрешённых границ")
    return int(number)


def effective_exchange_rate(paid_rub, credited_usd):
    """Фактическая стоимость USD: вся оплата RUB / реально зачисленные USD."""
    paid, credited = D(paid_rub), D(credited_usd)
    if paid <= 0 or credited <= 0:
        raise ValueError("Оплата RUB и зачисление USD должны быть положительными")
    return paid / credited


def money(value):
    return D(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def username_or_none(value):
    m = USER_RE.fullmatch(str(value or "").strip())
    return m.group(1) if m else None


def parse_reply(value):
    m = REPLY_RE.fullmatch(value or "")
    return (m.group(1), m.group(2)) if m else None


def effective_cost(price_usd, count, rub_per_usd, other_cost_rub="0"):
    price, rate, other = D(price_usd), D(rub_per_usd), D(other_cost_rub)
    if price <= 0 or rate <= 0 or other < 0:
        raise ValueError("Цена и курс должны быть положительными, прочие расходы неотрицательными")
    return price * strict_count(count) * rate + other


def finances(revenue_rub, product_price_usd, count, rub_per_usd, withdraw_pct, other_cost_rub="0"):
    revenue = D(revenue_rub)
    fee = D(withdraw_pct)
    if revenue <= 0 or not 0 <= fee < 100:
        raise ValueError("Выручка должна быть положительной, комиссия — от 0 до 100%")
    cost = effective_cost(product_price_usd, count, rub_per_usd, other_cost_rub)
    proceeds = revenue * (Decimal(1) - fee / 100)
    profit = proceeds - cost
    margin = profit / revenue * 100 if revenue > 0 else D("-999")
    return {"revenue": revenue, "cost": cost, "profit": profit, "margin_pct": margin}


def timestamp_fresh(value, hours=24):
    if not value or not isinstance(value, str):
        return False
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            return False
        age = datetime.now(timezone.utc) - stamp.astimezone(timezone.utc)
        return timedelta(0) <= age <= timedelta(hours=hours)
    except (ValueError, TypeError):
        return False


def currency_code(currency):
    code = getattr(currency, "code", None)
    if code:
        return str(code).upper()
    raw = getattr(currency, "name", None)
    if raw:
        return str(raw).upper()
    return str(currency or "").upper()


def status_name(status):
    return str(getattr(status, "name", status or "")).upper()


def stringify_json_body(payload):
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def sign(secret: str, method: str, path_with_query: str, timestamp: int, nonce: str, raw_body: bytes) -> str:
    sha = hashlib.sha256(raw_body).hexdigest()
    material = f"{method.upper()}\n{path_with_query}\n{timestamp}\n{nonce}\n{sha}"
    return hmac.new(secret.encode(), material.encode(), hashlib.sha256).hexdigest()


class ApiFailure(Exception):
    def __init__(self, code, message, status=None, retry_after=None):
        super().__init__(f"{code}: {message}")
        self.code, self.status, self.retry_after = code, status, retry_after


class UnknownOutcome(Exception):
    """Сеть оборвалась в момент POST: заказ мог быть создан. НЕ повторять автоматически."""


STEAM_CURRENCIES = {
    'RUB': {'kind':'steam_rub','product_id':1,'min_count':100,'max_count':500},
    'USD': {'kind':'steam_usd','product_id':10,'min_count':1,'max_count':5},
    'KZT': {'kind':'steam_kzt','product_id':9,'min_count':600,'max_count':2500},
}
STEAM_KINDS = tuple(v['kind'] for v in STEAM_CURRENCIES.values())


class SteamClient:
    def __init__(self, api_key: str, api_secret: str, base_url: str = BASE_URL, session=None,
                 allow_purchases=False):
        if not api_key or not api_secret:
            raise ValueError("STEAMRU_API_KEY и STEAMRU_API_SECRET обязательны")
        parsed = urlsplit(base_url)
        try:
            trusted = (parsed.scheme == "https" and parsed.hostname == "api.steam.ru"
                       and parsed.port in (None, 443) and parsed.username is None
                       and parsed.password is None and not parsed.query and not parsed.fragment
                       and parsed.path.rstrip("/") == "/api/reseller/v1")
        except ValueError:
            trusted = False
        if not trusted:
            raise ValueError("Допустим только официальный HTTPS API STEAM.RU")
        if requests is None and session is None:
            raise RuntimeError("Установите requests")
        self.key, self.secret = api_key, api_secret
        self.base_url = base_url.rstrip("/")
        self.session = session or requests.Session()
        self.allow_purchases = allow_purchases is True

    def request(self, method, endpoint, params=None, payload=None, idempotency=None, timeout=15):
        lock_path=os.getenv('AISKLAD_PURCHASE_LOCK')
        if str(method).upper()=='POST' and lock_path:
            from aisklad_shop.coordination import PurchaseLock
            with PurchaseLock(lock_path):
                return self._request(method,endpoint,params,payload,idempotency,timeout)
        return self._request(method,endpoint,params,payload,idempotency,timeout)

    def _request(self, method, endpoint, params=None, payload=None, idempotency=None, timeout=15):
        method = str(method).upper()
        if method not in ("GET", "HEAD", "OPTIONS") and not self.allow_purchases:
            raise PermissionError("Запросы с изменением данных запрещены в безопасном режиме")
        if not endpoint.startswith("/") or any(token in endpoint for token in ("..", "?", "#", "\\")):
            raise ValueError("Некорректный путь API")
        q = urlencode(params or {})
        path = endpoint + (("?" + q) if q else "")
        raw = stringify_json_body(payload) if payload is not None else b""
        url = self.base_url + path
        # HMAC подписывает ТОЧНЫЙ путь HTTP-запроса, включая /api/reseller/v1 и query.
        parsed = urlsplit(url)
        path_with_query = parsed.path + (("?" + parsed.query) if parsed.query else "")
        ts, nonce = int(time.time()), str(uuid.uuid4())
        headers = {
            "X-Reseller-Key": self.key,
            "X-Reseller-Timestamp": str(ts),
            "X-Reseller-Nonce": nonce,
            "X-Reseller-Signature": sign(self.secret, method, path_with_query, ts, nonce, raw),
            "Accept": "application/json",
        }
        if payload is not None:
            headers["Content-Type"] = "application/json"
        if idempotency is not None:
            headers["Idempotency-Key"] = idempotency
        try:
            resp = self.session.request(method, url, data=raw if payload is not None else None,
                                        headers=headers, timeout=timeout, allow_redirects=False)
        except Exception as exc:
            if method.upper() == "POST":
                raise UnknownOutcome("Ответ от сервера после отправки POST неизвестен") from exc
            raise ApiFailure("network.error", "Сеть или таймаут запроса", None) from exc
        if 300 <= resp.status_code < 400:
            raise ApiFailure("http.redirect", "Неожиданный редирект API", resp.status_code)
        try:
            body = resp.json()
        except ValueError as exc:
            if method.upper() == "POST":
                raise UnknownOutcome("POST вернул не-JSON: нельзя исключить списание") from exc
            raise ApiFailure("invalid_json", "API ответил не JSON", resp.status_code) from exc
        if not isinstance(body, dict):
            if method == "POST":
                raise UnknownOutcome("POST вернул неожиданный формат: исход покупки неизвестен")
            raise ApiFailure("invalid_response", "Ожидался JSON-объект", resp.status_code)
        if resp.status_code >= 400 or body.get("ok") is not True:
            err = body.get("error") or {}
            if not isinstance(err, dict):
                err = {}
            retry_after = resp.headers.get("Retry-After")
            # Текст и код из ответа поставщика могут содержать реквизиты запроса.
            # Сохраняем только HTTP статус; секреты не попадут в логи и сообщения.
            raise ApiFailure("api.error", "STEAM.RU отклонил запрос", resp.status_code, retry_after)
        if not isinstance(body.get("data"), dict):
            if method == "POST":
                raise UnknownOutcome("POST не содержит data: исход покупки неизвестен")
            raise ApiFailure("invalid_response", "Не найден data", resp.status_code)
        return body["data"]

    def account(self):
        """Документированный безопасный health-check: без покупки и списаний."""
        return self.request("GET", "/account")

    def balance(self):
        return D(self.request("GET", "/balance")["balance"])

    def product(self, service_slug, requested_id, count):
        count = strict_count(count, 50, 150)
        from urllib.parse import quote
        slug = quote(service_slug, safe="-")
        payload = self.request("GET", f"/catalog/services/{slug}/products")
        if payload.get("service") != service_slug or payload.get("type") != "topup" or not payload.get("requires_account", True):
            raise ApiFailure("catalog.mismatch", "Неожиданный тип или сервис в каталоге")
        products = payload.get("products") or []
        if requested_id is not None:
            candidates = [p for p in products if str(p.get("product_id")) == str(requested_id)]
        else:
            candidates = [p for p in products if strict_count(p.get("min_count", 1)) <= count <= strict_count(p.get("max_count", 0))]
        if len(candidates) != 1:
            raise ApiFailure("catalog.ambiguous", "Не найден однозначный товар: укажите product_id в config")
        p = candidates[0]
        if not (strict_count(p.get("min_count", 1)) <= count <= strict_count(p.get("max_count", 0))):
            raise ApiFailure("catalog.out_of_range", "Количество вне ограничений товара")
        if p.get("fields"):
            raise ApiFailure("catalog.fields_required", "Есть обязательные поля fields — нужен ручной разбор")
        if D(p.get("price_usd", 0)) <= 0:
            raise ApiFailure("catalog.invalid_price", "Неизвестная или нулевая цена")
        return p

    def check_username(self, username):
        data = self.request("GET", "/check/telegram-username", params={"account": username})
        if not isinstance(data.get("valid"), bool):
            raise ApiFailure("check.invalid_response", "API не прислал true/false")
        return data["valid"]

    def create(self, external_id, service, product_id, count, account):
        if service != "telegram-stars" or strict_count(product_id) != 55:
            raise ValueError("Разрешён только telegram-stars с product_id=55")
        count = strict_count(count, 50, 150)
        if not isinstance(external_id, str) or not external_id.startswith("funpay-") or not ORDER_RE.fullmatch(external_id[7:]):
            raise ValueError("Некорректный external_order_id FunPay")
        account = username_or_none(account)
        if not account:
            raise ValueError("Некорректный Telegram username")
        # Формат покупки Stars подтверждён службой поддержки (пустые fields не нужны).
        payload = {"external_order_id": external_id, "service": service,
                   "product_id": 55, "product_count": count,
                   "account": account}
        data = self.request("POST", "/orders", payload=payload, idempotency=external_id, timeout=35)
        if not data.get("uuid"):
            raise UnknownOutcome("Успешный POST без uuid: требуется проверка у поставщика")
        return data

    def get_order(self, order_uuid):
        from urllib.parse import quote
        return self.request("GET", "/orders/" + quote(str(order_uuid), safe="-"))

    def steam_rub_product(self, count):
        count = strict_count(count, 100, 500)
        data = self.request('GET', '/catalog/services/steam/products')
        if data.get('service') != 'steam' or data.get('type') != 'topup' or data.get('requires_account') is not True:
            raise ValueError('Некорректный каталог Steam')
        p = next((p for p in data.get('products', []) if p.get('product_id') == 1), None)
        if (p is None or str(p.get('name', '')).strip().lower() != 'steam rub'
                or p.get('fields') or not p.get('min_count') <= count <= p.get('max_count') or D(p.get('price_usd', 0)) <= 0):
            raise ValueError('Недоступен товар Steam RUB')
        return p

    def steam_currency_product(self, currency, count):
        if currency not in STEAM_CURRENCIES:
            raise ValueError('Неподдерживаемая валюта Steam')
        contract=STEAM_CURRENCIES[currency]
        count=strict_count(count,contract['min_count'],contract['max_count'])
        data=self.request('GET','/catalog/services/steam/products')
        if data.get('service')!='steam' or data.get('type')!='topup' or data.get('requires_account') is not True:
            raise ValueError('Некорректный каталог Steam')
        product=next((p for p in data.get('products',[]) if p.get('product_id')==contract['product_id']),None)
        if (not product or product.get('name')!='Steam '+currency or product.get('fields')
                or not strict_count(product.get('min_count'))<=count<=strict_count(product.get('max_count'))
                or D(product.get('price_usd',0))<=0):
            raise ValueError('Изменился товар Steam '+currency)
        return product

    def key_product(self, app_id, option_id, expected_region=None):
        app_id, option_id = strict_count(app_id), strict_count(option_id)
        data = self.request('GET', '/catalog/keys/' + str(app_id))
        if strict_count(data.get('app_id')) != app_id:
            raise ValueError('Каталог вернул другую игру')
        p = next((p for p in data.get('variants', []) if p.get('option_id') == option_id), None)
        if (p is None or p.get('platform') != 'steam' or p.get('content_kind') not in ('game', 'edition')
                or strict_count(p.get('stock', 0)) < 1
                or not p.get('min_quantity') <= 1 <= p.get('max_quantity') or D(p.get('price_usd', 0)) <= 0):
            raise ValueError('Ключ игры отсутствует на складе')
        if expected_region is not None and p.get('region') != expected_region:
            raise ValueError('Изменился регион активации ключа')
        return p

    def check_steam_login(self, account):
        data = self.request('GET', '/check/steam-account', params={'account': account})
        if not isinstance(data.get('valid'), bool):
            raise ValueError('Некорректный ответ проверки Steam')
        return data['valid']

    def create_steam_rub(self, external_id, count, account):
        count = strict_count(count, 100, 500)
        if not isinstance(account, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}', account):
            raise ValueError('Некорректное рублёвое пополнение Steam')
        self._validate_external_id(external_id)
        result = self.request('POST', '/orders', payload={'external_order_id': external_id, 'service': 'steam',
                    'product_id': 1, 'product_count': count, 'account': account}, idempotency=external_id, timeout=35)
        if not result.get('uuid'):
            raise UnknownOutcome('POST без UUID; повтор запрещён')
        return result

    def create_steam_currency(self, external_id, currency, count, account):
        if currency not in STEAM_CURRENCIES:raise ValueError('Неподдерживаемая валюта Steam')
        contract=STEAM_CURRENCIES[currency]
        count=strict_count(count,contract['min_count'],contract['max_count'])
        if not isinstance(account,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}',account):
            raise ValueError('Некорректный логин Steam')
        self._validate_external_id(external_id)
        result=self.request('POST','/orders',payload={'external_order_id':external_id,'service':'steam',
            'product_id':contract['product_id'],'product_count':count,'account':account},idempotency=external_id,timeout=35)
        if not result.get('uuid'):raise UnknownOutcome('POST Steam без UUID; повтор запрещён')
        return result

    def create_game_key(self, external_id, app_id, option_id):
        self._validate_external_id(external_id)
        result = self.request('POST', '/orders/game-key', payload={'external_order_id': external_id,
                    'app_id': strict_count(app_id), 'option_id': strict_count(option_id), 'quantity': 1},
                    idempotency=external_id, timeout=35)
        if not result.get('uuid'):
            raise UnknownOutcome('POST ключа без UUID; повтор запрещён')
        return result

    def create_service(self,external_id,service,product_id,fields=None,account=None):
        self._validate_external_id(external_id)
        if not isinstance(service,str) or not re.fullmatch(r'[a-z0-9-]{1,100}',service):raise ValueError('Неверный сервис')
        payload={'external_order_id':external_id,'service':service,'product_id':strict_count(product_id),'product_count':1}
        if fields:
            if not isinstance(fields,dict) or len(fields)>8 or any(not isinstance(k,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}',k)
                or not isinstance(v,str) or not 1<=len(v)<=255 for k,v in fields.items()):raise ValueError('Неверные поля получателя')
            payload['fields']=fields
        if account is not None:
            if not isinstance(account,str) or not 1<=len(account)<=255:raise ValueError('Неверный получатель')
            payload['account']=account
        result=self.request('POST','/orders',payload=payload,idempotency=external_id,timeout=35)
        if not result.get('uuid'):raise UnknownOutcome('POST сервиса без UUID; повтор запрещён')
        return result

    @staticmethod
    def _validate_external_id(external_id):
        if not isinstance(external_id, str) or not external_id.startswith('funpay-') or not ORDER_RE.fullmatch(external_id[7:]):
            raise ValueError('Неверный номер оплаченного заказа')


class Store:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self._create()

    @contextmanager
    def conn(self):
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        try:
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA busy_timeout=8000")
            conn.execute("PRAGMA journal_mode=WAL")
            yield conn
        finally:
            conn.close()

    def _create(self):
        with self.conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS orders (
                id TEXT PRIMARY KEY, buyer_id TEXT NOT NULL, chat_id TEXT NOT NULL,
                buyer_name TEXT NOT NULL, description TEXT NOT NULL,
                stars INTEGER NOT NULL, amount INTEGER NOT NULL,
                price_seen TEXT NOT NULL, username TEXT,
                status TEXT NOT NULL, supplier_uuid TEXT, supplier_status TEXT,
                external_id TEXT NOT NULL UNIQUE, quoted_usd TEXT, revenue_rub TEXT,
                cost_rub TEXT, profit_rub TEXT, details TEXT,
                buyer_notified INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                submitted_at TEXT)""")
            # Безопасная миграция SQLite для баз, созданных версией 0.9.
            cols = {r[1] for r in c.execute("PRAGMA table_info(orders)")}
            if "funpay_status" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN funpay_status TEXT")
            if "submitted_at" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN submitted_at TEXT")
                # В старой БД точное время POST неизвестно. Используем changed_at:
                # старые покупки учитываются консервативно, даже если день сдвинулся.
                c.execute("UPDATE orders SET submitted_at=changed_at WHERE quoted_usd IS NOT NULL")
            if "last_polled_at" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN last_polled_at REAL NOT NULL DEFAULT 0")
            if "charged_usd" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN charged_usd TEXT")
            if "applied_rate" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN applied_rate TEXT")
            if "captured_mode" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN captured_mode TEXT NOT NULL DEFAULT 'legacy'")
                c.execute("""UPDATE orders SET status='needs_review',
                    details='Режим захвата старого заказа неизвестен; автоматическая покупка запрещена',
                    changed_at=CURRENT_TIMESTAMP WHERE status IN ('awaiting_username','ready')""")
            if "peak_charged_usd" not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN peak_charged_usd TEXT")
                c.execute("UPDATE orders SET peak_charged_usd=charged_usd WHERE charged_usd IS NOT NULL")
            if 'kind' not in cols:
                c.execute("ALTER TABLE orders ADD COLUMN kind TEXT NOT NULL DEFAULT 'stars'")
            if 'voucher' not in cols:
                c.execute('ALTER TABLE orders ADD COLUMN voucher TEXT')
            if 'retry_after' not in cols:
                c.execute('ALTER TABLE orders ADD COLUMN retry_after REAL NOT NULL DEFAULT 0')
            c.execute("""CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT, event TEXT,
                detail TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")

    def event(self, order_id, event, detail=""):
        with self.lock, self.conn() as c:
            c.execute("INSERT INTO actions(order_id,event,detail) VALUES(?,?,?)", (order_id, event, str(detail)[:500]))

    def insert_order(self, oid, buyer_id, chat_id, buyer_name, description, stars, amount, price_seen,
                     captured_mode="legacy", kind="stars"):
        if not ORDER_RE.fullmatch(oid):
            raise ValueError("Нестандартный номер заказа FunPay")
        amount = strict_count(amount)
        if kind == 'stars':
            stars = strict_count(stars, 50, 150)
        elif kind in ('game_key','service_topup','service_code'):
            if stars != 1 or amount != 1: raise ValueError('Один заказ — один ключ')
        elif kind in STEAM_KINDS:
            contract=next(v for v in STEAM_CURRENCIES.values() if v['kind']==kind)
            stars = strict_count(stars,contract['min_count'],contract['max_count'])
        else:
            raise ValueError('Неизвестный товар')
        if captured_mode not in ("dry_run", "live", "legacy"):
            raise ValueError("Некорректный режим захвата заказа")
        with self.lock, self.conn() as c:
            cursor = c.execute("""INSERT OR IGNORE INTO orders
                 (id,buyer_id,chat_id,buyer_name,description,stars,amount,price_seen,status,external_id,captured_mode,kind)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(oid,str(buyer_id),str(chat_id),buyer_name,description,
                                                stars,amount,str(price_seen),
                                                "awaiting_username", "funpay-" + oid, captured_mode,kind))
            return bool(cursor.rowcount)

    def get(self, oid):
        with self.conn() as c:
            row = c.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
            return dict(row) if row else None

    def rows(self, statuses=None, limit=15):
        with self.conn() as c:
            if statuses:
                qs=",".join("?" for _ in statuses)
                rows=c.execute(f"SELECT * FROM orders WHERE status IN ({qs}) ORDER BY created_at ASC LIMIT ?", (*statuses,limit)).fetchall()
            else:
                rows=c.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()
            return [dict(x) for x in rows]

    def pending_rows(self, limit=20):
        """Честная очередь опроса: ручная проверка без UUID не занимает место."""
        limit = strict_count(limit)
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            rows = c.execute("""SELECT * FROM orders
                WHERE status IN ('supplier_pending','needs_review')
                AND supplier_uuid IS NOT NULL AND supplier_uuid != ''
                ORDER BY last_polled_at ASC, created_at ASC, id ASC LIMIT ?""", (limit,)).fetchall()
            selected_at = time.time()
            c.executemany("UPDATE orders SET last_polled_at=? WHERE id=?",
                          [(selected_at, row["id"]) for row in rows])
            c.execute("COMMIT")
            return [dict(row) for row in rows]

    def unnotified_completed(self, limit=20):
        with self.conn() as c:
            rows = c.execute("""SELECT * FROM orders WHERE status='completed'
                AND buyer_notified=0 ORDER BY created_at ASC, id ASC LIMIT ?""",
                             (strict_count(limit),)).fetchall()
            return [dict(row) for row in rows]

    def recover_interrupted(self):
        """Атомарно блокирует ВСЕ прерванные заказы; POST никогда не повторяется."""
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            rows = c.execute("SELECT * FROM orders WHERE status IN ('preparing','submitting')").fetchall()
            c.execute("""UPDATE orders SET status=CASE WHEN status='submitting'
                THEN 'uncertain' ELSE 'needs_review' END,
                details='Прервано перезапуском; автоматический повтор запрещён',
                changed_at=CURRENT_TIMESTAMP WHERE status IN ('preparing','submitting')""")
            c.execute("COMMIT")
            return [dict(row) for row in rows]

    def reserve_submission(self, oid, quoted_usd, max_single_usd, max_daily_usd, **fields):
        """Проверяет бюджет и сохраняет submitting в одной транзакции до POST."""
        quote, single, daily = D(quoted_usd), D(max_single_usd), D(max_daily_usd)
        if quote <= 0 or single <= 0 or daily <= 0 or quote > single:
            raise ValueError("Превышен лимит USD на один заказ или некорректен бюджет")
        allowed = {"revenue_rub", "cost_rub", "profit_rub", "details", "applied_rate"}
        if not set(fields).issubset(allowed):
            raise ValueError("Недопустимое поле резервирования")
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT status,captured_mode FROM orders WHERE id=?", (oid,)).fetchone()
            if not row or row["status"] != "preparing" or row["captured_mode"] != "live":
                c.execute("COMMIT")
                return False
            spent = c.execute("""SELECT quoted_usd, charged_usd, peak_charged_usd FROM orders
                WHERE quoted_usd IS NOT NULL AND submitted_at IS NOT NULL
                AND substr(submitted_at,1,10)=date('now')""").fetchall()
            spent_amount = sum((max(D(row["quoted_usd"]), D(row["charged_usd"] or 0),
                                    D(row["peak_charged_usd"] or 0))
                                for row in spent), Decimal(0))
            if spent_amount + quote > daily:
                c.execute("ROLLBACK")
                raise ValueError("Превышен ежедневный бюджет")
            assignments = {"status": "submitting", "quoted_usd": str(quote), **fields}
            c.execute("UPDATE orders SET " + ", ".join(key + "=?" for key in assignments)
                      + ", submitted_at=COALESCE(submitted_at,CURRENT_TIMESTAMP),"
                        " changed_at=CURRENT_TIMESTAMP WHERE id=? AND status='preparing'",
                      [*assignments.values(), oid])
            c.execute("COMMIT")
            return True

    def _preserve_peak_charge(self, c, oid, fields):
        if "charged_usd" not in fields:
            return fields
        charge = D(fields["charged_usd"])
        if charge < 0:
            raise ValueError("Списание поставщика не может быть отрицательным")
        previous = c.execute("SELECT peak_charged_usd,charged_usd FROM orders WHERE id=?", (oid,)).fetchone()
        peak = max(charge, D(previous["peak_charged_usd"] or 0), D(previous["charged_usd"] or 0)) if previous else charge
        return {**fields, "charged_usd": str(charge), "peak_charged_usd": str(peak)}

    def set(self, oid, **kw):
        if not kw:
            return
        cols = {"username","status","supplier_uuid","supplier_status","quoted_usd", "revenue_rub",
                "cost_rub","profit_rub","details","buyer_notified", "charged_usd", "applied_rate", "funpay_status", "voucher", "retry_after"}
        if not set(kw).issubset(cols):
            raise ValueError("Недопустимое поле")
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            kw = self._preserve_peak_charge(c, oid, kw)
            # Момент начала покупки сохраняется отдельно от времени последнего poll.
            stamp = ", submitted_at=COALESCE(submitted_at,CURRENT_TIMESTAMP)" if kw.get("status") == "submitting" else ""
            sql="UPDATE orders SET " + ", ".join(k+"=?" for k in kw) + stamp + ", changed_at=CURRENT_TIMESTAMP WHERE id=?"
            c.execute(sql, [*kw.values(),oid])
            c.execute("COMMIT")

    def set_if_status(self, oid, required_status, **kw):
        """Атомарное изменение состояния: исключает подготовку заказа после отмены в базе."""
        allowed = {"username", "status", "supplier_uuid", "supplier_status", "quoted_usd", "revenue_rub",
                   "cost_rub", "profit_rub", "details", "buyer_notified", "charged_usd", "applied_rate", "funpay_status", "voucher", "retry_after"}
        if not kw or not set(kw).issubset(allowed):
            raise ValueError("Недопустимое поле")
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            kw = self._preserve_peak_charge(c, oid, kw)
            stamp = ", submitted_at=COALESCE(submitted_at,CURRENT_TIMESTAMP)" if kw.get("status") == "submitting" else ""
            sql="UPDATE orders SET " + ", ".join(k+"=?" for k in kw) + stamp + ", changed_at=CURRENT_TIMESTAMP WHERE id=? AND status=?"
            cursor=c.execute(sql, [*kw.values(),oid,required_status])
            c.execute("COMMIT")
            return bool(cursor.rowcount)

    def take_ready(self):
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            r = c.execute("SELECT id FROM orders WHERE status='ready' AND retry_after<=? ORDER BY created_at LIMIT 1", (time.time(),)).fetchone()
            if not r:
                c.execute("COMMIT")
                return None
            c.execute("UPDATE orders SET status='preparing', changed_at=CURRENT_TIMESTAMP WHERE id=?",(r["id"],))
            c.execute("COMMIT")
            return self.get(r["id"])

    def set_username(self, oid, buyer_id, chat_id, username):
        if not isinstance(username, str):
            return False
        with self.lock, self.conn() as c:
            c.execute("BEGIN IMMEDIATE")
            r = c.execute("SELECT buyer_id,chat_id,status,kind FROM orders WHERE id=?",(oid,)).fetchone()
            if not r or r["buyer_id"] != str(buyer_id) or r["chat_id"] != str(chat_id) or r["status"] != "awaiting_username":
                c.execute("COMMIT")
                return False
            valid = username_or_none(username) if r['kind'] == 'stars' else re.fullmatch(r'[A-Za-z0-9_.-]{3,64}', username) if r['kind'] in STEAM_KINDS else False
            if not valid:
                c.execute('COMMIT')
                return False
            c.execute("UPDATE orders SET username=?,status='ready', changed_at=CURRENT_TIMESTAMP WHERE id=?",(username,oid))
            c.execute("COMMIT")
            return True

    def awaiting_for_buyer(self, buyer_id):
        with self.lock, self.conn() as c:
            rows = c.execute("SELECT * FROM orders WHERE buyer_id=? AND status='awaiting_username' ORDER BY created_at,id",
                             (str(buyer_id),)).fetchall()
            return [dict(row) for row in rows]

    def set_service_recipient(self,oid,buyer_id,chat_id,recipient):
        if not isinstance(recipient,dict) or not recipient or len(recipient)>8 or any(
            not isinstance(k,str) or not isinstance(v,str) or not re.fullmatch(r'[0-9]{3,20}',v) for k,v in recipient.items()):return False
        with self.lock,self.conn() as c:
            c.execute('BEGIN IMMEDIATE')
            cursor=c.execute("UPDATE orders SET username=?,status='ready',changed_at=CURRENT_TIMESTAMP WHERE id=? AND buyer_id=? AND chat_id=? AND kind='service_topup' AND status='awaiting_username'",
                (json.dumps(recipient,sort_keys=True),oid,str(buyer_id),str(chat_id)))
            c.execute('COMMIT');return bool(cursor.rowcount)

    def set_meta(self, key, value):
        with self.lock,self.conn() as c:
            c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key,str(value)))

    def get_meta(self, key, default=None):
        with self.conn() as c:
            x=c.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone()
            return x["value"] if x else default

    def today_spend(self):
        # Консервативно: учитываем все когда-либо начатые сегодня POST независимо от
        # обновлений статуса, рефандов и задержек. Сутки UTC по серверным часам SQLite.
        with self.conn() as c:
            r=c.execute("""SELECT quoted_usd, charged_usd, peak_charged_usd FROM orders
               WHERE quoted_usd IS NOT NULL
               AND submitted_at IS NOT NULL
               AND substr(submitted_at,1,10)=date('now')""").fetchall()
            return sum((max(D(x["quoted_usd"]), D(x["charged_usd"] or 0),
                            D(x["peak_charged_usd"] or 0)) for x in r), Decimal(0))

    def counts(self):
        with self.conn() as c:
            return {x["status"]:x["n"] for x in c.execute("SELECT status,COUNT(*) AS n FROM orders GROUP BY status")}
