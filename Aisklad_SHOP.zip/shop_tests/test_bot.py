import copy
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from aisklad_shop.bot import BuyerBot
from aisklad_shop import presentation as p


class Store:
    def __init__(self):
        self.sessions, self.settings = {}, {}

    def get_session(self, uid):
        return copy.deepcopy(self.sessions.get(uid, {}))

    def set_session(self, uid, data):
        self.sessions[uid] = copy.deepcopy(data)

    def get_setting(self, key, default=None):
        return self.settings.get(key, default)

    def set_setting(self, key, value):
        self.settings[key] = value


class FakeBot:
    def __init__(self):
        self.sent, self.answers = [], []
        self.photo_error = None

    def send_message(self, uid, text, **kwargs):
        self.sent.append((uid, text, kwargs))
        return NS(message_id=len(self.sent))

    def send_photo(self, uid, photo, caption="", **kwargs):
        if self.photo_error:
            raise self.photo_error
        self.sent.append((uid, caption, kwargs))
        return NS(message_id=len(self.sent))

    def answer_callback_query(self, call_id, text=None):
        self.answers.append((call_id, text))

    def register_message_handler(self, *args, **kwargs):
        pass

    def register_callback_query_handler(self, *args, **kwargs):
        pass


class FakeService:
    def __init__(self):
        self.store = Store()
        self.items = [{"id": "stars", "title": "Stars <Test>", "price_rub": "1.2345", "available": True,
                       "min_quantity": 50, "max_quantity": 999999, "kind": "topup"}]
        self._cart, self.help, self.checkedout = [], [], 0
        self._notifications, self.acked, self.favorite = [], [], False
        self.resets, self.enabled = 0, True

    def status(self):
        return {"enabled": self.enabled, "payment_enabled": False, "catalog": {"active": {"indexed": 44, "state": "complete"}}, "health_paused": self.resets == 0}

    def stats(self):
        return {"orders_total": 5, "customers": 2, "order_statuses": {"completed": 3, "needs_review": 2}, "health": {"catalog": 2}}

    def balance(self):
        return {"balance_usd": "5.96", "observed_at": 1}

    def reset_health(self):
        self.resets += 1

    def set_enabled(self, enabled):
        self.enabled = enabled

    def categories(self, **kwargs):
        return {"items": [{"id": "brand:1", "title": "Telegram"}], "total": 1, "page": 0, "pages": 1}

    def list_products(self, service_id, **kwargs):
        return {"items": self.items, "total": len(self.items), "page": 0, "pages": 1}

    def product(self, pid):
        return self.items[0]

    def requirements(self, pid):
        return [{"name": "account", "label": "Telegram username", "is_account": True, "required": True, "type": "text"}]

    def add_to_cart(self, uid, pid, quantity=1, fields=None):
        self._cart.append({"id": "i1", "title": self.items[0]["title"], "product_id": pid, "quantity": quantity,
                           "fields": fields, "total_rub": "61.725"})
        return self.cart(uid)

    def cart(self, uid):
        return {"items": self._cart, "total_rub": "61.725" if self._cart else "0"}

    def remove_cart(self, uid, iid):
        self._cart = [item for item in self._cart if item["id"] != iid]
        return self.cart(uid)

    def clear_cart(self, uid):
        self._cart = []
        return self.cart(uid)

    def checkout(self, uid):
        self.checkedout += 1
        exc = RuntimeError("SECRET API response")
        exc.code = "PAYMENT_UNAVAILABLE"
        raise exc

    def orders(self, uid, page=0):
        return {"items": [], "page": page, "pages": 1}

    def order(self, uid, oid):
        return {"id": oid, "user_id": 10, "status": "completed", "total_rub": "100", "delivery": ["VOUCHER-SAFETY"], "items": []}

    def request_help(self, uid, text, order_id=None):
        self.help.append((uid, text, order_id))
        return {"ticket_id": "T1"}

    def favorites(self, uid, page=0):
        return {"items": self.items if self.favorite else [], "total": int(self.favorite), "page": page, "pages": 1}

    def is_favorite(self, uid, pid):
        return self.favorite

    def toggle_favorite(self, uid, pid):
        self.favorite = not self.favorite

    def pending_notifications(self, limit=50):
        return self._notifications[:limit]

    def ack_notification(self, eid):
        self.acked.append(eid)


def message(text, uid=10, group=False):
    return NS(text=text, from_user=NS(id=uid), chat=NS(id=-123 if group else uid, type="group" if group else "private"))


class BotTests(unittest.TestCase):
    def setUp(self):
        self.service, self.bot = FakeService(), FakeBot()
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")

    def callback(self, label, uid=10, payload=None):
        if payload is None:
            markup = self.bot.sent[-1][2]["reply_markup"]
            payload = next(b.callback_data for row in markup.keyboard for b in row if label in b.text)
        call = NS(id="c1", from_user=NS(id=uid), message=message("", uid), data=payload)
        self.ui.handle_callback(call)
        return payload

    def test_start_pretty_private_only(self):
        self.ui.handle_message(message("/start", group=True))
        self.assertEqual(self.bot.sent, [])
        self.ui.handle_message(message("/start"))
        self.assertIn("Aisklad SHOP", self.bot.sent[-1][1])
        self.assertIn("!помощь", self.bot.sent[-1][1])

    def test_callbacks_short_signed_persistent_and_cross_user_protected(self):
        self.ui.handle_message(message("/start"))
        payload = self.bot.sent[-1][2]["reply_markup"].keyboard[0][0].callback_data
        self.assertLessEqual(len(payload.encode()), 64)
        self.callback("", uid=20, payload=payload)
        self.assertIn("недействительна", self.bot.answers[-1][1])
        self.assertEqual(len(self.bot.sent), 1)
        self.ui = BuyerBot(self.service, bot=self.bot, owner_id=99, assets_dir="/no-assets")
        self.callback("", payload=payload)
        self.assertIn("Каталог", self.bot.sent[-1][1])

    def test_stale_callback_not_replayed(self):
        self.ui.handle_message(message("/start"))
        data = self.callback("каталог")
        count = len(self.bot.sent)
        self.callback("", payload=data)
        self.assertEqual(count, len(self.bot.sent))
        self.assertIn("старое", self.bot.answers[-1][1])

    def test_dynamic_quantity_recipient_confirm_then_cart(self):
        self.ui._show_product(10, "stars", {})
        self.assertIn("&lt;Test&gt;", self.bot.sent[-1][1])
        self.callback("количество")
        self.ui.handle_message(message("49"))
        self.assertIn("50", self.bot.sent[-1][1])
        self.ui.handle_message(message("51"))
        self.assertIn("username", self.bot.sent[-1][1])
        self.ui.handle_message(message("@buyer_name"))
        self.assertEqual(self.service._cart, [])
        self.assertIn("Проверь", self.bot.sent[-1][1])
        data = self.callback("Всё верно")
        self.assertEqual(len(self.service._cart), 1)
        self.assertEqual(self.service._cart[0]["quantity"], 51)
        self.assertEqual(self.service._cart[0]["fields"], {"account": "@buyer_name"})
        self.callback("", payload=data)
        self.assertEqual(len(self.service._cart), 1)

    def test_callback_answers_before_backend(self):
        self.ui.handle_message(message("/start"))
        original = self.service.categories
        def categories(**kwargs):
            self.assertTrue(self.bot.answers)
            return original(**kwargs)
        self.service.categories = categories
        self.callback("каталог")

    def test_disabled_payment_never_paid_or_external_url(self):
        self.service._cart = [{"id": "i1", "title": "Stars", "quantity": 50, "fields": {}, "total_rub": "100"}]
        self.ui._checkout_preview(10, {})
        data = self.callback("доступность оплаты")
        self.assertEqual(self.service.checkedout, 1)
        self.assertIn("Товар ещё не оплачен", self.bot.sent[-1][1])
        self.assertNotIn("SECRET", self.bot.sent[-1][1])
        self.assertNotIn("http", self.bot.sent[-1][1])
        self.callback("", payload=data)
        self.assertEqual(self.service.checkedout, 1)

    def test_order_voucher_ownership_guard(self):
        with self.assertRaises(ValueError):
            self.ui._owned_order(20, "known")
        self.assertEqual(self.bot.sent, [])
        self.ui._action(10, "order", {"order_id": "known"}, {})
        self.assertIn("VOUCHER-SAFETY", self.bot.sent[-1][1])

    def test_long_delivery_code_never_truncated(self):
        code = "A" * 5000 + "-FINAL"
        self.ui._send_screen(10, p.order({"id": "owned", "status": "completed", "total_rub": "1", "delivery": [code]}))
        combined = "".join(text for _, text, _ in self.bot.sent)
        self.assertIn(code, combined)

    def test_help_durable_and_html_escaped(self):
        self.ui.handle_message(message("!помощь <broken>"))
        self.assertEqual(self.service.help[0], (10, "<broken>", None))
        self.assertIn("отправлено", self.bot.sent[-2][1])

    def test_owner_only_admin_and_module_toggle(self):
        class Modules:
            def __init__(self):
                self.state, self.calls = {"shop": True, "funpay": False}, []
            def status(self):
                return self.state
            def set_enabled(self, module, enabled, uid):
                self.calls.append((module, enabled, uid))
                self.state[module] = enabled
        modules = Modules()
        self.ui.module_controller = modules
        self.ui.handle_message(message("/shop_off"))
        self.assertEqual(modules.calls, [])
        self.ui.handle_message(message("/shop_off", uid=99))
        self.assertEqual(modules.calls, [("shop", False, 99)])
        self.ui.handle_message(message("/shop_admin", uid=99, group=True))
        self.assertEqual(len(modules.calls), 1)

    def test_owner_operational_commands_are_private_and_guarded(self):
        for command in ("/shop_stats", "/shop_balance", "/shop_sync", "/shop_resume"):
            self.ui.handle_message(message(command))
            self.ui.handle_message(message(command, uid=99, group=True))
        self.assertEqual(self.service.resets, 0)
        self.assertEqual(self.ui._admin_jobs, {})
        self.ui.handle_message(message("/shop_stats", uid=99))
        self.assertIn("Заказов: <b>5</b>", self.bot.sent[-1][1])
        self.assertIn("2/7", self.bot.sent[-1][1])
        self.ui.handle_message(message("/shop_resume", uid=99))
        self.assertEqual(self.service.resets, 1)
        self.assertTrue(self.service.enabled)
        self.assertFalse(self.service.status()["payment_enabled"])

    def test_owner_balance_is_read_only_and_uses_background_job(self):
        self.ui.handle_message(message("/shop_balance", uid=99))
        self.ui._admin_jobs["balance"].join(2)
        self.assertIn("$5.96", self.bot.sent[-1][1])
        self.assertEqual(self.service.checkedout, 0)

    def test_catalog_sync_is_nonblocking_and_deduplicated(self):
        entered, release = threading.Event(), threading.Event()
        calls = []
        def sync():
            calls.append(1)
            entered.set()
            release.wait(2)
            return {"state": "complete", "indexed": 10000, "services": 120}
        self.service.sync_catalog = sync
        self.ui.handle_message(message("/shop_sync", uid=99))
        self.assertTrue(entered.wait(1))
        self.ui.handle_message(message("/shop_sync", uid=99))
        self.assertIn("уже идёт", self.bot.sent[-1][1])
        self.ui.handle_message(message("/start", uid=20))
        self.assertIn("Aisklad SHOP", self.bot.sent[-1][1])
        release.set()
        self.ui._admin_jobs["catalog"].join(2)
        self.assertEqual(len(calls), 1)
        self.assertIn("10000", self.bot.sent[-1][1])

    def test_owner_notifier_prefers_management_bot_and_failure_preserves_event(self):
        events = []
        self.ui.owner_notifier = lambda uid, text: events.append((uid, text))
        self.service._notifications = [{"id": "owner1", "user_id": 99, "kind": "owner:alert", "payload": {"order_id": "known", "text": "Проверить"}}]
        self.ui.send_pending_notifications()
        self.assertEqual(events[0][0], 99)
        self.assertEqual(self.bot.sent, [])
        self.assertEqual(self.service.acked, ["owner1"])
        self.service.acked = []
        self.ui.owner_notifier = lambda uid, text: (_ for _ in ()).throw(TimeoutError("offline"))
        self.ui.send_pending_notifications()
        self.assertEqual(self.service.acked, [])

    def test_outbox_only_acks_success_and_same_existing_voucher(self):
        self.service._notifications = [{"id": "n1", "user_id": 10, "payload": {"order_id": "known"}},
                                       {"id": "n2", "user_id": 20, "payload": {"order_id": "known"}}]
        self.ui.send_pending_notifications()
        self.assertEqual(self.service.acked, ["n1"])
        self.assertEqual(self.service.checkedout, 0)
        self.assertEqual({uid for uid, _, _ in self.bot.sent}, {10})

    def test_owner_alert_does_not_require_buyer_ownership_or_expose_voucher(self):
        self.service._notifications = [{"id": "owner1", "user_id": 99, "kind": "owner:order", "payload": {"order_id": "known", "text": "Новый заказ"}},
                                       {"id": "bad-owner", "user_id": 20, "kind": "owner:order", "payload": {"order_id": "known", "text": "PRIVATE"}}]
        self.ui.send_pending_notifications()
        self.assertEqual(self.service.acked, ["owner1"])
        self.assertEqual(self.bot.sent[0][0], 99)
        self.assertIn("Новый заказ", self.bot.sent[0][1])
        self.assertNotIn("VOUCHER", self.bot.sent[0][1])

    def test_select_all_options_paginated_eight_per_page(self):
        self.service.requirements = lambda _: [{"name": "region", "label": "Регион", "type": "select", "options": [{"value": str(i), "label": "Вариант " + str(i)} for i in range(17)]}]
        self.ui._begin_buy(10, "stars", {})
        self.ui.handle_message(message("50"))
        markup = self.bot.sent[-1][2]["reply_markup"]
        self.assertEqual(sum(1 for row in markup.keyboard for b in row if b.text.startswith("Вариант")), 8)
        self.callback("Далее")
        self.callback("Далее")
        self.callback("Вариант 16")
        self.assertIn("16", self.bot.sent[-1][1])

    def test_navigation_edits_current_menu_without_chat_flood(self):
        edited = []
        self.bot.edit_message_text = lambda text, **kwargs: edited.append((text, kwargs))
        self.ui.handle_message(message("/start"))
        self.callback("каталог")
        self.assertEqual(len(self.bot.sent), 1)
        self.assertEqual(len(edited), 1)

    def test_temporary_send_error_keeps_outbox_without_retry_burst(self):
        self.service._notifications = [{"id": "n1", "user_id": 10, "payload": {"order_id": "known"}}]
        calls = []
        def fail(*args, **kwargs):
            calls.append(1)
            raise TimeoutError("network")
        self.bot.send_message = fail
        self.ui.send_pending_notifications()
        self.assertEqual(len(calls), 1)
        self.assertEqual(self.service.acked, [])

    def test_image_failure_falls_back_and_long_caption_no_broken_html(self):
        with tempfile.TemporaryDirectory() as directory:
            Path(directory, "home.jpg").write_bytes(b"test")
            self.ui.assets_dir = Path(directory)
            self.bot.photo_error = RuntimeError("Bad Request: photo unavailable")
            self.ui.handle_message(message("/start"))
            self.assertIn("Aisklad SHOP", self.bot.sent[-1][1])
            self.ui._send_screen(10, p.Screen("<b>" + "&lt;" * 1600 + "</b>", "home"))
            self.assertTrue(all(len(text) <= 3900 for _, text, _ in self.bot.sent))
            self.assertIsNone(self.bot.sent[-1][2]["parse_mode"])

    def test_select_optional_and_numeric_fields(self):
        self.service.requirements = lambda _: [{"name": "region", "label": "Регион", "options": [{"value": "EU", "label": "Европа"}], "required": True},
                                               {"name": "id", "label": "ID", "type": "integer", "min": 1, "max": 9, "required": True},
                                               {"name": "note", "label": "Комментарий", "required": False}]
        self.ui._begin_buy(10, "stars", {})
        self.ui.handle_message(message("50"))
        self.callback("Европа")
        self.ui.handle_message(message("nan"))
        self.assertIn("Проверь число", self.bot.sent[-1][1])
        self.ui.handle_message(message("3"))
        self.callback("Пропустить")
        self.assertIn("Проверь перед покупкой", self.bot.sent[-1][1])

    def test_terms_privacy_payment_support_exist(self):
        for command in ("/terms", "/privacy", "/paysupport"):
            self.ui.handle_message(message(command))
        self.assertIn("Мы рядом", self.bot.sent[-1][1])
        self.assertEqual(len(self.service.help), 1)

    def test_external_errors_do_not_expose_details(self):
        self.ui._error(10, RuntimeError("api_key=SECRET"))
        self.assertNotIn("SECRET", self.bot.sent[-1][1])

    def test_decimal_price_and_every_menu_preview(self):
        self.assertEqual(p.rub("61.725"), "61,72 ₽")
        self.assertEqual(p.rub("NaN"), "уточняется")
        self.assertEqual(set(p.gallery_examples()), set(p.MENU_KEYS))


if __name__ == "__main__":
    unittest.main()
