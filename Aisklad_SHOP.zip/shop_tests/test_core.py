"""All supplier/payment calls are in-memory fakes; never connects to real accounts."""
import copy
import hashlib
import hmac
import json
import tempfile
import threading
import unittest
from decimal import Decimal
from pathlib import Path
from aisklad_shop.catalog import product_id, safe_image
from aisklad_shop.payments import VerifiedPaymentEvent
from aisklad_shop.service import ShopError, ShopService
from aisklad_shop.store import ShopStore
from aisklad_shop.supplier import SteamSupplier


class FakeSupplier:
    def __init__(self):
        self.posts = []
        self.history = {}
        self.fail_sync = False
        self.fail_product = False
        self.unknown = False
        self.next_status = "completed"
        self.price = "0.0152"
        self.account_checks = []

    def brands(self):
        return [{"id": "telegram", "name": "Telegram", "icon": "https://steam.ru/icon.png"}, {"id": "games", "name": "Games"}]

    def services(self):
        return iter([{"id": "telegram-stars", "name": "Telegram Stars", "brand": "telegram"}, {"id": "ml", "name": "Mobile Legends", "brand": "games"}])

    def products(self, slug):
        if self.fail_product:
            raise OSError("offline")
        if slug == "telegram-stars":
            return {"service": slug, "type": "topup", "requires_account": True, "products": [{"product_id": 55, "name": "Stars", "price_usd": self.price, "min_count": 50, "max_count": 999999, "fields": []}]}
        return {"service": slug, "type": "topup", "requires_account": True, "products": [{"product_id": 9, "name": "Diamonds", "price_usd": "10", "min_count": 1, "max_count": 1,
                 "fields": [{"key": "player_id", "is_account": True, "type": "text", "pattern": "^[0-9]{3,10}$"}, {"key": "server", "type": "select", "options": [{"value": "EU", "label": "Europe"}, {"value": "AS", "label": "Asia"}]}]}]}

    def keys(self):
        return iter([{"app_id": n, "name": "Game " + str(n), "price_usd": 60, "image": "https://shared.steamstatic.com/store_item_assets/steam/apps/" + str(n) + "/header.jpg"} for n in range(1, 26)])

    def gifts(self):
        if self.fail_sync:
            raise OSError("partial")
        return iter([{"app_id": 88, "name": "Gift Game", "image": None}])

    def key_card(self, app_id):
        return {"app_id": app_id, "name": "Game", "variants": [{"app_id": app_id, "option_id": app_id * 10 + i, "name": "DLC" if i else "Game", "content_kind": "dlc" if i else "game", "price_usd": 60, "region": "GLOBAL", "countries": [], "stock": 4, "min_quantity": 1, "max_quantity": 4} for i in range(2)]}

    def gift_card(self, app_id):
        return {"app_id": app_id, "name": "Gift Game", "editions": [{"edition": "base", "name": "Base", "regions": [{"code": "CIS", "countries": ["KZ"], "price_usd": "3"}, {"code": "EU", "countries": ["DE"], "price_usd": "5"}]}, {"edition": "deluxe", "name": "Deluxe", "regions": [{"code": "CIS", "countries": ["KZ"], "price_usd": "9"}]}]}

    def check_account(self, service, account):
        self.account_checks.append((service, account))
        if account == "invalid":
            raise ValueError("invalid")

    def submit(self, product, quantity, fields, external_id, expected_max_usd=None):
        self.posts.append((copy.deepcopy(product), quantity, copy.deepcopy(fields), external_id))
        status = "delivered" if product["kind"] in ("key", "code") else self.next_status
        result = {"uuid": "12345678-1234-1234-1234-" + str(len(self.posts)).zfill(12), "status": status, "external_order_id": external_id}
        if product["kind"] in ("topup", "code"):
            result.update(product_id=product["supplier_product_id"], product_count=quantity, transfer_service=product["service"])
        if product["kind"] == "key":
            result.update(app_id=product["app_id"], option_id=product["option_id"], voucher="PRIVATE-CODE")
        self.history[external_id] = result
        if self.unknown:
            raise OSError("response lost after acceptance")
        return copy.deepcopy(result)

    def order(self, uuid):
        return copy.deepcopy(next(v for v in self.history.values() if v["uuid"] == uuid))

    def recover(self, external_id):
        return copy.deepcopy(self.history.get(external_id))


class FakeVerifier:
    def verify(self, raw_body, headers):
        # Only deterministic fake signatures in an offline unit test.
        expected = hmac.new(b"TEST-ONLY", raw_body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(headers.get("signature", ""), expected):
            raise ValueError("not authenticated")
        return VerifiedPaymentEvent(**json.loads(raw_body))


class FakePayments:
    enabled, provider, currency, verifier = True, "test-only", "RUB", FakeVerifier()
    def __init__(self):
        self.invoices = []
    def create_invoice(self, **value):
        self.invoices.append(value)
        return {"invoice_id": "test-" + value["order_id"]}


class ShopCoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.now = 1800000000
        self.store = ShopStore(Path(self.temp.name) / "shop.sqlite3", clock=lambda: self.now)
        self.supplier = FakeSupplier()
        self.payments = FakePayments()
        self.settings = {"enabled": True, "owner_id": 777, "fixed_cost_rub": ".25", "target_margin_pct": ".4", "payment_fee_pct": "3"}
        self.rate = {"rub_per_usd": "100", "observed_at": self.now, "source": "bank-effective"}
        self.shop = ShopService(self.store, self.supplier, self.settings, rate_provider=lambda: self.rate, payment_connector=self.payments, clock=lambda: self.now)
        self.shop.sync_catalog()
        self.stars = product_id("service", "telegram-stars", 55)

    def add_stars(self, quantity=50):
        return self.shop.add_to_cart(100, self.stars, quantity, {"account": "@test_user"})

    def paid_order(self, product=None, quantity=50, fields=None):
        if product is None:
            self.add_stars(quantity)
        else:
            self.shop.add_to_cart(100, product, quantity, fields)
        order = self.shop.checkout(100)
        self.pay(order)
        return order["id"]

    def pay(self, order, **changes):
        event = {"provider": "test-only", "event_id": "evt-" + order["id"], "charge_id": "charge-" + order["id"], "invoice_id": "test-" + order["id"], "order_id": order["id"], "user_id": 100, "amount": order["total_rub"], "currency": "RUB", "status": "succeeded"}
        event.update(changes)
        raw = json.dumps(event).encode()
        signature = hmac.new(b"TEST-ONLY", raw, hashlib.sha256).hexdigest()
        return self.shop.handle_payment(raw, {"signature": signature})

    def test_full_catalogue_and_expensive_games_have_no_funpay_caps(self):
        self.assertEqual(25, self.shop.list_products("keys", page_size=50)["total"])
        game = self.shop.list_products("keys")["items"][0]
        card = self.shop.product(game["id"])
        self.assertEqual(2, len(card["variants"]))
        self.assertTrue(any(v["content_kind"] == "dlc" and "DLC" in v["warning"] for v in card["variants"]))
        self.assertTrue(all(v["available"] for v in card["variants"]))

    def test_all_gift_editions_and_regions_included(self):
        group = self.shop.list_products("gifts")["items"][0]
        card = self.shop.product(group["id"])
        self.assertEqual(3, len(card["variants"]))
        self.assertEqual({("base", "CIS"), ("base", "EU"), ("deluxe", "CIS")}, {(v["edition"], v["region"]) for v in card["variants"]})

    def test_partial_sync_preserves_complete_active_snapshot(self):
        before = self.shop.catalog.status()["active"]
        self.supplier.fail_sync = True
        with self.assertRaises(ShopError):
            self.shop.sync_catalog()
        self.assertEqual(before, self.shop.catalog.status()["active"])
        self.assertEqual("partial_failed", self.shop.catalog.status()["last_attempt"]["state"])
        self.assertEqual(25, self.shop.list_products("keys", page_size=50)["total"])

    def test_slow_sync_does_not_block_existing_product_and_paid_order(self):
        entered, release, finished = threading.Event(), threading.Event(), threading.Event()
        original = self.supplier.gifts
        def blocked():
            entered.set()
            release.wait(3)
            return original()
        self.supplier.gifts = blocked
        thread = threading.Thread(target=lambda: (self.shop.sync_catalog(), finished.set()))
        thread.start()
        self.assertTrue(entered.wait(1))
        try:
            self.assertEqual(self.stars, self.shop.product(self.stars)["id"])
            self.assertFalse(finished.is_set())
        finally:
            release.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())

    def test_hydrated_key_and_gift_variants_survive_hourly_snapshot(self):
        key_group = self.shop.list_products("keys")["items"][0]
        key = self.shop.product(key_group["id"])["variants"][0]
        gift_group = self.shop.list_products("gifts")["items"][0]
        gift = self.shop.product(gift_group["id"])["variants"][0]
        self.shop.add_to_cart(100, key["id"], 1, {"country": "RU"})
        self.shop.add_to_cart(100, gift["id"], 1, {"country": "KZ", "invite_url": "https://s.team/p/abcd-efgh/ABCDE"})
        self.shop.sync_catalog()
        order = self.shop.checkout(100)
        self.pay(order)
        self.shop.sync_catalog()
        self.shop.process_pending()
        self.assertEqual("completed", self.shop.order(100, order["id"])["status"])
        self.assertEqual(2, len(self.supplier.posts))

    def test_quantity_quote_is_exact_not_minimum_multiplied(self):
        quote = self.shop.quote(100, self.stars, 100, {"account": "@test_user"})
        expected = ((Decimal("1.52") * 100 + Decimal(".25")) / Decimal(".966")).quantize(Decimal(".01"), rounding="ROUND_CEILING")
        self.assertEqual(str(expected), quote["total_rub"])
        self.assertEqual([], self.supplier.posts)
        self.assertEqual([], self.shop.cart(100)["items"])

    def test_stale_or_future_rate_makes_purchase_unavailable(self):
        self.rate["observed_at"] = self.now - 3601
        with self.assertRaises(ShopError) as cm:
            self.add_stars()
        self.assertEqual("RATE_UNAVAILABLE", cm.exception.code)
        self.rate["observed_at"] = self.now + 1
        self.assertFalse(self.shop.product(self.stars)["available"])

    def test_exact_fields_select_and_is_account(self):
        p = product_id("service", "ml", 9)
        self.assertEqual(["player_id", "server"], [f["name"] for f in self.shop.requirements(p)])
        for bad in ({"player_id": "123", "server": "injected"}, {"player_id": "ABC", "server": "EU"}, {"player_id": "123", "server": "EU", "secret": "no"}):
            with self.assertRaises(ShopError):
                self.shop.add_to_cart(100, p, 1, bad)
        self.shop.add_to_cart(100, p, 1, {"player_id": "123", "server": "EU"})
        self.assertEqual([], self.supplier.posts)

    def test_region_mismatch_and_fake_friend_link_rejected(self):
        group = self.shop.list_products("gifts")["items"][0]
        p = self.shop.product(group["id"])["variants"][0]["id"]
        for fields in ({"country": "RU", "invite_url": "https://s.team/p/abcd-efgh/ABCDE"}, {"country": "KZ", "invite_url": "https://s.team.evil.example/p/x"}):
            with self.assertRaises(ShopError):
                self.shop.add_to_cart(100, p, 1, fields)

    def test_disabled_payments_create_no_invoice_or_purchase(self):
        from aisklad_shop.payments import DisabledPayments
        self.shop.payments = DisabledPayments()
        self.add_stars()
        with self.assertRaises(ShopError) as cm:
            self.shop.checkout(100)
        self.assertEqual("PAYMENT_UNAVAILABLE", cm.exception.code)
        self.assertEqual([], self.shop.orders(100)["items"])
        self.assertEqual([], self.supplier.posts)

    def test_invoice_dedup_and_unpaid_never_bought(self):
        self.add_stars()
        a = self.shop.checkout(100)
        b = self.shop.checkout(100)
        self.assertEqual(a["id"], b["id"])
        self.assertEqual(1, len(self.payments.invoices))
        self.shop.process_pending()
        self.assertEqual([], self.supplier.posts)

    def test_quote_drift_requires_new_confirmation(self):
        self.add_stars()
        self.supplier.price = ".016"
        with self.assertRaises(ShopError) as cm:
            self.shop.checkout(100)
        self.assertEqual("QUOTE_CHANGED", cm.exception.code)
        self.assertEqual([], self.payments.invoices)
        self.shop.checkout(100)
        self.assertEqual(1, len(self.payments.invoices))

    def test_payment_requires_authenticated_transport(self):
        self.add_stars()
        order = self.shop.checkout(100)
        with self.assertRaises(ShopError):
            self.shop.handle_payment(json.dumps({"order_id": order["id"], "status": "paid"}).encode(), {})
        self.shop.process_pending()
        self.assertEqual([], self.supplier.posts)

    def test_payment_owner_amount_currency_exact(self):
        self.add_stars()
        order = self.shop.checkout(100)
        for wrong in ({"user_id": 101}, {"amount": ".01"}, {"currency": "USD"}, {"invoice_id": "other"}):
            with self.assertRaises(ShopError):
                self.pay(order, **wrong)
        self.assertEqual("awaiting_payment", self.shop.order(100, order["id"])["status"])

    def test_paid_authorization_persists_duplicate_event_is_noop(self):
        self.add_stars()
        order = self.shop.checkout(100)
        self.assertFalse(self.pay(order)["duplicate"])
        self.assertTrue(self.pay(order)["duplicate"])
        reopened = ShopStore(self.store.path)
        with reopened.connection() as db:
            self.assertEqual(1, db.execute("SELECT COUNT(*) FROM payment_authorizations").fetchone()[0])
        self.shop.process_pending()
        self.shop.process_pending()
        self.assertEqual(1, len(self.supplier.posts))
        self.assertEqual("completed", self.shop.order(100, order["id"])["status"])

    def test_known_paid_order_finishes_while_shop_module_off(self):
        order_id = self.paid_order()
        self.shop.set_enabled(False)
        self.shop.process_pending()
        self.assertEqual("completed", self.shop.order(100, order_id)["status"])
        self.add_stars()
        with self.assertRaises(ShopError):
            self.shop.checkout(100)

    def test_live_gate_holds_before_fence_but_can_resume_later(self):
        order_id = self.paid_order()
        self.supplier.can_purchase = lambda: False
        self.shop.process_pending()
        self.assertEqual("ready", self.shop.order(100, order_id)["items"][0]["status"])
        self.assertEqual([], self.supplier.posts)
        self.supplier.can_purchase = lambda: True
        self.now += 31
        self.shop.process_pending()
        self.assertEqual("completed", self.shop.order(100, order_id)["status"])

    def test_paid_order_does_not_require_old_rub_display_quote_to_stay_fresh(self):
        order_id = self.paid_order()
        self.now += 3700
        self.shop.process_pending()
        self.assertEqual("completed", self.shop.order(100, order_id)["status"])

    def test_unknown_post_recovery_never_repeats_purchase(self):
        order_id = self.paid_order()
        self.supplier.unknown = True
        self.shop.process_pending()
        self.assertEqual("needs_review", self.shop.order(100, order_id)["status"])
        self.now += 61
        self.shop.process_pending()
        self.assertEqual(1, len(self.supplier.posts))
        self.assertEqual("completed", self.shop.order(100, order_id)["status"])

    def test_unknown_without_history_stays_unknown(self):
        order_id = self.paid_order()
        self.supplier.unknown = True
        self.shop.process_pending()
        self.supplier.history.clear()
        for _ in range(3):
            self.now += 61
            self.shop.process_pending()
        self.assertEqual(1, len(self.supplier.posts))
        self.assertEqual("uncertain", self.shop.order(100, order_id)["items"][0]["status"])

    def test_error_review_closed_never_imply_refund(self):
        self.supplier.next_status = "review"
        order_id = self.paid_order()
        self.shop.process_pending()
        for state in ("error", "review", "closed"):
            list(self.supplier.history.values())[0]["status"] = state
            self.now += 61
            self.shop.process_pending()
            line = self.shop.order(100, order_id)["items"][0]
            self.assertEqual("needs_review", line["status"])
            self.assertFalse(line.get("supplier_refunded", False))
        list(self.supplier.history.values())[0]["status"] = "refunded"
        self.now += 61
        self.shop.process_pending()
        line = self.shop.order(100, order_id)["items"][0]
        self.assertEqual("refund_required", line["status"])
        self.assertTrue(line["supplier_refunded"])
        self.assertNotEqual("refunded", self.shop.order(100, order_id)["status"])

    def test_wrong_product_cannot_later_silently_deliver(self):
        self.supplier.next_status = "processing"
        order_id = self.paid_order()
        self.shop.process_pending()
        result = list(self.supplier.history.values())[0]
        result.update(product_id=99, status="completed")
        self.now += 61
        self.shop.process_pending()
        result["product_id"] = 55
        self.now += 61
        self.shop.process_pending()
        line = self.shop.order(100, order_id)["items"][0]
        self.assertEqual("PRODUCT_MISMATCH", line["review_reason"])
        self.assertEqual("needs_review", line["status"])
        self.assertTrue(line["supplier_uuid"])

    def test_unexpected_uuid_never_replaces_canonical_uuid(self):
        self.supplier.next_status = "processing"
        order_id = self.paid_order()
        self.shop.process_pending()
        canonical = self.shop.order(100, order_id)["items"][0]["supplier_uuid"]
        self.supplier.order = lambda value: {"uuid": "99999999-9999-9999-9999-999999999999", "status": "completed"}
        self.now += 61
        self.shop.process_pending()
        item = self.shop.order(100, order_id)["items"][0]
        self.assertEqual(canonical, item["supplier_uuid"])
        self.assertEqual("needs_review", item["status"])

    def test_same_supplier_uuid_never_fulfills_two_paid_lines(self):
        self.supplier.next_status = "processing"
        order1 = self.paid_order()
        self.shop.process_pending()
        canonical = copy.deepcopy(list(self.supplier.history.values())[0])
        order2 = self.paid_order()
        self.supplier.submit = lambda *args, **kwargs: dict(canonical, status="completed", external_order_id=args[3])
        self.shop.process_pending()
        item = self.shop.order(100, order2)["items"][0]
        self.assertEqual("needs_review", item["status"])
        self.assertEqual("DUPLICATE_SUPPLIER_UUID", item["review_reason"])
        self.assertIsNone(item["supplier_uuid"])

    def test_balance_known_not_submitted_retries_then_buys_once(self):
        from aisklad_shop.supplier import NotSubmitted
        order_id = self.paid_order()
        original = self.supplier.submit
        self.supplier.submit = lambda *args, **kwargs: (_ for _ in ()).throw(NotSubmitted("wallet empty", "BALANCE_WAIT"))
        self.shop.process_pending()
        self.assertEqual("ready", self.shop.order(100, order_id)["items"][0]["status"])
        self.assertEqual([], self.supplier.posts)
        self.supplier.submit = original
        self.now += 61
        self.shop.process_pending()
        self.shop.process_pending()
        self.assertEqual("completed", self.shop.order(100, order_id)["status"])
        self.assertEqual(1, len(self.supplier.posts))

    def test_same_cart_cannot_oversell_repeated_key_entries(self):
        group = self.shop.list_products("keys")["items"][0]
        key = self.shop.product(group["id"])["variants"][0]
        for _ in range(5):
            self.shop.add_to_cart(100, key["id"], 1, {"country": "RU"})
        with self.assertRaises(ShopError) as cm:
            self.shop.checkout(100)
        self.assertEqual("INSUFFICIENT_STOCK", cm.exception.code)
        self.assertEqual([], self.payments.invoices)

    def test_order_and_code_strict_owner_guard(self):
        group = self.shop.list_products("keys")["items"][0]
        product = self.shop.product(group["id"])["variants"][0]
        order_id = self.paid_order(product["id"], 1, {"country": "RU"})
        self.shop.process_pending()
        self.assertEqual(["PRIVATE-CODE"], self.shop.order(100, order_id)["delivery"])
        with self.assertRaises(ShopError):
            self.shop.order(101, order_id)
        self.assertEqual([], self.shop.orders(101)["items"])

    def test_favorites_sessions_cart_ownership_and_wal(self):
        item = self.add_stars()["items"][0]
        self.shop.remove_cart(101, item["id"])
        self.assertEqual(1, len(self.shop.cart(100)["items"]))
        self.shop.toggle_favorite(100, self.stars)
        self.assertTrue(self.shop.is_favorite(100, self.stars))
        self.assertFalse(self.shop.is_favorite(101, self.stars))
        self.store.set_session(100, {"stage": "country"})
        self.assertEqual("country", ShopStore(self.store.path).get_session(100)["stage"])
        with self.store.connection() as db:
            self.assertEqual("wal", db.execute("PRAGMA journal_mode").fetchone()[0])

    def test_unsupported_amount_no_global_pause_and_seven_scoped_failures(self):
        for _ in range(10):
            with self.assertRaises(ShopError):
                self.add_stars(49)
        self.assertFalse(self.shop.status()["health_paused"])
        for _ in range(6):
            self.shop._health("testnetwork", False)
        self.assertFalse(self.shop.status()["health_paused"])
        self.shop._health("unrelated", True)
        self.shop._health("testnetwork", False)
        self.assertTrue(self.shop.status()["health_paused"])
        self.shop.reset_health()
        self.assertFalse(self.shop.status()["health_paused"])

    def test_help_dedup_preserves_followup_detail_and_private_owner_event(self):
        a = self.shop.request_help(100, "Нужна помощь")
        b = self.shop.request_help(100, "Заказ задержался, уточнение")
        self.assertEqual(a["ticket_id"], b["ticket_id"])
        with self.store.connection() as db:
            self.assertIn("уточнение", db.execute("SELECT message FROM support").fetchone()[0])
        owner = [e for e in self.shop.pending_notifications() if e["user_id"] == 777]
        self.assertTrue(all(e["kind"].startswith("owner:") for e in owner))

    def test_supplier_images_do_not_expose_signed_urls_or_private_hosts(self):
        self.assertIsNotNone(safe_image("https://shared.steamstatic.com/apps/1/header.jpg"))
        for url in ("http://steam.ru/icon.png", "https://127.0.0.1/x", "https://steam.ru.evil.example/x", "https://steam.ru/x?token=secret", "https://user:pass@steam.ru/x"):
            self.assertIsNone(safe_image(url))


class SupplierContractTests(unittest.TestCase):
    def test_paginated_index_includes_every_page(self):
        class Client:
            def request(self, method, endpoint, params=None, **kwargs):
                page = params["page"]
                return {"games": [{"app_id": page}], "page": page, "total_pages": 3}
        self.assertEqual([1, 2, 3], [r["app_id"] for r in SteamSupplier(Client()).keys()])

    def test_repeated_page_aborts_instead_of_claiming_complete(self):
        class Client:
            def request(self, method, endpoint, params=None, **kwargs):
                return {"games": [{"app_id": 1}], "total_pages": 3}
        with self.assertRaises(RuntimeError):
            list(SteamSupplier(Client()).keys())

    def test_recovery_reads_later_order_pages_using_uuid_identity(self):
        class Client:
            def request(self, method, endpoint, params=None, **kwargs):
                if method != "GET":
                    raise AssertionError("unexpected purchase")
                page = params["page"]
                return {"orders": [{"uuid": str(page) + "-" + str(i), "external_order_id": "target" if page == 2 and i == 99 else "other"} for i in range(100)], "page": page, "total_pages": 2, "total": 200}
        recovered = SteamSupplier(Client(), min_get_interval=0).recover("target")
        self.assertEqual("2-99", recovered["uuid"])

    def test_incomplete_total_rejected(self):
        class Client:
            def request(self, *args, **kwargs):
                return {"games": [{"app_id": 1}], "page": 1, "total_pages": 1, "total": 2}
        with self.assertRaises(RuntimeError):
            list(SteamSupplier(Client(), min_get_interval=0).keys())

    def test_get_only_retries_throttle_with_bounded_retry_after(self):
        from plugins.steamru_stars_engine import ApiFailure
        class Client:
            def __init__(self): self.calls = 0
            def request(self, method, endpoint, **kwargs):
                self.calls += 1
                if self.calls < 3:
                    raise ApiFailure("api.error", "test", 429, "1")
                return {"balance": 5}
        clock = [0]
        supplier = SteamSupplier(Client(), min_get_interval=0, clock=lambda: clock[0], sleep=lambda n: clock.__setitem__(0, clock[0] + n))
        self.assertEqual(Decimal(5), supplier.balance())
        self.assertEqual(3, supplier.client.calls)
        self.assertEqual(2, clock[0])

    def test_supplier_payloads_are_exact_and_keep_account_in_fields(self):
        class Client:
            def __init__(self): self.posts = []
            def request(self, method, endpoint, **kwargs):
                self.posts.append((method, endpoint, kwargs))
                return {"uuid": "test"}
        client = Client()
        supplier = SteamSupplier(client)
        supplier.submit({"kind": "topup", "service": "ml", "supplier_product_id": 9, "fields": [{"name": "player_id", "is_account": True}, {"name": "server"}]}, 1, {"player_id": "123", "server": "EU"}, "aisklad-test")
        payload = client.posts[-1][2]["payload"]
        self.assertEqual({"player_id": "123", "server": "EU"}, payload["fields"])
        self.assertNotIn("account", payload)
        supplier.submit({"kind": "gift", "app_id": 88, "edition": "deluxe", "region": "CIS"}, 1, {"invite_url": "https://s.team/p/abc"}, "aisklad-test2")
        self.assertEqual("deluxe", client.posts[-1][2]["payload"]["edition"])
        self.assertEqual("/orders/game-gift", client.posts[-1][1])


if __name__ == "__main__":
    unittest.main()
