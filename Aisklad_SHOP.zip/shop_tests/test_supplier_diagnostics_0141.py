import json
import unittest
from unittest.mock import Mock

from plugins.steamru_stars_engine import SteamClient,ApiFailure,api_failure_diagnostic


class SupplierDiagnosticTests(unittest.TestCase):
    def client(self,status=401,code='unknown'):
        response=Mock(status_code=status,headers={})
        response.json.return_value={'ok':False,'error':{'code':code,'message':'PRIVATE_API_SECRET private login','details':{'api_key':'PRIVATE_API_KEY'}}}
        session=Mock();session.request.return_value=response
        return SteamClient(' PRIVATE_API_KEY ',' PRIVATE_API_SECRET ',session=session),session

    def test_http_error_identifies_access_failure_without_echoing_supplier_values(self):
        for status,reason in ((401,'authentication'),(403,'permission'),(404,'endpoint'),(429,'rate_limit'),(503,'server')):
            with self.subTest(status=status):
                client,session=self.client(status)
                with self.assertRaises(ApiFailure) as ctx:
                    client.request('GET','/check/steam-account',params={'account':'PRIVATE_ACCOUNT'})
                error=ctx.exception;diag=error.diagnostic()
                self.assertEqual(diag['http_status'],status);self.assertEqual(diag['reason'],reason)
                self.assertEqual(diag['endpoint'],'/check/steam-account')
                text=str(error)+json.dumps(diag)
                for private in ('PRIVATE_API_KEY','PRIVATE_API_SECRET','PRIVATE_ACCOUNT','private login'):
                    self.assertNotIn(private,text)
                self.assertIn('HTTP '+str(status),str(error))

    def test_known_signature_and_clock_errors_produce_static_actions(self):
        for code,reason in (('invalid_signature','signature'),('timestamp_expired','clock'),('nonce_reused','nonce')):
            client,_=self.client(401,code)
            with self.assertRaises(ApiFailure) as ctx:client.account()
            self.assertEqual(ctx.exception.diagnostic()['reason'],reason)

    def test_credential_whitespace_trimmed_before_hmac_and_header(self):
        client,session=self.client()
        with self.assertRaises(ApiFailure):client.account()
        self.assertEqual(client.secret,'PRIVATE_API_SECRET')
        self.assertEqual(session.request.call_args.kwargs['headers']['X-Reseller-Key'],'PRIVATE_API_KEY')

    def test_nested_diagnostic_follows_cause_without_unknown_exception_text(self):
        inner=ApiFailure('api.error','local message',401,method='GET',endpoint='/account')
        outer=RuntimeError('PRIVATE_SECRET');outer.__cause__=inner
        self.assertEqual(api_failure_diagnostic(outer)['http_status'],401)
        self.assertEqual(api_failure_diagnostic(ValueError('PRIVATE_SECRET')),{})


if __name__=='__main__':unittest.main()
