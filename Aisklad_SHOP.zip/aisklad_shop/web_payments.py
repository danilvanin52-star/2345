"""Authenticated outbound bridge to the independently deployed Aisklad website.

The website checks its payment provider. The bot accepts only a signed, immutable
invoice-bound event; redirects and buyer claims never authorize purchases.
No supplier request is made by this module. Disabled mode still reconciles old
invoices, while refusing new checkouts. HTTP transport is injectable for tests.
"""
from __future__ import annotations
import hashlib
import hmac
import ipaddress
import json
import re
import threading
import time
import uuid
import socket
import ssl
from dataclasses import fields as dataclass_fields
from decimal import Decimal, InvalidOperation
from urllib.parse import quote, urlencode, urlsplit, parse_qs
from .payments import PaymentUnavailable, VerifiedPaymentEvent, validate_event
from .store import dumps


DIAGNOSTICS = {
    "BRIDGE_NOT_CHECKED": (True, "Связь с сайтом ещё проверяется.", "Дождись фоновой проверки или открой диагностику владельца."),
    "BRIDGE_OK": (True, "Связь с сайтом восстановлена.", "Можно открыть сохранённый заказ."),
    "BRIDGE_TLS_ERROR": (True, "Не удалось установить защищённое соединение с сайтом.", "Проверь доступность HTTPS-домена оплаты с Bothost, сертификат и правила Cloudflare. Ключ STEAM.RU к этой ошибке не относится."),
    "BRIDGE_TIMEOUT": (True, "Сайт не ответил вовремя. Заказ сохранён.", "Проверь доступность сайта; повторяется регистрация того же счёта, новый заказ не создаётся."),
    "BRIDGE_DNS_ERROR": (True, "Сервер не смог определить адрес сайта оплаты.", "Проверь DNS домена оплаты и доступность адреса из Bothost."),
    "BRIDGE_CONNECTION_ERROR": (True, "Соединение с сайтом оплаты пока недоступно.", "Проверь доступность HTTPS-домена с Bothost и сетевые ограничения. Данные заказа сохранены."),
    "BRIDGE_AUTH_ERROR": (False, "Сайт пока не разрешил подключение магазина.", "Сверь отдельный секрет моста на Bothost и Cloudflare. Не отправляй значения в чат."),
    "BRIDGE_CLOCK_SKEW": (False, "Время серверов не совпало для проверки запроса.", "Проверь системное время сервера Bothost; подпись требует расхождения не более 5 минут."),
    "BRIDGE_AUTH_TIMESTAMP": (False, "Не подтверждён формат времени запроса.", "Обнови обе части платёжного моста и проверь системное время Bothost."),
    "BRIDGE_AUTH_NONCE": (False, "Не подтверждён идентификатор запроса.", "Обнови обе части платёжного моста; постоянный nonce использовать нельзя."),
    "BRIDGE_REPLAY": (True, "Сайт уже видел этот запрос. Повторная покупка не создавалась.", "Будет выполнена повторная сверка с новым идентификатором запроса и тем же номером счёта."),
    "BRIDGE_HTTP_FORBIDDEN": (False, "Доступ сервера к сайту оплаты ограничен.", "Проверь маршрутизацию и правила Cloudflare/WAF для API. Не обходи проверку подписи моста."),
    "BRIDGE_ROUTE_NOT_FOUND": (False, "На сайте не найдена нужная версия платёжного моста.", "Проверь адрес API, доменный маршрут и публикацию нового Worker с /api/shop/bridge/."),
    "BRIDGE_RATE_LIMIT": (True, "Сайт попросил уменьшить частоту запросов.", "Дождись следующей попытки; частые нажатия не ускоряют проверку."),
    "BRIDGE_REMOTE_ERROR": (True, "Сайт оплаты временно вернул ошибку.", "Проверь состояние Worker и базы данных Cloudflare. Заказ остаётся сохранённым."),
    "BRIDGE_REMOTE_CONFIG": (False, "На сайте не завершена настройка моста.", "Проверь SHOP_BRIDGE_SECRET и настройки Worker; не публикуй значения секретов."),
    "BRIDGE_REMOTE_DATABASE": (False, "Сайт не подтвердил доступ к базе заказов.", "Проверь привязку D1 DB и результат создания таблиц в Worker."),
    "BRIDGE_REMOTE_DATABASE_UNAVAILABLE": (True, "База заказов на сайте временно недоступна.", "Проверь состояние D1 и логи Worker без секретных данных."),
    "BRIDGE_REMOTE_DISABLED": (False, "Создание новых счетов отключено на сайте.", "Проверь SHOP_PAYMENTS_MODE в Worker и AISKLAD_WEB_PAYMENTS_MODE на Bothost; для реальных продаж оба должны быть live."),
    "BRIDGE_MODE_MISMATCH": (False, "Режим созданного счёта отличается от режима магазина.", "Сверь test/live в обеих частях. Старый тестовый счёт не становится реальным: новый создаётся только явным оформлением из корзины."),
    "BRIDGE_ORIGIN_MISMATCH": (False, "Не подтверждён адрес личной страницы заказа.", "Сверь AISKLAD_WEB_PAYMENTS_URL и SHOP_PUBLIC_BASE_URL с опубликованным HTTPS-маршрутом. Произвольные ссылки не разрешаются."),
    "BRIDGE_INVOICE_CONFLICT": (False, "Сайт хранит другой снимок этого счёта.", "Нельзя менять сумму или товары старого счёта. Сохрани историю и проверь соответствие версий магазина и Worker."),
    "BRIDGE_INVOICE_EXPIRED": (False, "Срок создания этого счёта закончился.", "Можно проверить, был ли старый счёт зарегистрирован. Для нового счёта явно открой корзину; старые платёжные подтверждения сохраняются."),
    "BRIDGE_INVOICE_INVALID": (False, "Сайт не принял параметры счёта.", "Проверь совместимость версий, ограничения суммы и состав позиций. Не меняй сохранённый платёжный снимок."),
    "BRIDGE_PAYLOAD_TOO_LARGE": (False, "Размер запроса или ответа сайта превышен.", "Проверь размер корзины и совместимость версий моста."),
    "BRIDGE_BAD_RESPONSE": (True, "Сайт вернул неподтверждённый формат ответа.", "Проверь, что API возвращает JSON, а не страницу входа, защиты Cloudflare или HTML-ошибку."),
    "BRIDGE_REDIRECT": (False, "Адрес API перенаправляет запрос на другую страницу.", "Укажи конечный HTTPS-адрес API с опубликованным маршрутом. Автоматические перенаправления с подписью запрещены."),
    "BRIDGE_HTTP_ERROR": (False, "Сайт не подтвердил запрос магазина.", "Проверь код HTTP в диагностике и настройки опубликованного Worker."),
    "BRIDGE_PROTOCOL_ERROR": (False, "Не удалось подтвердить данные платёжного моста.", "Сверь версии магазина и Worker; сохранённые счёт и история не заменяются."),
}

REMOTE_CODES = {
    "shop_bridge_unauthorized": "BRIDGE_AUTH_ERROR", "shop_bridge_signature_invalid": "BRIDGE_AUTH_ERROR",
    "shop_bridge_timestamp_invalid": "BRIDGE_AUTH_TIMESTAMP", "shop_bridge_time_skew": "BRIDGE_CLOCK_SKEW",
    "shop_bridge_nonce_invalid": "BRIDGE_AUTH_NONCE", "shop_bridge_replay": "BRIDGE_REPLAY",
    "shop_bridge_not_configured": "BRIDGE_REMOTE_CONFIG", "shop_route_not_found": "BRIDGE_ROUTE_NOT_FOUND",
    "shop_database_missing": "BRIDGE_REMOTE_DATABASE", "shop_database_binding_invalid": "BRIDGE_REMOTE_DATABASE",
    "shop_database_schema_failed": "BRIDGE_REMOTE_DATABASE", "shop_database_unavailable": "BRIDGE_REMOTE_DATABASE_UNAVAILABLE",
    "shop_payments_disabled": "BRIDGE_REMOTE_DISABLED", "shop_mode_invalid": "BRIDGE_MODE_MISMATCH",
    "shop_public_url_invalid": "BRIDGE_ORIGIN_MISMATCH", "shop_invoice_conflict": "BRIDGE_INVOICE_CONFLICT",
    "shop_invoice_expired": "BRIDGE_INVOICE_EXPIRED", "shop_payload_too_large": "BRIDGE_PAYLOAD_TOO_LARGE",
    "shop_invoice_invalid": "BRIDGE_INVOICE_INVALID", "shop_items_invalid": "BRIDGE_INVOICE_INVALID",
    "shop_fields_invalid": "BRIDGE_INVOICE_INVALID", "shop_activation_invalid": "BRIDGE_INVOICE_INVALID",
    "shop_duplicate_line_id": "BRIDGE_INVOICE_INVALID", "shop_items_total_mismatch": "BRIDGE_INVOICE_INVALID",
    "shop_amount_invalid": "BRIDGE_INVOICE_INVALID", "shop_bad_json": "BRIDGE_INVOICE_INVALID",
    "shop_bad_encoding": "BRIDGE_INVOICE_INVALID", "shop_internal_error": "BRIDGE_REMOTE_ERROR",
}


class WebPaymentError(RuntimeError):
    """Structured safe diagnostics; exception text never contains response bodies."""
    def __init__(self, message=None, *, code="BRIDGE_PROTOCOL_ERROR", status=None, retry_after=None, retryable=None):
        self.code = code if code in DIAGNOSTICS else "BRIDGE_PROTOCOL_ERROR"
        self.status = status if type(status) is int and 100 <= status <= 599 else None
        self.retryable = DIAGNOSTICS[self.code][0] if retryable is None else bool(retryable)
        self.retry_after = min(3600, max(0, int(retry_after))) if type(retry_after) in (int, float) and 0 <= retry_after < float("inf") else None
        self.buyer_message, self.action = DIAGNOSTICS[self.code][1:]
        super().__init__(self.buyer_message)

    def diagnostic(self):
        return {"code": self.code, "http_status": self.status, "retryable": self.retryable,
                "retry_after": self.retry_after, "buyer_message": self.buyer_message, "action": self.action}


def safe_diagnostic(error):
    if isinstance(error, WebPaymentError):
        return error.diagnostic()
    return WebPaymentError(code="BRIDGE_PROTOCOL_ERROR").diagnostic()


def _network_error(exc):
    chain, seen = [exc], set()
    while chain:
        item = chain.pop()
        if id(item) in seen:
            continue
        seen.add(id(item))
        name = type(item).__name__.lower()
        if isinstance(item, ssl.SSLError) or "ssl" in name or "tls" in name:
            return WebPaymentError(code="BRIDGE_TLS_ERROR")
        if isinstance(item, (TimeoutError, socket.timeout)) or "timeout" in name:
            return WebPaymentError(code="BRIDGE_TIMEOUT")
        if isinstance(item, socket.gaierror) or "nameresolution" in name or "gaierror" in name:
            return WebPaymentError(code="BRIDGE_DNS_ERROR")
        chain.extend(v for v in (getattr(item, "__cause__", None), getattr(item, "__context__", None), getattr(item, "reason", None)) if isinstance(v, BaseException))
        chain.extend(v for v in getattr(item, "args", ()) if isinstance(v, BaseException))
    return WebPaymentError(code="BRIDGE_CONNECTION_ERROR")


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON field")
        result[key] = value
    return result


def _amount(value):
    if isinstance(value, float) or isinstance(value, bool):
        raise ValueError("Payment amounts must be decimal strings")
    number = Decimal(str(value))
    if not number.is_finite() or number <= 0 or number != number.quantize(Decimal(".01")):
        raise ValueError("Invalid payment amount")
    result = format(number, ".2f")
    if not re.fullmatch(r"[0-9]{1,12}\.[0-9]{2}", result):
        raise ValueError("Invalid payment amount")
    return result


def _origin(url):
    parsed = urlsplit(str(url))
    host = parsed.hostname or ""
    if parsed.scheme != "https" or not host or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError("Only a public HTTPS website is accepted")
    if host.lower() == "localhost" or host.lower().endswith((".localhost", ".local", ".internal")):
        raise ValueError("Private website origins are not accepted")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ValueError("Private website origins are not accepted")
    return "https://" + host.lower()


class WebEventVerifier:
    def __init__(self, secret):
        self.secret = secret.encode("utf-8")

    def verify(self, raw_body, headers):
        if not isinstance(raw_body, bytes) or len(raw_body) > 1024 * 1024:
            raise ValueError("Invalid event body")
        signature = headers.get("X-Shop-Event-Signature", "")
        expected = hmac.new(self.secret, b"event\n" + raw_body, hashlib.sha256).hexdigest()
        if not isinstance(signature, str) or not re.fullmatch(r"[a-fA-F0-9]{64}", signature) or not hmac.compare_digest(expected, signature.lower()):
            raise ValueError("Invalid event authentication")
        payload = json.loads(raw_body.decode("utf-8"), object_pairs_hook=_object)
        allowed = {field.name for field in dataclass_fields(VerifiedPaymentEvent)}
        if not isinstance(payload, dict) or set(payload) != allowed:
            raise ValueError("Unexpected payment event fields")
        for key in allowed - {"user_id", "test"}:
            if not isinstance(payload[key], str) or not 1 <= len(payload[key]) <= 200:
                raise ValueError("Invalid payment event field")
        if type(payload["user_id"]) is not int or payload["user_id"] <= 0 or type(payload["test"]) is not bool:
            raise ValueError("Invalid payment recipient or mode")
        if payload["provider"] != "aisklad_web" or payload["currency"] != "RUB" or payload["amount"] != _amount(payload["amount"]):
            raise ValueError("Unexpected payment provider or amount")
        if payload["invoice_id"] != "shop:" + payload["order_id"]:
            raise ValueError("Unexpected invoice identity")
        return validate_event(VerifiedPaymentEvent(**payload))


class WebPayments:
    provider = "aisklad_web"
    currency = "RUB"
    external_payment = True
    reason = "Внешняя оплата на сайте Aisklad. Вход в аккаунт сайта для счёта не нужен."

    def __init__(self, base_url, secret, mode="test", session=None, clock=time.time, nonce_factory=None, timeout=15):
        parsed = urlsplit(str(base_url))
        self.base_url = _origin(base_url)
        if parsed.path not in ("", "/") or parsed.query or parsed.fragment:
            raise ValueError("Bridge base URL must contain only the website origin")
        if not isinstance(secret, str) or len(secret) < 32 or "\n" in secret:
            raise ValueError("Use a separate bridge secret of at least 32 characters")
        if mode not in ("disabled", "test", "live"):
            raise ValueError("Payment mode must be disabled, test or live")
        if session is None:
            import requests
            session = requests.Session()
        self.session, self.secret, self.mode = session, secret.encode("utf-8"), mode
        self.enabled = mode in ("test", "live")
        self.clock, self.nonce_factory = clock, nonce_factory or (lambda: uuid.uuid4().hex)
        self.timeout = min(30, max(1, float(timeout)))
        self.verifier = WebEventVerifier(secret)
        self._sync_lock = threading.Lock()

    def _read_body(self, response, limit=1024 * 1024, truncate=False):
        chunks, total = [], 0
        iterator = response.iter_content(chunk_size=16384) if hasattr(response, "iter_content") else [response.content]
        for chunk in iterator:
            if not chunk:
                continue
            total += len(chunk); chunks.append(chunk)
            if total > limit:
                if truncate:
                    return b"".join(chunks)[:limit]
                raise WebPaymentError(code="BRIDGE_PAYLOAD_TOO_LARGE", status=response.status_code)
        return b"".join(chunks)

    def _http_error(self, response):
        status = response.status_code
        code = None
        try:
            document = json.loads(self._read_body(response, 32768, truncate=True).decode("utf-8"), object_pairs_hook=_object)
            candidate = (document.get("error") or {}).get("code") if isinstance(document, dict) else None
            code = REMOTE_CODES.get(candidate) if isinstance(candidate, str) else None
        except (ValueError, TypeError, AttributeError, UnicodeDecodeError):
            pass
        if code is None:
            if 300 <= status < 400: code = "BRIDGE_REDIRECT"
            elif status in (401, 403): code = "BRIDGE_HTTP_FORBIDDEN"
            elif status == 404: code = "BRIDGE_ROUTE_NOT_FOUND"
            elif status == 429: code = "BRIDGE_RATE_LIMIT"
            elif status >= 500: code = "BRIDGE_REMOTE_ERROR"
            elif status == 413: code = "BRIDGE_PAYLOAD_TOO_LARGE"
            else: code = "BRIDGE_HTTP_ERROR"
        retry_after = None
        try:
            value = getattr(response, "headers", {}).get("Retry-After")
            if value:
                try: retry_after = min(3600, max(0, float(value)))
                except ValueError:
                    from email.utils import parsedate_to_datetime
                    retry_after = min(3600, max(0, parsedate_to_datetime(value).timestamp() - self.clock()))
        except (ValueError, TypeError, OverflowError):
            pass
        return WebPaymentError(code=code, status=status, retry_after=retry_after)

    def _request(self, method, path, payload=None):
        if not path.startswith("/api/shop/bridge/") or "#" in path or ".." in path or "\\" in path:
            raise WebPaymentError(code="BRIDGE_ROUTE_NOT_FOUND")
        raw = dumps(payload).encode("utf-8") if payload is not None else b""
        if len(raw) > 1024 * 1024:
            raise WebPaymentError(code="BRIDGE_PAYLOAD_TOO_LARGE")
        stamp, nonce = str(int(self.clock())), str(self.nonce_factory())
        material = "\n".join((stamp, nonce, method, path, hashlib.sha256(raw).hexdigest())).encode("utf-8")
        headers = {"X-Shop-Timestamp": stamp, "X-Shop-Nonce": nonce,
                   "X-Shop-Signature": hmac.new(self.secret, material, hashlib.sha256).hexdigest(),
                   "Accept": "application/json"}
        if payload is not None:
            headers["Content-Type"] = "application/json"
        response = None
        try:
            response = self.session.request(method, self.base_url + path, data=raw or None, headers=headers,
                                            timeout=self.timeout, allow_redirects=False, stream=True)
            if not 200 <= response.status_code < 300:
                raise self._http_error(response)
            try:
                document = json.loads(self._read_body(response).decode("utf-8"), object_pairs_hook=_object)
                if not isinstance(document, dict):
                    raise ValueError("Expected JSON object")
            except (ValueError, UnicodeDecodeError):
                raise WebPaymentError(code="BRIDGE_BAD_RESPONSE", status=response.status_code) from None
            return document
        except WebPaymentError:
            raise
        except Exception as exc:
            raise _network_error(exc) from None
        finally:
            if response is not None and hasattr(response, "close"):
                response.close()

    def _registered(self, request, result, expected_mode):
        if result.get("mode") != expected_mode:
            raise WebPaymentError(code="BRIDGE_MODE_MISMATCH", status=200)
        if result.get("invoice_id") != "shop:" + request["order_id"]:
            raise WebPaymentError(code="BRIDGE_INVOICE_CONFLICT", status=200)
        try:
            payment_url = result["payment_url"]
            parsed = urlsplit(payment_url)
            query, fragment = parse_qs(parsed.query), parse_qs(parsed.fragment)
            valid = (self.validate_checkout_url(payment_url) and
                     query.get("order_id") == [request["order_id"]] and len(fragment.get("token", [])) == 1 and
                     16 <= len(fragment["token"][0]) <= 1024)
            expiry = result["expires_at"]
            valid = valid and type(expiry) in (int, float) and float(expiry) == float(request["expires_at"])
            if not valid:
                raise ValueError("Untrusted checkout link")
        except (KeyError, ValueError, TypeError):
            raise WebPaymentError(code="BRIDGE_ORIGIN_MISMATCH", status=200) from None
        return {"invoice_id": result["invoice_id"], "payment_url": payment_url, "expires_at": expiry,
                "mode": expected_mode, "external_payment": True}

    def validate_checkout_url(self, url):
        try:
            parsed = urlsplit(url)
            query, fragment = parse_qs(parsed.query), parse_qs(parsed.fragment)
            return bool(_origin(url) == self.base_url and parsed.path == "/shop/checkout" and
                        set(query) == {"order_id"} and len(query["order_id"]) == 1 and
                        re.fullmatch(r"[A-Za-z0-9_-]{1,100}", query["order_id"][0]) and
                        set(fragment) == {"token"} and len(fragment["token"]) == 1 and 16 <= len(fragment["token"][0]) <= 1024)
        except (TypeError, ValueError, KeyError):
            return False

    def create_invoice(self, order_id, amount, currency, user_id, items, created_at, expires_at):
        if not self.enabled:
            raise PaymentUnavailable("Новые внешние счета отключены.")
        request = self._invoice_request(order_id, amount, currency, user_id, items, created_at, expires_at)
        return self._registered(request, self._request("POST", "/api/shop/bridge/invoices", request), self.mode)

    def _invoice_request(self, order_id, amount, currency, user_id, items, created_at, expires_at):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", str(order_id)) or type(user_id) is not int or user_id <= 0 or currency != "RUB":
            raise ValueError("Invalid invoice identity")
        if type(created_at) not in (int, float) or type(expires_at) not in (int, float) or not 0 < expires_at - created_at <= 86400:
            raise ValueError("Invalid invoice lifetime")
        amount = _amount(amount)
        if not isinstance(items, list) or not 1 <= len(items) <= 20:
            raise ValueError("Invalid invoice items")
        if sum((Decimal(_amount(item["total_rub"])) for item in items), Decimal(0)) != Decimal(amount):
            raise ValueError("Invoice lines do not match the total")
        return {"order_id": str(order_id), "amount": amount, "currency": currency, "user_id": user_id,
                "items": items, "created_at": created_at, "expires_at": expires_at}

    def recover_invoice(self, request, expected_mode):
        """Same immutable registration, never a fresh invoice/id after a timeout."""
        request = self._invoice_request(**request)
        if expected_mode not in ("test", "live"):
            raise WebPaymentError("Неизвестен исходный режим счёта.")
        return self._registered(request, self._request("POST", "/api/shop/bridge/invoices", request), expected_mode)

    def poll_events(self, limit=50):
        result = self._request("GET", "/api/shop/bridge/payments?" + urlencode({"limit": min(50, max(1, int(limit)))}))
        if not isinstance(result.get("events"), list) or len(result["events"]) > 50:
            raise WebPaymentError("Некорректная очередь платёжных событий.")
        return result["events"]

    def health_check(self):
        """Read-only authenticated diagnostics with a bounded public schema."""
        result = self._request("GET", "/api/shop/bridge/health")
        if result.get("ok") is not True or result.get("expected_mode") not in ("disabled", "test", "live"):
            raise WebPaymentError(code="BRIDGE_BAD_RESPONSE", status=200)
        configured = result.get("configured") or {}; database = result.get("database") or {}; providers = result.get("providers") or {}
        if not all(isinstance(value, dict) for value in (configured, database, providers)) or not isinstance(result.get("issues", []), list) or any(not isinstance(providers.get(name, {}), dict) for name in ("robokassa", "yookassa")):
            raise WebPaymentError(code="BRIDGE_BAD_RESPONSE", status=200)
        safe = {"ok": True, "version": str(result.get("version", ""))[:30] if re.fullmatch(r"[0-9.\-a-z]{1,30}", str(result.get("version", ""))) else "unknown",
                "expected_mode": result["expected_mode"], "unix_time": result.get("unix_time") if type(result.get("unix_time")) in (int, float) else None,
                "configured": {key: configured.get(key) is True for key in ("bridge_secret", "database_binding", "public_url")},
                "database": {"ready": database.get("ready") is True}, "payments_ready": result.get("payments_ready") is True,
                "providers": {name: {key: (providers.get(name) or {}).get(key) is True for key in ("test_ready", "live_ready", "active_ready")} for name in ("robokassa", "yookassa")},
                "issues": [value for value in (result.get("issues") or []) if value in REMOTE_CODES]}
        return safe

    def ack_event(self, event_id):
        if not isinstance(event_id, str) or not 1 <= len(event_id) <= 200:
            raise ValueError("Invalid event identity")
        result = self._request("POST", "/api/shop/bridge/payments/" + quote(event_id, safe="") + "/ack", {})
        if result.get("ok") is not True:
            raise WebPaymentError("Сайт не подтвердил приём события.")

    def _delivery(self, order, revision):
        return {"order_id": order["id"], "status": order["status"], "revision": int(revision),
                "items": [{"id": line["id"], "title": line["title"], "quantity": line["quantity"],
                           "fields": line.get("fields", {}), "status": line["status"],
                           "delivery": list(line.get("delivery", [])) if line["status"] == "completed" else [],
                           "activation": list(line.get("activation", []))} for line in order["items"]]}

    def _publish_payload(self, payload):
        result = self._request("POST", "/api/shop/bridge/delivery", payload)
        if result.get("ok") is not True or result.get("revision") != payload["revision"]:
            raise WebPaymentError("Сайт не подтвердил состояние выдачи.")
        return result

    def publish_order(self, order, revision):
        return self._publish_payload(self._delivery(order, revision))

    def synchronize(self, service):
        """At-least-once inbox + durable monotonic delivery outbox. No purchases."""
        if not self._sync_lock.acquire(blocking=False):
            return {"state": "busy", "accepted": 0, "published": 0}
        accepted, published, failed, failure = 0, 0, 0, None
        try:
            registration = service.retry_pending_invoices(limit=20)
            failed += registration.get("failed", 0)
            try:
                envelopes = self.poll_events()
            except Exception as error:
                service.record_payment_diagnostic(error, next_retry=self.clock() + max(15, getattr(error, "retry_after", None) or 0))
                raise
            for envelope in envelopes:
                try:
                    raw = envelope["raw"].encode("utf-8")
                    headers = {"X-Shop-Event-Signature": envelope["signature"]}
                    verified = self.verifier.verify(raw, headers)
                    # envelope.payload is display-only; only signed raw is trusted.
                    service.handle_payment(raw, headers)
                    self.ack_event(verified.event_id)  # strictly after SQLite commit
                    service.store.set_setting("bridge:last_ack", {"event_id": verified.event_id, "at": self.clock()})
                    accepted += 1
                except Exception as error:
                    failed += 1  # No ack: authenticated retry/recovery remains possible.
                    failure = error
            with service.store.connection() as db:
                rows = db.execute("SELECT id,status FROM orders WHERE json_valid(value) AND json_extract(value,'$.payment_provider')=? AND json_extract(value,'$.payment_mode')='live' AND status NOT IN ('invoice_creating','invoice_review','awaiting_payment') ORDER BY created_at", (self.provider,)).fetchall()
            for row in rows:
                key = "bridge:delivery:" + row["id"]
                state = service.store.get_setting(key, {"revision": 0})
                if row["status"] in ("completed", "test_paid") and state.get("published_status") == row["status"] and not state.get("pending"):
                    continue  # Do not reopen every delivered historical line on every poll.
                order = service.store.order_data(row["id"])
                if order.get("payment_provider") != self.provider or order.get("payment_mode") != "live" or order["status"] in ("invoice_creating", "invoice_review", "awaiting_payment", "test_paid"):
                    continue
                pending = state.get("pending")
                if not pending:
                    content = self._delivery(order, 0)
                    digest = hashlib.sha256(dumps(content).encode()).hexdigest()
                    if state.get("published_hash") == digest:
                        continue
                    pending = self._delivery(order, int(state.get("revision", 0)) + 1)
                    state.update(revision=pending["revision"], pending=pending, pending_hash=digest)
                    service.store.set_setting(key, state)  # durable before HTTP
                try:
                    self._publish_payload(pending)
                    state.update(published_hash=state.pop("pending_hash"), published_at=self.clock(), published_status=pending["status"])
                    state.pop("pending", None)
                    service.store.set_setting(key, state)
                    published += 1
                except Exception as error:
                    failed += 1
                    failure = error
            if failure is not None:
                service.record_payment_diagnostic(failure, next_retry=self.clock() + max(15, getattr(failure, "retry_after", None) or 0))
            elif not failed:
                # A healthy poll must not erase a stored blocked invoice diagnosis.
                with service.store.connection() as db:
                    pending = db.execute("SELECT 1 FROM orders WHERE status IN ('invoice_creating','invoice_review') LIMIT 1").fetchone()
                if not pending:
                    service.record_payment_diagnostic()
            service.store.set_setting("bridge:last_sync", {"at": self.clock(), "accepted": accepted, "published": published, "failed": failed})
            return {"state": "ok" if not failed else "retry", "accepted": accepted, "published": published, "failed": failed}
        finally:
            self._sync_lock.release()
