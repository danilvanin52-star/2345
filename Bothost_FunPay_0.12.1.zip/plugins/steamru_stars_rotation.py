# noplug — safe reuse of existing game-key slots, without supplier purchases.
"""Keep historic SKU bindings and drain paid orders before editing an offer."""
import json,time
from steamru_stars_engine import D
import steamru_stars_catalog as catalog
import steamru_stars_activity as activity

class RotationDeferred(ValueError):
    pass

def jobs(bot):
    return json.loads(bot.STORE.get_meta('rotation_jobs','[]'))

def busy_offers(bot):
    return {int(x['offer']) for x in jobs(bot) if x['stage']!='done'}

def put(bot,items):
    bot.STORE.set_meta('rotation_jobs',json.dumps(items,ensure_ascii=False))

def busy_rules(bot,c):
    names={r['description'][5:] for r in bot.STORE.rows(
        ('awaiting_username','ready','preparing','submitting','supplier_pending','uncertain','needs_review'),limit=10000)
        if r.get('kind')=='game_key' and r['description'].startswith('rule:')}
    result=c.account.get_sales(include_paid=True,include_closed=False,include_refunded=False,state='paid',section='lot-1008')
    if not isinstance(result,tuple) or len(result)<2 or not isinstance(result[1],list) or result[0]:
        raise RotationDeferred('Нельзя подтвердить полный список незавершённых заказов')
    for shortcut in result[1]:
        full=c.account.get_order(shortcut.id)
        matched=[name for name,rule in bot.CFG['lot_rules'].items() if rule.get('kind')=='game_key'
                 and all(catalog.field_matches(bot.order_field_value(full,k),k,rule) for k in rule['match_fields'])]
        if len(matched)!=1:raise RotationDeferred('Незавершённый заказ требует проверки привязки')
        names.add(matched[0])
    return names

def matches(bot,fields,rule):
    return all(catalog.field_matches(bot.editor_field_value(fields,k),k,rule) for k in rule['match_fields'])

def apply_existing(fields,rule,price):
    data=catalog.apply_rule(fields.fields,rule,price)
    fields.edit_fields(data)
    fields.title_ru=data['fields[summary][ru]'];fields.title_en=data['fields[summary][en]']
    catalog.update_copy(fields,rule)
    fields.price=float(price);fields.amount=1;fields.active=False;fields.auto_delivery=False
    fields.secrets=[];fields.images=[]
    return fields.renew_fields()

def commit(bot,item):
    old=bot.CFG['lot_rules'][item['old_name']]
    old['history']=True;old['sell_enabled']=False
    new=bot.CFG['lot_rules'].get(item['new_name']) or item['rule']
    new.update(history=False,sell_enabled=True,last_price_usd=item['rule']['last_price_usd'],
               description_revision=catalog.COPY_REVISION,last_listed_at=time.time())
    bot.CFG['lot_rules'][item['new_name']]=new
    bot.CFG['managed_lots'][str(item['offer'])]=item['new_name']
    bot.persist_settings()
    bot.STORE.set_meta('rotated_offer:'+str(item['offer']),str(time.time()))
    item['stage']='done'
    activity.record(bot,getattr(bot,'C',None),'rotation',f"🔄 Лот {item['offer']}: {old['game_name']} → {new['game_name']} · {new['region']}",item['offer'])

def run(bot,c):
    options=bot.CFG['rotation']
    if not options['enabled'] or bot.CFG['mode']!='live' or bot.paused() or not bot.live_allowed() or bot.STOP.is_set():return
    items=jobs(bot)
    if items:
        busy=busy_rules(bot,c)
        for item in items:
            if item['stage']=='done':continue
            if item['old_name'] in busy:continue
            with bot.PROCESS_LOCK,bot.LOT_WRITE_LOCK:
                if bot.paused() or bot.STOP.is_set():return
                old=bot.CFG['lot_rules'][item['old_name']]
                fields=c.account.get_lot_fields(item['offer'],node_id=1008)
                if matches(bot,fields,item['rule']):
                    if fields.active:raise RotationDeferred('Новый лот ещё не подтверждён как выключенный')
                    commit(bot,item);put(bot,items);continue
                if not matches(bot,fields,old):raise RotationDeferred('Поля заменяемого лота изменились')
                if item['stage']=='prepared' or fields.active:
                    fields.active=False;c.account.save_lot(fields.renew_fields())
                    check=c.account.get_lot_fields(item['offer'],node_id=1008)
                    if check.active:raise RotationDeferred('Лот не снят перед заменой')
                    item.update(stage='off',eligible_at=time.time()+options['drain_seconds'])
                    put(bot,items);continue
                if time.time()<item['eligible_at']:continue
                # Recheck after fetching editor fields: an order may have arrived meanwhile.
                if item['old_name'] in busy_rules(bot,c):continue
                product=bot.supplier_product(bot.client(),item['rule'],1)
                if D(product['price_usd'])>D(bot.CFG['catalog_sync']['max_game_price_usd']):
                    raise RotationDeferred('Новая игра стала дороже лимита каталога')
                item['rule']['last_price_usd']=str(D(product['price_usd']))
                # This pass started with a fresh full list of paid sales after the drain interval.
                item['stage']='editing';put(bot,items)
                _,price=bot.price_band(item['rule'],item['rule']['last_price_usd'])
                c.account.save_lot(apply_existing(fields,item['rule'],price))
                checked=c.account.get_lot_fields(item['offer'],node_id=1008)
                if checked.active or not matches(bot,checked,item['rule']):raise RotationDeferred('Замена не подтверждена')
                commit(bot,item);put(bot,items)
        if all(x['stage']=='done' for x in items):
            put(bot,[])
            bot.STORE.set_meta('next_rotation',str(time.time()+options['interval_seconds']))
            bot.alert(c,f'Ротация завершена: заменено игр {len(items)}. Ключи выдаются по оплате, закупок при замене нет.')
        return
    due=bot.STORE.get_meta('next_rotation','')
    if not due:
        bot.STORE.set_meta('next_rotation',str(time.time()+options['interval_seconds']));return
    if time.time()<float(due):return
    busy=busy_rules(bot,c)
    api=bot.client()
    pool=catalog.catalogue(api,bot.CFG['catalog_sync']['max_game_price_usd'],bot.STOP)
    balance=api.balance()-D(bot.CFG['min_balance_reserve_usd'])
    current={name for name in bot.CFG['managed_lots'].values()}
    signatures={tuple(sorted(bot.CFG['lot_rules'][name]['match_fields'].items())) for name in current}
    candidates=[]
    for name,rule in pool:
        previous=bot.CFG['lot_rules'].get(name)
        if name in current or D(rule['last_price_usd'])>balance:continue
        if tuple(sorted(rule['match_fields'].items())) in signatures:continue
        if previous and (previous['match_fields']!=rule['match_fields'] or previous.get('countries')!=rule.get('countries')
                         or previous.get('excluded_countries')!=rule.get('excluded_countries')):continue
        # Avoid a public identity identifying two distinct historic SKUs.
        if any(n!=name and r['match_fields']==rule['match_fields'] for n,r in bot.CFG['lot_rules'].items()):continue
        candidates.append((name,rule))
    candidates.sort(key=lambda x:bot.CFG['lot_rules'].get(x[0],{}).get('last_listed_at',0))
    slots=[(int(offer),name) for offer,name in bot.CFG['managed_lots'].items()
           if bot.CFG['lot_rules'][name].get('kind')=='game_key' and name not in busy
           and not bot.CFG.get('lot_controls',{}).get(str(offer),{}).get('pinned')
           and not bot.CFG.get('lot_controls',{}).get(str(offer),{}).get('owner_disabled')
           and not bot.CFG.get('lot_controls',{}).get(str(offer),{}).get('description_ru')
           and not bot.CFG.get('lot_controls',{}).get(str(offer),{}).get('manual_price')]
    slots.sort(key=lambda x:float(bot.STORE.get_meta('rotated_offer:'+str(x[0]),'0')))
    count=min(options['max_changes'],len(slots),len(candidates))
    if not count:
        bot.STORE.set_meta('next_rotation',str(time.time()+300));return
    items=[{'offer':slots[i][0],'old_name':slots[i][1],'new_name':candidates[i][0],
            'rule':candidates[i][1],'stage':'prepared'} for i in range(count)]
    put(bot,items)
    bot.STORE.set_meta('rotation_summary',f'Заменяю {count} игр; заказы защищены')
    for item in items:
        activity.record(bot,c,'rotation',f"⏳ Начата ротация лота {item['offer']}: {bot.CFG['lot_rules'][item['old_name']]['game_name']} → {item['rule']['game_name']}",item['offer'])
