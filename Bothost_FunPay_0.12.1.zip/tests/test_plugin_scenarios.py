import os
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "plugins"))
import steamru_stars as bot
from steamru_stars_engine import Store, UnknownOutcome

class FakeAccount:
    id=7
    def get_order(self, oid):
        return N(id=oid, status=N(name='PAID'), seller_id=7, subcategory=N(id=999),
                 short_description='STEAMRU TG STARS 50', buyer_id='12', buyer_username='buyer', chat_id='33',
                 amount=1, currency=N(code='rub'), sum=Decimal('75.77'))

class FakeCardinal:
    def __init__(self):
        self.account=FakeAccount()
        self.telegram=None
        self.plugins={bot.UUID: N(enabled=True)}
        self.messages=[]
    def send_message(self, chat_id, text, name, watermark=False):
        self.messages.append((chat_id, text))
        return [N()]

class FakeAPI:
    def __init__(self): self.buy_calls=0;self.check_result=True;self.timeout=False;self.price='0.0152'
    def product(self, service, pid, count):
        assert count==50
        return {'product_id':55, 'price_usd':self.price, 'fields': []}
    def check_username(self, username):return self.check_result
    def balance(self):return Decimal('100')
    def create(self,*args):
        self.buy_calls+=1
        if self.timeout:raise UnknownOutcome('Lost POST response')
        return {'uuid':'cf6a7f78-b460-4cb3-92ce-38bccd3c1ea6','product_id':55,'status':'created'}
    def get_order(self, uuid):
        return {'uuid':uuid, 'status':'completed', 'amount_charged_usd':'0.7600'}

class ScenarioTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.temp.name)/'db.sqlite3')
        self.store.set_meta('paused','no')
        bot.STOP.clear()
        self.c=FakeCardinal()
        self.api=FakeAPI()
        self.prev_store=bot.STORE
        self.prev_cfg=bot.CFG
        bot.STORE=self.store
        bot.CFG={**bot.DEFAULT,
                'mode':'live',
                'allowed_subcategory_ids':[999],
                'wallet_paid_rub':'884.5', 'wallet_credited_usd':'10',
                'rub_per_usd':'88.45',
                'rub_per_usd_updated_at':datetime.now(timezone.utc).isoformat()}
        self.patch_client=patch.object(bot,'client',return_value=self.api)
        self.patch_allowed=patch.object(bot,'live_allowed',return_value=True)
        self.patch_client.start();self.patch_allowed.start()
    def tearDown(self):
        self.patch_client.stop();self.patch_allowed.stop()
        bot.STORE=self.prev_store;bot.CFG=self.prev_cfg
        self.temp.cleanup()
    def add(self):
        e=N(order=N(description='STEAMRU TG STARS 50',status=N(name='PAID'),id='ABCD1234',
                    buyer_id=12, chat_id=33,buyer_username='buyer',amount=1,price=75.77))
        bot.on_new_order(self.c,e)
    def reply(self,nick='recipient123'):
        e=N(message=N(text=f'@{nick} #ABCD1234',author_id=12,chat_id=33,
                      type=N(name='NON_SYSTEM'),by_bot=False))
        bot.on_new_message(self.c,e)
    def test_good_order_one_purchase(self):
        self.add();self.reply()
        self.assertEqual(self.store.get('ABCD1234')['status'],'ready')
        bot.process_ready(self.c)
        self.assertEqual(self.store.get('ABCD1234')['status'],'completed')
        self.assertEqual(self.api.buy_calls,1)
        bot.process_ready(self.c)
        self.assertEqual(self.api.buy_calls,1)
        self.assertEqual(self.store.get('ABCD1234')['buyer_notified'],1)
    def test_wrong_buyer_cannot_redirect(self):
        self.add()
        e=N(message=N(text='@malicious123 #ABCD1234',author_id=999,chat_id=33,
                      type=N(name='NON_SYSTEM'),by_bot=False))
        bot.on_new_message(self.c,e)
        self.assertEqual(self.store.get('ABCD1234')['status'],'awaiting_username')
    def test_wrong_telegram_recipient_not_bought(self):
        self.add();self.reply()
        self.api.check_result=False
        bot.process_ready(self.c)
        self.assertEqual(self.api.buy_calls,0)
        self.assertEqual(self.store.get('ABCD1234')['status'],'awaiting_username')
    def test_not_profitable_is_blocked(self):
        self.add();self.reply()
        self.api.price='0.0250'
        bot.process_ready(self.c)
        self.assertEqual(self.api.buy_calls,0)
        self.assertEqual(self.store.get('ABCD1234')['status'],'needs_review')
        self.assertFalse(bot.paused())
    def test_lost_post_response_no_duplicate(self):
        self.add();self.reply()
        self.api.timeout=True
        bot.process_ready(self.c)
        self.assertEqual(self.api.buy_calls,1)
        self.assertEqual(self.store.get('ABCD1234')['status'],'uncertain')
        bot.process_ready(self.c)
        self.assertEqual(self.api.buy_calls,1)
        self.assertFalse(bot.paused())
    def test_refunded_before_post_blocks(self):
        self.add();self.reply()
        self.c.account.get_order=lambda oid:N(status=N(name='REFUNDED'))
        bot.process_ready(self.c)
        self.assertEqual(self.api.buy_calls,0)
    def test_supplier_error_is_not_refund_and_can_later_refund(self):
        self.add();self.reply()
        self.api.get_order=lambda uuid: {'uuid':uuid,'status':'error'}
        bot.process_ready(self.c)
        row=self.store.get('ABCD1234')
        self.assertEqual(row['status'],'needs_review')
        self.assertFalse(bot.paused())
        self.assertEqual(self.api.buy_calls,1)
        # Поставщик возвратил деньги не сразу: повторная проверка GET замечает refunded.
        self.api.get_order=lambda uuid: {'uuid':uuid,'status':'refunded'}
        bot.process_pending(self.c,self.store.get('ABCD1234'),api=self.api)
        self.assertEqual(self.store.get('ABCD1234')['status'],'refunded')
        self.assertEqual(self.api.buy_calls,1)
    def test_supplier_review_requires_manual_attention(self):
        self.add();self.reply()
        self.api.get_order=lambda uuid: {'uuid':uuid,'status':'review'}
        bot.process_ready(self.c)
        self.assertEqual(self.store.get('ABCD1234')['status'],'needs_review')
        self.assertFalse(bot.paused())
        self.assertEqual(self.api.buy_calls,1)
    def test_live_blocked_without_emergency_lot_disabling(self):
        from unittest.mock import patch
        self.patch_allowed.stop()  # Проверяем настоящую функцию, не мок процесса заказа.
        try:
            with patch.dict(os.environ,{
                'STEAMRU_API_KEY':'rk_live_test','STEAMRU_API_SECRET':'testsecret',
                'STEAMRU_OWNER_TG_ID':'123','STEAMRU_LIVE_CONFIRM':'I_ACCEPT_REAL_PURCHASES'
            }):
                self.assertFalse(bot.live_allowed())
                bot.CFG['auto_disable_lots_on_pause']=True
                bot.CFG['lot_ids_to_disable']=[123]
                self.assertTrue(bot.live_allowed())
        finally:
            self.patch_allowed.start()
    def test_event_dedup(self):
        self.add();self.add()
        self.assertEqual(len(self.store.rows()),1)

    def test_funpay_refund_remains_recorded_after_supplier_completion(self):
        self.add();self.reply()
        self.api.get_order=lambda uuid: {'uuid':uuid, 'status':'pending'}
        bot.process_ready(self.c)
        bot.on_order_status_change(self.c, N(order=N(id='ABCD1234', status=N(name='REFUNDED'))))
        self.api.get_order=lambda uuid: {'uuid':uuid, 'status':'completed'}
        bot.process_pending(self.c, self.store.get('ABCD1234'), api=self.api)
        row=self.store.get('ABCD1234')
        self.assertEqual(row['status'],'completed')
        self.assertEqual(row['funpay_status'],'REFUNDED')
        self.assertFalse(bot.paused())
        self.assertEqual(self.api.buy_calls,1)


class SlowWorkerLifecycle(unittest.TestCase):
    def test_restart_waits_for_old_worker_and_starts_exactly_one_new_worker(self):
        import threading
        first_started=threading.Event()
        second_started=threading.Event()
        release_first=threading.Event()
        calls=[]
        def slow_worker(c):
            calls.append(threading.current_thread())
            if len(calls)==1:
                first_started.set()
                bot.STOP.wait(5)
                release_first.wait(5)  # Имитируем заканчивающееся сетевое чтение.
            else:
                second_started.set()
                bot.STOP.wait(5)
        with tempfile.TemporaryDirectory() as temp:
            old=(bot.STORE, bot.WORKER, bot.RESTART_WAITER, bot.RUN_REQUESTED)
            bot.STORE=Store(Path(temp)/'state.db')
            bot.WORKER=None
            bot.RESTART_WAITER=None
            try:
                with patch.object(bot,'worker',side_effect=slow_worker):
                    bot.on_post_start(N())
                    self.assertTrue(first_started.wait(2))
                    bot.on_pre_stop(N())
                    bot.on_post_start(N())
                    bot.on_post_start(N())
                    self.assertEqual(len(calls),1)
                    release_first.set()
                    self.assertTrue(second_started.wait(2))
                    self.assertEqual(len(calls),2)
                    bot.on_pre_stop(N())
                    self.assertFalse(bot.WORKER.is_alive())
            finally:
                release_first.set()
                bot.STOP.set()
                if bot.WORKER:
                    bot.WORKER.join(2)
                if bot.RESTART_WAITER:
                    bot.RESTART_WAITER.join(2)
                bot.STORE,bot.WORKER,bot.RESTART_WAITER,bot.RUN_REQUESTED=old
                bot.STOP.clear()

if __name__=='__main__':unittest.main()
