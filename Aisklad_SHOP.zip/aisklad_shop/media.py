"""Bounded, verified product image cache. Never fetch buyer-provided URLs."""
from contextlib import closing
import hashlib
from io import BytesIO
import ipaddress
from pathlib import Path
import socket
import threading
import time
from urllib.parse import urljoin,urlsplit

from PIL import Image,UnidentifiedImageError
import requests

TRUSTED_SUFFIXES=('steam.ru','steamstatic.com','steampowered.com','steamusercontent.com','akamaihd.net',
                  'googleusercontent.com','wikimedia.org')
MAX_BYTES=8*1024*1024
MAX_PIXELS=24_000_000
IMAGE_REVISION='v2-footer14'


def clean_product_image(image,source):
    """The requested automatic footer crop applies only to supplier artwork.

    Official Steam covers and our own menu banners do not need this transform.
    Never overwrite a downloaded original or reuse the old unprocessed cache.
    """
    width,height=image.size
    host=(urlsplit(source).hostname or '').lower()
    if height>=240 and (host=='steam.ru' or host.endswith('.steam.ru')):
        image=image.crop((0,0,width,max(32,int(height*.86))))
    return image.convert('RGB')


def safe_image_url(value,extra_hosts=(),resolve=False):
    if not isinstance(value,str) or len(value)>2048:return False
    try:
        parsed=urlsplit(value);host=parsed.hostname
        if (parsed.scheme!='https' or not host or parsed.username or parsed.password
                or parsed.port not in (None,443) or parsed.fragment):return False
        host=host.lower().rstrip('.')
        if not any(host==suffix or host.endswith('.'+suffix) for suffix in TRUSTED_SUFFIXES) and host not in extra_hosts:
            return False
        try:
            if not ipaddress.ip_address(host).is_global:return False
        except ValueError:pass
        if resolve:
            addresses=socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
            if not addresses or any(not ipaddress.ip_address(item[4][0]).is_global for item in addresses):return False
        return True
    except (ValueError,OSError):return False


class MediaResolver:
    def __init__(self,cache_dir,assets_dir,session=None,extra_hosts=(),clock=time.time):
        self.cache_dir=Path(cache_dir);self.cache_dir.mkdir(parents=True,exist_ok=True)
        self.assets_dir=Path(assets_dir);self.session=session or requests.Session()
        self.extra_hosts=tuple(h.lower() for h in extra_hosts);self.clock=clock
        self.guard=threading.RLock()

    def fallback(self,name='product'):
        name=name if name in ('home','catalog','search','favorites','cart','checkout','orders','profile','help','product','assistant','about') else 'product'
        for key in (name,'product','catalog','home'):
            for suffix in ('.jpg','.png','.webp'):
                path=self.assets_dir/(key+suffix)
                if path.is_file():return path
        return None

    def resolve(self,product_or_url=None,fallback='product'):
        if isinstance(product_or_url,dict):
            source=product_or_url.get('image_url') or product_or_url.get('image')
            app_id=product_or_url.get('app_id')
            if str(app_id).isdigit() and int(app_id)>0:
                source=f'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{int(app_id)}/header.jpg'
        else:source=product_or_url
        if not safe_image_url(source,self.extra_hosts):return self.fallback(fallback)
        target=self.cache_dir/(hashlib.sha256((IMAGE_REVISION+':'+source).encode()).hexdigest()+'.jpg')
        with self.guard:
            if target.is_file() and self.clock()-target.stat().st_mtime<7*86400:return target
            try:
                payload=self._download(source)
                with Image.open(BytesIO(payload)) as image:
                    width,height=image.size
                    if width*height>MAX_PIXELS or min(width,height)<32:raise ValueError('Invalid image size')
                    image.load()
                    image=clean_product_image(image,source);image.thumbnail((1600,1200))
                    pending=target.with_suffix('.tmp')
                    image.save(pending,format='JPEG',quality=90,optimize=True)
                pending.replace(target)
                return target
            except (OSError,ValueError,requests.RequestException,UnidentifiedImageError,Image.DecompressionBombError):
                # Local artwork keeps navigation usable even when a CDN is down.
                return target if target.is_file() else self.fallback(fallback)

    def _download(self,source):
        for _ in range(4):
            if not safe_image_url(source,self.extra_hosts,resolve=True):raise ValueError('Image host unavailable')
            with closing(self.session.get(source,stream=True,allow_redirects=False,timeout=(3,8))) as response:
                if response.status_code in (301,302,303,307,308):
                    source=urljoin(source,response.headers.get('Location',''));continue
                if response.status_code!=200 or not response.headers.get('Content-Type','').lower().startswith('image/'):
                    raise ValueError('Image unavailable')
                length=response.headers.get('Content-Length')
                if length and int(length)>MAX_BYTES:raise ValueError('Image too large')
                blocks=[];size=0
                for block in response.iter_content(64*1024):
                    size+=len(block)
                    if size>MAX_BYTES:raise ValueError('Image too large')
                    blocks.append(block)
                return b''.join(blocks)
        raise ValueError('Too many image redirects')
