# noplug — pricing and read-only partner wallet quotes.
"""Competitor comparison, seller margin floor and live SBP replacement cost."""
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from urllib.parse import urlsplit
from steamru_stars_engine import D, money, finances, effective_exchange_rate, currency_code, strict_count

TOPUP_CLIENT = None
CENT = Decimal('0.01')


class PartnerFailure(ValueError):
    """Only fixed, credential-free explanations may leave the login client."""
    MESSAGES = {
        'connection_failed': 'Не удалось подключиться к partner.steam.ru. Проверь доступ к сайту.',
        'redirect_host': 'Кабинет отправил на другой сайт. Переход остановлен.',
        'login_page': 'Страница входа кабинета недоступна.',
        'login_form': 'На странице не найдена обычная форма входа STEAM.RU.',
        'login_denied': 'Кабинет не принял вход. Нужны e-mail и пароль от partner.steam.ru, введённые локально.',
        'login_http': 'Кабинет не подтвердил вход.',
        'login_browser': 'Для входа требуется проверка в браузере. Автоматический вход остановлен.',
        'csrf_expired': 'Сайт отклонил сессию входа. Повтори запуск, чтобы получить новую сессию.',
        'rate_limited': 'Сайт временно ограничил попытки входа. Подожди перед повторным запуском.',
        'quote_http': 'Страница курса кошелька недоступна.',
        'quote_form': 'Вместо формы курса сайт вернул другую страницу.',
        'quote_parameters': 'Не удалось прочитать курс или комиссию из формы кошелька.',
    }
    def __init__(self, code, status=None):
        self.code, self.status = code, status
        message = self.MESSAGES[code]
        if status is not None: message += f' HTTP {int(status)}.'
        super().__init__(message)


def ceil_cent(value):
    return D(value).quantize(CENT, rounding=ROUND_CEILING)


def seller_floor(unit_usd, stars, rate, fee_pct, other_rub, margin_pct, profit_rub=0):
    fee, margin, profit = D(fee_pct) / 100, D(margin_pct) / 100, D(profit_rub)
    if fee < 0 or margin < 0 or fee + margin >= 1 or profit < 0:
        raise ValueError('Некорректный порог прибыли или комиссии')
    cost = D(unit_usd) * strict_count(stars, 1, 500) * D(rate) + D(other_rub)
    if cost <= 0 or D(unit_usd) <= 0 or D(rate) <= 0 or D(other_rub) < 0:
        raise ValueError('Некорректная себестоимость')
    return ceil_cent(max(cost / (1 - fee - margin), (cost + profit) / (1 - fee)))


def comparable_minimum(lots, stars, seller_id, own_ids):
    result = []
    for lot in lots:
        try:
            if int(lot.id) in own_ids or int(lot.seller.id) == int(seller_id):
                continue
            if currency_code(lot.currency) != 'RUB' or getattr(lot, 'amount', None) == 0:
                continue
            attrs = lot.attributes or {}
            if str(attrs.get('f-quantity', '')).strip() != f'{stars} звёзд':
                continue
            if str(attrs.get('f-method', '')).strip().casefold() != 'по username':
                continue
            price = D(lot.price)
            if price <= 0:
                continue
            result.append((price, int(lot.id)))
        except (ValueError, TypeError, AttributeError):
            continue
    return min(result, default=None)


def buyer_price(calc):
    if calc.min_price_with_commission is not None and currency_code(calc.min_price_currency) == 'RUB':
        price = D(calc.min_price_with_commission)
    else:
        prices = [D(m.price) for m in calc.methods if currency_code(m.currency) == 'RUB']
        if not prices:
            raise ValueError('Нет комиссии покупателя RUB')
        price = min(prices)
    if price <= 0:
        raise ValueError('Некорректная цена для покупателя')
    return money(price)


def choose_price(floor, competitor, coefficient, quote, step='0.01', ceiling=None):
    floor, coefficient, step = ceil_cent(floor), D(coefficient), D(step)
    if coefficient < 1 or coefficient > 5 or step <= 0:
        raise ValueError('Некорректный коэффициент или шаг цены')
    target = money(competitor[0]) - step if competitor is not None else None
    candidate = floor if target is None else max(floor, (target / coefficient).quantize(CENT, rounding=ROUND_FLOOR))
    if ceiling is not None:
        candidate = min(candidate, max(floor, D(ceiling).quantize(CENT, rounding=ROUND_FLOOR)))
    public_price = buyer_price(quote(candidate))
    for _ in range(3):
        if target is None or public_price <= target or candidate <= floor:
            break
        reduction = max(CENT, ceil_cent((public_price - target) / coefficient))
        candidate = max(floor, candidate - reduction)
        public_price = buyer_price(quote(candidate))
    # Never claim a competitive price if rounding prevented undercutting.
    if target is not None and public_price > target and candidate > floor:
        candidate = floor
        public_price = buyer_price(quote(candidate))
    return {'seller_price': candidate, 'buyer_price': public_price, 'seller_floor': floor,
            'competitor_buyer_price': money(competitor[0]) if competitor else None,
            'competitor_id': competitor[1] if competitor else None,
            'reason': 'no_competitors' if target is None else ('competitive' if public_price <= target else 'margin_floor')}


def seller_ceiling(unit_usd, count, rate, fee_pct, other_rub, margin_pct):
    cost = D(unit_usd) * strict_count(count, 1, 500) * D(rate) + D(other_rub)
    denominator = 1 - D(fee_pct) / 100 - D(margin_pct) / 100
    if denominator <= 0:
        raise ValueError('Некорректная верхняя маржа')
    return (cost / denominator).quantize(CENT, rounding=ROUND_FLOOR)


def parse_topup(html, payment='sbp', reference='100'):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'lxml')
    form = soup.find('form', id='topup-form')
    if form is None or urlsplit(form.get('action', '')).path != '/wallet/topup':
        raise ValueError('Нет доступной формы курса пополнения')
    raw_rate = D(form.get('data-rate'))
    radio = form.find('input', attrs={'name': 'payment_service_id', 'value': payment})
    tile = radio.find_parent(attrs={'data-fee-percent': True}) if radio else None
    amount = form.find('input', id='topup-amount')
    if tile is None or amount is None:
        raise ValueError('Нет выбранного способа оплаты')
    fee, fixed = D(tile.get('data-fee-percent')), D(tile.get('data-fee-fix'))
    if not 0 <= fee < 100 or fixed < 0 or not 0 < raw_rate < 1000:
        raise ValueError('Некорректный курс или комиссия')
    minimum = D(amount.get('min', '0'))
    maximum = D(amount.get('max', '1000000'))
    reference = ceil_cent(max(D(reference), minimum))
    if not 0 < reference <= maximum:
        raise ValueError('Некорректная сумма для расчёта курса')
    base = (reference * raw_rate).quantize(Decimal('0.0001'), rounding=ROUND_CEILING)
    invoice = ceil_cent((base + fixed) / (1 - fee / 100))
    return {'raw_rub_per_usd': str(raw_rate), 'fee_pct': str(fee), 'fee_fix_rub': str(fixed),
            'reference_usd': str(reference), 'invoice_rub': str(invoice),
            'effective_rub_per_usd': str(invoice / reference), 'payment_method': payment,
            'verified_at': datetime.now(timezone.utc).isoformat(), 'read_only': True}


class PartnerTopupClient:
    """Only GET login/topup and POST login. No topup/payment submissions."""
    BASE = 'https://partner.steam.ru'

    def __init__(self, email, password, payment='sbp', reference='100', session=None):
        import requests
        self._session = session or requests.Session()
        self._email, self._password = email, password
        self.payment, self.reference = payment, reference
        self.snapshot = None
        self.trace = []

    def _request(self, method, path, data=None):
        if (method, path) not in {('GET', '/login'), ('POST', '/login'), ('GET', '/wallet/topup')}:
            raise ValueError('Запрещённая операция партнёрского кабинета')
        try:
            headers = {'Accept': 'text/html,application/xhtml+xml', 'Referer': self.BASE + '/login'}
            if method == 'POST': headers['Origin'] = self.BASE
            response = self._session.request(method, self.BASE + path, data=data,
                                             headers=headers, timeout=20, allow_redirects=False)
        except Exception:
            self.trace.append({'method':method,'path':path,'status':None})
            raise PartnerFailure('connection_failed') from None
        self.trace.append({'method':method,'path':path,'status':int(response.status_code)})
        self.trace = self.trace[-12:]
        location = response.headers.get('Location')
        if location:
            parsed = urlsplit(location)
            self.trace[-1].update(redirect_scheme=parsed.scheme or 'relative',
                redirect_same_host=not parsed.hostname or parsed.hostname=='partner.steam.ru',
                redirect_path=parsed.path if parsed.path in ('/','/login','/dashboard','/wallet','/wallet/topup') else 'other')
            if parsed.scheme not in ('','https','http') or parsed.hostname and parsed.hostname != 'partner.steam.ru':
                raise PartnerFailure('redirect_host')
            # Some reverse-proxy deployments generate a same-host HTTP Location after login.
            # We never follow Location: all subsequent requests still use the fixed HTTPS BASE.
        return response

    def _login(self):
        from bs4 import BeautifulSoup
        response = self._request('GET', '/login')
        if response.status_code != 200:
            raise PartnerFailure('rate_limited' if response.status_code==429 else 'login_page', response.status_code)
        soup = BeautifulSoup(response.text, 'lxml')
        form = next((f for f in soup.find_all('form') if urlsplit(f.get('action', '')).path == '/login'), None)
        token = form.find('input', attrs={'name': '_token'}) if form else None
        if token is None or not token.get('value'):
            raise PartnerFailure('login_form')
        if form.find('input', attrs={'name':'g-recaptcha-response'}) or form.find('input', attrs={'name':'h-captcha-response'}):
            raise PartnerFailure('login_browser')
        response = self._request('POST', '/login', {'_token': token['value'], 'email': self._email, 'password': self._password})
        target = urlsplit(response.headers.get('Location', '')).path
        if response.status_code == 419: raise PartnerFailure('csrf_expired',419)
        if response.status_code == 429: raise PartnerFailure('rate_limited',429)
        if response.status_code in (401,403,422) or target.rstrip('/') == '/login':
            raise PartnerFailure('login_denied',response.status_code)
        if response.status_code not in (200,302,303):
            raise PartnerFailure('login_http',response.status_code)
        # The intended page may differ from dashboard. Verify the actual wallet form next,
        # instead of treating an otherwise valid same-host redirect as a failed login.

    def refresh(self):
        response = self._request('GET', '/wallet/topup')
        if response.status_code in (302, 303, 401, 419):
            self._login()
            response = self._request('GET', '/wallet/topup')
        if response.status_code != 200:
            code = 'login_denied' if response.status_code in (302,303,401,403) else 'quote_http'
            raise PartnerFailure(code,response.status_code)
        try:
            self.snapshot = parse_topup(response.text, self.payment, self.reference)
        except ValueError:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.text,'lxml')
            if soup.find('form', id='topup-form') is None:
                code = 'login_denied' if soup.find('input',attrs={'name':'password'}) else 'quote_form'
            else: code = 'quote_parameters'
            raise PartnerFailure(code,200) from None
        return dict(self.snapshot)

    def close(self):
        self._email = self._password = ''
        self._session.cookies.clear()
        self._session.close()
        self.snapshot = None


def pricing_rate(cfg):
    funded = effective_exchange_rate(cfg['wallet_paid_rub'], cfg['wallet_credited_usd'])
    options = cfg.get('auto_pricing', {})
    if not options.get('enabled') or not options.get('watch_topup_rate'):
        return funded
    quote = TOPUP_CLIENT.snapshot if TOPUP_CLIENT is not None else None
    if quote is None:
        raise ValueError('Нет свежего курса нового пополнения STEAM.RU')
    try:
        stamp = datetime.fromisoformat(quote['verified_at'])
        age = datetime.now(timezone.utc) - stamp
        if stamp.tzinfo is None or not timedelta(0) <= age <= timedelta(seconds=7200):
            raise ValueError('Курс нового пополнения устарел')
        current = D(quote['effective_rub_per_usd'])
        if not 0 < current < 1000:
            raise ValueError('Некорректный курс нового пополнения')
    except (KeyError, TypeError):
        raise ValueError('Некорректная проверка курса') from None
    return max(funded, current)
