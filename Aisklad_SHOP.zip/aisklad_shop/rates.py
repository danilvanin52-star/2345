"""Read-only STEAM.RU replacement cost, shared with the FunPay module."""
from datetime import datetime,timezone
from decimal import Decimal,InvalidOperation
import json
import os
from pathlib import Path
import threading
import time


def decimal(value):
    number=Decimal(str(value))
    if not number.is_finite():raise ValueError('Некорректный курс.')
    return number


def atomic_json(path,payload):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_name(path.name+'.'+str(os.getpid())+'.tmp')
    pending.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8');pending.chmod(0o600)
    pending.replace(path)


def publish_partner_quote(quote):
    destination=os.getenv('AISKLAD_RATE_FILE')
    if destination:atomic_json(Path(destination),{key:quote[key] for key in
                ('effective_rub_per_usd','verified_at')})


class RateProvider:
    def __init__(self,settings,client=None,clock=time.time):
        self.settings=settings;self.clock=clock;self.client=client;self.guard=threading.RLock()
        self.path=settings.shop_dir/'partner_rate.json'
        self._cached=None;self._cached_at=0;self._cached_files=None

    def _file_state(self):
        result=[]
        for path in (self.path,self.settings.funpay_dir/'storage/plugins/steamru_stars_config.json'):
            try:
                state=path.stat();result.append((state.st_mtime_ns,state.st_size))
            except OSError:result.append(None)
        return tuple(result)

    def _funded(self):
        path=self.settings.funpay_dir/'storage/plugins/steamru_stars_config.json'
        if not path.is_file():return Decimal(0)
        try:
            config=json.loads(path.read_text(encoding='utf-8'))
            paid=decimal(config.get('wallet_paid_rub'));credited=decimal(config.get('wallet_credited_usd'))
            return paid/credited if paid>0 and credited>0 else Decimal(0)
        except (ValueError,TypeError,InvalidOperation,ZeroDivisionError):return Decimal(0)

    def __call__(self):
        with self.guard:
            try:
                now=self.clock();state=self._file_state()
                if (self._cached is not None and state==self._cached_files
                        and 0<=now-self._cached_at<=15 and 0<=now-self._cached['observed_at']<=3600):
                    return dict(self._cached)
                quote=json.loads(self.path.read_text(encoding='utf-8'))
                stamp=datetime.fromisoformat(quote['verified_at'].replace('Z','+00:00'))
                if stamp.tzinfo is None:raise ValueError
                observed=stamp.timestamp();age=now-observed
                value=max(decimal(quote['effective_rub_per_usd']),self._funded())
                if not 0<=age<=3600 or not 0<value<1000:raise ValueError
                self._cached={'rub_per_usd':str(value),'observed_at':observed,
                              'source':'STEAM.RU: стоимость нового пополнения с комиссией'}
                self._cached_at=now;self._cached_files=state
                return dict(self._cached)
            except (OSError,KeyError,TypeError,ValueError,InvalidOperation):
                self._cached=None
                raise ValueError('Курс обновляется. Попробуй немного позже.') from None

    def refresh(self):
        with self.guard:
            try:return self()
            except ValueError:pass
            if self.client is None:
                if not self.settings.partner_email or not self.settings.partner_password:
                    raise ValueError('Не настроено чтение курса STEAM.RU.')
                from plugins.steamru_stars_pricing import PartnerTopupClient
                self.client=PartnerTopupClient(self.settings.partner_email,self.settings.partner_password)
            quote=self.client.refresh()
            atomic_json(self.path,{key:quote[key] for key in ('effective_rub_per_usd','verified_at')})
            return self()

    def close(self):
        if self.client is not None:self.client.close()
