"""Verified live editor labels, supplier-read retries and durable owner alarms."""
from copy import deepcopy
import configparser
import json
import logging
from pathlib import Path
import tempfile
from types import SimpleNamespace as N
import unittest
from unittest.mock import Mock, patch
import test_catalog_pricing as products
from test_cardinal_compatibility import source_interfaces, full_order, shortcut
from test_cardinal_compatibility import definitions, SOURCE
from test_safety_integration import Cardinal
import steamru_stars as bot
import steamru_stars_notifications as notices
import steamru_customer_messages as customer_messages
from steamru_stars_engine import Store, ApiFailure, UnknownOutcome, D

FIXTURE = Path(__file__).parent/'fixtures/verified_offer_labels.json'


class VerifiedOrderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.types=source_interfaces()
    setUp=products.NewProductsTests.setUp
    tearDown=products.NewProductsTests.tearDown
    create=products.NewProductsTests.create
    capture=products.NewProductsTests.capture

    def real_steam(self,amount=200):
        rule=products.catalog.rub_rule(1,{'price_usd':'.0118'})
        self.capture(rule,amount)
        self.c.account.order.fields={'currency':self.types.LotField('currency','RUB🔥',field_type_id='select'),
                                    'type':self.types.LotField('type','По логину🔥',field_type_id='radio')}
        return self.c.account.order

    def test_all_41_current_products_match_verified_customer_display_labels(self):
        rows=json.loads(FIXTURE.read_text(encoding='utf-8'))
        self.assertEqual(len(rows),41)
        bot.CFG['lot_rules']={r['name']:r['rule'] for r in rows}
        bot.CFG['allowed_subcategory_ids']=sorted({r['rule']['subcategory_id'] for r in rows})
        for record in rows:
            with self.subTest(product=record['name']):
                rule=record['rule'];kind=rule.get('kind','stars')
                amount=156 if kind=='steam_rub' else 1
                order=full_order(self.types,subcategory_id=rule['subcategory_id'],amount=amount)
                order.fields={k:self.types.LotField(k,v['value'],field_type_id=v['field_type_id'])
                              for k,v in record['order_fields'].items() if v['value']!=''}
                title,quantity,total,_=bot.full_order_data(Cardinal(order),order,order.id)
                self.assertEqual(title,'rule:'+record['name'])
                self.assertEqual(total,amount*rule['stars_per_unit'])
                self.assertEqual(quantity,amount)

    def test_verified_steam_supports_every_integer_from_100_to_500(self):
        order=self.real_steam()
        for amount in range(100,501):
            order.amount=amount
            self.assertEqual(bot.full_order_data(self.c,order,order.id)[2],amount)
        for amount in (99,501,156.5):
            order.amount=amount
            with self.assertRaises(ValueError):bot.full_order_data(self.c,order,order.id)

    def test_verified_steam_200_still_fulfils_once_after_price_changes(self):
        order=self.real_steam()
        bot.STORE.set_username(order.id,12,order.chat_id,'safe_login')
        order.sum=D('196');bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(self.api.created,[('funpay-ABCD1234',200,'safe_login')])
        self.assertEqual(bot.STORE.get(order.id)['status'],'completed')

    def test_usd_other_methods_and_fuzzy_labels_never_match_rub(self):
        order=self.real_steam()
        for key,label in [('currency','USD🔥'),('currency','RUB🔥 скидка'),('type','По ссылке🔥'),('type','По логину🔥 другое')]:
            original=order.fields[key].value;order.fields[key].value=label
            with self.subTest(label=label),self.assertRaises(ValueError):bot.full_order_data(self.c,order,order.id)
            order.fields[key].value=original
        order.fields['currency'].field_type_id='text'
        with self.assertRaises(ValueError):bot.full_order_data(self.c,order,order.id)

    def test_manually_fulfilled_order_exclusion_blocks_late_paid_events(self):
        self.real_steam()
        with bot.STORE.conn() as db:db.execute('DELETE FROM orders')
        bot.STORE.set_meta('manual_order:ABCD1234','fulfilled_by_owner')
        event=shortcut(self.types);event.subcategory.id=1086
        self.c.account.get_order=Mock(side_effect=AssertionError('Must not replay manual order'))
        bot.on_new_order(self.c,N(order=event))
        self.assertIsNone(bot.STORE.get('ABCD1234'));self.assertEqual(self.api.created,[])

    def test_terminal_historical_orders_never_pass_payment_check(self):
        order=self.real_steam()
        for status in ('CLOSED','REFUNDED','PARTIALLY_REFUNDED','UNPAID'):
            order.status=getattr(self.types.OrderStatuses,status)
            with self.subTest(status=status),self.assertRaises(ValueError):bot.full_order_data(self.c,order,order.id)
        self.assertEqual(self.api.created,[])

    def test_temporary_supplier_read_retries_before_post_and_then_completes(self):
        self.api.status='delivered';self.capture(products.catalog.key_rule(products.game()))
        self.api.key_product.side_effect=ApiFailure('network.error','Temporary offline')
        bot.process_ready(self.c)
        row=bot.STORE.get('ABCD1234');self.assertEqual(row['status'],'ready')
        self.assertIsNone(row['submitted_at']);self.assertEqual(self.api.created,[])
        bot.process_ready(self.c);self.assertEqual(self.api.created,[])
        self.api.key_product.side_effect=None;bot.STORE.set(row['id'],retry_after=0)
        bot.process_ready(self.c);self.assertEqual(len(self.api.created),1)
        self.assertEqual(bot.STORE.get(row['id'])['status'],'completed')

    def test_pre_purchase_read_retries_apply_to_every_product_kind(self):
        self.c=Cardinal(full_order(self.types))
        for i,kind in enumerate(('stars','steam_rub','game_key','service_topup','service_code')):
            oid='RETRY'+str(i)
            total=50 if kind=='stars' else 156 if kind=='steam_rub' else 1
            bot.STORE.insert_order(oid,12,'users-7-12','buyer','product',total,1,'100',captured_mode='live',kind=kind)
            bot.STORE.set(oid,status='preparing')
            self.assertTrue(bot.retry_before_purchase(self.c,bot.STORE.get(oid),TimeoutError()))
            self.assertEqual(bot.STORE.get(oid)['status'],'ready')
            self.assertIsNone(bot.STORE.get(oid)['submitted_at'])
        self.assertEqual(self.api.created,[])

    def test_checkout_steam_login_needs_no_second_buyer_message(self):
        order=self.real_steam(156)
        with bot.STORE.conn() as db:db.execute('DELETE FROM orders')
        order.player='login_from_checkout'
        event=shortcut(self.types);event.subcategory.id=1086
        bot.on_new_order(self.c,N(order=event))
        row=bot.STORE.get(order.id);self.assertEqual(row['status'],'ready')
        self.assertEqual(row['username'],'login_from_checkout')
        bot.process_ready(self.c)
        self.assertEqual(self.api.created,[('funpay-ABCD1234',156,'login_from_checkout')])

    def test_checkout_login_changed_before_purchase_blocks_supplier(self):
        order=self.real_steam(492)
        with bot.STORE.conn() as db:db.execute('DELETE FROM orders')
        order.player='login_from_checkout'
        event=shortcut(self.types);event.subcategory.id=1086
        bot.on_new_order(self.c,N(order=event));order.player='different_login'
        bot.process_ready(self.c)
        self.assertEqual(self.api.created,[])
        self.assertEqual(bot.STORE.get(order.id)['status'],'needs_review')

    def test_verified_region_labels_use_distinct_exact_codes(self):
        order=full_order(self.types,subcategory_id=1008)
        for label,code in [('СНГ','CIS'),('Россия','Russia'),('Европа','Europe'),('Global','Global')]:
            order.fields={'region2':self.types.LotField('region2',label,field_type_id='select')}
            self.assertEqual(bot.order_field_value(order,'region2'),code)
        order.subcategory.id=998
        order.fields['region2'].value='СНГ'
        self.assertEqual(bot.order_field_value(order,'region2'),'СНГ')

    def test_fourth_failed_read_holds_only_order_and_validation_error_never_retries(self):
        self.capture(products.catalog.key_rule(products.game()))
        self.api.key_product.side_effect=ApiFailure('api.error','Unavailable',status=503)
        for _ in range(4):
            bot.STORE.set('ABCD1234',retry_after=0);bot.process_ready(self.c)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'needs_review')
        self.assertFalse(bot.paused());self.assertEqual(self.api.created,[])
        row=bot.STORE.get('ABCD1234');bot.STORE.set(row['id'],status='preparing')
        self.assertFalse(bot.retry_before_purchase(self.c,row,ValueError('wrong product')))

    def test_unknown_purchase_outcome_is_never_resubmitted(self):
        self.capture(products.catalog.key_rule(products.game()))
        self.api.create_game_key.side_effect=UnknownOutcome('lost purchase response')
        bot.process_ready(self.c);bot.process_ready(self.c)
        self.assertEqual(self.api.create_game_key.call_count,1)
        self.assertEqual(bot.STORE.get('ABCD1234')['status'],'uncertain')
        self.assertFalse(bot.retry_before_purchase(self.c,bot.STORE.get('ABCD1234'),TimeoutError()))

    def test_capture_read_timeout_retries_without_duplicate_or_early_purchase(self):
        self.real_steam();order=self.c.account.order
        with bot.STORE.conn() as db:db.execute('DELETE FROM orders')
        self.c.account.get_order=Mock(side_effect=TimeoutError())
        event=shortcut(self.types);event.subcategory.id=1086
        bot.on_new_order(self.c,N(order=event));bot.on_new_order(self.c,N(order=event))
        self.assertEqual(self.c.account.get_order.call_count,1);self.assertFalse(bot.paused())
        key='capture_retry:ABCD1234';queued=json.loads(bot.STORE.get_meta(key));queued['next_at']=0
        bot.STORE.set_meta(key,json.dumps(queued));self.c.account.get_order.side_effect=None
        self.c.account.get_order.return_value=order
        bot.retry_order_reads(self.c);bot.retry_order_reads(self.c)
        self.assertEqual(bot.STORE.get(order.id)['status'],'awaiting_username')
        self.assertEqual(self.api.created,[])

    def test_completion_messages_include_confirmation_review_and_clear_key(self):
        for record in json.loads(FIXTURE.read_text(encoding='utf-8')):
            rule=record['rule'];name=record['name'];bot.CFG['lot_rules'][name]=rule
            row={'id':'DONE123','description':'rule:'+name,'kind':rule.get('kind','stars'),
                 'stars':156 if rule.get('kind')=='steam_rub' else rule['stars_per_unit'],
                 'username':'recipient','voucher':'AAAAA-BBBBB-CCCCC'}
            message=bot.completed_message(row)
            self.assertIn('отзыву',message);self.assertIn('подтверди выполнение',message)
            if row['kind'] in ('game_key','service_code'):self.assertIn('\n\nAAAAA-BBBBB-CCCCC\n\n',message)


class DurableNotificationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=Store(Path(self.temp.name)/'state.db')
        self.api=Mock();self.api.send_message.return_value=N(message_id=17)
        self.c=N(telegram=N(bot=self.api,authorized_users={123:{}}))
        self.module=N(STORE=self.store,LOG=logging.getLogger('test'),paused=lambda:True)
        self.env=patch.dict('os.environ',{'STEAMRU_OWNER_TG_ID':'123'});self.env.start()
        self.sound=patch.object(notices,'local_sound');self.sound.start()
    def tearDown(self):self.sound.stop();self.env.stop();self.temp.cleanup()
    def rows(self):
        with self.store.conn() as db:return [dict(r) for r in db.execute('SELECT * FROM owner_notices')]
    def test_new_order_notifies_owner_once_and_persists_across_restart(self):
        notices.notify(self.module,self.c,'Оплачен #PAY123');notices.notify(self.module,self.c,'Оплачен #PAY123')
        self.module.STORE=Store(self.store.path);notices.dispatch(self.module,self.c,now=100)
        notices.dispatch(self.module,self.c,now=1000)
        self.assertEqual(self.api.send_message.call_count,1)
        self.assertEqual(self.api.send_message.call_args.args[0],123)
        self.assertFalse(self.api.send_message.call_args.kwargs['disable_notification'])
        self.assertIn('funpay.com/orders/PAY123',self.api.send_message.call_args.args[1])
    def test_failed_delivery_remains_pending_then_recovers(self):
        notices.notify(self.module,self.c,'Оплачен #PAY123')
        self.api.send_message.side_effect=TimeoutError();notices.dispatch(self.module,self.c,now=100)
        self.assertEqual(self.rows()[0]['state'],'pending')
        self.api.send_message.side_effect=None;notices.dispatch(self.module,self.c,now=159)
        self.assertEqual(self.api.send_message.call_count,1)
        notices.dispatch(self.module,self.c,now=160);self.assertEqual(self.rows()[0]['state'],'sent')
    def test_alarm_reminders_and_ack_preserve_financial_state(self):
        notices.notify(self.module,self.c,'Ошибка #PAY123',urgent=True)
        for t in (100,159,160,459,460,1359,1360):notices.dispatch(self.module,self.c,now=t)
        self.assertEqual(self.api.send_message.call_count,4);self.assertEqual(self.api.pin_chat_message.call_count,1)
        self.assertEqual(notices.acknowledge(self.module,'PAY123'),1)
        notices.dispatch(self.module,self.c,now=9999);self.assertEqual(self.api.send_message.call_count,4)
        self.assertIsNone(self.store.get('PAY123'));self.assertEqual(self.store.today_spend(),0)
    def test_ack_during_delivery_cannot_reactivate_alarm(self):
        notices.notify(self.module,self.c,'Ошибка #PAY123',urgent=True)
        def delivered(*args,**kwargs):
            notices.acknowledge(self.module,'PAY123');return N(message_id=17)
        self.api.send_message.side_effect=delivered;notices.dispatch(self.module,self.c,now=100)
        self.assertEqual(self.rows()[0]['state'],'acknowledged')
    def test_only_authorized_owner_receives_messages(self):
        notices.notify(self.module,self.c,'Оплачен #PAY123');self.c.telegram.authorized_users={456:{}}
        notices.dispatch(self.module,self.c,now=100);self.api.send_message.assert_not_called()
        self.assertEqual(self.rows()[0]['state'],'pending')
    def test_supplier_completion_resolves_only_matching_alarm(self):
        notices.notify(self.module,self.c,'Ошибка #PAY123',urgent=True)
        notices.notify(self.module,self.c,'Ошибка #OTHER123',urgent=True)
        notices.resolve(self.module,'PAY123');notices.dispatch(self.module,self.c,now=100)
        self.assertEqual(self.api.send_message.call_count,1)
        self.assertIn('OTHER123',self.api.send_message.call_args.args[1])
    def test_message_markup_is_escaped(self):
        notices.notify(self.module,self.c,'Ошибка <script> #PAY123',urgent=True)
        notices.dispatch(self.module,self.c,now=100)
        self.assertIn('&lt;script&gt;',self.api.send_message.call_args.args[1])

    def test_order_notifications_take_priority_over_activity_backlog(self):
        notices.notify(self.module,self.c,'Activity update')
        notices.notify(self.module,self.c,'Оплачен #PAY123')
        notices.dispatch(self.module,self.c,now=100)
        self.assertIn('PAY123',self.api.send_message.call_args_list[0].args[1])

    def test_telegram_429_preserves_queue_and_global_retry_after(self):
        class Flood(Exception):result_json={'error_code':429,'parameters':{'retry_after':180}}
        notices.notify(self.module,self.c,'Оплачен #PAY123');notices.notify(self.module,self.c,'Activity update')
        self.api.send_message.side_effect=Flood()
        notices.dispatch(self.module,self.c,now=100)
        self.assertEqual(self.store.get_meta('owner_send_cooldown'),'280')
        notices.dispatch(self.module,self.c,now=279)
        self.assertEqual(self.api.send_message.call_count,1)
        self.api.send_message.side_effect=None;notices.dispatch(self.module,self.c,now=280)
        self.assertEqual(self.api.send_message.call_count,3)


class NativeCustomerMessagesTests(unittest.TestCase):
    def test_actual_cardinal_review_handler_uses_all_five_rating_texts(self):
        api=source_interfaces();cfg=configparser.ConfigParser(interpolation=None)
        customer_messages.configure(cfg)
        order=N(id='REVIEW123',review=N(stars=5,text='Review',reply=None))
        c=N(old_mode_enabled=False,MAIN_CFG=cfg,account=N(send_review=Mock()),get_order_from_object=lambda obj:order)
        class ImmediateThread:
            def __init__(self,target,**kw):self.target=target
            def start(self):self.target()
        namespace={'Thread':ImmediateThread,'logger':logging.getLogger('test'),
                   'NewMessageEvent':api.NewMessageEvent,'LastChatMessageChangedEvent':api.LastChatMessageChangedEvent,
                   'types':api,'cardinal_tools':N(format_order_text=lambda text,order:text),
                   'send_review_notification':Mock()}
        definitions(SOURCE/'handlers.py',['process_review_handler'],namespace)
        for stars in range(1,6):
            order.review.stars=stars
            message=N(type=api.MessageTypes.NEW_FEEDBACK,i_am_buyer=False,chat_id='users-7-12')
            namespace['process_review_handler'](c,N(message=message))
            self.assertEqual(c.account.send_review.call_args.args,
                             ('REVIEW123',customer_messages.REVIEW_TEXTS[stars]))
        self.assertEqual(c.account.send_review.call_count,5)

    def test_actual_confirm_handler_only_thanks_closed_order(self):
        api=source_interfaces();cfg=configparser.ConfigParser(interpolation=None)
        customer_messages.configure(cfg);calls=[]
        class ImmediateThread:
            def __init__(self,target,args=(),kwargs=None,**kw):self.target=target;self.args=args;self.kwargs=kwargs or {}
            def start(self):self.target(*self.args,**self.kwargs)
        namespace={'Thread':ImmediateThread,'types':api,'logger':logging.getLogger('test'),
                   'cardinal_tools':N(format_order_text=lambda text,order:text)}
        definitions(SOURCE/'handlers.py',['send_thank_u_message_handler'],namespace)
        c=N(MAIN_CFG=cfg,account=N(get_chat_by_name=lambda name:None),send_message=lambda *args,**kw:calls.append(args))
        order=N(id='DONE123',buyer_username='buyer',chat_id='users-7-12',status=api.OrderStatuses.PAID)
        namespace['send_thank_u_message_handler'](c,N(order=order));self.assertEqual(calls,[])
        order.status=api.OrderStatuses.CLOSED
        namespace['send_thank_u_message_handler'](c,N(order=order))
        self.assertEqual(calls[0][1],customer_messages.CONFIRMED_TEXT)

    def test_configuring_replies_preserves_funpay_and_telegram_secrets(self):
        cfg=configparser.ConfigParser(interpolation=None)
        cfg['FunPay']={'golden_key':'OFFLINE_FAKE_COOKIE'};cfg['Telegram']={'token':'OFFLINE_FAKE_TOKEN'}
        customer_messages.configure(cfg)
        self.assertEqual(cfg['FunPay']['golden_key'],'OFFLINE_FAKE_COOKIE')
        self.assertEqual(cfg['Telegram']['token'],'OFFLINE_FAKE_TOKEN')


if __name__=='__main__':unittest.main()
