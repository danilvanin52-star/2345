"""Offline compatibility checks against the supplied Cardinal source.

Set FPC_SOURCE to a Cardinal checkout to run these checks outside this workspace.
Only selected definitions are compiled from its AST: main/auth/network code is
never imported or executed.
"""
from __future__ import annotations

import ast
import datetime
import hashlib
import importlib.util
import json
import logging
import os
import re
import sys
import unittest
from contextlib import contextmanager
from decimal import Decimal
from enum import Enum
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch
from uuid import UUID


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "plugins"))
import steamru_stars as bot

SOURCE = Path(os.environ.get(
    "FPC_SOURCE", str(Path(__file__).resolve().parent / "fixtures/FunPayCardinal-0.1.17.15")))


def definitions(path, names, namespace):
    """Execute only named class/function definitions, preserving source bodies."""
    tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    selected = [node for node in tree.body
                if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in names]
    found = {node.name for node in selected}
    if found != set(names):
        raise AssertionError(f"Missing source definitions: {set(names) - found}")
    future = ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future] + selected, type_ignores=[]))
    exec(compile(module, str(path), "exec"), namespace)


def source_interfaces():
    if not (SOURCE / "cardinal.py").exists():
        raise unittest.SkipTest("Cardinal source absent; set FPC_SOURCE to the supplied checkout")
    namespace = {"Enum": Enum, "re": re, "datetime": datetime,
                 "__name__": "offline_cardinal_interfaces"}
    definitions(SOURCE / "FunPayAPI/common/enums.py",
                ["EventTypes", "MessageTypes", "OrderStatuses", "SubCategoryTypes", "Currency"], namespace)
    definitions(SOURCE / "FunPayAPI/common/utils.py", ["RegularExpressions"], namespace)
    names = ["BaseOrderInfo", "Message", "OrderShortcut", "Order", "Category", "SubCategory", "LotField"]
    definitions(SOURCE / "FunPayAPI/types.py", names, namespace)
    namespace["types"] = N(**{name: namespace[name] for name in names})
    definitions(SOURCE / "FunPayAPI/updater/events.py",
                ["BaseEvent", "InitialOrderEvent", "NewOrderEvent", "NewMessageEvent", "OrderStatusChangedEvent",
                 "LastChatMessageChangedEvent"],
                namespace)
    return N(**namespace)


def source_loader():
    """Use the actual loader/registration bodies, without Cardinal.__init__."""
    if not (SOURCE / "cardinal.py").exists():
        raise unittest.SkipTest("Cardinal source absent; set FPC_SOURCE to the supplied checkout")
    tree = ast.parse((SOURCE / "cardinal.py").read_text(encoding="utf-8-sig"))
    cardinal = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Cardinal")
    method_names = {"is_uuid_valid", "is_plugin", "load_plugin", "add_handlers_from_plugin"}
    selected = [node for node in cardinal.body if isinstance(node, ast.FunctionDef) and node.name in method_names]
    init = next(node for node in cardinal.body if isinstance(node, ast.FunctionDef) and node.name == "__init__")
    binding = next(node for node in ast.walk(init)
                   if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Attribute) and target.attr == "handler_bind_var_names"
                           for target in node.targets))
    hook_names = [key.value for key in binding.value.keys]
    mini = ast.ClassDef(name="CardinalLoader", bases=[], keywords=[], body=selected, decorator_list=[])
    module = ast.fix_missing_locations(ast.Module(
        body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), mini],
        type_ignores=[]))
    namespace = {"UUID": UUID, "importlib": importlib, "sys": sys,
                 "logger": logging.getLogger("offline_cardinal_loader"),
                 "_": lambda *args: str(args),
                 "Utils": N(exceptions=N(FieldNotExistsError=RuntimeError))}
    exec(compile(module, str(SOURCE / "cardinal.py"), "exec"), namespace)
    loader = namespace["CardinalLoader"]()
    loader.handler_bind_var_names = {name: [] for name in hook_names}
    return loader


@contextmanager
def working_directory(path):
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


def full_order(api, oid="ABCD1234", title="STEAMRU TG STARS 50", amount=1,
               seller_id=7, subcategory_id=999, chat_id="users-7-12", status=None):
    category = api.Category(9, "Telegram")
    subcategory = api.SubCategory(subcategory_id, "Stars", api.SubCategoryTypes.COMMON, category)
    return api.Order(
        id_=oid, status=status or api.OrderStatuses.PAID, subcategory=subcategory,
        server=None, side=None, fields={"summary": api.LotField("summary", {"ru": title, "en": title})},
        amount=amount, sum_=Decimal("90"), currency=api.Currency.RUB, player=None,
        buyer_id=12, buyer_username="buyer", seller_id=seller_id, seller_username="seller",
        chat_id=chat_id, review=None, order_secrets=[], locale="ru")


def shortcut(api, oid="ABCD1234", description="STEAMRU TG STARS 50", chat_id="users-7-12",
             status=None, dont_search_amount=False):
    category = api.Category(9, "Telegram")
    subcategory = api.SubCategory(999, "Stars", api.SubCategoryTypes.COMMON, category)
    return api.OrderShortcut(
        oid, description, 90, api.Currency.RUB, "buyer", 12, chat_id,
        status or api.OrderStatuses.PAID, datetime.datetime.now(), "Stars", subcategory,
        "<div>offline fixture</div>", dont_search_amount=dont_search_amount)


def actual_delivery_test_event(api):
    """Build ADTEST using Cardinal's actual !автовыдача handler."""
    source = SOURCE / "handlers.py"
    tree = ast.parse(source.read_text(encoding="utf-8-sig"))
    template = next(node.value for node in tree.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == "ORDER_HTML_TEMPLATE"
                            for target in node.targets))
    namespace = {"OrderShortcut": api.OrderShortcut, "NewOrderEvent": api.NewOrderEvent,
                 "LastChatMessageChangedEvent": api.LastChatMessageChangedEvent,
                 "Currency": api.Currency, "types": api, "datetime": datetime.datetime,
                 "ORDER_HTML_TEMPLATE": ast.literal_eval(template),
                 "logger": logging.getLogger("offline_cardinal_delivery")}
    definitions(source, ["test_auto_delivery_handler"], namespace)
    captured = []
    cardinal = N(old_mode_enabled=False, delivery_tests={"offline-key": "STEAMRU TG STARS 50"},
                 new_order_handlers=[], run_handlers=lambda handlers, args: captured.append(args[1]))
    message = api.Message(1, "!автовыдача offline-key", "users-7-12", "buyer", 7,
                          "buyer", 12, "", determine_msg_type=False)
    namespace["test_auto_delivery_handler"](cardinal, api.NewMessageEvent("offline", message))
    if len(captured) != 1:
        raise AssertionError("The actual Cardinal test handler did not emit one event")
    return captured[0]


class CardinalCompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api = source_interfaces()

    def test_actual_cardinal_loader_accepts_plugin_and_skips_helper(self):
        loader = source_loader()
        with working_directory(ROOT), patch("socket.socket", side_effect=AssertionError("No network in loader")):
            self.assertTrue(loader.is_plugin("steamru_stars.py"))
            self.assertFalse(loader.is_plugin("steamru_stars_engine.py"))
            plugin, fields = loader.load_plugin("steamru_stars.py")
        self.assertEqual(fields["UUID"], bot.UUID)
        self.assertTrue(loader.is_uuid_valid(fields["UUID"]))
        self.assertFalse(loader.is_uuid_valid("not-a-uuid"))
        self.assertEqual(fields["VERSION"], bot.VERSION)
        self.assertTrue(fields["NAME"])
        self.assertTrue(fields["DESCRIPTION"])
        loader.add_handlers_from_plugin(plugin, fields["UUID"])
        expected = ("BIND_TO_PRE_INIT", "BIND_TO_POST_INIT", "BIND_TO_POST_START", "BIND_TO_PRE_STOP",
                    "BIND_TO_INIT_ORDER", "BIND_TO_NEW_ORDER", "BIND_TO_NEW_MESSAGE", "BIND_TO_ORDER_STATUS_CHANGED")
        for name in expected:
            with self.subTest(hook=name):
                functions = loader.handler_bind_var_names[name]
                self.assertTrue(functions)
                self.assertTrue(all(func.plugin_uuid == bot.UUID for func in functions))
        self.assertIs(loader.handler_bind_var_names["BIND_TO_INIT_ORDER"][0], plugin.on_initial_order)
        self.assertIsNone(plugin.STORE, "Loading must not start or initialize the plugin")

    def test_bundled_source_fixtures_match_recorded_original_hashes(self):
        fixtures = Path(__file__).resolve().parent / "fixtures/FunPayCardinal-0.1.17.15"
        manifest = json.loads((fixtures / "provenance.json").read_text(encoding="utf-8-sig"))
        self.assertEqual(manifest["version"], "0.1.17.15")
        self.assertEqual(len(manifest["hashes_sha256"]), 6)
        for relative, expected in manifest["hashes_sha256"].items():
            with self.subTest(file=relative):
                self.assertEqual(hashlib.sha256((fixtures / relative).read_bytes()).hexdigest(), expected)

    def test_actual_order_has_sum_and_localized_short_description(self):
        order = full_order(self.api)
        self.assertEqual(order.sum, Decimal("90"))
        self.assertEqual(order.short_description, "STEAMRU TG STARS 50")
        self.assertFalse(hasattr(order, "price"))
        self.assertFalse(hasattr(order, "description"))
        order.locale = "en"
        order.fields["summary"].value = {"ru": "STEAMRU TG STARS 50"}
        self.assertEqual(order.short_description, "STEAMRU TG STARS 50")

    def test_actual_event_contract_and_string_chat_id(self):
        order = shortcut(self.api)
        self.assertEqual(order.amount, 1)
        self.assertEqual(order.chat_id, "users-7-12")
        new = self.api.NewOrderEvent("offline", order)
        initial = self.api.InitialOrderEvent("offline", order)
        changed = self.api.OrderStatusChangedEvent("offline", order)
        self.assertIs(new.order, order)
        self.assertIs(initial.order, order)
        self.assertIs(changed.order, order)
        self.assertEqual(new.type, self.api.EventTypes.NEW_ORDER)
        self.assertEqual(initial.type, self.api.EventTypes.INITIAL_ORDER)

    def test_actual_delivery_command_emits_unpaid_synthetic_adtest(self):
        event = actual_delivery_test_event(self.api)
        self.assertEqual(event.order.id, "ADTEST")
        self.assertEqual(event.order.price, 0.0)
        self.assertEqual(event.order.buyer_id, 0)
        self.assertEqual(event.order.currency, self.api.Currency.UNKNOWN)
        self.assertIsNone(event.order.subcategory)


if __name__ == "__main__":
    unittest.main()
