"""Offline buyer policy and transparent editorial ranking tests."""
import tempfile
import unittest
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
from aisklad_shop.catalog import product_id
from aisklad_shop.merchandising import apply_buyer_policy, brand_of, item_brand, qualified_title, ranked
from aisklad_shop.service import ShopError, ShopService
from aisklad_shop.store import ShopStore


class DemoSupplier:
    """Fictitious test products only, never shipped as a production catalogue."""
    names = [
        ("steam", "Steam"), ("telegram-stars", "Telegram Stars"), ("telegram-premium", "Telegram Premium"),
        ("roblox", "Roblox"), ("pubg", "PUBG Mobile"), ("mobile-legends", "Mobile Legends"),
        ("fortnite", "Fortnite"), ("minecraft", "Minecraft"), ("genshin", "Genshin Impact"),
        ("honkai-star-rail", "Honkai Star Rail"), ("valorant", "Valorant"), ("playstation", "PlayStation"),
        ("xbox", "Xbox"), ("blizzard", "Blizzard Battle.net"), ("discord", "Discord Nitro"),
        ("spotify", "Spotify"), ("afk-journey", "AFK Journey"), ("unknown", "Abrand Unfamiliar")]
    def __init__(self): self.posts = []; self.gets = []; self.rub_min = 20; self.rub_max = 50000; self.kzt_min = 10; self.kzt_max = 200000
    def brands(self): return [{"id": slug, "name": title} for slug, title in self.names]
    def services(self): return iter([{"id": slug, "name": title, "brand": slug} for slug, title in self.names])
    def products(self, service):
        self.gets.append(service)
        title = dict(self.names)[service]
        if service == "steam":
            rows = [{"product_id": 1, "name": "RUB", "price_usd": ".01185", "min_count": self.rub_min, "max_count": self.rub_max, "fields": []},
                    {"product_id": 9, "name": "KZT", "price_usd": ".0023", "min_count": self.kzt_min, "max_count": self.kzt_max, "fields": []},
                    {"product_id": 10, "name": "USD", "price_usd": "1", "min_count": 1, "max_count": 100, "fields": []}]
        elif service == "telegram-stars":
            rows = [{"product_id": 55, "name": "Stars", "price_usd": ".0152", "min_count": 50, "max_count": 999999, "fields": []}]
        else:
            rows = [{"product_id": 100 + next(i for i, row in enumerate(self.names) if row[0] == service), "name": "3150 монет" if service == "afk-journey" else "80 единиц", "price_usd": "2", "min_count": 1, "max_count": 1, "fields": []}]
        return {"service": service, "service_name": title, "type": "topup", "requires_account": True, "products": rows}
    def keys(self): return iter([{"app_id": 1, "name": "A obscure indie", "price_usd": 3}, {"app_id": 2, "name": "Cyberpunk 2077", "price_usd": 5}, {"app_id": 3, "name": "Elden Ring", "price_usd": 6}, {"app_id": 4, "name": "The Witcher 3", "price_usd": 2}, {"app_id": 5, "name": "Astral Unfamiliar Game", "price_usd": 4}])
    def gifts(self): return iter([{"app_id": 2, "name": "Cyberpunk 2077"}, {"app_id": 3, "name": "Elden Ring"}])
    def key_card(self, app): return {"app_id": app, "name": {1: "A obscure indie", 2: "Cyberpunk 2077", 3: "Elden Ring", 4: "The Witcher 3", 5: "Astral Unfamiliar Game"}[app], "variants": [{"option_id": app * 10, "name": "Standard Edition", "content_kind": "game", "price_usd": 5, "stock": 3, "min_quantity": 1, "max_quantity": 3, "region": "GLOBAL", "countries": [], "platform": "steam"}]}
    def gift_card(self, app): return {"app_id": app, "name": "Cyberpunk 2077" if app == 2 else "Elden Ring", "editions": [{"edition": "base", "name": "Standard", "regions": [{"code": "CIS", "countries": ["KZ"], "price_usd": 5}, {"code": "EU", "countries": ["DE"], "price_usd": 6}]}]}
    def check_account(self, service, account): return True
    def balance(self): return Decimal("100")
    def submit(self, *args, **kwargs): self.posts.append(args); raise AssertionError("Test must not purchase")


class CataloguePolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.store = ShopStore(Path(self.temp.name) / "shop.sqlite3")
        self.supplier = DemoSupplier()
        self.now = 1800000000
        self.service = ShopService(self.store, self.supplier, {"enabled": True, "fixed_cost_rub": ".25", "payment_fee_pct": "3", "target_margin_pct": ".4"}, rate_provider=lambda: {"rub_per_usd": "87.417785234899328859", "observed_at": self.now}, clock=lambda: self.now)
        self.service.sync_catalog()

    def test_steam_first_root_then_curated_brands_not_alphabetical(self):
        rows = self.service.categories(page_size=50)["items"]
        self.assertEqual("brand:steam", rows[0]["id"])
        self.assertLess(next(i for i, r in enumerate(rows) if r["id"] == "brand:roblox"), next(i for i, r in enumerate(rows) if r["id"] == "brand:unknown"))
        self.assertEqual(len(rows), len({r["id"] for r in rows}))

    def test_steam_only_rub_kzt_even_with_old_cached_usd(self):
        rows = self.service.list_products("steam")["items"]
        self.assertEqual([1, 9], [p["supplier_product_id"] for p in rows])
        usd = product_id("service", "steam", 10)
        with self.assertRaises(ShopError): self.service.product(usd)
        self.assertTrue(self.service.catalog.get(usd))  # retained internally for paid recovery
        for query in ("Steam", "USD", "steam dollars", "стим"):
            self.assertFalse(any(p.get("supplier_product_id") == 10 and p.get("service") == "steam" for p in self.service.list_products(query=query)["items"]))

    def test_integer_min100_both_currencies_max_actual_api(self):
        for pid in (1, 9):
            item = self.service.product(product_id("service", "steam", pid))
            self.assertEqual(100, item["min_quantity"])
            self.assertEqual(self.supplier.rub_max if pid == 1 else self.supplier.kzt_max, item["max_quantity"])
            for amount in (99, "100.5", item["max_quantity"] + 1):
                with self.assertRaises(ShopError): self.service.quote(1, item["id"], amount, {"account": "steam_login"})
            self.assertEqual(156, self.service.quote(1, item["id"], 156, {"account": "steam_login"})["quantity"])
            self.assertEqual(492, self.service.quote(1, item["id"], 492, {"account": "steam_login"})["quantity"])

    def test_higher_supplier_minimum_preserved_and_no_hardcoded500(self):
        self.supplier.kzt_min = 600
        item = self.service.product(product_id("service", "steam", 9))
        self.assertEqual(600, item["min_quantity"])
        self.assertEqual(10000, self.service.quote(1, item["id"], 10000, {"account": "steam_login"})["quantity"])

    def test_perunit_fixedfee_minimumtotal_decimal_precision(self):
        item = self.service.product(product_id("service", "steam", 1))
        rate = Decimal("87.417785234899328859"); divisor = Decimal(".966")
        variable = Decimal(".01185") * rate / divisor
        fixed = Decimal(".25") / divisor
        self.assertEqual(str(variable.quantize(Decimal(".000001"), rounding=ROUND_CEILING)), item["unit_price_rub"])
        self.assertEqual(str(fixed.quantize(Decimal(".000001"), rounding=ROUND_CEILING)), item["fixed_charge_rub"])
        expected = (variable * 100 + fixed).quantize(Decimal(".01"), rounding=ROUND_CEILING)
        self.assertEqual(str(expected), item["min_total_rub"])
        exact = self.service.quote(1, item["id"], 156, {"account": "steam_login"})
        self.assertEqual(str((variable * 156 + fixed).quantize(Decimal(".01"), rounding=ROUND_CEILING)), exact["total_rub"])
        self.assertNotEqual(Decimal(item["min_total_rub"]) * 156, Decimal(exact["total_rub"]))

    def test_bare_denominations_gain_real_service_identity(self):
        item = self.service.list_products("afk-journey")["items"][0]
        self.assertIn("AFK Journey", item["title"])
        self.assertIn("3150", item["title"])
        game = self.service.list_products("keys")["items"][0]
        variant = self.service.product(game["id"])["variants"][0]
        self.assertIn(game["title"], variant["title"])

    def test_familiar_games_curated_but_unknown_exact_query_wins(self):
        items = self.service.list_products("keys")["items"]
        self.assertEqual("Elden Ring", items[0]["title"])
        found = self.service.list_products("keys", query="Astral Unfamiliar")["items"]
        self.assertEqual("Astral Unfamiliar Game", found[0]["title"])
        self.assertEqual(5, self.service.list_products("keys")["total"])

    def test_translit_typos_and_cyrillic_game_query_real_matches(self):
        for query in ("робуксы", "robloxx", "роблоукс", "rblx"):
            items = self.service.list_products(query=query)["items"]
            self.assertTrue(items, query)
            self.assertEqual("roblox", item_brand(items[0]))
        self.assertIn("The Witcher 3", [p["title"] for p in self.service.list_products(query="Ведьмак")["items"]])

    def test_hidden_usd_old_paid_validation_is_not_buyer_gate(self):
        item = self.service.catalog.refresh(product_id("service", "steam", 10))
        with self.assertRaises(ShopError): self.service._validate(item, 2, {"account": "steam_login"})
        qty, _ = self.service._validate(item, 2, {"account": "steam_login"}, for_paid=True)
        self.assertEqual(2, qty)

    def test_global_featured_variety_does_not_hide_any_denominations(self):
        base = self.service.catalog.get(product_id("service", "roblox", 103))
        self.assertIsNotNone(base)
        clones = [dict(base, id="denomination" + str(i), title="Roblox · " + str(i) + " Robux") for i in range(40)]
        self.service.catalog.put(clones)
        result = self.service.list_products(page_size=24)
        self.assertEqual([1, 9], [p["supplier_product_id"] for p in result["items"][:2]])
        self.assertGreaterEqual(len({p.get("service") or p.get("app_id") for p in result["items"]}), 15)
        self.assertGreater(result["total"], 50)


if __name__ == "__main__": unittest.main()
