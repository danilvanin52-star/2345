import os
import sys
import tempfile
import unittest
import threading
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "plugins"))
from steamru_stars_engine import (
    sign, finances, parse_reply, username_or_none, Store, SteamClient, ApiFailure,
    UnknownOutcome, timestamp_fresh, currency_code, status_name, money, D,
    strict_count, effective_exchange_rate)


class FakeResponse:
    def __init__(self, payload, status=200, headers=None):
        self.payload, self.status_code, self.headers=payload,status,headers or {}
    def json(self): return self.payload


class RecordingSession:
    def __init__(self, result): self.result=result; self.calls=[]
    def request(self,*args,**kwargs):
        self.calls.append((args,kwargs))
        if isinstance(self.result,Exception): raise self.result
        return self.result


class Basics(unittest.TestCase):
    def test_sign_known(self):
        import hashlib,hmac
        s=sign('supersecret','GET','/balance',42,'unique',b'')
        raw='GET\n/balance\n42\nunique\n'+hashlib.sha256(b'').hexdigest()
        self.assertEqual(s,hmac.new(b'supersecret',raw.encode(),hashlib.sha256).hexdigest())
    def test_profits(self):
        x=finances('75.77','0.0152',50,'88.45','3', '0')
        self.assertEqual(money(x['cost']),Decimal('67.22'))
        self.assertEqual(money(x['profit']),Decimal('6.27'))
    def test_no_profit(self):
        x=finances('60','0.0152',50,'88.45','3','0.25')
        self.assertLess(x['profit'],0)
    def test_username_parsing(self):
        self.assertEqual(username_or_none('@Buyer_123'),'Buyer_123')
        self.assertIsNone(username_or_none('my nickname'))
        self.assertEqual(parse_reply('@buyer123 #FP-AB12'),('buyer123','FP-AB12'))
        self.assertIsNone(parse_reply('@buyer123'))
        self.assertIsNone(parse_reply('my other text @buyer #FP-AB12'))
    def test_rate(self):
        self.assertTrue(timestamp_fresh(datetime.now(timezone.utc).isoformat(),24))
        self.assertFalse(timestamp_fresh((datetime.now(timezone.utc)-timedelta(days=2)).isoformat(),24))
        self.assertFalse(timestamp_fresh('yesterday',24))
    def test_currency(self):
        class Cur: code='rub'
        self.assertEqual(currency_code(Cur()),'RUB')
        class S: name='PAID'
        self.assertEqual(status_name(S()),'PAID')


class ApiClientTests(unittest.TestCase):
    def test_account_health_check_only_get(self):
        sess=RecordingSession(FakeResponse({'ok':True,'data':{'name':'Demo','balance':1.20}}))
        api=SteamClient('rk_test','secret',session=sess)
        self.assertEqual(api.account()['name'],'Demo')
        (args, kwargs) = sess.calls[0]
        self.assertEqual(args[0],'GET')
        self.assertEqual(args[1],'https://api.steam.ru/api/reseller/v1/account')
        self.assertNotIn('Idempotency-Key',kwargs['headers'])
    def test_balance_headers_and_path(self):
        sess=RecordingSession(FakeResponse({'ok':True,'data':{'balance': '12.5'}}))
        api=SteamClient('rk_test','secret',session=sess)
        self.assertEqual(api.balance(),Decimal('12.5'))
        args,kwargs=sess.calls[0]
        self.assertEqual(args[0],'GET')
        self.assertEqual(args[1],'https://api.steam.ru/api/reseller/v1/balance')
        headers=kwargs['headers']
        self.assertIn('X-Reseller-Signature', headers)
        self.assertIn('X-Reseller-Nonce',headers)
        self.assertNotIn('Content-Type',headers)
    def test_get_query_signed_exact(self):
        sess=RecordingSession(FakeResponse({'ok':True,'data':{'account':'test123','valid':True}}))
        api=SteamClient('rk_test','secret',session=sess)
        self.assertTrue(api.check_username('test123'))
        args,kwargs=sess.calls[0]
        self.assertTrue(args[1].endswith('/check/telegram-username?account=test123'))
        from steamru_stars_engine import sign
        h=kwargs['headers']
        expected=sign('secret','GET','/api/reseller/v1/check/telegram-username?account=test123',int(h['X-Reseller-Timestamp']),h['X-Reseller-Nonce'],b'')
        self.assertEqual(expected,h['X-Reseller-Signature'])
    def test_create_body_idempotent(self):
        u='c9152188-832f-44e6-ab26-50fbde7467fd'
        sess=RecordingSession(FakeResponse({'ok':True,'data':{'uuid':u, 'product_id':55, 'status':'created'}},201))
        api=SteamClient('rk_test','secret',session=sess,allow_purchases=True)
        self.assertEqual(api.create('funpay-ABC123','telegram-stars',55,50,'recipient123')['uuid'],u)
        args,kwargs=sess.calls[0]
        self.assertEqual(args[0],'POST')
        self.assertEqual(kwargs['headers']['Idempotency-Key'],'funpay-ABC123')
        self.assertEqual(kwargs['headers']['Content-Type'],'application/json')
        import json
        body=json.loads(kwargs['data'])
        self.assertEqual(body['product_count'],50)
        self.assertEqual(body['external_order_id'],'funpay-ABC123')
        self.assertEqual(body['account'],'recipient123')
        self.assertNotIn('fields',body)
        expected=sign('secret','POST','/api/reseller/v1/orders',int(kwargs['headers']['X-Reseller-Timestamp']),kwargs['headers']['X-Reseller-Nonce'],kwargs['data'])
        self.assertEqual(kwargs['headers']['X-Reseller-Signature'],expected)
    def test_timeout_after_post_is_uncertain(self):
        sess=RecordingSession(TimeoutError('lost'))
        api=SteamClient('rk_test','secret',session=sess,allow_purchases=True)
        with self.assertRaises(UnknownOutcome):
            api.create('funpay-ABC123','telegram-stars',55,50,'recipient123')
    def test_get_network_is_retryable_error(self):
        sess=RecordingSession(TimeoutError('lost'))
        api=SteamClient('rk_test','secret',session=sess)
        with self.assertRaises(ApiFailure): api.balance()
    def test_reject_catalog_ambiguous(self):
        sess=RecordingSession(FakeResponse({'ok':True,'data':{'service':'telegram-stars','type':'topup','requires_account':True,'products':[
            {'product_id':1,'min_count':50,'max_count':99999,'fields':[], 'price_usd':0.0152},
            {'product_id':2,'min_count':50,'max_count':99999,'fields':[], 'price_usd':0.0180}]}}))
        api=SteamClient('rk_test','secret',session=sess)
        with self.assertRaises(ApiFailure): api.product('telegram-stars',None,50)
    def test_reject_required_fields(self):
        sess=RecordingSession(FakeResponse({'ok':True,'data':{'service':'telegram-stars','type':'topup','requires_account':True,'products':[
            {'product_id':1,'min_count':50,'max_count':99999,'fields':[{'key':'region','type':'select'}], 'price_usd':0.0152}]}}))
        api=SteamClient('rk_test','secret',session=sess)
        with self.assertRaises(ApiFailure): api.product('telegram-stars',1,50)
    def test_error_429(self):
        sess=RecordingSession(FakeResponse({'ok':False,'error':{'code':'too_many_requests','message':'slow'}},429, {'Retry-After':'12'}))
        api=SteamClient('rk_test','secret',session=sess)
        with self.assertRaises(ApiFailure) as e: api.balance()
        self.assertEqual(e.exception.status,429)
        self.assertEqual(e.exception.retry_after,'12')


class Db(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory()
        self.db=Store(Path(self.d.name)/'items.sqlite3')
    def tearDown(self):self.d.cleanup()
    def add(self, oid='ABC123'):
        return self.db.insert_order(oid,'12','33','buyer','STEAMRU TG STARS 50',50,1,'75.77')
    def test_unique_order(self):
        self.assertTrue(self.add())
        self.assertFalse(self.add())
        self.assertEqual(len(self.db.rows()),1)
    def test_username_auth(self):
        self.add()
        self.assertFalse(self.db.set_username('ABC123','22','33','buyer123'))
        self.assertFalse(self.db.set_username('ABC123','12','999','buyer123'))
        self.assertTrue(self.db.set_username('ABC123','12','33','buyer123'))
        self.assertFalse(self.db.set_username('ABC123','12','33','another'))
        self.assertEqual(self.db.get('ABC123')['status'],'ready')
    def test_claim_once(self):
        self.add();self.db.set_username('ABC123','12','33','buyer123')
        a=self.db.take_ready();b=self.db.take_ready()
        self.assertEqual(a['id'],'ABC123')
        self.assertIsNone(b)
    def test_persistent(self):
        self.add()
        again=Store(self.db.path)
        self.assertIsNotNone(again.get('ABC123'))
    def test_daily_spend(self):
        self.add()
        self.db.set('ABC123',status='submitting',quoted_usd='0.76')
        self.db.set('ABC123',status='supplier_pending')
        self.assertEqual(self.db.today_spend(),Decimal('0.76'))
    def test_daily_spend_persists_after_status_change(self):
        self.add()
        self.db.set('ABC123', status='submitting', quoted_usd='1.31')
        first=self.db.get('ABC123')['submitted_at']
        self.db.set('ABC123', status='needs_review', supplier_status='error')
        self.db.set('ABC123', status='refunded', supplier_status='refunded')
        self.assertEqual(self.db.get('ABC123')['submitted_at'],first)
        self.assertEqual(self.db.today_spend(),Decimal('1.31'))
    def test_migration_old_db_preserves_order(self):
        from sqlite3 import connect
        path=Path(self.d.name)/'old.sqlite3'
        with closing(connect(path)) as c:
            c.execute("""CREATE TABLE orders (id TEXT PRIMARY KEY, quoted_usd TEXT, changed_at TEXT,
                status TEXT NOT NULL DEFAULT 'submitting', details TEXT)""")
            c.execute("INSERT INTO orders(id,quoted_usd,changed_at) VALUES ('a','0.76',CURRENT_TIMESTAMP)")
            c.commit()
        old=Store(path)
        with old.conn() as c:
            r=c.execute("SELECT submitted_at FROM orders WHERE id='a'").fetchone()
            self.assertIsNotNone(r['submitted_at'])
        self.assertEqual(old.today_spend(), Decimal('0.76'))
    def test_no_wrong_status_transition(self):
        self.add()
        self.db.set('ABC123',status='submitting')
        self.assertFalse(self.db.set_username('ABC123','12','33','different'))
    def test_sql_safe(self):
        self.add()
        with self.assertRaises(ValueError):
            self.db.set('ABC123',id='new')

class SafetyTransitions(unittest.TestCase):
    def test_atomic_transition_refunded_while_preparing(self):
        with tempfile.TemporaryDirectory() as d:
            s=Store(Path(d)/'x.db')
            s.insert_order('AA2222','1','2','buyer','lot',50,1,'76')
            s.set('AA2222',status='cancelled')
            self.assertFalse(s.set_if_status('AA2222','preparing',status='submitting'))
            self.assertEqual(s.get('AA2222')['status'],'cancelled')

    def test_transition_only_once(self):
        with tempfile.TemporaryDirectory() as d:
            s=Store(Path(d)/'x.db')
            s.insert_order('AA2222','1','2','buyer','lot',50,1,'76')
            s.set('AA2222',status='preparing')
            self.assertTrue(s.set_if_status('AA2222','preparing',status='submitting'))
            self.assertFalse(s.set_if_status('AA2222','preparing',status='submitting'))


class NumericSafety(unittest.TestCase):
    def test_nonfinite_is_rejected(self):
        for value in ('NaN', 'sNaN', 'Infinity', '-Infinity', float('nan'), float('inf')):
            with self.subTest(value=str(value)), self.assertRaises(ValueError):
                D(value)

    def test_count_is_integral_and_bounded(self):
        self.assertEqual(strict_count('50.0', 50, 150), 50)
        for value in ('49', '151', '50.5', True, 'NaN', '-1'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                strict_count(value, 50, 150)

    def test_effective_rate_uses_amount_actually_credited(self):
        self.assertEqual(effective_exchange_rate('900', '10'), Decimal('90'))
        self.assertEqual(effective_exchange_rate('900', '9'), Decimal('100'))
        for paid, credited in ((0, 10), (100, 0), (-100, 10), (100, -1)):
            with self.subTest(paid=paid, credited=credited), self.assertRaises(ValueError):
                effective_exchange_rate(paid, credited)

    def test_margin_refuses_invalid_financial_inputs(self):
        defaults = ['100', '0.01', 50, '90', '3', '0.25']
        for index, value in ((0, 0), (1, 0), (2, '50.5'), (3, -90), (4, -1), (4, 100), (5, -1)):
            values = list(defaults)
            values[index] = value
            with self.subTest(index=index, value=value), self.assertRaises(ValueError):
                finances(*values)

    def test_telegram_username_matches_documented_steamru_format(self):
        self.assertEqual(username_or_none('@Buyer_123'), 'Buyer_123')
        for value in ('abcd', '1buyer', '_buyer'):
            self.assertEqual(username_or_none(value), value)
            self.assertEqual(parse_reply('@' + value + ' #ABC123'), (value, 'ABC123'))
        for value in ('abc', 'buyer-name', 'a' * 33):
            with self.subTest(value=value):
                self.assertIsNone(username_or_none(value))
                self.assertIsNone(parse_reply('@' + value + ' #ABC123'))


class ExplicitPurchaseSafety(unittest.TestCase):
    def make(self, allow=False, response=None):
        self.session = RecordingSession(response or FakeResponse({'ok': True, 'data': {'uuid': 'abc'}}))
        return SteamClient('rk_test', 'private_test_secret', session=self.session, allow_purchases=allow)

    def test_all_mutating_requests_blocked_by_default(self):
        api = self.make()
        for method in ('POST', 'post', 'PUT', 'PATCH', 'DELETE'):
            with self.subTest(method=method), self.assertRaises(PermissionError):
                api.request(method, '/orders', payload={})
        with self.assertRaises(PermissionError):
            api.create('funpay-ABC123', 'telegram-stars', 55, 50, 'buyer123')
        self.assertEqual(self.session.calls, [])

    def test_only_explicit_boolean_true_unlocks(self):
        api = self.make(allow='true')
        with self.assertRaises(PermissionError):
            api.request('POST', '/orders', payload={})
        self.assertEqual(self.session.calls, [])

    def test_create_validation_precedes_network(self):
        api = self.make(allow=True)
        defaults = ['funpay-ABC123', 'telegram-stars', 55, 50, 'buyer123']
        for index, value in ((0, 'arbitrary-id'), (0, 'funpay-../oops'), (1, 'steam'),
                             (2, 54), (2, '55.5'), (3, 49), (3, 151), (3, 50.5), (4, 'buyer-name')):
            values = list(defaults)
            values[index] = value
            with self.subTest(index=index, value=value), self.assertRaises(ValueError):
                api.create(*values)
        self.assertEqual(self.session.calls, [])

    def test_untrusted_base_urls_are_rejected(self):
        session = RecordingSession(FakeResponse({}))
        for url in ('http://api.steam.ru/api/reseller/v1', 'https://evil.invalid/api/reseller/v1',
                    'https://api.steam.ru.evil.invalid/api/reseller/v1',
                    'https://user:password@api.steam.ru/api/reseller/v1',
                    'https://api.steam.ru:444/api/reseller/v1',
                    'https://api.steam.ru/api/reseller/v1?redirect=evil',
                    'https://api.steam.ru/unrelated', 'https://api.steam.ru:bad/api/reseller/v1'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                SteamClient('key', 'secret', base_url=url, session=session)
        self.assertEqual(session.calls, [])

    def test_response_text_cannot_leak_secrets(self):
        api = self.make(response=FakeResponse({'ok': False, 'error': {
            'code': 'private_test_secret', 'message': 'api_key=rk_test secret=private_test_secret'}}, 403))
        with self.assertRaises(ApiFailure) as caught:
            api.account()
        self.assertNotIn('private_test_secret', str(caught.exception))
        self.assertNotIn('rk_test', str(caught.exception))
        self.assertEqual(caught.exception.status, 403)

    def test_ambiguous_post_response_is_not_retryable(self):
        for payload in ([], {'ok': True}, {'ok': True, 'data': {}}):
            api = self.make(allow=True, response=FakeResponse(payload))
            with self.subTest(payload=payload), self.assertRaises(UnknownOutcome):
                api.create('funpay-ABC123', 'telegram-stars', 55, 50, 'buyer123')
            self.assertEqual(len(self.session.calls), 1)


class PersistentQueueSafety(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'orders.db')

    def tearDown(self):
        self.temp.cleanup()

    def add(self, oid, status='ready', uuid=None):
        self.store.insert_order(oid, '1', '2', 'buyer', 'lot', 50, 1, '80', captured_mode='live')
        self.store.set(oid, status=status, supplier_uuid=uuid)

    def test_concurrent_claim_same_order_is_once(self):
        self.add('ABC123')
        second = Store(self.store.path)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda s: s.take_ready(), (self.store, second)))
        self.assertEqual(sum(result is not None for result in results), 1)

    def test_concurrent_budget_reservation_cannot_overspend(self):
        self.add('ABC123', 'preparing')
        self.add('ABC124', 'preparing')
        second = Store(self.store.path)
        barrier = threading.Barrier(2)
        def reserve(args):
            store, oid = args
            barrier.wait(timeout=5)
            try:
                return store.reserve_submission(oid, '0.76', '1', '1')
            except ValueError:
                return False
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(reserve, ((self.store, 'ABC123'), (second, 'ABC124'))))
        self.assertEqual(results.count(True), 1)
        self.assertEqual(self.store.today_spend(), Decimal('0.76'))

    def test_cancelled_order_cannot_reserve_budget(self):
        self.add('ABC123', 'cancelled')
        self.assertFalse(self.store.reserve_submission('ABC123', '.76', '1', '1'))
        self.assertEqual(self.store.today_spend(), Decimal(0))

    def test_reservation_is_persistent_and_single_order_is_once(self):
        self.add('ABC123', 'preparing')
        self.assertTrue(self.store.reserve_submission('ABC123', '.76', '1', '1', revenue_rub='80'))
        again = Store(self.store.path)
        self.assertFalse(again.reserve_submission('ABC123', '.76', '1', '1'))
        self.assertEqual(again.today_spend(), Decimal('.76'))
        recovered = again.recover_interrupted()
        self.assertEqual(len(recovered), 1)
        self.assertEqual(again.get('ABC123')['status'], 'uncertain')
        self.assertIsNone(again.take_ready())
        self.assertEqual(again.today_spend(), Decimal('.76'))

    def test_budget_uses_actual_overcharge_and_does_not_release_refunds(self):
        self.add('ABC123', 'preparing')
        self.assertTrue(self.store.reserve_submission('ABC123', '.76', '2', '2', applied_rate='90'))
        self.store.set('ABC123', status='refunded', charged_usd='1.25')
        self.assertEqual(self.store.today_spend(), Decimal('1.25'))
        self.assertEqual(self.store.get('ABC123')['applied_rate'], '90')
        self.add('ABC124', 'preparing')
        with self.assertRaises(ValueError):
            self.store.reserve_submission('ABC124', '.76', '2', '2')
        self.assertEqual(self.store.get('ABC124')['status'], 'preparing')

    def test_refund_zero_charge_does_not_release_peak_budget(self):
        self.add('ABC123', 'preparing')
        self.assertTrue(self.store.reserve_submission('ABC123', '.76', '2', '2'))
        self.store.set('ABC123', charged_usd='1.25')
        self.store.set_if_status('ABC123', 'submitting', status='refunded', charged_usd='0')
        self.assertEqual(self.store.get('ABC123')['charged_usd'], '0')
        self.assertEqual(self.store.get('ABC123')['peak_charged_usd'], '1.25')
        self.assertEqual(self.store.today_spend(), Decimal('1.25'))
        again = Store(self.store.path)
        self.assertEqual(again.today_spend(), Decimal('1.25'))

    def test_concurrent_charge_updates_preserve_largest_observed(self):
        self.add('ABC123', 'preparing')
        self.assertTrue(self.store.reserve_submission('ABC123', '.76', '2', '2'))
        second = Store(self.store.path)
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda entry: entry[0].set('ABC123', charged_usd=entry[1]),
                          ((self.store, '1.25'), (second, '0'))))
        self.assertEqual(self.store.today_spend(), Decimal('1.25'))

    def test_nonlive_origin_cannot_reserve_even_after_ready_claim(self):
        for mode in ('dry_run', 'legacy'):
            oid = 'MODE' + mode.replace('_', '')
            self.store.insert_order(oid, '1', '2', 'buyer', 'lot', 50, 1, '80', captured_mode=mode)
            self.store.set(oid, status='preparing')
            self.assertFalse(self.store.reserve_submission(oid, '.76', '1', '1'))
        self.assertEqual(self.store.today_spend(), Decimal(0))

    def test_capture_origin_persists_and_legacy_upgrade_blocks_old_queue(self):
        self.store.insert_order('DRY123', '1', '2', 'buyer', 'lot', 50, 1, '80', captured_mode='dry_run')
        self.assertEqual(Store(self.store.path).get('DRY123')['captured_mode'], 'dry_run')
        with self.store.conn() as c:
            c.execute('ALTER TABLE orders DROP COLUMN captured_mode')
        upgraded = Store(self.store.path)
        self.assertEqual(upgraded.get('DRY123')['captured_mode'], 'legacy')
        self.assertEqual(upgraded.get('DRY123')['status'], 'needs_review')

    def test_capture_origin_cannot_be_overwritten(self):
        self.add('ABC123')
        with self.assertRaises(ValueError):
            self.store.set('ABC123', captured_mode='dry_run')

    def test_actual_undercharge_does_not_release_reserved_budget(self):
        self.add('ABC123', 'preparing')
        self.assertTrue(self.store.reserve_submission('ABC123', '.76', '1', '1'))
        self.store.set('ABC123', charged_usd='.50')
        self.assertEqual(self.store.today_spend(), Decimal('.76'))

    def test_pending_poll_rotates_and_excludes_review_without_uuid(self):
        for number in range(25):
            self.add('REV%03d' % number, 'needs_review')
            self.add('PEN%03d' % number, 'supplier_pending', 'uuid-%03d' % number)
        first = self.store.pending_rows(20)
        second = self.store.pending_rows(20)
        self.assertTrue(all(row['supplier_uuid'] for row in first + second))
        self.assertEqual(len({row['id'] for row in first + second}), 25)

    def test_completed_notifications_ignore_already_sent_rows(self):
        for number in range(25):
            oid = 'DONE%03d' % number
            self.add(oid, 'completed', 'uuid-%03d' % number)
            self.store.set(oid, buyer_notified=1)
        self.add('MISSED', 'completed', 'uuid-missed')
        self.assertEqual([row['id'] for row in self.store.unnotified_completed()], ['MISSED'])

    def test_recovery_does_not_stop_at_1000_rows(self):
        self.add('TEMPLATE', 'preparing')
        with self.store.conn() as c:
            c.execute('BEGIN IMMEDIATE')
            c.executemany("""INSERT INTO orders
                (id,buyer_id,chat_id,buyer_name,description,stars,amount,price_seen,status,external_id)
                VALUES (?,'1','2','buyer','lot',50,1,'80','preparing',?)""",
                          [('PRE%04d' % number, 'funpay-PRE%04d' % number) for number in range(1001)])
            c.execute('COMMIT')
        self.assertEqual(len(self.store.recover_interrupted()), 1002)
        self.assertEqual(self.store.counts(), {'needs_review': 1002})


if __name__ == '__main__':
    unittest.main()
