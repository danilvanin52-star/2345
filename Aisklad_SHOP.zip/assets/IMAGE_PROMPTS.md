# Aisklad SHOP — изображения меню

Создано 26 октября 2026 года встроенным `image_gen` по одному отдельному запросу на каждый баннер. Промпты и оригиналы сохранены; CLI и внешние API-ключи не использовались.

Все изображения оригинальные: темно-синяя студия, стекло, фиолетовый металл, мятные акценты, крупная русская типографика. Баннеры предназначены для Telegram `sendPhoto`; заголовки просмотрены после генерации. `product.png` — запасная иллюстрация товара, когда поставщик не дал подходящую обложку. Изображения не изображают реальный товар, код активации или статус доставки.

## home.png

```text
Use case: stylized-concept.
Asset type: premium original hero banner for the Telegram digital-goods store Aisklad SHOP, home menu, landscape 16:9.
Scene/backdrop: deep midnight navy #080E20 seamless studio with a subtle dark violet halo and generous clean space. Subject: a beautifully composed sculptural shopping bag made of frosted smoke glass, a satin violet game controller, two ivory gift cards with abstract mint circles, and a small luminous mint star arranged as a confident premium product still life. Original objects, realistic bevels, high-end 3D editorial art direction, not a busy collage.
Composition: generous margins, bold clean white typography on the left half, hero objects arranged mostly on the right half with breathing room; mobile readable. Mint accent line and restrained violet caustics, cinematic softbox lighting, refined details, soft grounding shadows.
Text verbatim, exactly only: "Aisklad SHOP" large elegant bold modern sans-serif. Small eyebrow above it exactly "ТВОЙ ЦИФРОВОЙ МИР". No other text.
Constraints: immaculate premium branded illustration, no UI buttons or fake interfaces, no people, no company logos, no game characters, no watermark, no illegible microtext. Full opaque background.
```

## catalog.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: three sculptural floating frosted-glass rounded tiles displaying an original gamepad silhouette, a mint five-point star, and a ribboned gift card, arranged in an elegant ascending fan. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Каталог" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## search.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a beautiful sculptural magnifying glass with a violet anodized rim and a clear glass lens focusing a luminous mint four-point sparkle; two tiny abstract tiles add depth. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Поиск" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## favorites.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a large floating heart sculpted from translucent violet glass, softly illuminated mint edges, beside two ivory digital collectible cards with subtle star embossing. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Избранное" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## cart.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a delightful premium shopping cart sculpted from thick clear glass and satin violet metal with two ivory digital cards and a mint star inside; dynamic but orderly still life. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Корзина" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## checkout.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a satin violet gift box open just slightly with a softly glowing mint orb above it, elegant frosted glass checkmark seal on the side, original embossed shapes with no digits or financial institution logos. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Оформление" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## orders.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: two elegantly stacked translucent violet order cards with embossed mint completion checkmarks, an original small wrapped digital gift and a subtle tiny glass star beside them. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Мои покупки" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## profile.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a sculptural minimal circular avatar medallion in frosted violet glass, mint rim light, elegant abstract silhouette without facial features, with a small ivory membership card standing beside it. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Профиль" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## help.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a luxurious satin violet support headset with thick mint ear cushions, a small floating smoke-glass speech bubble with a single mint question mark shape, friendly refined still life. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Помощь" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## product.png

```text
Use case: stylized-concept. Asset type: landscape 16:9 Telegram menu header for premium digital-goods store Aisklad SHOP. Create one standalone polished coordinated branded banner. Midnight navy #080E20 seamless studio, subtle dark violet halo, restrained electric mint and violet highlights, white typography, soft grounding shadows, immaculate photoreal 3D product illustration. Subject: a single beautifully crafted original ivory digital gift card with a satin violet ribbon and a mint geometric star embossed in its center, a small soft glass orb for depth, timeless premium digital product fallback. Composition: clean generous negative space on the left 48%, hero objects on the right, legible at mobile size, safe margins. Exactly text "Aisklad SHOP" as small white eyebrow upper left and "Твой цифровой товар" as large bold white modern sans-serif heading below, with short mint accent line. No other text. Elegant softbox lighting, realistic bevels, frosted glass and satin anodized surfaces. Avoid UI screenshots, buttons, company/game logos, characters, money claims, tiny text, watermarks, clutter. Full opaque background.
```

## Дополнение 0.13.1 — 27 октября 2026 года

Два отдельных встроенных запроса image_gen: экран помощника и рекламный баннер магазина. Оба изображения 1672×941 PNG с непрозрачным фоном, меньше 2 МБ каждый. Существующие десять изображений сохранены без изменений. Новые баннеры просмотрены после генерации: написание заголовков, читаемость, композиция и единый navy/mint/violet стиль проверены. Оригиналы генераций сохранены; в публичном manifest приведены только имена файлов, без персональных абсолютных путей.

### assistant.png

Назначение: меню «Умный помощник», оригинальная стеклянная сфера в орбитальной лампе.

```text
Use case: stylized-concept.
Asset type: premium original landscape 16:9 Telegram bot menu banner for digital-goods store Aisklad SHOP, exact section "Умный помощник".
Primary request: a high-end cinematic editorial 3D still life suggesting friendly helpful guidance and product discovery. A luminous mint glass orb inside an elegant open satin-violet orbital lamp structure, tiny floating original glass sparkle shapes and a single translucent speech-bubble tile. Beautiful material thickness, subtle refraction and soft shadows; friendly and sophisticated, absolutely no humanoid robot or third-party AI logos.
Scene/backdrop: seamless deep midnight navy #080E20 studio, subtle dark violet halo, restrained electric mint and violet highlights, consistent branded gallery style.
Composition: wide 16:9, generous margins and negative space left half for bold mobile-readable typography, sculptural scene on right, balanced uncluttered silhouette.
Text verbatim: small white eyebrow "Aisklad SHOP"; large clean white modern sans-serif heading "Умный помощник", line break between the two words allowed. Short mint accent line. No other text.
Avoid: UI buttons, screenshots, tiny text, watermarks, copyrighted characters, real company marks, excessive neon, dense collage, misleading claims. Full opaque background.
```

### about.png

Назначение: рекламная заставка/описание перед запуском магазина; точный текст «Aisklad SHOP» и «Игры • Пополнения • Подарки».

```text
Use case: ads-marketing.
Asset type: premium original landscape 16:9 advertising / onboarding photo for the Telegram digital-goods store Aisklad SHOP, visible before starting the bot. Build a beautifully polished campaign image matching a midnight-navy, frosted-glass, satin-violet, electric-mint brand.
Scene/backdrop: deep midnight navy #080E20 seamless studio with restrained violet halo and a cinematic reflective floor. Subject: elegant original violet game controller, ivory ribboned digital gift cards, luminous mint star, and a beautiful sculptural glass shopping bag grouped as a cohesive premium store still life on the right. Strong material craft, rounded bevels, softbox studio lighting, sophisticated and welcoming, clear silhouette, not a cluttered collage.
Composition: wide 16:9, generous safe margins, readable even as a mobile thumbnail; large clean white bold brand lettering on the left half and a single clear subtitle beneath, product scene on right, subtle mint accent line, premium editorial art direction.
Exact text only: "Aisklad SHOP" as the prominent brand title, with optional line break between words. Below it exactly "Игры • Пополнения • Подарки" in readable medium white modern sans-serif. No tiny text or other words.
Constraints: original digital store objects only, no fake game logos, no copyrighted characters, no app screenshot or buttons, no bank logos, no promises of instant delivery, no prices or discount percentages, no watermark. Full opaque background.
```


